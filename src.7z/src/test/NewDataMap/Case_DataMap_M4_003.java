package test.NewDataMap;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M4_003 extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M4_003
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200211单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200211", true, "测试用例Case_DataMap_M4_003");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200211", "", "");
		MainContainer.selectTab(1);	
						
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull8,000.00nullnullshenzhen 深圳nullnullnull");
		GridUtil.checkGridRowValue("detail", 2, "finednull700.00nullnulltianjin 天津nullnullnull");
		
		//勾选第一条单据明细
		Grid.element("detail").selectRowClick("选择",1);
		GridUtil.checkRowSelected(Grid.element("detail"), "选择", true, 1);
		ToolBar.element("ToolBar1").click("Map_17");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("optKey1");
		DialogUtil.checkQueryBoxDialog();
	
		
		//换页
		Grid.element("Grid1").pageClick(2);
		
		//勾选查询的三条明细
		Grid.element("Grid1").selectRowClick("选择",5);
		Grid.element("Grid1").celComboClick("映射边类型", 5).comboItemClick("Map_17");
		Grid.element("Grid1").selectRowClick("选择",7);
		Grid.element("Grid1").celComboClick("映射边类型", 7).comboItemClick("DataMap_17_1");
		Grid.element("Grid1").selectRowClick("选择",11);
		Grid.element("Grid1").celComboClick("映射边类型",11).comboItemClick("DataMap_17_1");
		DialogUtil.checkQueryBoxDialog();
		QueryBoxDialog.element().fieldPushClick();
		
		
		
		//修改入库数量
		MainContainer.selectTab(2);
		Grid.element("detail").cellDbInput("入库数量", 1, "1000");
		Grid.element("detail").cellDbInput("入库数量", 2, "10");
		Grid.element("detail").cellDbInput("入库数量", 3, "100");
		Grid.element("detail").cellDbInput("入库数量", 4, "99");
		ToolBar.element("ToolBar1").click("Save");
		//检查明细是否存在
		
		GridUtil.checkGridRowValue("detail", 1, "finedfalse10.00nullnulltianjin 天津nullMap_17");
		GridUtil.checkGridRowValue("detail", 2, "finedfalse100.00nullnulltianjin 天津nullDataMap_17_1");
		GridUtil.checkGridRowValue("detail", 3, "finedfalse99.00nullnullshanghai 上海nullDataMap_17_1");
		GridUtil.checkGridRowValue("detail", 4, "finedfalse1,000.00nullnullshenzhen 深圳nullMap_17");
		MainContainer.closeAllTab();		
		System.out.println("============================================================");
	}
	
}
		