package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M2_008 extends AbstractTestScript {
	public void  run(){
		//测试用例Case_DataMap_M2_008
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_01中100104单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100104", true, "测试用例Case_DataMap_M2_008");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100104", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件的值
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100104", "测试用例Case_DataMap_M2_008");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M2_008");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "600.00", "测试用例Case_DataMap_M2_008");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Pirce"), "3.00", "测试用例Case_DataMap_M2_008");
		DictUtil.checkInputValue("Warehouse", "beijing 北京", "测试用例Case_DataMap_M2_008");
		DictUtil.checkInputValue("Material", "01 电脑", "测试用例Case_DataMap_M2_008");
		
		//检查明细的值
		GridUtil.checkGridRowValue("Grid1", 1, "finednullnull600.003.00nullbeijing 北京01 电脑nullnullnull");
				
		System.out.println("============================================================");
		
		//勾选单据明细
		Grid.element("Grid1").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		ToolBar.element("ToolBar1").click("Map04");
		MainContainer.selectTab(2);
		
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		//重新打开目标单
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_001View").dblClick();
		MainContainer.selectTab(0);
				
		//检查目标单1中100104单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100104", true, "测试用例Case_DataMap_M2_008");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100104", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件的值
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100104", "测试用例Case_DataMap_M2_008");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M2_008");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "600.00", "测试用例Case_DataMap_M2_008");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Pirce"), "3.00", "测试用例Case_DataMap_M2_008");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Total"), "1,800.00", "测试用例Case_DataMap_M2_008");
		DictUtil.checkInputValue("Warehouse", "beijing 北京", "测试用例Case_DataMap_M2_008");
		DictUtil.checkInputValue("Material", "01 电脑", "测试用例Case_DataMap_M2_008");
		
		//检查明细的值
		GridUtil.checkGridRowValue("Grid1", 1, "finednullnull600.003.001,800.00beijing 北京01 电脑null常量_04Map_04");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
