package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M2_010  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M2_010
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200201单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200202", true, "测试用例Case_DataMap_M2_010");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200202", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200202", "测试用例Case_DataMap_010");	
			
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull100.00nullnullnullnullnullnull");
				
		
		//勾选单据明细
		Grid.element("detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("detail"), "选择", true);
				
		System.out.println("============================================================");
		ToolBar.element("ToolBar1").click("Map_08");
		MainContainer.selectTab(2);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200202", "测试用例Case_DataMap_010");	
						
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finedfalse100.00nullnullnullnullMap_08");
		
		//修改明细入库数量为40
		Grid.element("detail").cellDbInput("入库数量", 1, "40");
		
		//点击保存
		ToolBar.element("ToolBar1").click("Save");
		GridUtil.checkGridRowValue("detail", 1, "finedfalse40.00nullnullnullnullMap_08");
		MainContainer.closeAllTab();
		
		//查看源单
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200201单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200202", true, "测试用例Case_DataMap_M2_010");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200202", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200202", "测试用例Case_DataMap_010");
		NumberEditorUtil.checkInputValue(NumberEditor.element("FeedBack_Amount"), "40.00", "测试用例Case_DataMap_M2_010");
			
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull100.00nullnullnullnullnull1");
				
		//勾选单据明细
		Grid.element("detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("detail"), "选择", true);
						
		System.out.println("============================================================");
		ToolBar.element("ToolBar1").click("Map_08");
		MainContainer.selectTab(2);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200202", "测试用例Case_DataMap_010");
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finedfalse60.00nullnullnullnullMap_08");
		
		//点击保存
		ToolBar.element("ToolBar1").click("Save");
		GridUtil.checkGridRowValue("detail", 1, "finedfalse60.00nullnullnullnullMap_08");
		MainContainer.closeAllTab();
		
		//查看源单
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
				
		//检查源单_02中200201单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200202", true, "测试用例Case_DataMap_M2_010");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200202", "", "");
		MainContainer.selectTab(1);
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200202", "测试用例Case_DataMap_010");
		NumberEditorUtil.checkInputValue(NumberEditor.element("FeedBack_Amount"), "100.00", "测试用例Case_DataMap_M2_010");
					
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull100.00nullnullnullnullnull2");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
