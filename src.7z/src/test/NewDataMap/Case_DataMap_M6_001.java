package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M6_001 extends AbstractTestScript {
	public void run(){
		//测试用例Case_DataMap_M6_001
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单1中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100117", true, "测试用例Case_DataMap_M6_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100117", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100117", "测试用例Case_DataMap_M6_001");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M6_001");
						
		//检查明细
		GridUtil.checkGridRowValue("Grid1", 1, "finednullA10,000.00nullnullbeijing 北京nullnullnullnull");
		
		//修改状态为审批通过
		ToolBar.element("ToolBar1").click("Edit");
		ComboBox.element("Status").dropDownClick().itemClick("审批通过").getText();
		ToolBar.element("ToolBar1").click("Save");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "审批通过", "测试用例Case_DataMap_M6_001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开目标单1
		MenuEntry.element("DataMap/CustomBill/DataMap_001View").dblClick();
		MainContainer.selectTab(0);
				
		//检查目标单1中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100117", true, "测试用例Case_DataMap_M6_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100117", "", "");
		MainContainer.selectTab(1);	
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100117", "测试用例Case_DataMap_M6_001");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "审批通过", "测试用例Case_DataMap_M6_001");
								
		//检查明细
		GridUtil.checkGridRowValue("Grid1", 1, "finednullA10,000.00nullnullbeijing 北京nullnullnullMap_16");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
