package test.NewDataMap;


import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DataMap_M6_004 extends AbstractTestScript {
	public void run() {
		//测试用例CASE_DataMap_M6_004
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_04View").dblClick();
		MainContainer.selectTab(0);
		
		
	   	//点击【MapEx】
    	ToolBarButton.element("MapEx").click();
    	MainContainer.selectTab(1);
    	ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		//重新打开目标单
		MenuEntry.element("DataMap/CustomBill/DataMap_004View").dblClick();
		MainContainer.selectTab(0);
	
		//检查目标单4中300301单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "300301", true, "测试用例CASE_DataMap_M6_004");
		//双击打开
		ListView.element("list").dbClick("单据编号", "300301", "", "");
		MainContainer.selectTab(1);
		
		//检查明细的值
		GridUtil.checkGridRowValue("detail", 1, "finednull100.00beijing 北京01 电脑null");
		GridUtil.checkGridRowValue("detail", 2, "finednull200.00shanghai 上海02 手机null");
		MainContainer.closeAllTab();
	}

}
