package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M7_002  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M7_002
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_03View").dblClick();
		MainContainer.selectTab(0);
				
		//检查源单3中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "300301", true, "测试用例Case_DataMap_M7_002");
		//双击打开
		ListView.element("list").dbClick("单据编号", "300301", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "300301", "测试用例Case_DataMap_M7_002");
		DatePickerUtil.checkInputValue(DatePicker.element("BillDate"), "2018-04-03 00:00:00", "测试用例Case_DataMap_M7_002");
		
		//点击下推
		ToolBar.element("ToolBar1").click("optKey1");
		MainContainer.selectTab(2);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "300301", "测试用例Case_DataMap_M7_002");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "Tue Apr 03 00:00:00 CST 2018", "测试用例Case_DataMap_M7_002");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
		
		
		
		
	}

}
