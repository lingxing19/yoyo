package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;


public class Case_DataMap_M2_011 extends AbstractTestScript {
	public void run(){
		//测试用例Case_DataMap_M2_011
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
				
		//检查源单_02中200201单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200203", true, "测试用例Case_DataMap_M2_011");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200203", "", "");
		MainContainer.selectTab(1); 
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200203", "测试用例Case_DataMap_011");	
					
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullnullnullnullnull");
		
		//勾选单据明细
		Grid.element("detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("detail"), "选择", true);
						
		System.out.println("============================================================");
		ToolBar.element("ToolBar1").click("Map_09");
		MainContainer.selectTab(2);
		
		//修改入库数量为200
		Grid.element("detail").cellDbInput("入库数量", 1, "200");
		ToolBar.element("ToolBar1").click("Save");
		GridUtil.checkGridRowValue("detail", 1, "finedfalse200.00nullnullnullnullMap_09");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//查看源单反填200
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200203单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200203", true, "测试用例Case_DataMap_M2_011");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200203", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200203", "测试用例Case_DataMap_011");
		
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullnullnull200.001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开目标单200203
		MenuEntry.element("DataMap/CustomBill/DataMap_002View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单中200203的存在
		ListViewUtil.checkFormExsit("list","单据编号" , "200203", true, "测试用例Case_DataMap_011");
		ListView.element("list").dbClick("单据编号", "200203", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200203", "测试用例Case_DataMap_011");	
							
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull200.00nullnullnullnullMap_09");
		
		//修改入库数量为300
		ToolBar.element("ToolBar1").click("Edit");
		Grid.element("detail").cellDbInput("入库数量", 1, "300");
		ToolBar.element("ToolBar1").click("Save");
		GridUtil.checkGridRowValue("detail", 1, "finednull300.00nullnullnullnullMap_09");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//查看源单反填300
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
				
		//检查源单_02中200203单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200203", true, "测试用例Case_DataMap_M2_011");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200203", "", "");
		MainContainer.selectTab(1);
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200203", "测试用例Case_DataMap_011");
				
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullnullnull300.001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
		//打开目标单200203
		MenuEntry.element("DataMap/CustomBill/DataMap_002View").dblClick();
		MainContainer.selectTab(0);
				
		//检查目标单中200203的存在
		ListViewUtil.checkFormExsit("list","单据编号" , "200203", true, "测试用例Case_DataMap_011");
		ListView.element("list").dbClick("单据编号", "200203", "", "");
		MainContainer.selectTab(1);
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200203", "测试用例Case_DataMap_011");	
									
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull300.00nullnullnullnullMap_09");
				
		//修改入库数量为100
		ToolBar.element("ToolBar1").click("Edit");
		Grid.element("detail").cellDbInput("入库数量", 1, "100");
		ToolBar.element("ToolBar1").click("Save");
		GridUtil.checkGridRowValue("detail", 1, "finednull100.00nullnullnullnullMap_09");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//查看源单反填100
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
						
		//检查源单_02中200203单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200203", true, "测试用例Case_DataMap_M2_011");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200203", "", "");
		MainContainer.selectTab(1);
						
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200203", "测试用例Case_DataMap_011");
						
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullnullnull100.001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
		
	}
}
