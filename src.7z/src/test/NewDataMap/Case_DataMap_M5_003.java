package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M5_003  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M5_003
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_01中100116单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100116", true, "测试用例Case_DataMap_M5_003");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100116", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100116", "测试用例Case_DataMap_M5_003");	
									
		//检查明细
		GridUtil.checkGridRowValue("Grid1", 1, "finednullnull1,000.00nullnullnullnullnullnullnull");
		GridUtil.checkGridRowValue("Grid1", 2, "finednullnull100.00nullnullnullnullnullnullnull");
		
		//勾选单据明细
		Grid.element("Grid1").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		ToolBar.element("ToolBar1").click("Map_27");
		MainContainer.selectTab(2);
		//编辑目标单1编号为：100116 
		TextEditor.element("NO").input("100116");
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		//重新打开目标单
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_001View").dblClick();
		MainContainer.selectTab(0);
				
		//检查目标单1中100116单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100116", true, "测试用例Case_DataMap_M5_003");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100116", "", "");
		MainContainer.selectTab(1);
		
		//检查明细
		GridUtil.checkGridRowValue("Grid1", 1, "finednullnullnullnullnullnullnullnullnullnull");
		GridUtil.checkGridRowValue("Grid1", 2, "finednullnull100.00nullnullnullnullnullnullnull");	
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}
	
	

}
