package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M2_004 extends AbstractTestScript {
		public void run(){
			//测试用例Case_DataMap_M2_004
			MenuEntry.element("DataMap/CustomBill").click();
			MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
			MainContainer.selectTab(0);
			
			ListViewUtil.checkFormExsit("list", "单据编号", "100102", true, "测试用例Case_DataMap_M2_004");
			
			ListView.element("list").dbClick("单据编号", "100102", "", "");
			MainContainer.selectTab(1);
			
			//检查头控件的值
			TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100102", "测试用例Case_DataMap_M2_004");
			ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M2_004");
			
			//检查明细的值
			GridUtil.checkGridRowValue("Grid1", 1, "finednullnull100.00nullnullnullnullnullnullnull");
			
			System.out.println("============================================================");
			
			//勾选单据明细
			Grid.element("Grid1").selectAllClick("选择");
			//校验明细行是否全勾选
			GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
			ToolBar.element("ToolBar1").click("Map_01");
			MainContainer.selectTab(2);
			
			Grid.element("Grid1").cellDbInput("数量", 1, "200");
			
			ToolBar.element("ToolBar1").click("Save");
			DialogUtil.checkShowErrorDialog("映射数量已超量");
			ErrorDialog.element().close();
			
			Grid.element("Grid1").cellClear("数量",1);
			Grid.element("Grid1").cellDbInput("数量", 1, "90");
			ToolBar.element("ToolBar1").click("Save");
			
			GridUtil.checkGridRowValue("Grid1", 1, "finedfalsenull90.00nullnullnullnullnullnullMap_02");
			
			MainContainer.closeAllTab();
			
			System.out.println("============================================================");
			
			MenuEntry.element("DataMap/CustomBill").click();
			MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
			MainContainer.selectTab(0);
			
			ListViewUtil.checkFormExsit("list", "单据编号", "100102", true, "测试用例Case_DataMap_M2_004");
			
			ListView.element("list").dbClick("单据编号", "100102", "", "");
			MainContainer.selectTab(1);
			
			
			System.out.println("============================================================");
			
			//勾选单据明细
			Grid.element("Grid1").selectAllClick("选择");
			//校验明细行是否全勾选
			GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
			
			ToolBar.element("ToolBar1").click("Map_01");
			MainContainer.selectTab(2);
			
			GridUtil.checkGridRowValue("Grid1", 1, "finedfalsenull10.00nullnullnullnullnullnullMap_02");
			
			ToolBar.element("ToolBar1").click("Save");
			MainContainer.closeAllTab();
			
			System.out.println("============================================================");
			
			MenuEntry.element("DataMap/CustomBill").click();
			MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
			MainContainer.selectTab(0);
			
			ListViewUtil.checkFormExsit("list", "单据编号", "100102", true, "测试用例Case_DataMap_M2_004");
			
			ListView.element("list").dbClick("单据编号", "100102", "", "");
			MainContainer.selectTab(1);
			
			//勾选单据明细
			Grid.element("Grid1").selectAllClick("选择");
			//校验明细行是否全勾选
			GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
			ToolBar.element("ToolBar1").click("Map_01");
			DialogUtil.checkShowErrorDialog("缺少可映射数据");
			ErrorDialog.element().close();
			MainContainer.closeAllTab();
			
			
			
			
		}
		
	}


