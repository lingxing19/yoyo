package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DataMap_M6_003 extends AbstractTestScript {
	public void run(){
		//测试用例CASE_DataMap_M6_003
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_04View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单4中单据【30303】【30304】【30305】是否存在
		ListViewUtil.checkFormCount("list", "单据编号", "300303", 1, "测试用例CASE_DataMap_M6_003");
    	ListViewUtil.checkFormCount("list", "单据编号", "300304", 1, "测试用例CASE_DataMap_M6_003");
    	ListViewUtil.checkFormCount("list", "单据编号", "300305", 1, "测试用例CASE_DataMap_M6_003");
		
    	//勾选单据【30303】【30304】【30305】
    	ListView.element("list").selectRowClick("column1", 2, 3, 4);
    	ListViewUtil.checkRowSelected(ListView.element("list"), "column1", true, 2, 3, 4);
		
    	//点击【BatchMap】
    	ToolBarButton.element("BatchMap").click();
		MainContainer.closeAllTab();
		
		//打开目标单4
		MenuEntry.element("DataMap/CustomBill/DataMap_004View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单4中单据【30303】【30304】【30305】是否存在
		ListViewUtil.checkFormCount("list", "单据编号", "300303", 1, "测试用例CASE_DataMap_M6_003");
    	ListViewUtil.checkFormCount("list", "单据编号", "300304", 1, "测试用例CASE_DataMap_M6_003");
    	ListViewUtil.checkFormCount("list", "单据编号", "300305", 1, "测试用例CASE_DataMap_M6_003");
		MainContainer.closeAllTab();
		
		
		
		
		
		
		
		
		
		
		
	}
}
