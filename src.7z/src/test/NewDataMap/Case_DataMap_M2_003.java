package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M2_003 extends AbstractTestScript {
	public void run(){
		//测试用例Case_DataMap_M2_003
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_01中100108单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100108", true, "测试用例Case_DataMap_M2_003");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100108", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100108", "测试用例Case_DataMap_M2_003");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M2_003");	
		
		//检查明细
		GridUtil.checkGridRowValue("Grid1", 1, "finednullA200.001.00nullbeijing 北京02 手机2018-01-18nullnull");
		GridUtil.checkGridRowValue("Grid1", 2, "finednullB300.002.00nullshanghai 上海01 电脑2018-03-12nullnull");
		System.out.println("============================================================");
		
		//勾选单据明细
		Grid.element("Grid1").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		ToolBar.element("ToolBar1").click("Map_13");
		MainContainer.selectTab(2);
		AssertUtil.checkEnabled(NumberEditor.element("Amount"), false,"");
		MainContainer.closeAllTab();
		
			
	}

}
