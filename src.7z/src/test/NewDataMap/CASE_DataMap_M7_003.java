package test.NewDataMap;


import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DataMap_M7_003  extends AbstractTestScript{
	public void run(){
		//测试用例CASE_DataMap_M7_003
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_04View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单4中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "300306", true, "测试用例CASE_DataMap_M7_003");
		//双击打开
		ListView.element("list").dbClick("单据编号", "300306", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "300306", "测试用例CASE_DataMap_M7_003");
		
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,100.00shanghai 上海01 电脑");
		GridUtil.checkGridRowValue("detail", 2, "finednull1,200.00beijing 北京02 手机");
		
		//勾选单据明细
		Grid.element("detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("detail"), "选择", true);
		ToolBar.element("ToolBar1").click("optKey1");
		MainContainer.selectTab(2);
		
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		
		//重新打开目标单4=300306
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_004View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单4=300306单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "300306", true, "测试用例CASE_DataMap_M7_003");
			
		//双击打开
		ListView.element("list").dbClick("单据编号", "300306", "", "");
		MainContainer.selectTab(1);	
		
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,100.00shanghai 上海01 电脑21");
		GridUtil.checkGridRowValue("detail", 2, "finednull1,200.00beijing 北京02 手机21");
		MainContainer.closeAllTab();	
		System.out.println("============================================================");
	}

}
