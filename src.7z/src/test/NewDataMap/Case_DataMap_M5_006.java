package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M5_006 extends AbstractTestScript {
	public void run(){
		//测试用例Case_DataMap_M5_006
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_002aView").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单_02中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200205", true, "测试用例Case_DataMap_M5_006");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200205", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200205", "测试用例Case_DataMap_M5_006");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_006");
						
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull50.00nullnullbeijing 北京nullnull");
		GridUtil.checkGridRowValue("detail", 2, "finednull100.00nullnullnullnullnull");
		
		//点击审批
		ToolBar.element("ToolBar1").click("optKey1");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "审批通过", "测试用例Case_DataMap_M5_006");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开源单2
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
				
		//检查源单_02中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200205", true, "测试用例Case_DataMap_M5_006");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200205", "", "");
		MainContainer.selectTab(1);	
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200205", "测试用例Case_DataMap_M5_006");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_006");
								
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull50.00nullnullbeijing 北京null50.001");
		GridUtil.checkGridRowValue("detail", 2, "finednull100.00nullnullnullnull100.001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
	}

}
