package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M7_001  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M7_001
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单2中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200208", true, "测试用例Case_DataMap_M7_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200208", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200208", "测试用例Case_DataMap_M7_001");
										
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullbeijing 北京nullnullnull");
		GridUtil.checkGridRowValue("detail", 2, "finednull100.00nullnullshanghai 上海nullnullnull");
		
		//勾选单据明细
		Grid.element("detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("detail"), "选择", true);
		ToolBar.element("ToolBar1").click("Map_09");
		MainContainer.selectTab(2);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200208", "测试用例Case_DataMap_M7_001");
												
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finedfalse1,000.00nullnullbeijing 北京nullMap_09");
		GridUtil.checkGridRowValue("detail", 2, "finedfalse100.00nullnullshanghai 上海nullMap_09");
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开源单
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单2中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200208", true, "测试用例Case_DataMap_M7_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200208", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200208", "测试用例Case_DataMap_M7_001");
												
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullbeijing 北京null1,000.001");
		GridUtil.checkGridRowValue("detail", 2, "finednull100.00nullnullshanghai 上海null100.001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开目标单2
		MenuEntry.element("DataMap/CustomBill/DataMap_002View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单2中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200208", true, "测试用例Case_DataMap_M7_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200208", "", "");
		MainContainer.selectTab(1);	
		ToolBar.element("ToolBar1").click("Delete");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开源单2
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//双击打开
		ListView.element("list").dbClick("单据编号", "200208", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200208", "测试用例Case_DataMap_M7_001");
														
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullbeijing 北京nullnullnull");
		GridUtil.checkGridRowValue("detail", 2, "finednull100.00nullnullshanghai 上海nullnullnull");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
	}
}
