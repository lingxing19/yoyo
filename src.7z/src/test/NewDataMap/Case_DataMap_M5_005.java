package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M5_005  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M5_005
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_002View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单_02中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200212", true, "测试用例Case_DataMap_M5_005");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200212", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200212", "测试用例Case_DataMap_M5_005");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_005");
				
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull550.00nullnullshanghai 上海nullMap_32");
		GridUtil.checkGridRowValue("detail", 2, "finednull500.00nullnulltianjin 天津nullMap_32");
		GridUtil.checkGridRowValue("detail", 3, "finednull300.00nullnullbeijing 北京nullMap_32");
		
		//点击审批
		ToolBar.element("ToolBar1").click("optKey2");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "审批通过", "测试用例Case_DataMap_M5_005");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开源单2
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200212", true, "测试用例Case_DataMap_M5_005");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200212", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200212", "测试用例Case_DataMap_M5_005");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_005");
						
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull550.00nullnullshanghai 上海null650.002");
		GridUtil.checkGridRowValue("detail", 2, "finednull600.00nullnulltianjin 天津null500.002");
		GridUtil.checkGridRowValue("detail", 3, "finednull300.00nullnullbeijing 北京null305.002");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开目标单02
		MenuEntry.element("DataMap/CustomBill/DataMap_002View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单_02中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200212", true, "测试用例Case_DataMap_M5_005");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200212", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200212", "测试用例Case_DataMap_M5_005");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "审批通过", "测试用例Case_DataMap_M5_005");
				
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull550.00nullnullshanghai 上海nullMap_32");
		GridUtil.checkGridRowValue("detail", 2, "finednull500.00nullnulltianjin 天津nullMap_32");
		GridUtil.checkGridRowValue("detail", 3, "finednull300.00nullnullbeijing 北京nullMap_32");
		
		//点击初始
		ToolBar.element("ToolBar1").click("optKey3");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_005");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开源单2
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
				
		//检查源单_02中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200212", true, "测试用例Case_DataMap_M5_005");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200212", "", "");
		MainContainer.selectTab(1);	
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200212", "测试用例Case_DataMap_M5_005");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_005");
								
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull550.00nullnullshanghai 上海null100.002");
		GridUtil.checkGridRowValue("detail", 2, "finednull600.00nullnulltianjin 天津nullnull2");
		GridUtil.checkGridRowValue("detail", 3, "finednull300.00nullnullbeijing 北京null5.002");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
	}

}
