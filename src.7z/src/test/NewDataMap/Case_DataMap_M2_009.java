package test.NewDataMap;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M2_009 extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M2_009
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200201单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200201", true, "测试用例Case_DataMap_M2_009");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200201", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200201", "测试用例Case_DataMap_M2_009");	
		
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullnullnullnullnull");
		
		//勾选单据明细
		Grid.element("detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("detail"), "选择", true);
		
		System.out.println("============================================================");
		
		ToolBar.element("ToolBar1").click("Map_06");
		MainContainer.selectTab(2);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200201", "测试用例Case_DataMap_M2_009");	
				
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finedfalse1,000.00nullnullnullnullMap_06");
		
		//点击保存
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200201单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200201", true, "测试用例Case_DataMap_M2_009");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200201", "", "");
		MainContainer.selectTab(1);
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200201", "测试用例Case_DataMap_M2_009");	
				
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull1,000.00nullnullnull2.001,000.001");
		
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
		
		
		
		
		
		
		
		
		
	}

}
