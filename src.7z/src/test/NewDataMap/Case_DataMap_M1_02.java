package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M1_02 extends AbstractTestScript {
	public void run(){
		//测试用例Case_DataMap_M1_02
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_01中100111单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100111", true, "测试用例Case_DataMap_M1_02");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100111", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100111", "测试用例Case_DataMap_M1_02");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M1_02");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "800.00", "测试用例Case_DataMap_M1_02");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Pirce"), "8.00", "测试用例Case_DataMap_M1_02");
		DictUtil.checkInputValue("Warehouse", "beijing 北京", "测试用例Case_DataMap_M1_02");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2018-01-09", "测试用例Case_DataMap_M1_02	");
		
		System.out.println("============================================================");
		
		ToolBar.element("ToolBar1").click("Map_19");
		MainContainer.selectTab(2);
		
		GridUtil.checkGridRowValue("Grid1", 1, "finedfalsenull800.008.006,400.00beijing 北京null2018-01-092Map_19");
		//编辑目标单1编号为：100111 
		TextEditor.element("NO").input("100111");
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		ListViewUtil.checkFormExsit("list", "单据编号", "100111", true, "测试用例Case_DataMap_M1_02");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100111", "", "");
		System.out.println("============================================================");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100111", "测试用例Case_DataMap_M1_02");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M1_02");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "800.00", "测试用例Case_DataMap_M1_02");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Pirce"), "8.00", "测试用例Case_DataMap_M1_02");
		DictUtil.checkInputValue("Warehouse", "beijing 北京", "测试用例Case_DataMap_M1_02");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2018-01-09", "测试用例Case_DataMap_M1_02");
		NumberEditorUtil.checkInputValue(NumberEditor.element("FeedBack"), "2.00", "测试用例Case_DataMap_M1_02");
		NumberEditorUtil.checkInputValue(NumberEditor.element("FeedBack_Amount"), "800.00", "测试用例Case_DataMap_M1_02");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
	}

}
