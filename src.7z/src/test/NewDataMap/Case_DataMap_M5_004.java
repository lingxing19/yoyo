package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M5_004 extends AbstractTestScript {
	public void run(){
		//测试用例Case_DataMap_M5_004
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_002View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单_02中200204单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200204", true, "测试用例Case_DataMap_M5_004");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200204", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200204", "测试用例Case_DataMap_M5_004");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_004");
		
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull10,000.00nullnullnullnullMap_15");
		
		ToolBar.element("ToolBar1").click("optKey2");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "审批通过", "测试用例Case_DataMap_M5_004");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开源单2
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200204单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200204", true, "测试用例Case_DataMap_M5_004");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200204", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "200204", "测试用例Case_DataMap_M5_004");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M5_004");
		
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull10,000.00nullnullnullnull10,000.001");
		MainContainer.closeAllTab();
	}

}
