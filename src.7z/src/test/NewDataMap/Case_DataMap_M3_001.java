package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M3_001 extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M3_001
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
	
		//检查源单_01中100112单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100112", true, "测试用例Case_DataMap_M3_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100112", "", "");
		MainContainer.selectTab(1);	
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100112", "测试用例Case_DataMap_M3_001");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M3_001");
		
		//检查明细
		GridUtil.checkGridRowValue("Grid1", 1, "finednullA1,000.001.001,000.00beijing 北京02 手机2018-01-19nullnull");
		GridUtil.checkGridRowValue("Grid1", 2, "finednullB2,000.001.002,000.00shenzhen 深圳01 电脑2018-03-12nullnull");
		System.out.println("============================================================");
		
		//勾选单据明细
		Grid.element("Grid1").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		ToolBar.element("ToolBar1").click("Map_20");
		MainContainer.selectTab(2);
		//编辑目标单1编号为：100112 
		TextEditor.element("NO").input("100112");
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		MenuEntry.element("DataMap/CustomBill/DataMap_001View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单1中100112单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100112", true, "测试用例Case_DataMap_M3_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100112", "", "");
		MainContainer.selectTab(1);	
		//检查明细
		GridUtil.checkGridRowValue("Grid1", 1, "finednullA1,000.001.001,000.00beijing 北京null2018-01-19常量Map_20");
		GridUtil.checkGridRowValue("Grid1", 2, "finednullB2,000.001.002,000.00shenzhen 深圳null2018-03-12常量Map_20");	
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
		
		
		
		
		
		
		
	}

}
