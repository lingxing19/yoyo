package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M4_001  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M4_001
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_02View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_02中200209单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "200209", true, "测试用例Case_DataMap_M4_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "200209", "", "");
		MainContainer.selectTab(1);	
		
						
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull10,000.00nullnullshanghai 上海nullnullnull");
		GridUtil.checkGridRowValue("detail", 2, "finednull1,000.00nullnullbeijing 北京nullnullnull");
		GridUtil.checkGridRowValue("detail", 3, "finednull100.00nullnulltianjin 天津nullnullnull");
		
		//勾选第一条单据明细
		Grid.element("detail").selectRowClick("选择",1);
		GridUtil.checkRowSelected(Grid.element("detail"), "选择", true, 1);
		ToolBar.element("ToolBar1").click("Map_17");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("optKey1");
		DialogUtil.checkQueryBoxDialog();
		
		
		//勾选单据明细
		Grid.element("Grid1").pageClick(1);
		Grid.element("Grid1").selectRowClick("选择",12);
		//换页
		Grid.element("Grid1").pageClick(2);
		Grid.element("Grid1").selectRowClick("选择",1);
		Grid.element("Grid1").selectRowClick("选择",8);
		DialogUtil.checkQueryBoxDialog();
		QueryBoxDialog.element().constantPushClick();
		
		//修改入库数量
		MainContainer.selectTab(2);
		Grid.element("detail").cellDbInput("入库数量", 1, "5000");
		Grid.element("detail").cellDbInput("入库数量", 2, "500");
		Grid.element("detail").cellDbInput("入库数量", 3, "50");
		Grid.element("detail").cellDbInput("入库数量", 4, "5");
		ToolBar.element("ToolBar1").click("Save");
		
		
		GridUtil.checkGridRowValue("detail", 1, "finedfalse500.00nullnullbeijing 北京nullMap_17");
		GridUtil.checkGridRowValue("detail", 2, "finedfalse50.00nullnulltianjin 天津nullMap_17");
		GridUtil.checkGridRowValue("detail", 3, "finedfalse5.00nullnullbeijing 北京nullMap_17");
		GridUtil.checkGridRowValue("detail", 4, "finedfalse5,000.00nullnullshanghai 上海nullMap_17");	
		MainContainer.closeAllTab();
		System.out.println("============================================================");
	}

}
