package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M2_005 extends AbstractTestScript {
	public void run(){
		//测试用例Case_DataMap_M2_005
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_01中100106单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100106", true, "测试用例Case_DataMap_M2_005");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100106", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件的值
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100106", "测试用例Case_DataMap_M2_005");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M2_005");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "1,000.00", "测试用例Case_DataMap_M2_005");
		
		//检查明细的值
		GridUtil.checkGridRowValue("Grid1", 1, "finednullnull99.00nullnullnullnullnullnullnull");
		
		System.out.println("============================================================");
		
		//勾选单据明细
		Grid.element("Grid1").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		ToolBar.element("ToolBar1").click("Map_11");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_01中100106单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100106", true, "测试用例Case_DataMap_M2_005");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100106", "", "");
		MainContainer.selectTab(1);
		
		ToolBar.element("ToolBar1").click("Edit");
		
		Grid.element("Grid1").cellDbInput("入库数量", 1, "1000");
		
		ToolBar.element("ToolBar1").click("Save");
		
		GridUtil.checkGridRowValue("Grid1", 1, "finednullnull1,000.00nullnullnullnullnullnullnull");
		
		System.out.println("============================================================");
		
		//勾选单据明细
		Grid.element("Grid1").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		ToolBar.element("ToolBar1").click("Map_11");
		MainContainer.selectTab(2);
		
		ToolBar.element("ToolBar1").click("Save");
		GridUtil.checkGridRowValue("Grid1", 1, "finedfalsenull1,000.00nullnullnullnullnullnullMap_11");
		
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		
		
		
		
		
		
		
	}

}
