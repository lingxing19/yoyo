package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMap_M1_001  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DataMap_M1_001
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
				
		//检查源单_01中100110单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100110", true, "测试用例Case_DataMap_M1_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100110", "", "");
		MainContainer.selectTab(1);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100110", "测试用例Case_DataMap_M1_001");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M1_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "600.00", "测试用例Case_DataMap_M1_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Pirce"), "12.00", "测试用例Case_DataMap_M1_001");
		
		System.out.println("============================================================");
		
		ToolBar.element("ToolBar1").click("Map_18");
		MainContainer.selectTab(2);
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "100110", "测试用例Case_DataMap_M1_001");
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "初始", "测试用例Case_DataMap_M1_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "600.00", "测试用例Case_DataMap_M1_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Pirce"), "12.00", "测试用例Case_DataMap_M1_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("Total"), "7,200.00", "测试用例Case_DataMap_M1_001");
		TextEditorUtil.checkInputValue(TextEditor.element("Map_04"), "Map_18常量", "测试用例Case_DataMap_M1_001");
		
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.closeAllTab();
		
		MenuEntry.element("DataMap/CustomBill/DataMap_01View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单_01中100110单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100110", true, "测试用例Case_DataMap_M1_001");
		//双击打开
		ListView.element("list").dbClick("单据编号", "100110", "", "");
		MainContainer.selectTab(1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("Amount"), "600.00", "测试用例Case_DataMap_M1_01");
		NumberEditorUtil.checkInputValue(NumberEditor.element("FeedBack"), "2.00", "测试用例Case_DataMap_M1_01");
		NumberEditorUtil.checkInputValue(NumberEditor.element("FeedBack_Amount"), "600.00", "测试用例Case_DataMap_M1_001");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		
		
		
		
		
		
		
		
		
		
	}

}
