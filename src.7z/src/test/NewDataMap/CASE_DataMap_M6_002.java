package test.NewDataMap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DataMap_M6_002 extends AbstractTestScript {
	public void run(){
		//测试用例CASE_DataMap_M6_002
		MenuEntry.element("DataMap/CustomBill").click();
		MenuEntry.element("DataMap/CustomBill/DataMap_04View").dblClick();
		MainContainer.selectTab(0);
		
		//检查源单4中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "300302", true, "测试用例CASE_DataMap_M6_002");
		//双击打开
		ListView.element("list").dbClick("单据编号", "300302", "", "");
		MainContainer.selectTab(1);	
				
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "300302", "测试用例CASE_DataMap_M6_002");
								
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull300.00shenzhen 深圳02 手机");
		GridUtil.checkGridRowValue("detail", 2, "finednull400.00shenzhen 深圳01 电脑");
		
		//勾选单据明细
		Grid.element("detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("detail"), "选择", true);
		ToolBar.element("ToolBar1").click("AutoMap");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//查看目标单4
		MenuEntry.element("DataMap/CustomBill/DataMap_004View").dblClick();
		MainContainer.selectTab(0);
		
		//检查目标单4中单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "300302", true, "测试用例CASE_DataMap_M6_002");
		//双击打开
		ListView.element("list").dbClick("单据编号", "300302", "", "");
		MainContainer.selectTab(1);	
		
		//检查头控件
		TextEditorUtil.checkInputValue(TextEditor.element("NO"), "300302", "测试用例CASE_DataMap_M6_002");
										
		//检查明细
		GridUtil.checkGridRowValue("detail", 1, "finednull300.00shenzhen 深圳02 手机null");
		GridUtil.checkGridRowValue("detail", 2, "finednull400.00shenzhen 深圳01 电脑null");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
	}

}
