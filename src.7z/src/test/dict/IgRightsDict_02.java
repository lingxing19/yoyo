package test.dict;

import java.util.ArrayList;
import java.util.List;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.dictquerybox.BaseDictQueryItem;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.DictQueryBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.grid.BaseGrid;
import com.bokesoft.yes.autotest.component.grid.BaseGridDictItem;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class IgRightsDict_02 extends AbstractTestScript {
	public void run() {
		logOut();
		doLogin("User1", "");
		waittime(1000);
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/Dict_Ig_RightsView").dblClick();
		MainContainer.selectTab(0);
		// 3.点击"新增"
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);
	
		//1.打开表格字典"IgnoreRights=true"
		List<BaseGridDictItem> expList = new ArrayList<BaseGridDictItem>();
		List<BaseGridDictItem> list=Grid.element("detail").celDictClick("IgnoreRights=true", 1).getChildren(true);
		expList.add(new BaseGridDictItem("A01", 1, 0));
		expList.add(new BaseGridDictItem("A02", 1, 0));
		expList.add(new BaseGridDictItem("A03", 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list, "测试用例IgRightsDict_02");	
		//2.双击表格字典"IgnoreRights=true";3.输入：A
        Grid.element("detail").cellDbInput("IgnoreRights=true", 1, "A").pressEnterKey();
        
        List<BaseDictQueryItem> expSet = new ArrayList<BaseDictQueryItem>();     
		List<BaseDictQueryItem> set = DictQueryBox.element("1","column0").getChildren();
		
		expSet.add(new BaseDictQueryItem("上海", "A01", 0));
		expSet.add(new BaseDictQueryItem("北京", "A02", 0));
		expSet.add(new BaseDictQueryItem("深圳", "A03", 0));
		DictUtil.checkQueryBoxItemFiled(set, expSet, "测试用例IgRightsDict_02");
		//4.点击"取消"
        DictQueryBox.element("1","column0").queryBoxButtonClick("取消");
        //5.输入：深圳
        Grid.element("detail").cellDbInput("IgnoreRights=true", 1, "深圳").pressEnterKey();
        GridUtil.checkCellValue("detail","IgnoreRights=true", 1, "A03 深圳");
		//6.清空表格字典"IgnoreRights=true"
        Grid.element("detail").cellClear("IgnoreRights=true", 1);
        //7.点击表格字典"IgnoreRights=true"下拉箭头;8.输入：A;9.点击查询
		BaseGrid grid = Grid.element("detail").celDictClick("IgnoreRights=true", 1);
        expList.clear();
        List<BaseGridDictItem> list1 = grid.searchBoxInput("A").searchButtonClick().getChildren(true);
		expList.add(new BaseGridDictItem("A01", 1, 0));
		expList.add(new BaseGridDictItem("A02", 1, 0));
		expList.add(new BaseGridDictItem("A03", 1, 0));
		GridUtil.checkGridDictItemFiled(list1, expList, "测试用例IgRightsDict_02");
        //10.删除：A;11.输入：深圳;12.点击查询
        expList.clear();
        List<BaseGridDictItem> list2 = grid.searchInputClear().searchBoxInput("深圳").searchButtonClick().getChildren(true);;
		expList.add(new BaseGridDictItem("A03", 1, 0));
		GridUtil.checkGridDictItemFiled(list2, expList, "测试用例IgRightsDict_02");
		//13.打开表格字典"IgnoreRights=false"
		expList.clear();
		List<BaseGridDictItem> list3 =Grid.element("detail").celDictClick("IgnoreRights=false", 1).getChildren(true);
		expList.add(new BaseGridDictItem("A01", 1, 0));
		expList.add(new BaseGridDictItem("A02", 1, 0));
		GridUtil.checkGridDictItemFiled(list3, expList, "测试用例IgRightsDict_02");
		//14.双击表格字典"IgnoreRights=false";15.输入：A; 
		Grid.element("detail").cellDbInput("IgnoreRights=false", 1, "A").pressEnterKey();
		expSet.clear();
		List<BaseDictQueryItem> set1 = DictQueryBox.element("1","column1").getChildren();
		expSet.add(new BaseDictQueryItem("上海", "A01", 0));
		expSet.add(new BaseDictQueryItem("北京", "A02", 0));
		DictUtil.checkQueryBoxItemFiled(set1, expSet, "测试用例IgRightsDict_02");
		//16.点击"取消"
        DictQueryBox.element("1","column1").queryBoxButtonClick("取消");
        //17.输入：深圳
        Grid.element("detail").cellDbInput("IgnoreRights=false", 1, "深圳").pressEnterKey();
        expSet.clear();
        waittime(500);
		List<BaseDictQueryItem> set2 = DictQueryBox.element("1","column1").getChildren();
		DictUtil.checkQueryBoxItemFiled(set2, expSet, "测试用例IgRightsDict_02");
		//18.点击"取消"
		DictQueryBox.element("1","column1").queryBoxButtonClick("取消");
		//19.点击表格字典"IgnoreRights=false"下拉箭头;20.输入：A;21.点击查询
		BaseGrid grid1 = Grid.element("detail").celDictClick("IgnoreRights=false", 1);
        expList.clear();
        List<BaseGridDictItem> list4 = grid1.searchBoxInput("A").searchButtonClick().getChildren(true);
		expList.add(new BaseGridDictItem("A01", 1, 0));
		expList.add(new BaseGridDictItem("A02", 1, 0));
		GridUtil.checkGridDictItemFiled(list4, expList, "测试用例IgRightsDict_02");
		//22.删除：A;23.输入：深圳;24.点击查询
        expList.clear();
        List<BaseGridDictItem> list5 = grid1.searchInputClear().searchBoxInput("深圳").searchButtonClick().getChildren(true);
		GridUtil.checkGridDictItemFiled(list5, expList, "测试用例IgRightsDict_02");
		MainContainer.closeAllTab();


		


	}

}
