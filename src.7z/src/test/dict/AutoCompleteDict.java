package test.dict;

import java.util.ArrayList;
import java.util.List;

import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.component.dictquerybox.BaseDictQueryItem;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.DictQueryBox;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class AutoCompleteDict extends AbstractTestScript{
	public void run(){
	
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/AutocompleteDictView").dblClick();		
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();		
		MainContainer.selectTab(1);
		
		Dict.element("Dict1").input("001").pressEnterKey();
		DictUtil.checkInputValue("Dict1", "001 华东地区", "测试用例AutocompleteDict_01");
		
		Dict.element("Dict1").pressBackspaceKey(4, 4);
		Dict.element("Dict1").pressEnterKey();
		waittime(500);
		
	    List<BaseDictQueryItem> expSet = new ArrayList<BaseDictQueryItem>();
		List<BaseDictQueryItem> set = DictQueryBox.element("Dict1").getChildren();
        expSet.add(new BaseDictQueryItem("华东地区","001",1));
	    expSet.add(new BaseDictQueryItem("华东地区1","003",1));
	    DictUtil.checkQueryBoxItemFiled(set, expSet, "测试用例AutocompleteDict_01");
		
		DictQueryBox.element("Dict1").queryBoxButtonClick("取消");
		DictUtil.checkInputValue("Dict1", "001 华东地区", "测试用例AutocompleteDict_01");
		
		Dict.element("Dict1").clear();
		
		Dict.element("Dict1").input("0").pressTabKey();
		waittime(500);
		
		expSet.clear();
		List<BaseDictQueryItem> set1 = DictQueryBox.element("Dict1").getChildren();
        expSet.add(new BaseDictQueryItem("华东地区","001",1)); 
        expSet.add(new BaseDictQueryItem("华北地区","002",1));
        expSet.add(new BaseDictQueryItem("华东地区1","003",1));
	    expSet.add(new BaseDictQueryItem("华北地区1","004",1));
	    DictUtil.checkQueryBoxItemFiled(set1, expSet, "测试用例AutocompleteDict_01");
	    DictQueryBox.element("Dict1").queryBoxButtonClick("取消");
	    
	    
//	    Dict.element("Dict1").input("5");
//	    Dict.element("Dict2").input("5").pressEnterKey();
//	    DictQueryBox.element().queryBoxButtonClick("取消");
	    
	    MainContainer.closeAllTab();
		
	}

}
