package test.dict;

import java.util.ArrayList;
import java.util.List;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.dictview.BaseDictViewItem;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.DictView;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class LevelDictTest extends AbstractTestScript{
		public void run() {
	
			MenuEntry.element("Dict/NewGroup").click();
			MenuEntry.element("Dict/NewGroup/ComLevelDictView").dblClick();		
			MainContainer.selectTab(0);
			ToolBarButton.element("新增").click();		
			MainContainer.selectTab(1);
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict1", "地区", "测试用例ComLevelDict_001");			
			Dict.element("Dict1").viewClick();
			//校验汇总节点各属性是否正确
    		List<BaseDictItem> expList = new ArrayList<BaseDictItem>();
    		List<BaseDictItem> list= Dict.element("Dict1").viewClick().getChildren(true);
    		expList.add(new BaseDictItem("004 华北地区1",1,1));			
			DictUtil.checkDictItemFiled(list, expList,"测试用例ComLevelDict_001");

			//校验明细节点各属性是否正确
    		expList.clear();
    		List<BaseDictItem> list1= Dict.element("Dict1").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
			expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list1, expList,"测试用例ComLevelDict_001"); 
            //校验字典编辑框取值是否正确
			Dict.element("Dict1").itemClick("004 华北地区1");
			DictUtil.checkInputValue("Dict1", "004 华北地区1", "测试用例ComLevelDict_001");
			waittime(1000);
//-------------------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict7", "地区", "测试用例ComLevelDict_002");
			Dict.element("Dict7").viewClick();
			
			//校验汇总节点各属性是否正确
			expList.clear();
    		List<BaseDictItem> list2= Dict.element("Dict7").viewClick().getChildren(true);
    		expList.add(new BaseDictItem("001 华东地区",1,1));
    		expList.add(new BaseDictItem("002 华北地区",1,1));
    		expList.add(new BaseDictItem("003 华东地区1",1,1));
    		expList.add(new BaseDictItem("004 华北地区1",1,1));
    		expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list2, expList,"测试用例ComLevelDict_002");
			
			//校验明细节点各属性是否正确
			expList.clear();
    		List<BaseDictItem> list3= Dict.element("Dict7").expandClick("001 华东地区").getChildren(false);
			expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));			
			DictUtil.checkDictItemFiled(list3, expList,"测试用例ComLevelDict_002"); 
			
			expList.clear();
    		List<BaseDictItem> list4= Dict.element("Dict7").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));
    		waittime(500);
			DictUtil.checkDictItemFiled(list4, expList,"测试用例ComLevelDict_002"); 
			
			expList.clear();
    		List<BaseDictItem> list5= Dict.element("Dict7").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list5, expList,"测试用例ComLevelDict_002"); 
						
			expList.clear();
    		List<BaseDictItem> list6= Dict.element("Dict7").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list6, expList,"测试用例ComLevelDict_002"); 
			//依赖组件勾选，节点过滤是否正确
			CheckBox.element("CheckBox1").click();
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict7", "地区", "测试用例ComLevelDict_002");
			Dict.element("Dict7").viewClick();
			
			//校验汇总节点各属性是否正确
			expList.clear();
    		List<BaseDictItem> list7= Dict.element("Dict7").viewClick().getChildren(true);
    		expList.add(new BaseDictItem("001 华东地区",1,1));
    		expList.add(new BaseDictItem("002 华北地区",1,1));
    		expList.add(new BaseDictItem("003 华东地区1",1,1));
    		expList.add(new BaseDictItem("004 华北地区1",1,1));
			DictUtil.checkDictItemFiled(list7, expList,"测试用例ComLevelDict_002");
			
			//校验明细节点各属性是否正确
			expList.clear();
    		List<BaseDictItem> list8= Dict.element("Dict7").expandClick("001 华东地区").getChildren(false);		
			DictUtil.checkDictItemFiled(list8, expList,"测试用例ComLevelDict_002"); 
			
			expList.clear();
    		List<BaseDictItem> list9= Dict.element("Dict7").expandClick("002 华北地区").getChildren(false);		
			DictUtil.checkDictItemFiled(list9, expList,"测试用例ComLevelDict_002"); 
			
			expList.clear();
    		List<BaseDictItem> list10= Dict.element("Dict7").expandClick("003 华东地区1").getChildren(false);
			DictUtil.checkDictItemFiled(list10, expList,"测试用例ComLevelDict_002"); 
						
			expList.clear();
    		List<BaseDictItem> list11= Dict.element("Dict7").expandClick("004 华北地区1").getChildren(false);			
			DictUtil.checkDictItemFiled(list11, expList,"测试用例ComLevelDict_002"); 
			
			//选中节点,撤销勾选
			Dict.element("Dict7").itemClick("002 华北地区");
			DictUtil.checkInputValue("Dict7", "002 华北地区", "测试用例ComLevelDict_002");
			CheckBox.element("CheckBox1").click();
			DictUtil.checkInputValue("Dict7", "", "测试用例ComLevelDict_002");
			waittime(1000);
//--------------------------------------------------------------------------------------------------------------------
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict8", "地区", "测试用例ComLevelDict_003");
			Dict.element("Dict8").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list12= Dict.element("Dict8").viewClick().getChildren(true);		
			expList.add(new BaseDictItem("001 华东地区",1,1));
    		expList.add(new BaseDictItem("002 华北地区",1,1));
    		expList.add(new BaseDictItem("003 华东地区1",1,1));
    		expList.add(new BaseDictItem("004 华北地区1",1,1));
    		expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list12, expList, "测试用例ComLevelDict_003");
			
			//检查明细节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list13= Dict.element("Dict8").expandClick("001 华东地区").getChildren(false);		
			expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));			
			DictUtil.checkDictItemFiled(list13, expList,"测试用例ComLevelDict_003"); 
			
			expList.clear();
    		List<BaseDictItem> list14= Dict.element("Dict8").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list14, expList,"测试用例ComLevelDict_003"); 
			
			expList.clear();
    		List<BaseDictItem> list15= Dict.element("Dict8").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list15, expList,"测试用例ComLevelDict_003"); 
						
			expList.clear();
    		List<BaseDictItem> list16= Dict.element("Dict8").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list16, expList,"测试用例ComLevelDict_003"); 
			
			//勾选依赖组件
			CheckBox.element("CheckBox2").click();
		    
		    //检查根节点是否正确
		    DictUtil.checkRootNode("Dict8", "地区", "测试用例ComLevelDict_003");
		    Dict.element("Dict8").viewClick();
		    
		    //检查汇总节点各属性是否正确
		    expList.clear();
			List<BaseDictItem> list17= Dict.element("Dict8").viewClick().getChildren(true);		
			expList.add(new BaseDictItem("001 华东地区",1,1));
    		expList.add(new BaseDictItem("002 华北地区",1,1));
    		expList.add(new BaseDictItem("003 华东地区1",1,1));
    		expList.add(new BaseDictItem("004 华北地区1",1,1));
			DictUtil.checkDictItemFiled(list17, expList, "测试用例ComLevelDict_003");	
			
			//检查明细节点各属性是否正确
			expList.clear();
    		List<BaseDictItem> list18= Dict.element("Dict8").expandClick("001 华东地区").getChildren(false);		
			DictUtil.checkDictItemFiled(list18, expList,"测试用例ComLevelDict_003"); 
			
			expList.clear();
    		List<BaseDictItem> list19= Dict.element("Dict8").expandClick("002 华北地区").getChildren(false);		
			DictUtil.checkDictItemFiled(list19, expList,"测试用例ComLevelDict_003"); 
			
			expList.clear();
    		List<BaseDictItem> list20= Dict.element("Dict8").expandClick("003 华东地区1").getChildren(false);
			DictUtil.checkDictItemFiled(list20, expList,"测试用例ComLevelDict_003"); 
						
			expList.clear();
    		List<BaseDictItem> list21= Dict.element("Dict8").expandClick("004 华北地区1").getChildren(false);			
			DictUtil.checkDictItemFiled(list21, expList,"测试用例ComLevelDict_003"); 
			Dict.element("Dict8").viewClick();
			waittime(1000);
//---------------------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict13", "地区", "测试用例ComLevelDict_004");
			Dict.element("Dict13").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list22= Dict.element("Dict13").viewClick().getChildren(true);		
			expList.add(new BaseDictItem("001 华东地区",1,1));
    		expList.add(new BaseDictItem("002 华北地区",1,1));
    		expList.add(new BaseDictItem("003 华东地区1",1,1));
    		expList.add(new BaseDictItem("004 华北地区1",1,1));
    		expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list22, expList, "测试用例ComLevelDict_004");
		
			
			//检查明细节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list23= Dict.element("Dict13").expandClick("001 华东地区").getChildren(false);		
			expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));			
			DictUtil.checkDictItemFiled(list23, expList,"测试用例ComLevelDict_004"); 
			
			expList.clear();
    		List<BaseDictItem> list24= Dict.element("Dict13").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list24, expList,"测试用例ComLevelDict_004"); 
			
			expList.clear();
    		List<BaseDictItem> list25= Dict.element("Dict13").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list25, expList,"测试用例ComLevelDict_004"); 
						
			expList.clear();
    		List<BaseDictItem> list26= Dict.element("Dict13").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list26, expList,"测试用例ComLevelDict_004"); 
			
			//勾选依赖组件
			CheckBox.element("CheckBox3").click();
			
			//检查根节点是否正确
		    DictUtil.checkRootNode("Dict13", "地区", "测试用例ComLevelDict_004");
		    Dict.element("Dict13").viewClick();
		    
		    //检查汇总节点各属性是否正确
		    expList.clear();
		    List<BaseDictItem> list27=Dict.element("Dict13").viewClick().getChildren(true);
		    expList.add(new BaseDictItem("001 华东地区",1,1));
    		expList.add(new BaseDictItem("002 华北地区",1,1));
    		expList.add(new BaseDictItem("003 华东地区1",1,1));
    		expList.add(new BaseDictItem("004 华北地区1",1,1));
    		DictUtil.checkDictItemFiled(list27, expList, "测试用例ComLevelDict_004");
    		
    		//检查明细节点各属性是否正确
    		expList.clear();
			List<BaseDictItem> list28= Dict.element("Dict13").expandClick("001 华东地区").getChildren(false);				
			DictUtil.checkDictItemFiled(list28, expList,"测试用例ComLevelDict_004"); 
			
			expList.clear();
    		List<BaseDictItem> list29= Dict.element("Dict13").expandClick("002 华北地区").getChildren(false);			
			DictUtil.checkDictItemFiled(list29, expList,"测试用例ComLevelDict_004"); 
			
			expList.clear();
    		List<BaseDictItem> list30= Dict.element("Dict13").expandClick("003 华东地区1").getChildren(false);
			DictUtil.checkDictItemFiled(list30, expList,"测试用例ComLevelDict_004"); 
    		
			expList.clear();
    		List<BaseDictItem> list31= Dict.element("Dict13").expandClick("004 华北地区1").getChildren(false);		
			DictUtil.checkDictItemFiled(list31, expList,"测试用例ComLevelDict_004"); 
			Dict.element("Dict13").viewClick();
			waittime(1000);
//---------------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict2", "地区", "测试用例ComLevelDict_005");
			Dict.element("Dict2").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list32=Dict.element("Dict2").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
			DictUtil.checkDictItemFiled(list32, expList, "测试用例ComLevelDict_005");
			
			//检查明细节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list33=Dict.element("Dict2").expandClick("001 华东地区").getChildren(false);
			DictUtil.checkDictItemFiled(list33, expList, "测试用例ComLevelDict_005");
			
			//选中节点
			Dict.element("Dict2").itemClick("001 华东地区");
			DictUtil.checkInputValue("Dict2", "001 华东地区", "测试用例ComLevelDict_005");
			waittime(1000);
//----------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict9", "地区", "测试用例ComLevelDict_006");
			Dict.element("Dict9").viewClick();
			
			//检查子节点是否正确
			expList.clear();
			List<BaseDictItem> list34=Dict.element("Dict9").viewClick().getChildren(true);
			expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list34, expList, "测试用例ComLevelDict_006");
			
			//勾选复选框
			CheckBox.element("CheckBox4").click();
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict9", "地区", "测试用例ComLevelDict_006");
			Dict.element("Dict9").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list35=Dict.element("Dict9").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	DictUtil.checkDictItemFiled(list35, expList, "测试用例ComLevelDict_006");
	    	
			//检查明细节点是否存在
	    	expList.clear();
	    	List<BaseDictItem> list36= Dict.element("Dict9").expandClick("001 华东地区").getChildren(false);				
			DictUtil.checkDictItemFiled(list36, expList,"测试用例ComLevelDict_006"); 
			
			expList.clear();
    		List<BaseDictItem> list37= Dict.element("Dict9").expandClick("002 华北地区").getChildren(false);			
			DictUtil.checkDictItemFiled(list37, expList,"测试用例ComLevelDict_006"); 
			
			expList.clear();
    		List<BaseDictItem> list38= Dict.element("Dict9").expandClick("003 华东地区1").getChildren(false);
			DictUtil.checkDictItemFiled(list38, expList,"测试用例ComLevelDict_006"); 
    		
			expList.clear();
    		List<BaseDictItem> list39= Dict.element("Dict9").expandClick("004 华北地区1").getChildren(false);		
			DictUtil.checkDictItemFiled(list39, expList,"测试用例ComLevelDict_006"); 
			Dict.element("Dict9").viewClick();
			waittime(1000);
//--------------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict12", "地区", "测试用例ComLevelDict_007");
			Dict.element("Dict12").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list40=Dict.element("Dict12").viewClick().getChildren(true);
			expList.add(new BaseDictItem("002 华北地区",1,1));
			DictUtil.checkDictItemFiled(list40, expList, "测试用例ComLevelDict_007");
			
			//检查明细节点是否存在
			expList.clear();
			List<BaseDictItem> list41=Dict.element("Dict12").expandClick("002 华北地区").getChildren(false);
			DictUtil.checkDictItemFiled(list41, expList, "测试用例ComLevelDict_007");
			Dict.element("Dict12").viewClick();
			waittime(1000);
//-----------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict15", "地区", "测试用例ComLevelDict_008");
			Dict.element("Dict15").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list42=Dict.element("Dict15").viewClick().getChildren(true);
			expList.add(new BaseDictItem("003 华东地区1",1,1));
			expList.add(new BaseDictItem("004 华北地区1",1,1));
			DictUtil.checkDictItemFiled(list42,expList, "测试用例ComLevelDict_008");		
			
			//检查明细节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list43=Dict.element("Dict15").expandClick("003 华东地区1").getChildren(false);
			expList.add(new BaseDictItem("jiangxi 江西省",1,0));
			expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list43, expList, "测试用例ComLevelDict_008");
			
			expList.clear();
			List<BaseDictItem> list44=Dict.element("Dict15").expandClick("004 华北地区1").getChildren(false);
			expList.add(new BaseDictItem("jilin 吉林省",1,0));
			expList.add(new BaseDictItem("tianjin 天津市",1,0));
			DictUtil.checkDictItemFiled(list44, expList, "测试用例ComLevelDict_008");
			Dict.element("Dict15").viewClick();
			waittime(1000);
//-----------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict10", "地区", "测试用例ComLevelDict_009");
			Dict.element("Dict10").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list45=Dict.element("Dict10").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	expList.add(new BaseDictItem("fujian 福建省",1,0));
	    	DictUtil.checkDictItemFiled(list45, expList, "测试用例ComLevelDict_009");
	    	
	    	//检查明细节点各属性是否正确
	    	expList.clear();
	    	List<BaseDictItem> list46=Dict.element("Dict10").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		DictUtil.checkDictItemFiled(list46, expList, "测试用例ComLevelDict_009");
    		
    		expList.clear();
    		List<BaseDictItem> list47= Dict.element("Dict10").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list47, expList,"测试用例ComLevelDict_009"); 
			
			expList.clear();
    		List<BaseDictItem> list48= Dict.element("Dict10").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list48, expList,"测试用例ComLevelDict_009"); 
						
			expList.clear();
    		List<BaseDictItem> list49= Dict.element("Dict10").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list49, expList,"测试用例ComLevelDict_009"); 
			
			//勾选复选框
			CheckBox.element("CheckBox5").click();
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict10", "地区", "测试用例ComLevelDict_009");
			Dict.element("Dict10").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list50=Dict.element("Dict10").viewClick().getChildren(true);
			expList.add(new BaseDictItem("002 华北地区",1,1));
			DictUtil.checkDictItemFiled(list50, expList, "测试用例ComLevelDict_009");
			
			//检查明细节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list51=Dict.element("Dict10").expandClick("002 华北地区").getChildren(false);
			expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));	
    		DictUtil.checkDictItemFiled(list51, expList, "测试用例ComLevelDict_009");
    		
    		//选中节点
    		Dict.element("Dict10").itemClick("002 华北地区");
    		DictUtil.checkInputValue("Dict10", "002 华北地区", "测试用例ComLevelDict_009");
    		
    		//复选框撤销勾选
    		CheckBox.element("CheckBox5").click();
    		DictUtil.checkInputValue("Dict10", "","测试用例ComLevelDict_009");
    		waittime(1000);
//-------------------------------------------------------------------------------------------------------------
    		
    		//检查根节点是否正确
    		DictUtil.checkRootNode("Dict4", "地区", "测试用例ComLevelDict_010");
    		Dict.element("Dict4").viewClick();
    		
    		//检查汇总节点各属性是否正确
    		expList.clear();
    		List<BaseDictItem> list52=Dict.element("Dict4").viewClick().getChildren(true);
    		expList.add(new BaseDictItem("001 华东地区",1,1));
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	expList.add(new BaseDictItem("fujian 福建省",1,0));
	    	DictUtil.checkDictItemFiled(list52, expList, "测试用例ComLevelDict_010");
	    	
	    	//检查明细节点各属性是否正确
	    	expList.clear();
	    	List<BaseDictItem> list53=Dict.element("Dict4").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		DictUtil.checkDictItemFiled(list53, expList, "测试用例ComLevelDict_010");
    		
    		expList.clear();
    		List<BaseDictItem> list54= Dict.element("Dict4").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list54, expList,"测试用例ComLevelDict_010"); 
			
			expList.clear();
    		List<BaseDictItem> list55= Dict.element("Dict4").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list55, expList,"测试用例ComLevelDict_010"); 
						
			expList.clear();
    		List<BaseDictItem> list56= Dict.element("Dict4").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list56, expList,"测试用例ComLevelDict_010"); 
            
			//勾选复选框
			CheckBox.element("CheckBox6").click();
			
			//检查根节点是否正确
    		DictUtil.checkRootNode("Dict4", "地区", "测试用例ComLevelDict_010");
    		Dict.element("Dict4").expandClick("001 华东地区").expandClick("002 华北地区").expandClick("003 华东地区1").expandClick("004 华北地区1").viewClick();
    		
    		//检查汇总节点各属性是否正确
    		expList.clear();
    		List<BaseDictItem> list57=Dict.element("Dict4").viewClick().getChildren(true);
    		expList.add(new BaseDictItem("001 华东地区",1,1));
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	expList.add(new BaseDictItem("fujian 福建省",1,0));
	    	DictUtil.checkDictItemFiled(list57, expList, "测试用例ComLevelDict_010");
	    	
	    	//检查明细节点各属性是否正确
	    	expList.clear();
	    	List<BaseDictItem> list58=Dict.element("Dict4").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		DictUtil.checkDictItemFiled(list58, expList, "测试用例ComLevelDict_010");
    		
    		expList.clear();
    		List<BaseDictItem> list59= Dict.element("Dict4").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list59, expList,"测试用例ComLevelDict_010"); 
			
			expList.clear();
    		List<BaseDictItem> list60= Dict.element("Dict4").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list60, expList,"测试用例ComLevelDict_010"); 
						
			expList.clear();
    		List<BaseDictItem> list61= Dict.element("Dict4").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list61, expList,"测试用例ComLevelDict_010"); 
			
			//新增表单
			MainContainer.selectTab(0);
			ToolBarButton.element("新增").click();		
			MainContainer.selectTab(2); 
			
			//勾选复选框
			CheckBox.element("CheckBox6").click();
			
			//检查根节点是否正确
    		DictUtil.checkRootNode("Dict4", "地区", "测试用例ComLevelDict_010");
    		Dict.element("Dict4").expandClick("002 华北地区").expandClick("003 华东地区1").expandClick("004 华北地区1").viewClick();
    		
    		//检查汇总节点各属性是否正确
    		expList.clear();
    		List<BaseDictItem> list62=Dict.element("Dict4").viewClick().getChildren(true);
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	DictUtil.checkDictItemFiled(list62, expList, "测试用例ComLevelDict_010");
	    	
	    	//检查明细节点各属性是否正确   		
    		expList.clear();
    		List<BaseDictItem> list63= Dict.element("Dict4").expandClick("002 华北地区").getChildren(false);		
			DictUtil.checkDictItemFiled(list63, expList,"测试用例ComLevelDict_010"); 
			
			expList.clear();
    		List<BaseDictItem> list64= Dict.element("Dict4").expandClick("003 华东地区1").getChildren(false);
			DictUtil.checkDictItemFiled(list64, expList,"测试用例ComLevelDict_010"); 
						
			expList.clear();
    		List<BaseDictItem> list65= Dict.element("Dict4").expandClick("004 华北地区1").getChildren(false);		
			DictUtil.checkDictItemFiled(list65, expList,"测试用例ComLevelDict_010"); 
			
			//复选框撤销勾选
			CheckBox.element("CheckBox6").click();
			
			//检查根节点是否正确
    		DictUtil.checkRootNode("Dict4", "地区", "测试用例ComLevelDict_010");
    		Dict.element("Dict4").viewClick();
    		
    		//检查汇总节点各属性是否正确
    		expList.clear();
    		List<BaseDictItem> list66=Dict.element("Dict4").viewClick().getChildren(true);
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	DictUtil.checkDictItemFiled(list66, expList, "测试用例ComLevelDict_010");
	    	
	    	//检查明细节点各属性是否正确   		
    		expList.clear();
    		List<BaseDictItem> list67= Dict.element("Dict4").expandClick("002 华北地区").getChildren(false);		
			DictUtil.checkDictItemFiled(list67, expList,"测试用例ComLevelDict_010"); 
			
			expList.clear();
    		List<BaseDictItem> list68= Dict.element("Dict4").expandClick("003 华东地区1").getChildren(false);
			DictUtil.checkDictItemFiled(list68, expList,"测试用例ComLevelDict_010"); 
						
			expList.clear();
    		List<BaseDictItem> list69= Dict.element("Dict4").expandClick("004 华北地区1").getChildren(false);		
			DictUtil.checkDictItemFiled(list69, expList,"测试用例ComLevelDict_010"); 
			Dict.element("Dict4").viewClick();
			waittime(1000);
//------------------------------------------------------------------------------------------------------------------------
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict6", "地区", "测试用例ComLevelDict_011");
			Dict.element("Dict6").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list70=Dict.element("Dict6").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	expList.add(new BaseDictItem("fujian 福建省",1,0));
	    	DictUtil.checkDictItemFiled(list70, expList, "测试用例ComLevelDict_011");
	    	
	    	//检查明细节点各属性是否正确
	    	expList.clear();
	    	List<BaseDictItem> list71=Dict.element("Dict6").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		DictUtil.checkDictItemFiled(list71, expList, "测试用例ComLevelDict_011");
    		
    		expList.clear();
    		List<BaseDictItem> list72= Dict.element("Dict6").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list72, expList,"测试用例ComLevelDict_011"); 
			
			expList.clear();
    		List<BaseDictItem> list73= Dict.element("Dict6").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list73, expList,"测试用例ComLevelDict_011"); 
			
			Dict.element("Dict6").expandClick("001 华东地区").expandClick("002 华北地区").expandClick("003 华东地区1");	
			
			expList.clear();
    		List<BaseDictItem> list74= Dict.element("Dict6").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list74, expList,"测试用例ComLevelDict_011"); 
			Dict.element("Dict6").viewClick();
			waittime(1000);
//----------------------------------------------------------------------------------------------------------------------------
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict16", "地区", "测试用例ComLevelDict_012");
			Dict.element("Dict16").viewClick();
			
			//检查子节点是否存在
			expList.clear();
			List<BaseDictItem> list75=Dict.element("Dict16").viewClick().getChildren(true);
			DictUtil.checkDictItemFiled(list75, expList, "测试用例ComLevelDict_012");
			Dict.element("Dict16").viewClick();
			
			//点击单选框
			RadioButton.element("RadioButton2").click();
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict16", "地区", "测试用例ComLevelDict_012");
			Dict.element("Dict16").viewClick();
			
			//检查子节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list76=Dict.element("Dict16").viewClick().getChildren(true);
	    	expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list76, expList, "测试用例ComLevelDict_012");
//-----------------------------------------------------------------------------------------------------------
			MainContainer.selectTab(0);
			ToolBarButton.element("新增").click();		
			MainContainer.selectTab(3); 
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict17", "地区", "测试用例ComLevelDict_013");
			Dict.element("Dict17").viewClick();
			//检查子节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list77=Dict.element("Dict17").viewClick().getChildren(true);
			DictUtil.checkDictItemFiled(list77, expList,"测试用例ComLevelDict_013");
			Dict.element("Dict17").viewClick();
			//选中[RadioButton1]，[Or]下拉查看
			RadioButton.element("RadioButton1").click();
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict17", "地区", "测试用例ComLevelDict_013");
			Dict.element("Dict17").viewClick();
			List<BaseDictItem> list103=Dict.element("Dict17").viewClick().getChildren(true);
			DictUtil.checkDictItemFiled(list103, expList,"测试用例ComLevelDict_013");
			Dict.element("Dict17").viewClick();
			//点击单选框
			RadioButton.element("RadioButton2").click();
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict17", "地区", "测试用例ComLevelDict_013");
			Dict.element("Dict17").viewClick();

			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list78=Dict.element("Dict17").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
	        expList.add(new BaseDictItem("002 华北地区",1,1));
	        expList.add(new BaseDictItem("003 华东地区1",1,1));
	    	expList.add(new BaseDictItem("004 华北地区1",1,1));
	    	expList.add(new BaseDictItem("fujian 福建省",1,0));
	    	DictUtil.checkDictItemFiled(list78, expList, "测试用例ComLevelDict_013");
	    	
	    	//检查明细节点各属性是否正确
	    	expList.clear();
	    	List<BaseDictItem> list79=Dict.element("Dict17").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		DictUtil.checkDictItemFiled(list79, expList, "测试用例ComLevelDict_013");
    		
    		expList.clear();
    		List<BaseDictItem> list80= Dict.element("Dict17").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list80, expList,"测试用例ComLevelDict_013"); 
			
			expList.clear();
    		List<BaseDictItem> list81= Dict.element("Dict17").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list81, expList,"测试用例ComLevelDict_013"); 
						
			expList.clear();
    		List<BaseDictItem> list82= Dict.element("Dict17").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list82, expList,"测试用例ComLevelDict_013"); 
//----------------------------------------------------------------------------------------------------------------
		
			//打开DictView
			MenuEntry.element("Dict/CustomBill").click();
			MenuEntry.element("Dict/CustomBill/LevelDict").dblClick();		
			MainContainer.selectTab(4);
            
			//更改“003”节点状态
			DictView.element().itemClick("003");
			ToolBar.element("main_toolbar").click("DisabledDict");
			
  		    //检查汇总节点各属性是否正确
    		List<BaseDictViewItem> expItems = new ArrayList<BaseDictViewItem>();
    		List<BaseDictViewItem> items =DictView.element().getChildren(true);
    		expItems.add(new BaseDictViewItem("华东地区",1,1));
    		expItems.add(new BaseDictViewItem("华北地区",1,1));
    		expItems.add(new BaseDictViewItem("华东地区1", 0, 1));
    		expItems.add(new BaseDictViewItem("华北地区1",1,1));
    		expItems.add(new BaseDictViewItem("福建省",1,0));
    		DictUtil.checkDictViewItemFiled(items, expItems, "测试用例ComLevelDict_014");
    		
    	 	//检查明细节点各属性是否正确
    		expItems.clear();
	    	List<BaseDictViewItem> items1=DictView.element().expandItemClick("001").itemClick("001").getChildren(false);
	    	expItems.add(new BaseDictViewItem("安徽省",1,0));
	    	expItems.add(new BaseDictViewItem("江苏省",1,0));
    		DictUtil.checkDictViewItemFiled(items1, expItems, "测试用例ComLevelDict_014");
    		
    		expItems.clear();
    		List<BaseDictViewItem> items2= DictView.element().expandItemClick("002").itemClick("002").getChildren(false);
    		expItems.add(new BaseDictViewItem("北京市",1,0));	
    		expItems.add(new BaseDictViewItem("河北省",1,0));			
			DictUtil.checkDictViewItemFiled(items2, expItems,"测试用例ComLevelDict_014"); 
			
			expItems.clear();
    		List<BaseDictViewItem> items3= DictView.element().expandItemClick("003").itemClick("003").getChildren(false);
    		expItems.add(new BaseDictViewItem("江西省",0,0));	
    		expItems.add(new BaseDictViewItem("上海市",0,0));
			DictUtil.checkDictViewItemFiled(items3, expItems,"测试用例ComLevelDict_014"); 
						
			expItems.clear();
    		List<BaseDictViewItem> items4= DictView.element().expandItemClick("004").itemClick("004").getChildren(false);
    		expItems.add(new BaseDictViewItem("吉林省",1,0));
    		expItems.add(new BaseDictViewItem("天津市",1,0));			
			DictUtil.checkDictViewItemFiled(items4, expItems,"测试用例ComLevelDict_014"); 

			//打开字典表单
	
			MainContainer.selectTab(0);
			ToolBarButton.element("新增").click();		
			MainContainer.selectTab(5);
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict18", "地区", "测试用例ComLevelDict_014");
			Dict.element("Dict18").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list83= Dict.element("Dict18").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
			expList.add(new BaseDictItem("002 华北地区",1,1));
			expList.add(new BaseDictItem("003 华东地区1", 0, 1));
			expList.add(new BaseDictItem("004 华北地区1",1,1));
			expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list83, expList, "测试用例ComLevelDict_014");
			
			//检查明细节点各属性是否正确
			expList.clear();
	    	List<BaseDictItem> list84=Dict.element("Dict18").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		waittime(500);
    		DictUtil.checkDictItemFiled(list84, expList, "测试用例ComLevelDict_014");
    		
    		expList.clear();
    		List<BaseDictItem> list85= Dict.element("Dict18").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list85, expList,"测试用例ComLevelDict_014"); 
			
			expList.clear();
			List<BaseDictItem> list86=Dict.element("Dict18").expandClick("003 华东地区1").getChildren(false);
			expList.add(new BaseDictItem("jiangxi 江西省",0,0));	
			expList.add(new BaseDictItem("shanghai 上海市",0,0));
			DictUtil.checkDictItemFiled(list86, expList, "测试用例ComLevelDict_014");
						
            expList.clear();
            List<BaseDictItem> list87= Dict.element("Dict18").expandClick("004 华北地区1").getChildren(false);
            expList.add(new BaseDictItem("jilin 吉林省",1,0));
            expList.add(new BaseDictItem("tianjin 天津市",1,0));			
            DictUtil.checkDictItemFiled(list87, expList,"测试用例ComLevelDict_014"); 
            
			//打开DictView
			MainContainer.selectTab(4);
			
			//更改"jiangxi"\"shanghai"节点状态
			DictView.element().itemClick("jiangxi");
			ToolBar.element("main_toolbar").click("InvalidDict");
			waittime(1000);
			DictView.element().itemClick("shanghai");
			ToolBar.element("main_toolbar").click("InvalidDict");
			
			//检查汇总节点各属性是否正确
			expItems.clear();
			List<BaseDictViewItem> items5=DictView.element().getChildren(true);
			expItems.add(new BaseDictViewItem("华东地区",1,1));
    		expItems.add(new BaseDictViewItem("华北地区",1,1));
    		expItems.add(new BaseDictViewItem("华东地区1", 0, 1));
    		expItems.add(new BaseDictViewItem("华北地区1",1,1));
    		expItems.add(new BaseDictViewItem("福建省",1,0));
    		DictUtil.checkDictViewItemFiled(items5, expItems, "测试用例ComLevelDict_014");
    		
    		//检查明细节点各属性是否正确
    		expItems.clear();
	    	List<BaseDictViewItem> items6=DictView.element().itemClick("001").getChildren(false);
	    	expItems.add(new BaseDictViewItem("安徽省",1,0));
	    	expItems.add(new BaseDictViewItem("江苏省",1,0));
    		DictUtil.checkDictViewItemFiled(items6, expItems, "测试用例ComLevelDict_014");
    		
    		expItems.clear();
    		List<BaseDictViewItem> items7= DictView.element().itemClick("002").getChildren(false);
    		expItems.add(new BaseDictViewItem("北京市",1,0));	
    		expItems.add(new BaseDictViewItem("河北省",1,0));			
			DictUtil.checkDictViewItemFiled(items7, expItems,"测试用例ComLevelDict_014"); 
			
			expItems.clear();
    		List<BaseDictViewItem> items8= DictView.element().itemClick("003").getChildren(false);
    		expItems.add(new BaseDictViewItem("江西省",-1,0));	
    		expItems.add(new BaseDictViewItem("上海市",-1,0));
			DictUtil.checkDictViewItemFiled(items8, expItems,"测试用例ComLevelDict_014"); 
						
			expItems.clear();
    		List<BaseDictViewItem> items9= DictView.element().itemClick("004").getChildren(false);
    		expItems.add(new BaseDictViewItem("吉林省",1,0));
    		expItems.add(new BaseDictViewItem("天津市",1,0));			
			DictUtil.checkDictViewItemFiled(items9, expItems,"测试用例ComLevelDict_014"); 
						
			//打开字典表单
			MainContainer.selectTab(0);
			ToolBarButton.element("新增").click();
			MainContainer.selectTab(6);
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict18", "地区", "测试用例ComLevelDict_014");
			Dict.element("Dict18").viewClick();
			
			//检查汇总节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list88= Dict.element("Dict18").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
			expList.add(new BaseDictItem("002 华北地区",1,1));
			expList.add(new BaseDictItem("003 华东地区1", 0, 1));
			expList.add(new BaseDictItem("004 华北地区1",1,1));
			expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list88, expList, "测试用例ComLevelDict_014");
			
			//检查明细节点各属性是否正确
			expList.clear();
	    	List<BaseDictItem> list89=Dict.element("Dict18").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
    		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		DictUtil.checkDictItemFiled(list89, expList, "测试用例ComLevelDict_014");
    		
    		expList.clear();
    		List<BaseDictItem> list90= Dict.element("Dict18").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list90, expList,"测试用例ComLevelDict_014"); 
			
			expList.clear();
			List<BaseDictItem> list91=Dict.element("Dict18").expandClick("003 华东地区1").getChildren(false);
			expList.add(new BaseDictItem("jiangxi 江西省",2,0));	
			expList.add(new BaseDictItem("shanghai 上海市",2,0));
			DictUtil.checkDictItemFiled(list91, expList, "测试用例ComLevelDict_014");
						
            expList.clear();
            List<BaseDictItem> list92= Dict.element("Dict18").expandClick("004 华北地区1").getChildren(false);
            expList.add(new BaseDictItem("jilin 吉林省",1,0));
            expList.add(new BaseDictItem("tianjin 天津市",1,0));			
            DictUtil.checkDictItemFiled(list92, expList,"测试用例ComLevelDict_014"); 
            Dict.element("Dict18").viewClick();
            waittime(1000);
//--------------------------------------------------------------------------------------------------------------			
			//检查根节点是否正确
            DictUtil.checkRootNode("Dict19", "地区", "测试用例ComLevelDict_015");
            Dict.element("Dict19").viewClick();
            
            //检查汇总节点各属性是否正确
        	expList.clear();
			List<BaseDictItem> list93= Dict.element("Dict19").viewClick().getChildren(true);
			expList.add(new BaseDictItem("003 华东地区1", 0, 1));
			DictUtil.checkDictItemFiled(list93, expList, "测试用例ComLevelDict_015");
			
			//检查明细节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list94=Dict.element("Dict19").expandClick("003 华东地区1").getChildren(false);
			expList.add(new BaseDictItem("jiangxi 江西省",2,0));	
			expList.add(new BaseDictItem("shanghai 上海市",2,0));
			DictUtil.checkDictItemFiled(list94, expList, "测试用例ComLevelDict_015");
			
			//选中"003"节点
			Dict.element("Dict19").itemClick("003 华东地区1");
			DictUtil.checkInputValue("Dict19", "003 华东地区1", "测试用例ComLevelDict_015");
			
			//保存表单
			ToolBar.element("ToolBar1").click("Save");
			
			//打开DictView
			MainContainer.selectTab(4);
            
			//更改"003"节点状态
			DictView.element().itemClick("003");
			ToolBar.element("main_toolbar").click("EnabledDict");
			
			//检查汇总节点各属性是否正确
			expItems.clear();
			List<BaseDictViewItem> items10=DictView.element().getChildren(true);
			expItems.add(new BaseDictViewItem("华东地区",1,1));
    		expItems.add(new BaseDictViewItem("华北地区",1,1));
    		expItems.add(new BaseDictViewItem("华东地区1",1,1));
    		expItems.add(new BaseDictViewItem("华北地区1",1,1));
    		expItems.add(new BaseDictViewItem("福建省",1,0));
    		DictUtil.checkDictViewItemFiled(items10, expItems, "测试用例ComLevelDict_015");
    		
    		//检查明细节点各属性是否正确
    		expItems.clear();
	    	List<BaseDictViewItem> items11=DictView.element().expandItemClick("001").itemClick("001").getChildren(false);
	    	expItems.add(new BaseDictViewItem("安徽省",1,0));
	    	expItems.add(new BaseDictViewItem("江苏省",1,0));
    		DictUtil.checkDictViewItemFiled(items11, expItems, "测试用例ComLevelDict_015");
    		
    		expItems.clear();
    		List<BaseDictViewItem> items12= DictView.element().expandItemClick("002").itemClick("002").getChildren(false);
    		expItems.add(new BaseDictViewItem("北京市",1,0));	
    		expItems.add(new BaseDictViewItem("河北省",1,0));			
			DictUtil.checkDictViewItemFiled(items12, expItems,"测试用例ComLevelDict_015"); 
			
			expItems.clear();
    		List<BaseDictViewItem> items13= DictView.element().expandItemClick("003").itemClick("003").getChildren(false);
    		expItems.add(new BaseDictViewItem("江西省",1,0));	
    		expItems.add(new BaseDictViewItem("上海市",1,0));
			DictUtil.checkDictViewItemFiled(items13, expItems,"测试用例ComLevelDict_015"); 
						
			expItems.clear();
    		List<BaseDictViewItem> items14= DictView.element().expandItemClick("004").itemClick("004").getChildren(false);
    		expItems.add(new BaseDictViewItem("吉林省",1,0));
    		expItems.add(new BaseDictViewItem("天津市",1,0));			
			DictUtil.checkDictViewItemFiled(items14, expItems,"测试用例ComLevelDict_015"); 
			
			//打开保存的表单	
			MainContainer.selectTab(0);
		    ListView.element("list").dbClick(1);
		    
		    //点击编辑
		    MainContainer.selectTab(7);
		    ToolBar.element("ToolBar1").click("Edit");
		    
		    //校验字典编辑框
		    DictUtil.checkInputValue("Dict19", "003 华东地区1", "测试用例ComLevelDict_015");
		    
			//检查汇总节点是否存在
		    expList.clear();
		    List<BaseDictItem> list95=Dict.element("Dict19").viewClick().getChildren(true);
		    DictUtil.checkDictItemFiled(list95, expList, "测试用例ComLevelDict_015");
		    waittime(1000);
//------------------------------------------------------------------------------------------------------------------------
		    //检查根节点是否正确
		    DictUtil.checkRootNode("Dict20", "地区", "测试用例ComLevelDict_016");
		    Dict.element("Dict20").viewClick();
		    //检查汇总节点各属性是否正确
		    expList.clear();
		    List<BaseDictItem> list96=Dict.element("Dict20").viewClick().getChildren(true);
			expList.add(new BaseDictItem("001 华东地区",1,1));
			expList.add(new BaseDictItem("002 华北地区",1,1));
			expList.add(new BaseDictItem("003 华东地区1", 1, 1));
			expList.add(new BaseDictItem("004 华北地区1",1,1));
			expList.add(new BaseDictItem("fujian 福建省",1,0));
			DictUtil.checkDictItemFiled(list96, expList, "测试用例ComLevelDict_016");
			
			//检查明细节点各属性是否正确
			expList.clear();
	    	List<BaseDictItem> list97=Dict.element("Dict20").expandClick("001 华东地区").getChildren(false);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
	    	expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
    		DictUtil.checkDictItemFiled(list97, expList, "测试用例ComLevelDict_016");
    		
    		expList.clear();
    		List<BaseDictItem> list98= Dict.element("Dict20").expandClick("002 华北地区").getChildren(false);
    		expList.add(new BaseDictItem("beijing 北京市",1,0));	
    		expList.add(new BaseDictItem("hebei 河北省",1,0));			
			DictUtil.checkDictItemFiled(list98, expList,"测试用例ComLevelDict_016"); 
			
			expList.clear();
    		List<BaseDictItem> list99= Dict.element("Dict20").expandClick("003 华东地区1").getChildren(false);
    		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
    		expList.add(new BaseDictItem("shanghai 上海市",1,0));
			DictUtil.checkDictItemFiled(list99, expList,"测试用例ComLevelDict_016"); 
						
			expList.clear();
    		List<BaseDictItem> list100= Dict.element("Dict20").expandClick("004 华北地区1").getChildren(false);
    		expList.add(new BaseDictItem("jilin 吉林省",1,0));
    		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
			DictUtil.checkDictItemFiled(list100, expList,"测试用例ComLevelDict_016"); 
		    
			//选中“001”
			Dict.element("Dict20").itemClick("001 华东地区");
	    	DictUtil.checkInputValue("Dict20", "001 华东地区", "测试用例ComLevelDict_016");
			
			//检查根节点是否正确
			DictUtil.checkRootNode("Dict21", "001 华东地区", "测试用例ComLevelDict_016");
			Dict.element("Dict21").viewClick();
			
			//检查子节点各属性是否正确
			expList.clear();
			List<BaseDictItem> list101=Dict.element("Dict21").viewClick().getChildren(true);
	    	expList.add(new BaseDictItem("anhui 安徽省",1,0));
	    	expList.add(new BaseDictItem("jiangsu 江苏省",1,0));
	    	DictUtil.checkDictItemFiled(list101, expList, "测试用例ComLevelDict_016");
	    	
	    	//选中“anhui”
	    	Dict.element("Dict21").itemClick("anhui 安徽省");
	    	DictUtil.checkInputValue("Dict21", "anhui 安徽省", "测试用例ComLevelDict_016");
	    	//清空root
	    	Dict.element("Dict20").clear().pressEnterKey();
	    	DictUtil.checkInputValue("Dict20", "", "测试用例ComLevelDict_016");
	    	DictUtil.checkInputValue("Dict21", "", "测试用例ComLevelDict_016");
	    	
	    	//选中“fujian”
	    	Dict.element("Dict20").viewClick().itemClick("fujian 福建省");
	    	DictUtil.checkInputValue("Dict20", "fujian 福建省", "测试用例ComLevelDict_016");
	    	
	    	//检查根节点是否正确
	    	DictUtil.checkRootNode("Dict21", "fujian 福建省", "测试用例ComLevelDict_016");
	    	Dict.element("Dict21").viewClick();
	    	
	    	//检查子节点是否存在
	        expList.clear();
	        List<BaseDictItem> list102=Dict.element("Dict21").viewClick().getChildren(true);
	        DictUtil.checkDictItemFiled(list102, expList, "测试用例ComLevelDict_016");
		    MainContainer.closeAllTab();
		    
//--------------------------------------------------------------------------------------------------------------
			MenuEntry.element("Dict/CustomBill").click();
			MenuEntry.element("Dict/CustomBill/Dict_Fr_003").dblClick();		
			MainContainer.selectTab(0);
			
			//检查汇总节点各属性是否正确
			expItems.clear();
			List<BaseDictViewItem> items15=DictView.element().getChildren(true);
			expItems.add(new BaseDictViewItem("华东地区",1,1));
			//expItems.add(new BaseDictViewItem("江苏省",1,0));
			DictUtil.checkDictViewItemFiled(items15, expItems, "测试用例ComLevelDict_017");
			
			//检测明细节点各属性是否正确
//			expItems.clear();
//			List<BaseDictViewItem> items16=DictView.element().expandItemClick("001").itemClick("001").getChildren(false);
//			expItems.add(new BaseDictViewItem("安徽省",1,0));
//			DictUtil.checkDictViewItemFiled(items16, expItems, "测试用例ComLevelDict_017");
			
			//数值框输入“1”
//			NumberEditor.element("NumberEditor1").clear().input("1").pressEnterKey();
//			NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "1", "测试用例ComLevelDict_017");
			
			//检查汇总节点是否正确
//			expItems.clear();
//			List<BaseDictViewItem> items17=DictView.element().getChildren(true);
//			expItems.add(new BaseDictViewItem("华东地区",1,1));
//			DictUtil.checkDictViewItemFiled(items17, expItems, "测试用例ComLevelDict_017");
			
			//检查明细节点是否存在
//			expItems.clear();
//			List<BaseDictViewItem> items18=DictView.element().expandItemClick("001").itemClick("001").getChildren(false);
//			DictUtil.checkDictViewItemFiled(items18, expItems, "测试用例ComLevelDict_017");
			
			//数值框输入“0”
			NumberEditor.element("NumberEditor1").clear().input("0").pressEnterKey();
			waittime(1000);
			
			//检查子节点是否正确
			expItems.clear();
			List<BaseDictViewItem> items19=DictView.element().getChildren(true);
			expItems.add(new BaseDictViewItem("江苏省",1,0));
			DictUtil.checkDictViewItemFiled(items19, expItems, "测试用例ComLevelDict_017");
//	        MainContainer.closeAllTab();
//--------------------------------------------------------------------------------------------------------------------
		    MenuEntry.element("Dict/CustomBill").click();
			MenuEntry.element("Dict/CustomBill/Material").dblClick();		
			MainContainer.selectTab(1);
			
			expItems.clear();
			List<BaseDictViewItem> items20=DictView.element().getChildren(true);
			expItems.add(new BaseDictViewItem("电子类",1,1));
			DictUtil.checkDictViewItemFiled(items20, expItems, "测试用例ComLevelDict_018");
			MainContainer.closeAllTab();
		}
}