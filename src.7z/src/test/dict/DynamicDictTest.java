package test.dict;

import java.util.ArrayList;
import java.util.List;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DynamicDictTest extends AbstractTestScript{

	public void run() {
		
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/CommonDynamicDictView").dblClick();		
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();		
		MainContainer.selectTab(1);
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict3", "地区", "测试用例CommonDynamicDict_01");
		Dict.element("DynamicDict3").viewClick();
		//检查汇总节点各属性是否正确
		List<BaseDictItem> expList = new ArrayList<BaseDictItem>();
		List<BaseDictItem> list= Dict.element("DynamicDict3").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1));
		expList.add(new BaseDictItem("002 华北地区",1,1));
		expList.add(new BaseDictItem("003 华东地区1",1,1));
		expList.add(new BaseDictItem("004 华北地区1",1,1));
		expList.add(new BaseDictItem("fujian 福建省",1,0));
		DictUtil.checkDictItemFiled(list, expList, "测试用例CommonDynamicDict_01");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list2=Dict.element("DynamicDict3").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));			
		DictUtil.checkDictItemFiled(list2, expList,"测试用例CommonDynamicDict_01"); 
		
		expList.clear();
		List<BaseDictItem> list3= Dict.element("DynamicDict3").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0));			
		DictUtil.checkDictItemFiled(list3, expList,"测试用例CommonDynamicDict_01"); 
		
		expList.clear();
		List<BaseDictItem> list4= Dict.element("DynamicDict3").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0));
		DictUtil.checkDictItemFiled(list4, expList,"测试用例CommonDynamicDict_01"); 
					
		expList.clear();
		List<BaseDictItem> list5= Dict.element("DynamicDict3").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0));
		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
		DictUtil.checkDictItemFiled(list5, expList,"测试用例CommonDynamicDict_01");  
	
		//选中“001”
		Dict.element("DynamicDict3").itemClick("001 华东地区");
		DictUtil.checkInputValue("DynamicDict3", "001 华东地区", "测试用例CommonDynamicDict_01");
		
		//选中"City"
		RadioButton.element("City").click();
		
		//字典编辑框为空
		DictUtil.checkInputValue("DynamicDict3", "",  "测试用例CommonDynamicDict_01");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict3", "城市", "测试用例CommonDynamicDict_01");
		Dict.element("DynamicDict3").viewClick();
		
		//检查子节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list6=Dict.element("DynamicDict3").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 上海市",1,0));
		expList.add(new BaseDictItem("002 北京市",1,0));
		expList.add(new BaseDictItem("003 天津市",1,0));
		expList.add(new BaseDictItem("004 江苏省",1,0));
		expList.add(new BaseDictItem("005 湖南省",1,0));
		expList.add(new BaseDictItem("006 安徽省",1,0));
		DictUtil.checkDictItemFiled(list6, expList, "测试用例CommonDynamicDict_01");
		Dict.element("DynamicDict3").viewClick();
//--------------------------------------------------------------------------------------------------
		//选中“地区”
		RadioButton.element("LevelDict").click();
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict2", "地区", "测试用例CommonDynamicDict_02");
		Dict.element("DynamicDict2").viewClick();
		//检查汇总节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list7= Dict.element("DynamicDict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1));
		expList.add(new BaseDictItem("002 华北地区",1,1));
		expList.add(new BaseDictItem("003 华东地区1",1,1));
		expList.add(new BaseDictItem("004 华北地区1",1,1));
		expList.add(new BaseDictItem("fujian 福建省",1,0));
		DictUtil.checkDictItemFiled(list7, expList, "测试用例CommonDynamicDict_02");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list8=Dict.element("DynamicDict2").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));			
		DictUtil.checkDictItemFiled(list8, expList,"测试用例CommonDynamicDict_02"); 
		
		expList.clear();
		List<BaseDictItem> list9= Dict.element("DynamicDict2").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0));			
		DictUtil.checkDictItemFiled(list9, expList,"测试用例CommonDynamicDict_02"); 
		
		expList.clear();
		List<BaseDictItem> list10= Dict.element("DynamicDict2").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0));
		DictUtil.checkDictItemFiled(list10, expList,"测试用例CommonDynamicDict_02"); 
					
		expList.clear();
		List<BaseDictItem> list11= Dict.element("DynamicDict2").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0));
		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
		DictUtil.checkDictItemFiled(list11, expList,"测试用例CommonDynamicDict_02");  
		
		//选中“001”
		Dict.element("DynamicDict2").itemClick("001 华东地区");
		DictUtil.checkInputValue("DynamicDict2", "001 华东地区", "测试用例CommonDynamicDict_02");
		
		//ComboBox1选中“汇总节点”
		ComboBox.element("ComboBox1").dropDownClick().itemClick("汇总节点");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "汇总节点", "测试用例CommonDynamicDict_02");
		waittime(100);
		DictUtil.checkInputValue("DynamicDict2", "", "测试用例CommonDynamicDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict2", "地区", "测试用例CommonDynamicDict_02");
		Dict.element("DynamicDict2").viewClick();
		//检查汇总节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list12= Dict.element("DynamicDict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1));
		expList.add(new BaseDictItem("002 华北地区",1,1));
		expList.add(new BaseDictItem("003 华东地区1",1,1));
		expList.add(new BaseDictItem("004 华北地区1",1,1));
		DictUtil.checkDictItemFiled(list12, expList, "测试用例CommonDynamicDict_02");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list13=Dict.element("DynamicDict2").expandClick("001 华东地区").getChildren(false);	
		DictUtil.checkDictItemFiled(list13, expList,"测试用例CommonDynamicDict_02"); 
		
		expList.clear();
		List<BaseDictItem> list14= Dict.element("DynamicDict2").expandClick("002 华北地区").getChildren(false);			
		DictUtil.checkDictItemFiled(list14, expList,"测试用例CommonDynamicDict_02"); 
		
		expList.clear();
		List<BaseDictItem> list15= Dict.element("DynamicDict2").expandClick("003 华东地区1").getChildren(false);
		DictUtil.checkDictItemFiled(list15, expList,"测试用例CommonDynamicDict_02"); 
					
		expList.clear();
		List<BaseDictItem> list16= Dict.element("DynamicDict2").expandClick("004 华北地区1").getChildren(false);		
		DictUtil.checkDictItemFiled(list16, expList,"测试用例CommonDynamicDict_02");  
		
		//选中“001”
		Dict.element("DynamicDict2").itemClick("001 华东地区");
		DictUtil.checkInputValue("DynamicDict2", "001 华东地区", "测试用例CommonDynamicDict_02");
		
		//ComboBox1选中“明细节点”
		ComboBox.element("ComboBox1").dropDownClick().itemClick("明细节点");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "明细节点", "测试用例CommonDynamicDict_02");
		waittime(100);
		DictUtil.checkInputValue("DynamicDict2", "", "测试用例CommonDynamicDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict2", "地区", "测试用例CommonDynamicDict_02");
		Dict.element("DynamicDict2").viewClick();
		//检查子节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list17= Dict.element("DynamicDict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("fujian 福建省",1,0));
		DictUtil.checkDictItemFiled(list17, expList, "测试用例CommonDynamicDict_02");
		
		//选中“福建省”
		Dict.element("DynamicDict2").itemClick("fujian 福建省");
		DictUtil.checkInputValue("DynamicDict2", "fujian 福建省", "测试用例CommonDynamicDict_02");
		
		//ComboBox1选中“不确定”
		ComboBox.element("ComboBox1").dropDownClick().itemClick("不确定");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "不确定", "测试用例CommonDynamicDict_02");
		waittime(100);
		DictUtil.checkInputValue("DynamicDict2", "", "测试用例CommonDynamicDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict2", "地区", "测试用例CommonDynamicDict_02");
		Dict.element("DynamicDict2").viewClick();
		//检查汇总节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list18= Dict.element("DynamicDict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1));
		expList.add(new BaseDictItem("002 华北地区",1,1));
		expList.add(new BaseDictItem("003 华东地区1",1,1));
		expList.add(new BaseDictItem("004 华北地区1",1,1));
		expList.add(new BaseDictItem("fujian 福建省",1,0));
		DictUtil.checkDictItemFiled(list18, expList, "测试用例CommonDynamicDict_02");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list19=Dict.element("DynamicDict2").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0));			
		DictUtil.checkDictItemFiled(list19, expList,"测试用例CommonDynamicDict_02"); 
		
		expList.clear();
		List<BaseDictItem> list20= Dict.element("DynamicDict2").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0));			
		DictUtil.checkDictItemFiled(list20, expList,"测试用例CommonDynamicDict_02"); 
		
		expList.clear();
		List<BaseDictItem> list21= Dict.element("DynamicDict2").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0));
		DictUtil.checkDictItemFiled(list21, expList,"测试用例CommonDynamicDict_02"); 
					
		expList.clear();
		List<BaseDictItem> list22= Dict.element("DynamicDict2").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0));
		expList.add(new BaseDictItem("tianjin 天津市",1,0));			
		DictUtil.checkDictItemFiled(list22, expList,"测试用例CommonDynamicDict_02");  
		
		//单选框选中“城市”
		RadioButton.element("City").click();
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict2", "城市", "测试用例CommonDynamicDict_02");
		Dict.element("DynamicDict2").viewClick();
		//检查子节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list23=Dict.element("DynamicDict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 上海市",1,0));
		expList.add(new BaseDictItem("002 北京市",1,0));
		expList.add(new BaseDictItem("003 天津市",1,0));
		expList.add(new BaseDictItem("004 江苏省",1,0));
		expList.add(new BaseDictItem("005 湖南省",1,0));
		expList.add(new BaseDictItem("006 安徽省",1,0));
		DictUtil.checkDictItemFiled(list23, expList, "测试用例CommonDynamicDict_02");
		
		//下拉框选中“汇总节点”
		ComboBox.element("ComboBox1").dropDownClick().itemClick("汇总节点");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "汇总节点", "测试用例CommonDynamicDict_02");
		waittime(100);
		DictUtil.checkInputValue("DynamicDict2", "", "测试用例CommonDynamicDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict2", "城市", "测试用例CommonDynamicDict_02");
		Dict.element("DynamicDict2").viewClick();
		
		//检查子节点是否存在
		expList.clear();
		List<BaseDictItem> list24=Dict.element("DynamicDict2").viewClick().getChildren(true);
		DictUtil.checkDictItemFiled(list24, expList, "测试用例CommonDynamicDict_02");
		
		//下拉框选中“明细节点”
		ComboBox.element("ComboBox1").dropDownClick().itemClick("明细节点");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "明细节点","测试用例CommonDynamicDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("DynamicDict2", "城市", "测试用例CommonDynamicDict_02");
		Dict.element("DynamicDict2").viewClick();
		//检查子节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list25=Dict.element("DynamicDict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 上海市",1,0));
		expList.add(new BaseDictItem("002 北京市",1,0));
		expList.add(new BaseDictItem("003 天津市",1,0));
		expList.add(new BaseDictItem("004 江苏省",1,0));
		expList.add(new BaseDictItem("005 湖南省",1,0));
		expList.add(new BaseDictItem("006 安徽省",1,0));
		DictUtil.checkDictItemFiled(list25, expList, "测试用例CommonDynamicDict_02");
	    MainContainer.closeAllTab();
		
		
		
		
		
		
		
		
		
		
	}
	
}
