package test.dict;

import java.util.ArrayList;
import java.util.List;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.DictView;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TabPanel;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class PublicDictTest extends AbstractTestScript {
	public void run() {

		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/PublicDictView").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);

		AssertUtil.checkEnabled(Dict.element("Dict1"), false, "测试用例PublicDict_01");
		AssertUtil.checkDisplayed(Dict.element("Dict2"), false, "测试用例PublicDict_02");
		AssertUtil.checkHovertext(Dict.element("Dict4"), "提示信息", "测试用例PublicDict_03");
		AssertUtil.checkRequired(Dict.element("Dict3"), true, "测试用例PublicDict_04");

		Dict.element("Dict3").viewClick().itemClick("Admin 系统管理员");
		// 选中“admin”
		Dict.element("Dict6").viewClick().itemClick("Admin 系统管理员");
		DictUtil.checkInputValue("Dict6", "Admin 系统管理员", "测试用例PublicDict_05");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "1.00", "测试用例PublicDict_05");

		// AssertUtil.uiCheck(Dict.element("Dict11"), true,
		// "测试用例PublicDict_06");
		// AssertUtil.checkErrorInfo(Dict.element("Dict11"), "必填",
		// "测试用例PublicDict_06");

		AssertUtil.uiCheck(Dict.element("Dict15"), true, "测试用例PublicDict_07");
		AssertUtil.checkErrorInfo(Dict.element("Dict15"), "必填", "测试用例PublicDict_07");
		Dict.element("Dict15").viewClick().itemClick("Admin 系统管理员");
		// 查看默认值
		DictUtil.checkInputValue("Dict9", "Admin 系统管理员", "测试用例PublicDict_08");
		// 查看节点选中状态
		DictUtil.checkItemChecked("Dict9", "Admin 系统管理员", true, "测试用例PublicDict_08");
		Dict.element("Dict9").viewClick().pressEnterKey();
		DictUtil.checkInputValue("Dict9", "Admin 系统管理员", "测试用例PublicDict_08");
		DictUtil.checkInputValue("Dict10", "Admin 系统管理员", "测试用例PublicDict_09");
		DictUtil.checkItemChecked("Dict10", "Admin 系统管理员", true, "测试用例PublicDict_09");
		Dict.element("Dict10").viewClick().pressEnterKey();
		DictUtil.checkInputValue("Dict10", "Admin 系统管理员", "测试用例PublicDict_09");
		DictUtil.checkInputValue("Dict14", "Admin 系统管理员,Guest 游客", "测试用例PublicDict_10");
		DictUtil.checkInputValue("Dict13", "Admin 系统管理员,Guest 游客", "测试用例PublicDict_11");
		DictUtil.checkRootState("Dict13", "2", "测试用例PublicDict_11");
		Dict.element("Dict13").dictButtonClick("确定");
		DictUtil.checkInputValue("Dict13", "Admin 系统管理员,Guest 游客", "测试用例PublicDict_11");
		// 字典加载策略
		DictUtil.checkRootNode("Dict25", "地区", "测试用例ComLevelDict_023");
		Dict.element("Dict25").viewClick();
		DictUtil.checkItemDisableSelect("Dict25", "001 华东地区", true, "测试用例ComLevelDict_023");
		List<BaseDictItem> expList = new ArrayList<BaseDictItem>();
		List<BaseDictItem> list1 = Dict.element("Dict25").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("jiangsu 江苏省", 1, 0));
		DictUtil.checkDictItemFiled(list1, expList, "Case_Dict_M4_023");
		// TextField
		Dict.element("Dict26").viewClick().itemClick("001 华东地区");
		DictUtil.checkInputValue("Dict26", "001", "Case_Dict_M4_023");
		Dict.element("Dict26").clear();
		Dict.element("Dict26").viewClick().itemClick("002 华北地区");
		DictUtil.checkInputValue("Dict26", "002", "Case_Dict_M4_023");
		// FormulaText
		Dict.element("Dict27").viewClick().itemClick("001 华东地区");
		DictUtil.checkInputValue("Dict27", "001--华东地区", "Case_Dict_M4_023");
		ToolBarButton.element("保存").click();
		ToolBarButton.element("关闭").click();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);
		ToolBarButton.element("编辑").click();
		waittime(500);
		DictUtil.checkInputValue("Dict26", "002", "Case_Dict_M4_023");
		DictUtil.checkInputValue("Dict27", "001--华东地区", "Case_Dict_M4_023");
		// 字典缓存更新
		Button.element("Button1").click();
		waittime(1000);
		TextEditor.element("TextEditor1").getText();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "Guest", "Case_Dict_M4_024");
		MainContainer.closeAllTab();
		MenuEntry.element("Common/System").click();
		MenuEntry.element("Common/System/Operator").dblClick();
		MainContainer.selectTab(0);
		DictView.element().itemClick("Guest");
		ToolBar.element("main_toolbar").click("Modify");
		AbstractComponent.setFormID(AbstractComponent.getFormID() + 1);
		TextEditor.element("Code").clear().input("Guest1");
		AbstractComponent.setFormID(AbstractComponent.getFormID() - 1);
		ToolBar.element("main_toolbar").click("Save");
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/PublicDictView").dblClick();
		MainContainer.selectTab(1);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(2);
		Button.element("Button1").click();
		waittime(1000);
		TextEditor.element("TextEditor1").getText();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "Guest1", "Case_Dict_M4_024");
		// DictView容器合并属性
		MainContainer.closeAllTab();
		MenuEntry.element("Common/System").click();
		MenuEntry.element("Common/System/Operator").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("NewDict");
		ToolBar.element("main_toolbar").click("optKey1");
		ConfirmDialog.element().okClick();
		ToolBar.element("main_toolbar").click("Cancel");
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/PublicDictView").dblClick();
		MainContainer.selectTab(1);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(2);

		TabPanel.element("TabPanel1").selectTab(1);
		AssertUtil.checkHalign(Dict.element("Dict16"), "left", "测试用例PublicDict_12");
		AssertUtil.checkHalign(Dict.element("Dict17"), "right", "测试用例PublicDict_13");
		AssertUtil.checkHalign(Dict.element("Dict18"), "center", "测试用例PublicDict_14");
		AssertUtil.checkForeColor(Dict.element("Dict19"), "153, 204, 153", "测试用例PublicDict_15");
		AssertUtil.checkBackColor(Dict.element("Dict20"), "204, 255, 255", "测试用例PublicDict_16");
		AssertUtil.checkFontName(Dict.element("Dict21"), "Arial", "测试用例PublicDict_17");
		AssertUtil.checkFontSize(Dict.element("Dict22"), "20px", "测试用例PublicDict_18");
		AssertUtil.checkFontWeight(Dict.element("Dict23"), "bold", "测试用例PublicDict_19");
		AssertUtil.checkFontStyle(Dict.element("Dict24"), "italic", "测试用例PublicDict_20");
		MainContainer.closeAllTab();
	}
}
