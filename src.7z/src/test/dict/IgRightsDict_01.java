package test.dict;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.dictquerybox.BaseDictQueryItem;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.DictQueryBox;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class IgRightsDict_01 extends AbstractTestScript {
	public void run() {
		logOut();
		doLogin("User1", "");
		waittime(1000);
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/Dict_Ig_RightsView").dblClick();
		MainContainer.selectTab(0);
		// 3.点击"新增"
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);
		// 4.打开字典"IgnoreRights=true"
		List<BaseDictItem> expList = new ArrayList<BaseDictItem>();
		List<BaseDictItem> list = Dict.element("Dict1").viewClick().getChildren(true);
		expList.add(new BaseDictItem("A01", 1, 0));
		expList.add(new BaseDictItem("A02", 1, 0));
		expList.add(new BaseDictItem("A03", 1, 0));
		DictUtil.checkDictItemFiled(list, expList, "测试用例IgRightsDict_01");
		Dict.element("Dict1").viewClick();
		// 5.点击字典"IgnoreRights=true";输入：A； 移动光标
		
		Dict.element("Dict1").input("a");
	
		Dict.element("Dict1").inputClick().pressEnterKey();
		// 弹出查询框
		List<BaseDictQueryItem> expSet = new ArrayList<BaseDictQueryItem>();

		List<BaseDictQueryItem> set = DictQueryBox.element("Dict1").getChildren();
		expSet.add(new BaseDictQueryItem("上海", "A01", 0));
		expSet.add(new BaseDictQueryItem("北京", "A02", 0));
		expSet.add(new BaseDictQueryItem("深圳", "A03", 0));
		DictUtil.checkQueryBoxItemFiled(set, expSet, "测试用例IgRightsDict_01");
		// 7.点击"取消"
		DictQueryBox.element("Dict1").queryBoxButtonClick("取消");
		// 8.输入：深圳
		Dict.element("Dict1").input("深圳").pressEnterKey();
		DictUtil.checkInputValue("Dict1", "A03 深圳", "测试用例IgRightsDict_01");
		// 9.清空字典"IgnoreRights=true"
		Dict.element("Dict1").clear();
		// 10.点击字典"IgnoreRights=true"下拉箭头;输入：A;点击查询
		expList.clear();
		List<BaseDictItem> list1 = Dict.element("Dict1").viewClick().searchBoxInput("A").searchButtonClick() .getChildren(true);
		expList.add(new BaseDictItem("A01", 1, 0));
		expList.add(new BaseDictItem("A02", 1, 0));
		expList.add(new BaseDictItem("A03", 1, 0));
		DictUtil.checkDictItemFiled(list1, expList, "测试用例IgRightsDict_01");
		// 13.删除：A
		Dict.element("Dict1").searchInputClear().viewClick();
		// 14.输入：深圳;15.点击查询
		expList.clear();
		List<BaseDictItem> list2 = Dict.element("Dict1").viewClick().searchBoxInput("深圳").searchButtonClick()
				.getChildren(true);
		expList.add(new BaseDictItem("A03", 1, 0));
		DictUtil.checkDictItemFiled(list2, expList, "测试用例IgRightsDict_01");
		Dict.element("Dict1").viewClick();
		// 15.打开字典"IgnoreRights=false"
		expList.clear();
		List<BaseDictItem> list3 = Dict.element("Dict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("A01", 1, 0));
		expList.add(new BaseDictItem("A02", 1, 0));
		DictUtil.checkDictItemFiled(list3, expList, "测试用例IgRightsDict_01");
		Dict.element("Dict2").viewClick();
		// 16.点击字典"IgnoreRights=false";17.输入：A；移动光标
		Dict.element("Dict2").input("A").pressEnterKey();
		expSet.clear();
		List<BaseDictQueryItem> set1 = DictQueryBox.element("Dict2").getChildren();
		expSet.add(new BaseDictQueryItem("上海", "A01", 0));
		expSet.add(new BaseDictQueryItem("北京", "A02", 0));
		DictUtil.checkQueryBoxItemFiled(set1, expSet, "测试用例IgRightsDict_01");
		// 18.点击"取消";19.输入：深圳
		DictQueryBox.element("Dict2").queryBoxButtonClick("取消");
		Dict.element("Dict2").input("深圳").pressEnterKey();
		expSet.clear();
		List<BaseDictQueryItem> set2 = DictQueryBox.element("Dict2").getChildren();
		DictUtil.checkQueryBoxItemFiled(set2, expSet, "测试用例IgRightsDict_01");
		DictQueryBox.element("Dict2").queryBoxButtonClick("取消");
		// 21.点击字典"IgnoreRights=false"下拉箭头;22.输入：A;23.点击查询
		expList.clear();
		List<BaseDictItem> list4 = Dict.element("Dict2").viewClick().searchBoxInput("A").searchButtonClick().getChildren(true);
		expList.add(new BaseDictItem("A01", 1, 0));
		expList.add(new BaseDictItem("A02", 1, 0));
		DictUtil.checkDictItemFiled(list4, expList, "测试用例IgRightsDict_01");
		Dict.element("Dict2").searchInputClear().viewClick();
		expList.clear();
		List<BaseDictItem> list5 = Dict.element("Dict2").viewClick().searchBoxInput("深圳").searchButtonClick().getChildren(true);
		DictUtil.checkDictItemFiled(list5, expList, "测试用例IgRightsDict_01");
        Dict.element("Dict2").viewClick();

        System.out.println("==========================================================================================================");
		
		
		
	}

}
