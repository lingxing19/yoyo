package test.dict;

import java.util.ArrayList;
import java.util.List;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CheckBoxDictTest extends AbstractTestScript{
	public void run(){
		
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/DXDictView").dblClick();		
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();		
		MainContainer.selectTab(1);
		
		//勾选根节点
		Dict.element("Dict1").viewClick().itemCheckClick("地区").dictButtonClick("确定");
		DictUtil.checkInputValue("Dict1", "", "测试用例DXDict_01");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("Dict1", "地区", "测试用例DXDict_01");		
		Dict.element("Dict1").viewClick();
		DictUtil.checkRootState("Dict1", "1", "测试用例DXDict_01");
		Dict.element("Dict1").viewClick();
		//检查汇总节点各属性是否正确
		List<BaseDictItem> expList = new ArrayList<BaseDictItem>();
		List<BaseDictItem> list= Dict.element("Dict1").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1,0));
		expList.add(new BaseDictItem("002 华北地区",1,1,0));
		expList.add(new BaseDictItem("003 华东地区1",1,1,0));
		expList.add(new BaseDictItem("004 华北地区1",1,1,0));
		expList.add(new BaseDictItem("fujian 福建省",1,0,0));
		DictUtil.checkDictItemFiled(list, expList, "测试用例DXDict_01");
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list1= Dict.element("Dict1").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0,0));			
		DictUtil.checkDictItemFiled(list1, expList,"测试用例DXDict_01"); 
		
		expList.clear();
		List<BaseDictItem> list2= Dict.element("Dict1").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0,0));			
		DictUtil.checkDictItemFiled(list2, expList,"测试用例DXDict_01"); 
		
		expList.clear();
		List<BaseDictItem> list3= Dict.element("Dict1").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0,0));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0,0));
		DictUtil.checkDictItemFiled(list3, expList,"测试用例DXDict_01"); 
					
		expList.clear();
		List<BaseDictItem> list4= Dict.element("Dict1").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0,0));
		expList.add(new BaseDictItem("tianjin 天津市",1,0,0));			
		DictUtil.checkDictItemFiled(list4, expList,"测试用例DXDict_01"); 
		Dict.element("Dict1").viewClick();
		//勾选“华东地区”/“华北地区”
		Dict.element("Dict1").viewClick().itemCheckClick("001 华东地区").itemCheckClick("002 华北地区").dictButtonClick("确定");
		DictUtil.checkInputValue("Dict1", "001 华东地区,002 华北地区", "测试用例DXDict_01");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("Dict1", "地区", "测试用例DXDict_01");
		Dict.element("Dict1").viewClick();
		DictUtil.checkRootState("Dict1", "1", "测试用例DXDict_01");
		Dict.element("Dict1").viewClick();
		
		//检查汇总节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list5=Dict.element("Dict1").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1,1));
		expList.add(new BaseDictItem("002 华北地区",1,1,1));
		expList.add(new BaseDictItem("003 华东地区1",1,1,0));
		expList.add(new BaseDictItem("004 华北地区1",1,1,0));
		expList.add(new BaseDictItem("fujian 福建省",1,0,0));
		DictUtil.checkDictItemFiled(list5, expList, "测试用例DXDict_01");
		
		Dict.element("Dict1").expandClick("001 华东地区").expandClick("002 华北地区").expandClick("003 华东地区1").expandClick("004 华北地区1");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list6=Dict.element("Dict1").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0,0));			
		DictUtil.checkDictItemFiled(list6, expList,"测试用例DXDict_01"); 
		
		expList.clear();
		List<BaseDictItem> list7= Dict.element("Dict1").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0,0));			
		DictUtil.checkDictItemFiled(list7, expList,"测试用例DXDict_01"); 
		
		expList.clear();
		List<BaseDictItem> list8= Dict.element("Dict1").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0,0));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0,0));
		DictUtil.checkDictItemFiled(list8, expList,"测试用例DXDict_01"); 
					
		expList.clear();
		List<BaseDictItem> list9= Dict.element("Dict1").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0,0));
		expList.add(new BaseDictItem("tianjin 天津市",1,0,0));			
		DictUtil.checkDictItemFiled(list9, expList,"测试用例DXDict_01"); 
		Dict.element("Dict1").viewClick();
		
		//勾选“福建省”,“吉林省”
		Dict.element("Dict1").viewClick().itemCheckClick("fujian 福建省").itemCheckClick("jilin 吉林省").dictButtonClick("确定");
		DictUtil.checkInputValue("Dict1", "001 华东地区,002 华北地区,fujian 福建省,jilin 吉林省", "测试用例DXDict_01");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("Dict1", "地区", "测试用例DXDict_01");
		Dict.element("Dict1").viewClick();
		DictUtil.checkRootState("Dict1", "1", "测试用例DXDict_01");
		Dict.element("Dict1").viewClick();
		
		//检查汇总节点各属性是否正确
		expList.clear();
	    List<BaseDictItem> list10= Dict.element("Dict1").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1,1));
		expList.add(new BaseDictItem("002 华北地区",1,1,1));
		expList.add(new BaseDictItem("003 华东地区1",1,1,0));
		expList.add(new BaseDictItem("004 华北地区1",1,1,0));
		expList.add(new BaseDictItem("fujian 福建省",1,0,1));
		DictUtil.checkDictItemFiled(list10, expList, "测试用例DXDict_01");
		
		Dict.element("Dict1").expandClick("001 华东地区").expandClick("002 华北地区").expandClick("003 华东地区1").expandClick("004 华北地区1");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list11=Dict.element("Dict1").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0,0));	
		DictUtil.checkDictItemFiled(list11, expList, "测试用例DXDict_01");
		
		expList.clear();
		List<BaseDictItem> list12=Dict.element("Dict1").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0,0));		
		DictUtil.checkDictItemFiled(list12, expList, "测试用例DXDict_01");
		
		expList.clear();
		List<BaseDictItem> list13=Dict.element("Dict1").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0,0));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0,0));
		DictUtil.checkDictItemFiled(list13, expList, "测试用例DXDict_01");
		
		expList.clear();
		List<BaseDictItem>list14=Dict.element("Dict1").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0,1));
		expList.add(new BaseDictItem("tianjin 天津市",1,0,0));
		DictUtil.checkDictItemFiled(list14, expList, "测试用例DXDict_01");
		Dict.element("Dict1").viewClick();
//----------------------------------------------------------------------------------------------------------
		//勾选根节点
		Dict.element("Dict2").viewClick().itemCheckClick("地区").dictButtonClick("确定");
		DictUtil.checkInputValue("Dict2", "全选", "测试用例DXDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("Dict2", "地区", "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();
		DictUtil.checkRootState("Dict2", "1", "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();
		
		//检查汇总节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list15=Dict.element("Dict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1,1));
		expList.add(new BaseDictItem("002 华北地区",1,1,1));
		expList.add(new BaseDictItem("003 华东地区1",1,1,1));
		expList.add(new BaseDictItem("004 华北地区1",1,1,1));
		expList.add(new BaseDictItem("fujian 福建省",1,0,1));
		DictUtil.checkDictItemFiled(list15, expList, "测试用例DXDict_02");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem> list16=Dict.element("Dict2").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0,1));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0,1));
		DictUtil.checkDictItemFiled(list16, expList,  "测试用例DXDict_02");
		
		expList.clear();
		List<BaseDictItem> list17=Dict.element("Dict2").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0,1));	
		expList.add(new BaseDictItem("hebei 河北省",1,0,1));	
		DictUtil.checkDictItemFiled(list17, expList, "测试用例DXDict_02");
		
		expList.clear();
		List<BaseDictItem> list18=Dict.element("Dict2").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0,1));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0,1));
		DictUtil.checkDictItemFiled(list18, expList, "测试用例DXDict_02");
		
		expList.clear();
		List<BaseDictItem>list19=Dict.element("Dict2").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0,1));
		expList.add(new BaseDictItem("tianjin 天津市",1,0,1));
		DictUtil.checkDictItemFiled(list19, expList, "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();
		
		//撤销"001 华东地区","002 华北地区"
		Dict.element("Dict2").viewClick().itemCheckClick("001 华东地区").itemCheckClick("002 华北地区").dictButtonClick("确定");
		DictUtil.checkInputValue("Dict2", "003 华东地区1,004 华北地区1,fujian 福建省", "测试用例DXDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("Dict2","地区", "测试用例DXDict_02"); 
		Dict.element("Dict2").viewClick();
		DictUtil.checkRootState("Dict2", "2", "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();
		
		//检查汇总节点各属性是否正确
		expList.clear();
		List<BaseDictItem>list20=Dict.element("Dict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1,0));
		expList.add(new BaseDictItem("002 华北地区",1,1,0));
		expList.add(new BaseDictItem("003 华东地区1",1,1,1));
		expList.add(new BaseDictItem("004 华北地区1",1,1,1));
		expList.add(new BaseDictItem("fujian 福建省",1,0,1));
		DictUtil.checkDictItemFiled(list20, expList, "测试用例DXDict_02");
		
		Dict.element("Dict2").expandClick("001 华东地区").expandClick("002 华北地区").expandClick("003 华东地区1").expandClick("004 华北地区1");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem>list21=Dict.element("Dict2").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0,0));
		DictUtil.checkDictItemFiled(list21, expList, "测试用例DXDict_02");
		
		expList.clear();
		List<BaseDictItem> list22=Dict.element("Dict2").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0,0));	
	    DictUtil.checkDictItemFiled(list22, expList, "测试用例DXDict_02");	
		
	    expList.clear();
	    List<BaseDictItem> list23=Dict.element("Dict2").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0,1));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0,1));
		DictUtil.checkDictItemFiled(list23, expList, "测试用例DXDict_02");
		
		expList.clear();
		List<BaseDictItem> list24=Dict.element("Dict2").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0,1));
		expList.add(new BaseDictItem("tianjin 天津市",1,0,1));
		DictUtil.checkDictItemFiled(list24, expList, "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();

		//撤销"吉林省","天津市"
		Dict.element("Dict2").viewClick().itemCheckClick("jilin 吉林省").itemCheckClick("tianjin 天津市").dictButtonClick("确定");
		DictUtil.checkInputValue("Dict2", "003 华东地区1,fujian 福建省", "测试用例DXDict_02");
		
		//检查根节点是否正确
		DictUtil.checkRootNode("Dict2","地区", "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();
		DictUtil.checkRootState("Dict2", "2", "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();
		
		//检查汇总节点各属性是否正确
		expList.clear();
		List<BaseDictItem>list25=Dict.element("Dict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001 华东地区",1,1,0));
		expList.add(new BaseDictItem("002 华北地区",1,1,0));
		expList.add(new BaseDictItem("003 华东地区1",1,1,1));
		expList.add(new BaseDictItem("004 华北地区1",1,1,0));
		expList.add(new BaseDictItem("fujian 福建省",1,0,1));
		DictUtil.checkDictItemFiled(list25, expList, "测试用例DXDict_02");
		Dict.element("Dict2").expandClick("001 华东地区").expandClick("002 华北地区").expandClick("003 华东地区1").expandClick("004 华北地区1");
		
		//检查明细节点各属性是否正确
		expList.clear();
		List<BaseDictItem>list26=Dict.element("Dict2").expandClick("001 华东地区").getChildren(false);
		expList.add(new BaseDictItem("anhui 安徽省",1,0,0));
		expList.add(new BaseDictItem("jiangsu 江苏省",1,0,0));
		DictUtil.checkDictItemFiled(list26, expList, "测试用例DXDict_02");
		
		expList.clear();
		List<BaseDictItem> list27=Dict.element("Dict2").expandClick("002 华北地区").getChildren(false);
		expList.add(new BaseDictItem("beijing 北京市",1,0,0));	
		expList.add(new BaseDictItem("hebei 河北省",1,0,0));	
	    DictUtil.checkDictItemFiled(list27, expList, "测试用例DXDict_02");	
		
	    expList.clear();
	    List<BaseDictItem> list28=Dict.element("Dict2").expandClick("003 华东地区1").getChildren(false);
		expList.add(new BaseDictItem("jiangxi 江西省",1,0,1));	
		expList.add(new BaseDictItem("shanghai 上海市",1,0,1));
		DictUtil.checkDictItemFiled(list28, expList, "测试用例DXDict_02");
		
		expList.clear();
		List<BaseDictItem> list29=Dict.element("Dict2").expandClick("004 华北地区1").getChildren(false);
		expList.add(new BaseDictItem("jilin 吉林省",1,0,0));
		expList.add(new BaseDictItem("tianjin 天津市",1,0,0));
		DictUtil.checkDictItemFiled(list29, expList, "测试用例DXDict_02");
		Dict.element("Dict2").viewClick();
//--------------------------------------------------------------------------------------------------------------
		Dict.element("Dict3").viewClick().itemClick("地区");
		DictUtil.checkInputValue("Dict3", "",  "测试用例DXDict_03");
		
		Dict.element("Dict3").viewClick().itemClick("001 华东地区");
		DictUtil.checkInputValue("Dict3", "001 华东地区",  "测试用例DXDict_03");
		
		Dict.element("Dict3").viewClick().itemClick("002 华北地区");
		DictUtil.checkInputValue("Dict3", "002 华北地区",  "测试用例DXDict_03");

	    MainContainer.closeAllTab();
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
