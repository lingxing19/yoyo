package test.dict;

import java.util.ArrayList;
import java.util.List;

import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.dictquerybox.BaseDictQueryItem;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.DictQueryBox;
import com.bokesoft.yes.autotest.component.factory.DictView;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class ChainDictTest extends AbstractTestScript{

	public void run(){
		
		MenuEntry.element("Dict/NewGroup").click();
		MenuEntry.element("Dict/NewGroup/ComChainDictView").dblClick();		
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();		
		MainContainer.selectTab(1);
		waittime(500);
		//检查页码是否正确
		DictUtil.checkDictPage("Dict1", "1", "测试用例ComChainDict_001");
		Dict.element("Dict1").viewClick();
		//检查节点是否正确
		List<BaseDictItem> expList = new ArrayList<BaseDictItem>();
		List<BaseDictItem> list= Dict.element("Dict1").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list, expList, "测试用例ComChainDict_001");
		
		//选中“001 人员1”
		Dict.element("Dict1").chainItemClick("001", "确定");
		DictUtil.checkInputValue("Dict1", "001  人员1", "测试用例ComChainDict_001");
		
		//删除"人员1"		
		//Dict.element("Dict1").pressBackspaceKey();
		//Dict.element("Dict1").pressBackspaceKey();
		//Dict.element("Dict1").pressBackspaceKey();
		//Dict.element("Dict1").pressBackspaceKey();
		//Dict.element("Dict1").pressEnterKey();
		//DictUtil.checkInputValue("Dict1", "001 人员1", "测试用例ComChainDict_001");		

		//清除"001"
		Dict.element("Dict1").pressBackspaceKey(3,5);
		Dict.element("Dict1").pressEnterKey();
		waittime(500);
	    //弹出查询框
	    List<BaseDictQueryItem> expSet = new ArrayList<BaseDictQueryItem>();
	    List<BaseDictQueryItem> set = DictQueryBox.element("Dict1").getChildren();
	    expSet.add(new BaseDictQueryItem("人员1","001",0));
	    expSet.add(new BaseDictQueryItem("人员10","010",0));
		DictUtil.checkQueryBoxItemFiled(set, expSet, "测试用例ComChainDict_001");
		
		//关闭查询框
		DictQueryBox.element("Dict1").queryBoxButtonClick("取消");
//---------------------------------------------------------------------------------------
		expList.clear();
		List<BaseDictItem> list1= Dict.element("Dict8").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		DictUtil.checkDictItemFiled(list1, expList, "测试用例ComChainDict_002");
		Dict.element("Dict8").viewClick();
		DictUtil.checkDictPage("Dict8", "1", "测试用例ComChainDict_002");
		
		//选中radiobutton2
		RadioButton.element("RadioButton2").click();			

		expList.clear();
		List<BaseDictItem> list2= Dict.element("Dict8").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list2, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		//List<BaseDictItem> list3= Dict.element("Dict8").nextPageClick().getChildren(true);
		List<BaseDictItem> list3= Dict.element("Dict8").numClick(2).getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list3, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		List<BaseDictItem> list4= Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list4, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		List<BaseDictItem> list5=Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list5, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		List<BaseDictItem> list6= Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list6, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		List<BaseDictItem> list7= Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list7, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		List<BaseDictItem> list8= Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list8, expList, "测试用例ComChainDict_002");

		expList.clear();
		List<BaseDictItem> list9=Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list9, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		List<BaseDictItem> list10= Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list10, expList, "测试用例ComChainDict_002");

		expList.clear();
		List<BaseDictItem> list11= Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list11, expList, "测试用例ComChainDict_002");
		
		expList.clear();
		List<BaseDictItem> list12=Dict.element("Dict8").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list12, expList, "测试用例ComChainDict_002");
		Dict.element("Dict8").viewClick();
//------------------------------------------------------------------------------------------------------------
		
		expList.clear();
		List<BaseDictItem> list13= Dict.element("Dict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list13, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list14= Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list14, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list15= Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list15, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list16= Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list16, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list17= Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list17, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list18= Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list18, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list19= Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list19, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list20=Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list20, expList, "测试用例ComChainDict_003");

		expList.clear();
		List<BaseDictItem> list21=Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list21, expList, "测试用例ComChainDict_003");

		expList.clear();
		List<BaseDictItem> list22=Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list22, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list23=Dict.element("Dict2").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list23, expList, "测试用例ComChainDict_003");
		
		//选中radiobutton4
		RadioButton.element("RadioButton4").click();
		
		DictUtil.checkDictPage("Dict2", "1", "测试用例ComChainDict_003");	
		Dict.element("Dict2").viewClick();
		expList.clear();
		List<BaseDictItem> list24= Dict.element("Dict2").viewClick().getChildren(true);
		expList.add(new BaseDictItem("100",1,0));
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list24, expList, "测试用例ComChainDict_003");
		Dict.element("Dict2").viewClick();
//-------------------------------------------------------------------------------------------------------------
		
		expList.clear();
		List<BaseDictItem> list25= Dict.element("Dict3").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list25, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list26= Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list26, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list27=Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list27, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list28= Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list28, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list29= Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list29, expList, "测试用例ComChainDict_003");
		
		expList.clear();
		List<BaseDictItem> list30= Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list30, expList, "测试用例ComChainDict_004");

		expList.clear();
		List<BaseDictItem> list31=Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list31, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list32=Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list32, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list33=Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list33, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list34 = Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list34, expList, "测试用例ComChainDict_004");
		
		expList.clear();
		List<BaseDictItem> list35= Dict.element("Dict3").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list35, expList, "测试用例ComChainDict_004");
		
		//选中RadioButton6
		RadioButton.element("RadioButton6").click();
		
		DictUtil.checkDictPage("Dict3", "1", "测试用例ComChainDict_004");	
		Dict.element("Dict3").viewClick();
		expList.clear();
		List<BaseDictItem> list36= Dict.element("Dict3").viewClick().getChildren(true);
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list36, expList, "测试用例ComChainDict_004");
		Dict.element("Dict3").viewClick();
//----------------------------------------------------------------------------------------------------------
		DictUtil.checkDictPage("Dict12", "1" ,"测试用例ComChainDict_005");
		Dict.element("Dict12").viewClick();
		expList.clear();
		List<BaseDictItem> list37= Dict.element("Dict12").viewClick().getChildren(true);
		expList.add(new BaseDictItem("100",1,0));
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list37, expList, "测试用例ComChainDict_005");
		Dict.element("Dict12").viewClick();
//-----------------------------------------------------------------------------------------------------------
		expList.clear();
		List<BaseDictItem> list38= Dict.element("Dict13").viewClick().getChildren(true);
		DictUtil.checkDictItemFiled(list38, expList, "测试用例ComChainDict_006");
		
		//选中RadioButton7
		RadioButton.element("RadioButton7").click();
		
		DictUtil.checkDictPage("Dict13", "1","测试用例ComChainDict_006" );
		Dict.element("Dict13").viewClick();
		expList.clear();
		List<BaseDictItem> list39= Dict.element("Dict13").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		DictUtil.checkDictItemFiled(list39, expList, "测试用例ComChainDict_006");
		Dict.element("Dict13").viewClick();
//------------------------------------------------------------------------------------------------		
		expList.clear();
		List<BaseDictItem> list40= Dict.element("Dict11").viewClick().getChildren(true);
		expList.add(new BaseDictItem("009",1,0));
		DictUtil.checkDictItemFiled(list40, expList, "测试用例ComChainDict_007");
		Dict.element("Dict11").viewClick();
//------------------------------------------------------------------------------------------------
		expList.clear();
		List<BaseDictItem> list41= Dict.element("Dict22").viewClick().getChildren(true);
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list41, expList, "测试用例ComChainDict_008");
		Dict.element("Dict22").viewClick();
//------------------------------------------------------------------------------------------------
		expList.clear();
		List<BaseDictItem> list42= Dict.element("Dict4").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list42, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list43= Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list43, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list44=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list44, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list45=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list45, expList, "测试用例ComChainDict_009");

		expList.clear();
		List<BaseDictItem> list46=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list46, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list47=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list47, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list48=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list48, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list49=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list49, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list50=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list50, expList, "测试用例ComChainDict_009");

		expList.clear();
		List<BaseDictItem> list51=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list51, expList, "测试用例ComChainDict_009");

		expList.clear();
		List<BaseDictItem> list52=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list52, expList, "测试用例ComChainDict_009");
		
		//勾选CheckBox1
		CheckBox.element("CheckBox1").click();
		
		expList.clear();
		List<BaseDictItem> list53= Dict.element("Dict4").viewClick().getChildren(true);
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list53, expList, "测试用例ComChainDict_009");
		
		//撤销勾选CheckBox1
		CheckBox.element("CheckBox1").click();
		
		expList.clear();
		List<BaseDictItem> list54= Dict.element("Dict4").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list54, expList, "测试用例ComChainDict_009");
		

		expList.clear();
		//List<BaseDictItem> list55=Dict.element("Dict4").nextPageClick().getChildren(true);
		List<BaseDictItem> list55=Dict.element("Dict4").numClick(2).getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list55, expList, "测试用例ComChainDict_009");
		
	
		expList.clear();
		List<BaseDictItem> list56=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list56, expList, "测试用例ComChainDict_009");

		expList.clear();
		List<BaseDictItem> list57=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list57, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list58=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list58, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list59=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list59, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list60=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list60, expList, "测试用例ComChainDict_009");
		
		expList.clear();
		List<BaseDictItem> list61=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list61, expList, "测试用例ComChainDict_009");

		expList.clear();
		List<BaseDictItem> list62=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list62, expList, "测试用例ComChainDict_009");

		expList.clear();
		List<BaseDictItem> list63=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list63, expList, "测试用例ComChainDict_009");

		expList.clear();
		List<BaseDictItem> list64=Dict.element("Dict4").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list64, expList, "测试用例ComChainDict_009");
		Dict.element("Dict4").viewClick();
//-------------------------------------------------------------------------------------------------		
		expList.clear();
		List<BaseDictItem> list65= Dict.element("Dict6").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list65, expList, "测试用例ComChainDict_010");

		expList.clear();
		List<BaseDictItem> list66= Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list66, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list67= Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list67, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list68=Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list68, expList, "测试用例ComChainDict_010");

		expList.clear();
		List<BaseDictItem> list69=Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list69, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list70=Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list70, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list71= Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list71, expList, "测试用例ComChainDict_010");

		expList.clear();
		List<BaseDictItem> list72=Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list72, expList, "测试用例ComChainDict_010");

		expList.clear();
		List<BaseDictItem> list73=Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list73, expList, "测试用例ComChainDict_010");

		expList.clear();
		List<BaseDictItem> list74=Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list74, expList, "测试用例ComChainDict_010");

		expList.clear();
		List<BaseDictItem> list75=Dict.element("Dict6").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list75, expList, "测试用例ComChainDict_010");
		
		//勾选"CheckBox2"
		//CheckBox.element("CheckBox2").click();
		
		/**
		expList.clear();
		List<BaseDictItem> list76= Dict.element("Dict6").viewClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list76, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list77=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
	
		DictUtil.checkDictItemFiled(list77, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list78=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
	
		DictUtil.checkDictItemFiled(list78, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list79=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
	
		DictUtil.checkDictItemFiled(list79, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list80= Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0)); 
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
	
		DictUtil.checkDictItemFiled(list80, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list81=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list81, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list82=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list82, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list83=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list83, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list84=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list84, expList, "测试用例ComChainDict_010");

		expList.clear();
		List<BaseDictItem> list85=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list85, expList, "测试用例ComChainDict_010");
		
		expList.clear();
		List<BaseDictItem> list86=Dict.element("Dict6").lastPageClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list86, expList, "测试用例ComChainDict_010");
		**/
		
		//新增表单
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();		
		MainContainer.selectTab(2);
		
		//勾选"CheckBox2"
		CheckBox.element("CheckBox2").click();
		
		expList.clear();
		List<BaseDictItem> list87= Dict.element("Dict6").viewClick().getChildren(true);
		expList.add(new BaseDictItem("020",1,0));
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		DictUtil.checkDictItemFiled(list87, expList, "测试用例ComChainDict_010");
		Dict.element("Dict6").viewClick();
//--------------------------------------------------------------------------------------------------
		expList.clear();
		List<BaseDictItem> list88= Dict.element("Dict17").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list88, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list89=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list89, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list90=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list90, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list91=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list91, expList, "测试用例ComChainDict_011");

		expList.clear();
		List<BaseDictItem> list92=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list92, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list93=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list93, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list94=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list94, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list95=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list95, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list96=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list96, expList, "测试用例ComChainDict_011");

		expList.clear();
		List<BaseDictItem> list97=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list97, expList, "测试用例ComChainDict_011");
		
		expList.clear();
		List<BaseDictItem> list98=Dict.element("Dict17").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list98, expList, "测试用例ComChainDict_011");
		Dict.element("Dict17").viewClick();
//---------------------------------------------------------------------------------------------------
		expList.clear();
		List<BaseDictItem> list99= Dict.element("Dict15").viewClick().getChildren(true);
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list99, expList, "测试用例ComChainDict_012");
		
		//选中RadioButton9
		RadioButton.element("RadioButton9").click();
		
		expList.clear();
		List<BaseDictItem> list100= Dict.element("Dict15").viewClick().getChildren(true);
		DictUtil.checkDictItemFiled(list100, expList, "测试用例ComChainDict_012");
		Dict.element("Dict15").viewClick();
//----------------------------------------------------------------------------------------------------
		expList.clear();
		List<BaseDictItem> list101= Dict.element("Dict18").viewClick().getChildren(true);
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list101, expList, "测试用例ComChainDict_013");
		
		//选中RadioButton10
		RadioButton.element("RadioButton10").click();
		
		expList.clear();
		List<BaseDictItem> list102= Dict.element("Dict18").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",1,0));
		expList.add(new BaseDictItem("002",1,0));
		expList.add(new BaseDictItem("003",1,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list102, expList, "测试用例ComChainDict_013");

		expList.clear();
		//List<BaseDictItem> list103=Dict.element("Dict18").nextPageClick().getChildren(true);
		List<BaseDictItem> list103=Dict.element("Dict18").numClick(2).getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list103, expList, "测试用例ComChainDict_013");

		expList.clear();
		List<BaseDictItem> list104=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list104, expList, "测试用例ComChainDict_013");
		
		expList.clear();
		List<BaseDictItem> list105=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list105, expList, "测试用例ComChainDict_013");
		
		expList.clear();
		List<BaseDictItem> list106=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list106, expList, "测试用例ComChainDict_013");

		expList.clear();
		List<BaseDictItem> list107=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list107, expList, "测试用例ComChainDict_013");
		
		expList.clear();
		List<BaseDictItem> list108=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list108, expList, "测试用例ComChainDict_013");

		expList.clear();
		List<BaseDictItem> list109=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list109, expList, "测试用例ComChainDict_013");

		expList.clear();
		List<BaseDictItem> list110=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list110, expList, "测试用例ComChainDict_013");

		expList.clear();
		List<BaseDictItem> list111=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list111, expList, "测试用例ComChainDict_013");
		
		expList.clear();
		List<BaseDictItem> list112=Dict.element("Dict18").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list112, expList, "测试用例ComChainDict_013");
		Dict.element("Dict18").viewClick();
//----------------------------------------------------------------------------------------------------------
		MenuEntry.element("Dict/CustomBill").click();
		MenuEntry.element("Dict/CustomBill/ChainDict").dblClick();		
		MainContainer.selectTab(3);
        //更改“人员1/人员2/人员3”为停用状态
		DictView.element().itemClick("001");
		ToolBar.element("main_toolbar").click("DisabledDict");
		waittime(1000);
		DictView.element().itemClick("002");
		ToolBar.element("main_toolbar").click("DisabledDict");
		waittime(1000);
		DictView.element().itemClick("003");
		ToolBar.element("main_toolbar").click("DisabledDict");
		
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		waittime(500);
		MainContainer.selectTab(4);
		
		expList.clear();
		List<BaseDictItem> list113= Dict.element("Dict20").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",0,0));
		expList.add(new BaseDictItem("002",0,0));
		expList.add(new BaseDictItem("003",0,0));
		expList.add(new BaseDictItem("004",1,0));
		expList.add(new BaseDictItem("005",1,0));
		expList.add(new BaseDictItem("006",1,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list113, expList, "测试用例ComChainDict_014");

		expList.clear();
		//List<BaseDictItem> list114=Dict.element("Dict20").nextPageClick().getChildren(true);
		List<BaseDictItem> list114=Dict.element("Dict20").numClick(2).getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list114, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list115=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list115, expList, "测试用例ComChainDict_014");

		expList.clear();
		List<BaseDictItem> list116=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list116, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list117=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list117, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list118=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list118, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list119=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list119, expList, "测试用例ComChainDict_014");

		expList.clear();
		List<BaseDictItem> list120=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list120, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list121=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list121, expList, "测试用例ComChainDict_014");

		expList.clear();
		List<BaseDictItem> list122=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list122, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list123=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list123, expList, "测试用例ComChainDict_014");
		Dict.element("Dict20").viewClick();
		
		MainContainer.selectTab(3);
		
		//更改“人员4/人员5/人员6”为作废状态
		DictView.element().itemClick("004");
		ToolBar.element("main_toolbar").click("DisabledDict");
		ToolBar.element("main_toolbar").click("InvalidDict");
		DictView.element().itemClick("005");
		ToolBar.element("main_toolbar").click("DisabledDict");
		ToolBar.element("main_toolbar").click("InvalidDict");
		DictView.element().itemClick("006");
		ToolBar.element("main_toolbar").click("DisabledDict");
		ToolBar.element("main_toolbar").click("InvalidDict");
		
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		waittime(500);
		MainContainer.selectTab(5);
		
		expList.clear();
		List<BaseDictItem> list124= Dict.element("Dict20").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",0,0));
		expList.add(new BaseDictItem("002",0,0));
		expList.add(new BaseDictItem("003",0,0));
		expList.add(new BaseDictItem("004",2,0));
		expList.add(new BaseDictItem("005",2,0));
		expList.add(new BaseDictItem("006",2,0));
		expList.add(new BaseDictItem("007",1,0));
		expList.add(new BaseDictItem("008",1,0));
		expList.add(new BaseDictItem("009",1,0));
		expList.add(new BaseDictItem("010",1,0));
		DictUtil.checkDictItemFiled(list124, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		//List<BaseDictItem> list125=Dict.element("Dict20").nextPageClick().getChildren(true);
		List<BaseDictItem> list125=Dict.element("Dict20").numClick(2).getChildren(true);
		expList.add(new BaseDictItem("011",1,0));
		expList.add(new BaseDictItem("012",1,0));
		expList.add(new BaseDictItem("013",1,0));
		expList.add(new BaseDictItem("014",1,0));
		expList.add(new BaseDictItem("015",1,0));
		expList.add(new BaseDictItem("016",1,0));
		expList.add(new BaseDictItem("017",1,0));
		expList.add(new BaseDictItem("018",1,0));
		expList.add(new BaseDictItem("019",1,0));
		expList.add(new BaseDictItem("020",1,0));
		DictUtil.checkDictItemFiled(list125, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list126=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("021",1,0));
		expList.add(new BaseDictItem("022",1,0));
		expList.add(new BaseDictItem("023",1,0));
		expList.add(new BaseDictItem("024",1,0));
		expList.add(new BaseDictItem("025",1,0));
		expList.add(new BaseDictItem("026",1,0));
		expList.add(new BaseDictItem("027",1,0));
		expList.add(new BaseDictItem("028",1,0));
		expList.add(new BaseDictItem("029",1,0));
		expList.add(new BaseDictItem("030",1,0));
		DictUtil.checkDictItemFiled(list126, expList, "测试用例ComChainDict_014");

		expList.clear();
		List<BaseDictItem> list127=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("031",1,0));
		expList.add(new BaseDictItem("032",1,0));
		expList.add(new BaseDictItem("033",1,0));
		expList.add(new BaseDictItem("034",1,0));
		expList.add(new BaseDictItem("035",1,0));
		expList.add(new BaseDictItem("036",1,0));
		expList.add(new BaseDictItem("037",1,0));
		expList.add(new BaseDictItem("038",1,0));
		expList.add(new BaseDictItem("039",1,0));
		expList.add(new BaseDictItem("040",1,0));
		DictUtil.checkDictItemFiled(list127, expList, "测试用例ComChainDict_014");

		expList.clear();
		List<BaseDictItem> list128=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("041",1,0));
		expList.add(new BaseDictItem("042",1,0));
		expList.add(new BaseDictItem("043",1,0));
		expList.add(new BaseDictItem("044",1,0));
		expList.add(new BaseDictItem("045",1,0));
		expList.add(new BaseDictItem("046",1,0));
		expList.add(new BaseDictItem("047",1,0));
		expList.add(new BaseDictItem("048",1,0));
		expList.add(new BaseDictItem("049",1,0));
		expList.add(new BaseDictItem("050",1,0));
		DictUtil.checkDictItemFiled(list128, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list129=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("051",1,0));
		expList.add(new BaseDictItem("052",1,0));
		expList.add(new BaseDictItem("053",1,0));
		expList.add(new BaseDictItem("054",1,0));
		expList.add(new BaseDictItem("055",1,0));
		expList.add(new BaseDictItem("056",1,0));
		expList.add(new BaseDictItem("057",1,0));
		expList.add(new BaseDictItem("058",1,0));
		expList.add(new BaseDictItem("059",1,0));
		expList.add(new BaseDictItem("060",1,0));
		DictUtil.checkDictItemFiled(list129, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list130=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("061",1,0));
		expList.add(new BaseDictItem("062",1,0));
		expList.add(new BaseDictItem("063",1,0));
		expList.add(new BaseDictItem("064",1,0));
		expList.add(new BaseDictItem("065",1,0));
		expList.add(new BaseDictItem("066",1,0));
		expList.add(new BaseDictItem("067",1,0));
		expList.add(new BaseDictItem("068",1,0));
		expList.add(new BaseDictItem("069",1,0));
		expList.add(new BaseDictItem("070",1,0));
		DictUtil.checkDictItemFiled(list130, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list131=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("071",1,0));
		expList.add(new BaseDictItem("072",1,0));
		expList.add(new BaseDictItem("073",1,0));
		expList.add(new BaseDictItem("074",1,0));
		expList.add(new BaseDictItem("075",1,0));
		expList.add(new BaseDictItem("076",1,0));
		expList.add(new BaseDictItem("077",1,0));
		expList.add(new BaseDictItem("078",1,0));
		expList.add(new BaseDictItem("079",1,0));
		expList.add(new BaseDictItem("080",1,0));
		DictUtil.checkDictItemFiled(list131, expList, "测试用例ComChainDict_014");

		expList.clear();
		List<BaseDictItem> list132=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("081",1,0));
		expList.add(new BaseDictItem("082",1,0));
		expList.add(new BaseDictItem("083",1,0));
		expList.add(new BaseDictItem("084",1,0));
		expList.add(new BaseDictItem("085",1,0));
		expList.add(new BaseDictItem("086",1,0));
		expList.add(new BaseDictItem("087",1,0));
		expList.add(new BaseDictItem("088",1,0));
		expList.add(new BaseDictItem("089",1,0));
		expList.add(new BaseDictItem("090",1,0));
		DictUtil.checkDictItemFiled(list132, expList, "测试用例ComChainDict_014");

		expList.clear();
		List<BaseDictItem> list133=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("091",1,0));
		expList.add(new BaseDictItem("092",1,0));
		expList.add(new BaseDictItem("093",1,0));
		expList.add(new BaseDictItem("094",1,0));
		expList.add(new BaseDictItem("095",1,0));
		expList.add(new BaseDictItem("096",1,0));
		expList.add(new BaseDictItem("097",1,0));
		expList.add(new BaseDictItem("098",1,0));
		expList.add(new BaseDictItem("099",1,0));
		expList.add(new BaseDictItem("100",1,0));
		DictUtil.checkDictItemFiled(list133, expList, "测试用例ComChainDict_014");
		
		expList.clear();
		List<BaseDictItem> list134=Dict.element("Dict20").nextPageClick().getChildren(true);
		expList.add(new BaseDictItem("101",1,0));
		expList.add(new BaseDictItem("102",1,0));
		expList.add(new BaseDictItem("103",1,0));
		DictUtil.checkDictItemFiled(list134, expList, "测试用例ComChainDict_014");
		Dict.element("Dict20").viewClick();
//--------------------------------------------------------------------------------------------------
		DictUtil.checkDictPage("Dict21", "1", "测试用例ComChainDict_015");
		Dict.element("Dict21").viewClick();
		expList.clear();
		List<BaseDictItem> list135= Dict.element("Dict21").viewClick().getChildren(true);
		expList.add(new BaseDictItem("001",0,0));
		expList.add(new BaseDictItem("002",0,0));
		expList.add(new BaseDictItem("003",0,0));
		expList.add(new BaseDictItem("004",2,0));
		expList.add(new BaseDictItem("005",2,0));
		expList.add(new BaseDictItem("006",2,0));
		DictUtil.checkDictItemFiled(list135, expList, "测试用例ComChainDict_015");

		Dict.element("Dict21").chainItemClick("001", "确定");
		DictUtil.checkInputValue("Dict21", "001 人员1", "测试用例ComChainDict_015");
		
		ToolBar.element("ToolBar1").click("Save");
		MainContainer.selectTab(3);
		
		DictView.element().itemClick("001");
		ToolBar.element("main_toolbar").click("EnabledDict");
		
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(6);
		ToolBar.element("ToolBar1").click("Edit");
		
		DictUtil.checkInputValue("Dict21", "001 人员1", "测试用例ComChainDict_015");
		expList.clear();
		List<BaseDictItem> list136= Dict.element("Dict21").viewClick().getChildren(true);
		expList.add(new BaseDictItem("002",0,0));
		expList.add(new BaseDictItem("003",0,0));
		expList.add(new BaseDictItem("004",2,0));
		expList.add(new BaseDictItem("005",2,0));
		expList.add(new BaseDictItem("006",2,0));
		DictUtil.checkDictItemFiled(list136, expList, "测试用例ComChainDict_015");
		
	    MainContainer.closeAllTab();
	}
}
