package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;
import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Text;

public class TextEditor_03 extends AbstractTestScript {
	public void run() {
		// ====序时簿查询====	
		
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/TextEditorTest/TextEditor_03View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.CheckAllRows("list", 3, "测试用例Control_TextEditor_M1_025");
		TextEditor.element("TextEditor1").input("A");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 1, "测试用例Control_TextEditor_M1_025");
		ListViewUtil.checkFormExsit("list", "序时簿查询：", "输入ABC", true, "测试用例Control_TextEditor_M1_025");
		Button.element("cancel").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "", "测试用例Control_TextEditor_M1_025");
		TextEditor.element("TextEditor1").input("B");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 2, "测试用例Control_TextEditor_M1_025");
		ListViewUtil.checkFormExsit("list", "序时簿查询：", "输入ABC", true, "测试用例Control_TextEditor_M1_025");
		ListViewUtil.checkFormExsit("list", "序时簿查询：", "输入b", true, "测试用例Control_TextEditor_M1_025");
		TextEditor.element("TextEditor1").clear();
		TextEditor.element("TextEditor1").input("F");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 0, "测试用例Control_TextEditor_M1_025");
		// ====删除按钮测试====
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		TextEditor.element("TextEditor2").input("上海博科资讯股份有限公司Yigo研究院");
		TextEditorUtil.checkClearButton("TextEditor2", true, "测试用例Control_TextEditor_M1_026");
		TextEditor.element("TextEditor2").clearClick();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "", "测试用例Control_TextEditor_M1_026");
		// ====特殊字符输入====
		TextEditor.element("TextEditor3").click();
		TextEditor.element("TextEditor3").input("~").input("·").input("@").input("!").input("#").input("$").input("%")
				.input("^").input("&").input("(").input("-").input("_").input("-").input(")").input("`").input("/")
				.input("、").input(">").input("。").input("<").input("？").input("》").input("{").input("*").input("}")
				.input("《").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "~·@!#$%^&(-_-)`/、>。<？》{*}《","测试用例Control_TextEditor_M1_027");
		TextEditor.element("TextEditor3").click().clearClick();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "", "测试用例Control_TextEditor_M1_027");
		Button.element("Button1").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "~·@!#$%^&(-_-)`/\\/>。<、》{*-*}《","测试用例Control_TextEditor_M1_027");
		TextEditor.element("TextEditor3").click().clearClick();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "", "测试用例Control_TextEditor_M1_027");
		TextEditor.element("TextEditor3").paste("~·@!#$%^&(-_-)`/、>。<？》{*}《").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "~·@!#$%^&(-_-)`/、>。<？》{*}《","测试用例Control_TextEditor_M1_027");
		// ====值改变事件非编辑状态不触发====
		ToolBarButton.element("保存").click();
		AssertUtil.checkEnabled(TextEditor.element("TextEditor2"), false, "测试用例Control_TextEditor_M1_028");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor3"), false, "测试用例Control_TextEditor_M1_028");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor4"), false, "测试用例Control_TextEditor_M1_028");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_028");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "~·@!#$%^&(-_-)`/、>。<？》{*}《",
				"测试用例Control_TextEditor_M1_028");

		MainContainer.closeTab(1);
		MainContainer.selectTab(0);
		TextEditor.element("TextEditor1").click().clearClick();
		Button.element("Query").click();
		ListView.element("list").dbClick(4);
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "~·@!#$%^&(-_-)`/、>。<？》{*}《",
				"测试用例Control_TextEditor_M1_028");

		TextEditor.element("TextEditor4").click().pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "", "测试用例Control_TextEditor_M1_028");
		MainContainer.closeAllTab();
		//====文本输入为HTML====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/TextEditorTest/TextEditor_03View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		TextEditor.element("TextEditor6").input("<image src=\"a.jpg\"/>");
		ToolBarButton.element("保存").click();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "文本为HTML", "<image src=\"a.jpg\"/>", true, "测试用例Control_TextEditor_M1_030");
		
		
		
		
		
		
		
		MainContainer.closeAllTab();
	}

}
