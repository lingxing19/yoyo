package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.RadioButtonUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class RadioButton_01 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/radiobutton").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/radiobutton/RadioButton_01View").dblClick();
		// ====可用性与可见性====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton1"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton2"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton3"), true, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton4"), true, "测试用例Control_RadioButton_M8_001");
		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton1"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton2"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton3"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton4"), false, "测试用例Control_RadioButton_M8_001");
		// ====提示信息====
		AssertUtil.checkHovertext(RadioButton.element("RadioButton5"), "单选框测试", "测试用例Control_RadioButton_M8_002");
		// ====默认值公式====
		RadioButtonUtil.checkRadioBtChecked("RadioButton14", false,  "测试用例Control_RadioButton_M8_003");
		RadioButtonUtil.checkRadioBtChecked("RadioButton15", false,  "测试用例Control_RadioButton_M8_003");
		RadioButtonUtil.checkRadioBtChecked("RadioButton16", true,  "测试用例Control_RadioButton_M8_003");
		// ====默认值====
		RadioButtonUtil.checkRadioBtChecked("RadioButton17", true,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton18", false,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton19", false,  "测试用例Control_RadioButton_M8_004");
		// ====值改变事件====
		RadioButton.element("RadioButton21").click();
		RadioButtonUtil.checkRadioBtChecked("RadioButton20", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton21", true,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton22", false,  "测试用例Control_RadioButton_M8_005");
		AssertUtil.checkDisplayed(Label.element("Label8"), true, "测试用例Control_RadioButton_M8_005");
		Button.element("Button1").click();
		RadioButtonUtil.checkRadioBtChecked("RadioButton23", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton24", true,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton25", false,  "测试用例Control_RadioButton_M8_005");
		AssertUtil.checkForeColor(RadioButton.element("RadioButton24"), "255, 0, 0", "测试用例Control_RadioButton_M8_005");
		// ====垂直水平对齐====
		AssertUtil.checkVertical(RadioButton.element("RadioButton7"), "top", "测试用例Control_RadioButton_M8_006");
		AssertUtil.checkVertical(RadioButton.element("RadioButton6"), "middle", "测试用例Control_RadioButton_M8_006");		
		AssertUtil.checkVertical(RadioButton.element("RadioButton8"), "bottom", "测试用例Control_RadioButton_M8_006");
		// ====前景色====
		AssertUtil.checkForeColor(RadioButton.element("RadioButton9"), "204, 128, 153", "测试用例Control_RadioButton_M8_007");
		// ====背景色====
		AssertUtil.checkBackColor(RadioButton.element("RadioButton10"), "204, 153, 204", "测试用例Control_RadioButton_M8_008");
		// ====字体大小====
		AssertUtil.checkFontName(RadioButton.element("RadioButton11"), "KaiTi", "测试用例Control_RadioButton_M8_009");
		AssertUtil.checkFontSize(RadioButton.element("RadioButton11"), "18px", "测试用例Control_RadioButton_M8_009");
		// ====粗体====
		AssertUtil.checkFontWeight(RadioButton.element("RadioButton12"), "bold", "测试用例Control_RadioButton_M8_010");
		// ====斜体====
		AssertUtil.checkFontStyle(RadioButton.element("RadioButton13"), "italic", "测试用例Control_RadioButton_M8_011");
		// ====同组只能单选====
		RadioButton.element("RadioButton15").click();
		RadioButtonUtil.checkRadioBtChecked("RadioButton14", false,  "测试用例Control_RadioButton_M8_012");
		RadioButtonUtil.checkRadioBtChecked("RadioButton15", true,  "测试用例Control_RadioButton_M8_012");
		RadioButtonUtil.checkRadioBtChecked("RadioButton16", false,  "测试用例Control_RadioButton_M8_012");
		ToolBarButton.element("保存").click();
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton1"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton2"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton3"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton4"), false, "测试用例Control_RadioButton_M8_001");
		RadioButtonUtil.checkRadioBtChecked("RadioButton17", true,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton18", false,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton19", false,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton20", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton21", true,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton22", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton23", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton24", true,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton25", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton14", false,  "测试用例Control_RadioButton_M8_012");
		RadioButtonUtil.checkRadioBtChecked("RadioButton15", true,  "测试用例Control_RadioButton_M8_012");
		RadioButtonUtil.checkRadioBtChecked("RadioButton16", false,  "测试用例Control_RadioButton_M8_012");
		MainContainer.closeTab(1);
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton1"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton2"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkDisplayed(RadioButton.element("RadioButton3"), false, "测试用例Control_RadioButton_M8_001");
		AssertUtil.checkEnabled(RadioButton.element("RadioButton4"), false, "测试用例Control_RadioButton_M8_001");
		RadioButtonUtil.checkRadioBtChecked("RadioButton14", false,  "测试用例Control_RadioButton_M8_003");
		RadioButtonUtil.checkRadioBtChecked("RadioButton15", false,  "测试用例Control_RadioButton_M8_003");
		RadioButtonUtil.checkRadioBtChecked("RadioButton16", true,  "测试用例Control_RadioButton_M8_003");
		RadioButtonUtil.checkRadioBtChecked("RadioButton17", true,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton18", false,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton19", false,  "测试用例Control_RadioButton_M8_004");
		RadioButtonUtil.checkRadioBtChecked("RadioButton20", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton21", true,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton22", false,  "测试用例Control_RadioButton_M8_005");
		AssertUtil.checkDisplayed(Label.element("Label8"), true, "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton23", false,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton24", true,  "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton25", false,  "测试用例Control_RadioButton_M8_005");
		AssertUtil.checkForeColor(RadioButton.element("RadioButton24"), "255, 0, 0", "测试用例Control_RadioButton_M8_005");
		RadioButtonUtil.checkRadioBtChecked("RadioButton14", false,  "测试用例Control_RadioButton_M8_012");
		RadioButtonUtil.checkRadioBtChecked("RadioButton15", true,  "测试用例Control_RadioButton_M8_012");
		RadioButtonUtil.checkRadioBtChecked("RadioButton16", false,  "测试用例Control_RadioButton_M8_012");
		MainContainer.closeAllTab();
	}

}
