package test.controltest;


import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CheckBox_01 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckBox").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckBox/CheckBox_01View").dblClick();
		// ====可用性与可见性====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox1"), false, "测试用例Control_CheckBox_M7_001");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox2"), false, "测试用例Control_CheckBox_M7_001");
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox3"), true, "测试用例Control_CheckBox_M7_001");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox4"), true, "测试用例Control_CheckBox_M7_001");
		CheckBox.element("CheckBox5").click();
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox1"), false, "测试用例Control_CheckBox_M7_001");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox2"), false, "测试用例Control_CheckBox_M7_001");
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox3"), false, "测试用例Control_CheckBox_M7_001");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox4"), false, "测试用例Control_CheckBox_M7_001");
		CheckBox.element("CheckBox2").click();
		CheckBoxUtil.checkChecked("CheckBox2", false, "测试用例Control_CheckBox_M7_001");
		// ====提示信息====
		AssertUtil.checkHovertext(CheckBox.element("CheckBox6"), "复选框测试", "测试用例Control_CheckBox_M7_002");
		// ====必填====
		AssertUtil.checkRequired(CheckBox.element("CheckBox7"), true, "测试用例Control_CheckBox_M7_003");
		CheckBoxUtil.checkChecked("CheckBox7", false, "测试用例Control_CheckBox_M7_003");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkShowErrorDialog("必填 不能为空");
		ErrorDialog.element().close();
		CheckBox.element("CheckBox7").click();
		AssertUtil.checkRequired(CheckBox.element("CheckBox7"), false, "测试用例Control_CheckBox_M7_003");
		CheckBoxUtil.checkChecked("CheckBox7", true, "测试用例Control_CheckBox_M7_003");
		// ====值变化事件====
		CheckBox.element("CheckBox8").click();
		CheckBoxUtil.checkChecked("CheckBox8", true, "测试用例Control_CheckBox_M7_004");
		AssertUtil.checkDisplayed(Label.element("Label1"), true, "测试用例Control_CheckBox_M7_004");
		Button.element("Button1").click();
		CheckBoxUtil.checkChecked("CheckBox9", true, "测试用例Control_CheckBox_M7_004");
		AssertUtil.checkBackColor(CheckBox.element("CheckBox9"), "255, 0, 0", "测试用例Control_CheckBox_M7_004");
		// ====默认值====
		CheckBoxUtil.checkChecked("CheckBox10", true, "测试用例Control_CheckBox_M7_005");
		// ====默认值公式====
		CheckBoxUtil.checkChecked("CheckBox11", true, "测试用例Control_CheckBox_M7_006");
		// ====垂直对齐方式====
		AssertUtil.checkVertical(CheckBox.element("CheckBox13"), "top", "测试用例Control_CheckBox_M7_007");
		AssertUtil.checkVertical(CheckBox.element("CheckBox12"), "middle", "测试用例Control_CheckBox_M7_007");
		AssertUtil.checkVertical(CheckBox.element("CheckBox14"), "bottom", "测试用例Control_CheckBox_M7_007");
		// ====前景色====
		AssertUtil.checkForeColor(CheckBox.element("CheckBox15"), "255, 217, 0", "测试用例Control_CheckBox_M7_008");
		// ====背景色====
		AssertUtil.checkBackColor(CheckBox.element("CheckBox16"), "18, 155, 255", "测试用例Control_CheckBox_M7_009");
		// ====字体大小====
		AssertUtil.checkFontName(CheckBox.element("CheckBox17"), "Arial Black", "测试用例Control_CheckBox_M7_010");
		AssertUtil.checkFontSize(CheckBox.element("CheckBox17"), "22px", "测试用例Control_CheckBox_M7_010");
		// ====粗体====
		AssertUtil.checkFontWeight(CheckBox.element("CheckBox18"), "bold", "测试用例Control_CheckBox_M7_011");
		// ====斜体====
		AssertUtil.checkFontStyle(CheckBox.element("CheckBox19"), "italic", "测试用例Control_CheckBox_M7_012");
		// ====公共属性保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox1"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox2"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox3"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox4"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox7"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkRequired(CheckBox.element("CheckBox7"), false, "测试用例Control_CheckBox_M7_003");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox15"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkForeColor(CheckBox.element("CheckBox15"), "255, 217, 0", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox16"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkBackColor(CheckBox.element("CheckBox16"), "18, 155, 255", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox17"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontName(CheckBox.element("CheckBox17"), "Arial Black", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontSize(CheckBox.element("CheckBox17"), "22px", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox18"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontWeight(CheckBox.element("CheckBox18"), "bold", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox19"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontStyle(CheckBox.element("CheckBox19"), "italic", "测试用例Control_CheckBox_M7_013");
		MainContainer.closeAllTab();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckBox/CheckBox_01View").dblClick();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(6);
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox1"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox2"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkDisplayed(CheckBox.element("CheckBox3"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox4"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox7"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkRequired(CheckBox.element("CheckBox7"), false, "测试用例Control_CheckBox_M7_003");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox15"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkForeColor(CheckBox.element("CheckBox15"), "255, 217, 0", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox16"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkBackColor(CheckBox.element("CheckBox16"), "18, 155, 255", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox17"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontName(CheckBox.element("CheckBox17"), "Arial Black", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontSize(CheckBox.element("CheckBox17"), "22px", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox18"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontWeight(CheckBox.element("CheckBox18"), "bold", "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkEnabled(CheckBox.element("CheckBox19"), false, "测试用例Control_CheckBox_M7_013");
		AssertUtil.checkFontStyle(CheckBox.element("CheckBox19"), "italic", "测试用例Control_CheckBox_M7_013");
		// ====查询字段====
		MainContainer.selectTab(0);
		ListViewUtil.CheckAllRows("list", 6, "测试用例Control_CheckBox_M7_014");
		ComboBox.element("ComboBox1").dropDownClick().itemClick("是");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 3, "测试用例Control_CheckBox_M7_014");
		ListViewUtil.checkRowSelected(ListView.element("list"), "查询字段", true, 1);
		ListViewUtil.checkRowSelected(ListView.element("list"), "查询字段", true, 2);
		ListViewUtil.checkRowSelected(ListView.element("list"), "查询字段", true, 3);
		Button.element("cancel").click();
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 6, "测试用例Control_CheckBox_M7_014");
		ComboBox.element("ComboBox1").dropDownClick().itemClick("否");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 3, "测试用例Control_CheckBox_M7_014");
		ListViewUtil.checkRowSelected(ListView.element("list"), "查询字段", false, 1);
		ListViewUtil.checkRowSelected(ListView.element("list"), "查询字段", false, 2);
		ListViewUtil.checkRowSelected(ListView.element("list"), "查询字段", false, 3);
		MainContainer.closeAllTab();

	}

}
