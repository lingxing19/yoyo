package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class NumberEditor_03 extends AbstractTestScript {
	public void run() {
		// ====序时簿查询====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/NumberEditorTest/NumberEditor_03View").dblClick();
		MainContainer.selectTab(0);
		NumberEditor.element("NumberEditor1").input("-1");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 4, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "1.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "2.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "3.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "-1.00", true, "测试用例Control_NumberEditor_M2_023");
		NumberEditor.element("NumberEditor1_Comp2").input("2");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 3, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "1.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "2.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "-1.00", true, "测试用例Control_NumberEditor_M2_023");
		Button.element("cancel").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "", "测试用例Control_NumberEditor_M2_023");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1_Comp2"), "", "测试用例Control_NumberEditor_M2_023");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 5, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "1.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "2.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "3.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "-1.00", true, "测试用例Control_NumberEditor_M2_023");
		ListViewUtil.checkFormExsit("list", "查询字段：", "-2.50", true, "测试用例Control_NumberEditor_M2_023");
		// ====默认值为1/0====
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "#DIV/0", "测试用例Control_NumberEditor_M2_024");
		// ====值改变事件非编辑状态不触发====
		ToolBarButton.element("保存").click();
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor2"), false, "测试用例Control_NumberEditor_M2_025");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor3"), false, "测试用例Control_NumberEditor_M2_025");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor4"), false, "测试用例Control_NumberEditor_M2_025");
		
		NumberEditor.element("NumberEditor3").click().pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor4"), "", "测试用例Control_NumberEditor_M2_025");
		
		MainContainer.closeAllTab();
	}

}
