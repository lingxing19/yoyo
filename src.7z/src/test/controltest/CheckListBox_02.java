package test.controltest;

import com.bokesoft.yes.autotest.common.util.CheckListBoxUtil;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CheckListBox_02 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckListBox/CheckListBox_02View").dblClick();
		// ====下拉项来源于固定值====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		CheckListBox.element("CheckListBox12").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox12"), "今天昨天明天后天百年大计，教育为本。教育大计，教师为本。",
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "今天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "昨天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "明天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "后天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "百年大计，教育为本。教育大计，教师为本。", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkButtons(CheckListBox.element("CheckListBox12"), "取消", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkButtons(CheckListBox.element("CheckListBox12"), "清除", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkButtons(CheckListBox.element("CheckListBox12"), "确定", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").itemClick("今天", "昨天");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "今天", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "昨天", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "明天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "后天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "百年大计，教育为本。教育大计，教师为本。", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox12"), "今天,昨天",
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").dropDownClick();
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "今天", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "昨天", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "明天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "后天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "百年大计，教育为本。教育大计，教师为本。", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").itemClick("昨天", "百年大计，教育为本。教育大计，教师为本。");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "今天", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "昨天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "明天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "后天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "百年大计，教育为本。教育大计，教师为本。", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox12"), "今天,百年大计，教育为本。教育大计，教师为本。",
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").dropDownClick();
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "今天", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "昨天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "明天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "后天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "百年大计，教育为本。教育大计，教师为本。", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").itemClick("今天");
		CheckListBox.element("CheckListBox12").clickName("取消");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox12"), "今天,百年大计，教育为本。教育大计，教师为本。",
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").dropDownClick();
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "今天", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "昨天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "明天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "后天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "百年大计，教育为本。教育大计，教师为本。", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").clickName("清除");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox12"), "",
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").dropDownClick();
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "今天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "昨天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "明天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "后天", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox12"), "百年大计，教育为本。教育大计，教师为本。", false,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkButtons(CheckListBox.element("CheckListBox12"), "取消", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkButtons(CheckListBox.element("CheckListBox12"), "清除", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBoxUtil.checkButtons(CheckListBox.element("CheckListBox12"), "确定", true,
				"测试用例Control_ CheckListBox_M5_010");
		CheckListBox.element("CheckListBox12").backClick();
		// ====下拉项来源于表达式====
		CheckListBox.element("CheckListBox13").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox13"), "北京上海重庆天津深圳长沙武汉",
				"测试用例Control_ CheckListBox_M5_011");
		CheckListBox.element("CheckListBox13").backClick();
		// ====下拉项来源于SQL查询====
		CheckListBox.element("CheckListBox14").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox14"), "北京天津",
				"测试用例Control_ CheckListBox_M5_012");
		CheckListBox.element("CheckListBox14").itemClick("北京").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox14"), "北京", "测试用例Control_ CheckListBox_M5_012");
		NumberEditor.element("NumberEditor1").clear();
		NumberEditor.element("NumberEditor1").input("3").pressEnterKey();
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox14"), "", "测试用例Control_ CheckListBox_M5_012");
		CheckListBox.element("CheckListBox14").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox14"), "北京",
				"测试用例Control_ CheckListBox_M5_012");
		CheckListBox.element("CheckListBox14").backClick();
		// ====下拉项来源于状态集合（表单自身）====
		CheckListBox.element("CheckListBox15").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox15"), "前进后退加速减速", "测试用例Control_ CheckListBox_M5_013");
		CheckListBox.element("CheckListBox15").backClick();
		MainContainer.closeAllTab();
		// ====下拉项来源于状态集合（Common）====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckListBox/CheckListBox_03View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		CheckListBox.element("CheckListBox1").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox1"), "表单状态1表单状态2", "测试用例Control_ CheckListBox_M5_014");
		MainContainer.closeAllTab();
		// ====下拉项来源于状态集合（应用）====
		MenuEntry.element("Common/OutSide").click();
		MenuEntry.element("Common/OutSide/OutSideTestView").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		CheckListBox.element("CheckListBox1").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox1"), "应用状态1应用状态2应用状态3", "测试用例Control_ CheckListBox_M5_015");
		MainContainer.closeAllTab();
		// ====下拉项来源于参数组====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckListBox").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckListBox/CheckListBox_02View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		CheckListBox.element("CheckListBox16").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox16"), "米厘米毫米", "测试用例Control_ CheckListBox_M5_016");
		MainContainer.closeAllTab();
		
		
		
		
		
		
		
		
		
	}

}
