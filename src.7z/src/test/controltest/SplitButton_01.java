package test.controltest;


import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.SplitButtonUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SplitButton;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class SplitButton_01 extends AbstractTestScript {
	public void run() {
		// ====可用性与可见性====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/SplitButtonTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/SplitButtonTest/SplitButton_01View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton1"), false, "测试用例Control_SplitButton_M10_001");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton2"), false, "测试用例Control_SplitButton_M10_001");
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton3"), true, "测试用例Control_SplitButton_M10_001");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton4"), true, "测试用例Control_SplitButton_M10_001");
		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton1"), false, "测试用例Control_SplitButton_M10_001");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton2"), false, "测试用例Control_SplitButton_M10_001");
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton3"), false, "测试用例Control_SplitButton_M10_001");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton4"), false, "测试用例Control_SplitButton_M10_001");
		// ====提示信息====
		AssertUtil.checkHovertext(SplitButton.element("SplitButton5"), "拆分按钮测试", "测试用例Control_SplitButton_M10_002");
		// ====垂直水平对齐====
		AssertUtil.checkVertical(SplitButton.element("SplitButton6"), "top", "测试用例Control_SplitButton_M10_003");
		AssertUtil.checkVertical(SplitButton.element("SplitButton7"), "middle", "测试用例Control_SplitButton_M10_003");
		AssertUtil.checkVertical(SplitButton.element("SplitButton8"), "bottom", "测试用例Control_SplitButton_M10_003");
		// ====前景色====
		AssertUtil.checkForeColor(SplitButton.element("SplitButton9"), "179, 26, 26",
				"测试用例Control_SplitButton_M10_004");
		// ====字体大小====
		AssertUtil.checkFontName(SplitButton.element("SplitButton11"), "Microsoft Tai Le",
				"测试用例Control_SplitButton_M10_005");
		AssertUtil.checkFontSize(SplitButton.element("SplitButton11"), "17px", "测试用例Control_SplitButton_M10_005");
		// ====粗体====
		AssertUtil.checkFontWeight(SplitButton.element("SplitButton12"), "bold", "测试用例Control_SplitButton_M10_006");
		// ====斜体====
		AssertUtil.checkFontStyle(SplitButton.element("SplitButton13"), "italic", "测试用例Control_SplitButton_M10_007");
		// ====图标====
		SplitButtonUtil.checkIconName(SplitButton.element("SplitButton14"), "setting.png", true,
				"测试用例Control_SplitButton_M10_008");
		// ====点击事件自身无；子项有====
		SplitButton.element("SplitButton14").click();
		SplitButtonUtil.checkIsClicked(SplitButton.element("SplitButton14"), true, "测试用例Control_SplitButton_M10_009");
		SplitButton.element("SplitButton14").dropDownClick();
		SplitButtonUtil.checkItemNames(SplitButton.element("SplitButton14"), "子项1分隔线子项2分隔线子项3",
				"测试用例Control_SplitButton_M10_009");
		SplitButton.element("SplitButton14").itemClick("子项3");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("子选项3触发");
		ConfirmDialog.element().okClick();
		// ====点击事件自身有；子项有====
		SplitButton.element("SplitButton15").click();
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("自身点击事件触发");
		ConfirmDialog.element().okClick();
		SplitButton.element("SplitButton15").dropDownClick();
		SplitButtonUtil.checkItemNames(SplitButton.element("SplitButton15"), "子项4", "测试用例Control_SplitButton_M10_010");
		SplitButton.element("SplitButton15").itemClick("子项4");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("子选项4触发");
		ConfirmDialog.element().okClick();
		// ====拆分按钮界面保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton1"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton2"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton3"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton4"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton14"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton15"), false, "测试用例Control_SplitButton_M10_011");
		SplitButtonUtil.checkIconName(SplitButton.element("SplitButton14"), "setting.png", true,
				"测试用例Control_SplitButton_M10_011");
		AssertUtil.checkForeColor(SplitButton.element("SplitButton9"), "179, 26, 26",
				"测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontName(SplitButton.element("SplitButton11"), "Microsoft Tai Le",
				"测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontSize(SplitButton.element("SplitButton11"), "17px", "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontWeight(SplitButton.element("SplitButton12"), "bold", "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontStyle(SplitButton.element("SplitButton13"), "italic", "测试用例Control_SplitButton_M10_011");
		MainContainer.closeAllTab();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/SplitButtonTest/SplitButton_01View").dblClick();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton1"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton2"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkDisplayed(SplitButton.element("SplitButton3"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton4"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton14"), false, "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkEnabled(SplitButton.element("SplitButton15"), false, "测试用例Control_SplitButton_M10_011");
		SplitButtonUtil.checkIconName(SplitButton.element("SplitButton14"), "setting.png", true,
				"测试用例Control_SplitButton_M10_011");
		AssertUtil.checkForeColor(SplitButton.element("SplitButton9"), "179, 26, 26",
				"测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontName(SplitButton.element("SplitButton11"), "Microsoft Tai Le",
				"测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontSize(SplitButton.element("SplitButton11"), "17px", "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontWeight(SplitButton.element("SplitButton12"), "bold", "测试用例Control_SplitButton_M10_011");
		AssertUtil.checkFontStyle(SplitButton.element("SplitButton13"), "italic", "测试用例Control_SplitButton_M10_011");
		MainContainer.closeAllTab();
	}

}
