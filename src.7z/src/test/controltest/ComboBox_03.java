package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class ComboBox_03 extends AbstractTestScript{
	public void run() {
		// ====序时簿查询====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest/ComboBox_03View").dblClick();
		MainContainer.selectTab(0);

		ComboBox.element("ComboBox2").dropDownClick().itemClick("4");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 2, "测试用例Control_ComboBox_M4_027");
		ListViewUtil.checkFormExsit("list", "可编辑+整型", "6", true, "测试用例Control_ComboBox_M4_027");		
		ListViewUtil.checkFormExsit("list", "可编辑+整型", "7", true, "测试用例Control_ComboBox_M4_027");
		Button.element("cancel").click();
		ComboBox.element("ComboBox2").dropDownClick().itemClick("1");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 3, "测试用例Control_ComboBox_M4_027");
		ListViewUtil.checkFormExsit("list", "可编辑+整型", "3", true, "测试用例Control_ComboBox_M4_027");		
		ListViewUtil.checkFormExsit("list", "可编辑+整型", "6", true, "测试用例Control_ComboBox_M4_027");		
		ListViewUtil.checkFormExsit("list", "可编辑+整型", "7", true, "测试用例Control_ComboBox_M4_027");
		
		// ====可编辑+整型====
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox2"), "0", "测试用例Control_ComboBox_M4_028");
		ComboBox.element("ComboBox2").clear();
		ComboBox.element("ComboBox2").input("105").pressEnterKey();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox2"), "105", "测试用例Control_ComboBox_M4_028");
		ComboBoxUtil.checkgetAutoItems(ComboBox.element("ComboBox2"), "", "测试用例Control_ComboBox_M4_028");
		
		// ====下拉项无caption也可存入value值====
		ComboBox.element("ComboBox3").dropDownClick().itemClick("");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox3"), "", "测试用例Control_ComboBox_M4_029");
		ToolBarButton.element("保存").click();
		AssertUtil.checkEnabled(ComboBox.element("ComboBox3"), false, "测试用例Control_ComboBox_M4_029");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox3"), "", "测试用例Control_ComboBox_M4_029");
		String[][] expTable = { { "" } ,{ ""},{ ""},{ ""},{ ""},{ "3"}};
		DataBaseUtil.checkDataMatch("SELECT ComboBox3 FROM ComboBox_03Head", expTable, "测试用例Control_ComboBox_M4_029");
		
		// ====下拉框取整可进行计算====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(2);
		ComboBox.element("ComboBox4").dropDownClick().itemClick("A3");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox4"), "A3", "测试用例Control_ComboBox_M4_030");
		ComboBox.element("ComboBox5").dropDownClick().itemClick("B2");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "B2", "测试用例Control_ComboBox_M4_030");
		Button.element("Button1").click();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "C5", "测试用例Control_ComboBox_M4_030");
		// ====下拉框存储“0”显示Caption====
		ComboBox.element("ComboBox8").dropDownClick().itemClick("值=0");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox8"), "值=0", "测试用例Control_ComboBox_M4_031");
		ComboBox.element("ComboBox10").dropDownClick().itemClick("值=0");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "值=0", "测试用例Control_ComboBox_M4_031");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest/ComboBox_03View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "整型Key=0", "值=0", true,  "测试用例Control_ComboBox_M4_031");
		ListViewUtil.checkFormExsit("list", "字符串Key=0", "值=0", true,  "测试用例Control_ComboBox_M4_031");
		ListView.element("list").dbClick("字符串Key=0", "值=0", "", "测试用例Control_ComboBox_M4_031");
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox7"), "值=0", "测试用例Control_ComboBox_M4_031");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox8"), "值=0", "测试用例Control_ComboBox_M4_031");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox9"), "值=0", "测试用例Control_ComboBox_M4_031");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "值=0", "测试用例Control_ComboBox_M4_031");
		// ====下拉动态依赖====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(2);
		ComboBox.element("ComboBox11").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox11"), "武汉", "测试用例Control_ComboBox_M4_032");
		ComboBox.element("ComboBox12").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox12"), "北京", "测试用例Control_ComboBox_M4_032");
		NumberEditor.element("NumberEditor1").clear();
		NumberEditor.element("NumberEditor1").input("2").pressEnterKey();
		ComboBox.element("ComboBox11").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox11"), "上海", "测试用例Control_ComboBox_M4_032");
		ComboBox.element("ComboBox12").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox12"), "北京上海", "测试用例Control_ComboBox_M4_032");
		ComboBox.element("ComboBox12").itemClick("上海");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox12"), "上海", "测试用例Control_ComboBox_M4_032");
		NumberEditor.element("NumberEditor1").clear();
		NumberEditor.element("NumberEditor1").input("5").pressEnterKey();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox12"), "", "测试用例Control_ComboBox_M4_032");
		ComboBox.element("ComboBox12").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox12"), "北京", "测试用例Control_ComboBox_M4_032");
        
		MainContainer.closeAllTab();
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
