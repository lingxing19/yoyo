package test.controltest;




import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DatePicker_02 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DatePickerTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DatePickerTest/DatePicker_02View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		// ====日期格式为yyyy-mm-dd====
//		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2015-09-08", "测试用例Control_DatePicker_M3_014");
//		DatePicker.element("DatePicker1").click();
//		DatePicker.element("DatePicker1").pressBackspaceKey(6);
//		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2015", "测试用例Control_DatePicker_M3_014");
//		DatePicker.element("DatePicker1").input("6").pressEnterKey();
//		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2015-06-01", "测试用例Control_DatePicker_M3_014");
//		DatePicker.element("DatePicker1").clear();
//  	DatePicker.element("DatePicker1").input("2018").input("1123").input("201132").pressEnterKey();
//		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2018-11-23", "测试用例Control_DatePicker_M3_014");
		// ====日期格式为yyyy-mm-dd hh:mm:ss====
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2016-01-25 12:23:50", "测试用例Control_DatePicker_M3_015");
//		DatePicker.element("DatePicker2").focusMovetoEnd();
//		DatePicker.element("DatePicker2").pressBackspaceKey(15);
//		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2016", "测试用例Control_DatePicker_M3_015");
//		DatePicker.element("DatePicker2").pressEnterKey();
//		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2016-01-01 00:00:00", "测试用例Control_DatePicker_M3_015");
//		DatePicker.element("DatePicker2").clear();
//		DatePicker.element("DatePicker2").input("2018").input("1123").input("201132").pressEnterKey();
//     	DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2018-11-23 20:11:32", "测试用例Control_DatePicker_M3_015");
//     	DatePicker.element("DatePicker2").chooseFocus(12, 13).input("13").pressEnterKey();
//    	DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2018-11-23 13:11:32", "测试用例Control_DatePicker_M3_015");
//    	DatePicker.element("DatePicker2").chooseFocus(6, 7).input("08").pressEnterKey();
//    	DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2018-08-23 13:11:32", "测试用例Control_DatePicker_M3_015");
		// ====编辑日期框（无时间）====
     	DatePicker.element("DatePicker3").viewClick();
     	DatePickerUtil.checkCurrDate(DatePicker.element("DatePicker3"), "测试用例Control_DatePicker_M3_016");
     	DatePicker.element("DatePicker3").viewInput(2018, "六月", 9);
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker3"), "2018-06-09", "测试用例Control_DatePicker_M3_016");
		// ====编辑日期框（带时间）====	
		DatePicker.element("DatePicker4").viewClick();
		DatePicker.element("DatePicker4").viewInput(2019, "一月", 30, 15, 14, 13);
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker4"), "2019-01-30 15:14:13", "测试用例Control_DatePicker_M3_017");
		
		MainContainer.closeAllTab();
		
		
		
		
		
		
		
	}

}
