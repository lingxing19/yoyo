package test.controltest;

import java.awt.Dialog;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.TextButtonUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextButton;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class TextButton_01 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").dblClick();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/TextButtonTest").dblClick();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/TextButtonTest/TextButton_01View").dblClick();
		// ====可用性与可见性====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
//		AssertUtil.checkDisplayed(TextButton.element("TextButton1"), false, "测试用例Control_TextButton_M13_001");
//		AssertUtil.checkEnabled(TextButton.element("TextButton2"), false, "测试用例Control_TextButton_M13_001");
//		AssertUtil.checkDisplayed(TextButton.element("TextButton3"), true, "测试用例Control_TextButton_M13_001");
//		AssertUtil.checkEnabled(TextButton.element("TextButton4"), true, "测试用例Control_TextButton_M13_001");
//        CheckBox.element("CheckBox1").click();
//		AssertUtil.checkDisplayed(TextButton.element("TextButton1"), false, "测试用例Control_TextButton_M13_001");
//		AssertUtil.checkEnabled(TextButton.element("TextButton2"), false, "测试用例Control_TextButton_M13_001");
//		AssertUtil.checkDisplayed(TextButton.element("TextButton3"), false, "测试用例Control_TextButton_M13_001");
//		AssertUtil.checkEnabled(TextButton.element("TextButton4"), false, "测试用例Control_TextButton_M13_001");
//		// ====提示信息====
//		AssertUtil.checkHovertext(TextButton.element("TextButton5"), "文本按钮测试", "测试用例Control_TextButton_M13_002");
//		// ====必填====
//		AssertUtil.checkRequired(TextButton.element("TextButton6"), true,  "测试用例Control_TextButton_M13_003");
//		ToolBarButton.element("保存").click();
//		DialogUtil.checkShowErrorDialog();
//		DialogUtil.checkShowErrorDialog("必填： 不能为空");
//		ErrorDialog.element().close("关闭");
//		TextButton.element("TextButton6").input("必填").pressEnterKey();
//		AssertUtil.checkRequired(TextButton.element("TextButton6"), false,  "测试用例Control_TextButton_M13_003");
//		TextButton.element("TextButton6").clear();
//		AssertUtil.checkRequired(TextButton.element("TextButton6"), true,  "测试用例Control_TextButton_M13_003");
//		Button.element("Button1").click();
//		TextButtonUtil.checkInputValue(TextButton.element("TextButton6"), "@!$%^&*~", "测试用例Control_TextButton_M13_003");
//		AssertUtil.checkRequired(TextButton.element("TextButton6"), false,  "测试用例Control_TextButton_M13_003");
//		// ====检查规则====
//		AssertUtil.uiCheck(TextButton.element("TextButton7"), true, "测试用例Control_TextButton_M13_004");
//		AssertUtil.checkErrorInfo(TextButton.element("TextButton7"), "此控件值为\"ABC\"", "测试用例Control_TextButton_M13_004");
//		TextButton.element("TextButton7").input("自动化").pressEnterKey();
//		AssertUtil.uiCheck(TextButton.element("TextButton7"), true, "测试用例Control_TextButton_M13_004");
//		ToolBarButton.element("保存").click();
//		DialogUtil.checkShowErrorDialog();
//		DialogUtil.checkShowErrorDialog("此控件值为\"ABC\"");
//		ErrorDialog.element().close("关闭");
//		Button.element("Button2").click();
//		TextButtonUtil.checkInputValue(TextButton.element("TextButton7"), "ABC", "测试用例Control_TextButton_M13_004");
//		AssertUtil.uiCheck(TextButton.element("TextButton7"), false, "测试用例Control_TextButton_M13_004");
		// ====值改变事件====
		TextButton.element("TextButton8").input("123").pressEnterKey();
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("值改变事件触发");
		ConfirmDialog.element().okClick();
		Button.element("Button3").click();
		TextButtonUtil.checkInputValue(TextButton.element("TextButton9"), "abc", "测试用例Control_TextButton_M13_005");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("值改变事件触发");
		ConfirmDialog.element().okClick();
		// ====默认值====
		TextButtonUtil.checkInputValue(TextButton.element("TextButton10"), "默认值", "测试用例Control_TextButton_M13_006");
		// ====默认值公式====
		TextButtonUtil.checkInputValue(TextButton.element("TextButton11"), "abc", "测试用例Control_TextButton_M13_007");
		// ====前景色====
		AssertUtil.checkForeColor(TextButton.element("TextButton12"), "179, 26, 26", "测试用例Control_TextButton_M13_008");
		// ====背景色====
		AssertUtil.checkBackColor(TextButton.element("TextButton13"), "230, 230, 77", "测试用例Control_TextButton_M13_009");
		// ====字体大小====
		
		
		
	}

}
 