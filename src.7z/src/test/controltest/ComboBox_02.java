package test.controltest;


import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;


public class ComboBox_02 extends AbstractTestScript {
	public void run() {

		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest/ComboBox_02View").dblClick();
		// ====Validation====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "A",  "测试用例Control_ComboBox_M4_013");
		ComboBox.element("ComboBox1").dropDownClick().itemClick("B");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "A",  "测试用例Control_ComboBox_M4_013");
		ComboBox.element("ComboBox1").dropDownClick().itemClick("C");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "C",  "测试用例Control_ComboBox_M4_013");
		Button.element("Button3").click();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "B",  "测试用例Control_ComboBox_M4_013");
		ComboBox.element("ComboBox1").dropDownClick().itemClick("A");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "B",  "测试用例Control_ComboBox_M4_013");
		// ====ValueChanged====
		ComboBox.element("ComboBox2").dropDownClick().itemClick("B");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox2"), "B",  "测试用例Control_ComboBox_M4_014");
		AssertUtil.checkForeColor(Label.element("Label1"), "255, 0, 0","测试用例Control_ComboBox_M4_014");
		Button.element("Button1").click();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox3"), "A",  "测试用例Control_ComboBox_M4_014");
		AssertUtil.checkBackColor(Label.element("Lab_ComboBox3"), "255, 0, 0", "测试用例Control_ComboBox_M4_014");
		// ====ValueChanging====
		ComboBox.element("ComboBox4").dropDownClick().itemClick("B");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox4"), "B", "测试用例Control_ComboBox_M4_015");
		AssertUtil.checkForeColor(Label.element("Lab_ComboBox4"),"51, 51, 51" ,"测试用例Control_ComboBox_M4_015");
      // ====Validation+Changed+Changing（表达式）====
		ComboBox.element("ComboBox5").dropDownClick().itemClick("A");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "A", "测试用例Control_ComboBox_M4_016");
    	AssertUtil.checkForeColor(Label.element("Lab_ComboBox5"),"255, 0, 0" ,"测试用例Control_ComboBox_M4_016");
		NumberEditor.element("NumberEditor1").input("200").pressEnterKey();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "A", "测试用例Control_ComboBox_M4_016");
    	AssertUtil.checkForeColor(Label.element("Lab_ComboBox5"),"255, 0, 0" ,"测试用例Control_ComboBox_M4_016");
    	AssertUtil.checkBackColor(Label.element("Label3"), "0, 0, 0", "测试用例Control_ComboBox_M4_016");
    	ComboBox.element("ComboBox5").dropDownClick().itemClick("B");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "B", "测试用例Control_ComboBox_M4_016");
    	AssertUtil.checkForeColor(Label.element("Lab_ComboBox5"),"255, 0, 0" ,"测试用例Control_ComboBox_M4_016");
    	AssertUtil.checkBackColor(Label.element("Label3"), "255, 0, 0", "测试用例Control_ComboBox_M4_016");
		// ====Validation+Changed+Changing（Confirm）====
		ComboBox.element("ComboBox6").dropDownClick().itemClick("B");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "B", "测试用例Control_ComboBox_M4_017");
    	AssertUtil.checkBackColor(Label.element("Label4"), "255, 0, 0",  "测试用例Control_ComboBox_M4_017");
    	ComboBox.element("ComboBox6").dropDownClick().itemClick("C");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "C", "测试用例Control_ComboBox_M4_017");
    	DialogUtil.checkConfirmDialogText("是否确认？");
    	ConfirmDialog.element().yesClick();
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "C", "测试用例Control_ComboBox_M4_017");
    	NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "200.00", "测试用例Control_ComboBox_M4_017");
    	ComboBox.element("ComboBox6").dropDownClick().itemClick("A");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "A", "测试用例Control_ComboBox_M4_017");
    	DialogUtil.checkConfirmDialogText("是否确认？");
    	ConfirmDialog.element().noClick();
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "C", "测试用例Control_ComboBox_M4_017");
    	NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "100.00", "测试用例Control_ComboBox_M4_017");
		// ====是否可编辑====
    	ComboBox.element("ComboBox10").input("f");
    	waittime(200);
    	ComboBoxUtil.checkgetAutoItems(ComboBox.element("ComboBox10"), "F", "测试用例Control_ComboBox_M4_018");
    	ComboBox.element("ComboBox10").autoItemClick("F");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "F", "测试用例Control_ComboBox_M4_018");
    	ComboBox.element("ComboBox10").clear();
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "", "测试用例Control_ComboBox_M4_018");
    	ComboBox.element("ComboBox10").input("2").pressEnterKey();
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "B", "测试用例Control_ComboBox_M4_018");
    	ComboBox.element("ComboBox10").clear();
    	ComboBox.element("ComboBox10").input("2").pressEnterKey();
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "B", "测试用例Control_ComboBox_M4_018");
    	ComboBox.element("ComboBox10").clear();
    	ComboBox.element("ComboBox10").input("Good").pressEnterKey();
    	ComboBoxUtil.checkgetAutoItems(ComboBox.element("ComboBox10"), "", "测试用例Control_ComboBox_M4_018");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "Good", "测试用例Control_ComboBox_M4_018");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox11"), "C", "测试用例Control_ComboBox_M4_018");
    	ComboBox.element("ComboBox11").clear().pressEnterKey();
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox11"), "", "测试用例Control_ComboBox_M4_018");
    	ComboBox.element("ComboBox11").input("Good").pressEnterKey();
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox11"), "", "测试用例Control_ComboBox_M4_018");
    	ToolBarButton.element("保存").click();
    	AssertUtil.checkEnabled(ComboBox.element("ComboBox10"), false, "测试用例Control_ComboBox_M4_018");
    	AssertUtil.checkEnabled(ComboBox.element("ComboBox11"), false, "测试用例Control_ComboBox_M4_018");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox10"), "Good", "测试用例Control_ComboBox_M4_018");
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox11"), "", "测试用例Control_ComboBox_M4_018");
    	MainContainer.closeTab(1);
		// ====下拉项来源于固定值====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		ComboBox.element("ComboBox12").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox12"), "固定值1固定值2固定值3固定值4百年大计，教育为本。教育大计，教师为本。", "测试用例Control_ComboBox_M4_019");
		ComboBox.element("ComboBox12").itemClick("固定值3");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox12"), "固定值3", "测试用例Control_ComboBox_M4_019");
		ComboBox.element("ComboBox12").dropDownClick();
		ComboBoxUtil.checkIsSelected(ComboBox.element("ComboBox12"),"固定值3" , "测试用例Control_ComboBox_M4_019");
		ComboBox.element("ComboBox12").itemClick("固定值1");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox12"), "固定值1", "测试用例Control_ComboBox_M4_019");
		// ====下拉项来源于表达式====
		ComboBox.element("ComboBox13").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox13"), "北京上海重庆天津深圳长沙武汉", "测试用例Control_ComboBox_M4_020");
	    ComboBox.element("ComboBox13").backClick();
		// ====下拉项来源于SQL查询====
		ComboBox.element("ComboBox14").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox14"), "北京天津长沙武汉", "测试用例Control_ComboBox_M4_021");
		ComboBox.element("ComboBox14").backClick();
		// ====下拉项来源于状态集合（表单自身）====
		ComboBox.element("ComboBox15").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox15"), "表单状态1表单状态2表单状态3表单状态4表单状态5", "测试用例Control_ComboBox_M4_022");
		MainContainer.closeAllTab();
		// ====下拉项来源于状态集合（Common）====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest/ComboBox_03View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		ComboBox.element("ComboBox1").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox1"), "表单状态1表单状态2", "测试用例Control_ComboBox_M4_023");
		// ====下拉项来源于状态集合（应用）====
		MenuEntry.element("Common/OutSide").click();
		MenuEntry.element("Common/OutSide/OutSideTestView").dblClick();
		MainContainer.selectTab(2);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(3);
		ComboBox.element("ComboBox1").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox1"), "应用状态1应用状态2应用状态3", "测试用例Control_ComboBox_M4_024");
		MainContainer.closeAllTab();
		// ====下拉项来源于参数组====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest/ComboBox_02View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		ComboBox.element("ComboBox16").dropDownClick();
		ComboBoxUtil.checkgetItemsValue(ComboBox.element("ComboBox16"), "今天明天昨天前天", "测试用例Control_ComboBox_M4_025");
		MainContainer.closeAllTab();
		
		
		
		
		
	}

}
