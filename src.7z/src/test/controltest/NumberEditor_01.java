package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class NumberEditor_01 extends AbstractTestScript {
	public void run() {
		// ====可用性与可见性====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/NumberEditorTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/NumberEditorTest/NumberEditor_01View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor1"), false, "测试用例Control_NumberEditor_M2_001");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor2"), false, "测试用例Control_NumberEditor_M2_001");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor3"), true, "测试用例Control_NumberEditor_M2_001");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor4"), true, "测试用例Control_NumberEditor_M2_001");
		CheckBox.element("CheckBox1").click();
		CheckBoxUtil.checkChecked("CheckBox1", true, "测试用例Control_NumberEditor_M2_001");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor1"), false, "测试用例Control_NumberEditor_M2_001");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor2"), false, "测试用例Control_NumberEditor_M2_001");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor3"), false, "测试用例Control_NumberEditor_M2_001");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor4"), false, "测试用例Control_NumberEditor_M2_001");
		// ====必填====
		AssertUtil.checkRequired(NumberEditor.element("NumberEditor5"), true, "测试用例Control_NumberEditor_M2_002");
		Button.element("Button1").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "123,456,789.01",
				"测试用例Control_NumberEditor_M2_002");
		AssertUtil.checkRequired(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_002");
		Button.element("Button2").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "", "测试用例Control_NumberEditor_M2_002");
		AssertUtil.checkRequired(NumberEditor.element("NumberEditor5"), true, "测试用例Control_NumberEditor_M2_002");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("必填： 不能为空");
		ErrorDialog.element().close();
		NumberEditor.element("NumberEditor5").input("123456789.01").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "123,456,789.01",
				"测试用例Control_NumberEditor_M2_002");
		AssertUtil.checkRequired(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_002");
		// ====检查规则与错误描述====
		AssertUtil.uiCheck(NumberEditor.element("NumberEditor6"), true, "测试用例Control_NumberEditor_M2_003");
		AssertUtil.checkErrorInfo(NumberEditor.element("NumberEditor6"), "不为空", "测试用例Control_NumberEditor_M2_003");
		Button.element("Button3").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "-123,456,789.01",
				"测试用例Control_NumberEditor_M2_003");
		AssertUtil.uiCheck(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_003");
		Button.element("Button4").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "", "测试用例Control_NumberEditor_M2_003");
		AssertUtil.uiCheck(NumberEditor.element("NumberEditor6"), true, "测试用例Control_NumberEditor_M2_003");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("不为空");
		ErrorDialog.element().close();
		NumberEditor.element("NumberEditor6").input("-123456789.01").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "-123,456,789.01",
				"测试用例Control_NumberEditor_M2_003");
		AssertUtil.uiCheck(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_003");
		// ====值改变事件====
		NumberEditor.element("NumberEditor9").input("1").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor10"), "1,234.00",
				"测试用例Control_NumberEditor_M2_004");
		Button.element("Button5").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor11"), "-12,345.00",
				"测试用例Control_NumberEditor_M2_004");
		AssertUtil.checkForeColor(Label.element("Lab_NumberEditor11"), "255, 109, 30",
				"测试用例Control_NumberEditor_M2_004");
		// ===默认值====
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor7"), "123,456,789.01",
				"测试用例Control_NumberEditor_M2_005");
		// ===默认值公式====
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor8"), "-12,345.00",
				"测试用例Control_NumberEditor_M2_006");
		// ===提示信息====
		AssertUtil.checkHovertext(NumberEditor.element("NumberEditor12"), "【控件测试用例】",
				"测试用例Control_NumberEditor_M2_007");
		// ===前景色====
		AssertUtil.checkForeColor(NumberEditor.element("NumberEditor13"), "210, 20, 152",
				"测试用例Control_NumberEditor_M2_008");
		// ====背景色====
		AssertUtil.checkBackColor(NumberEditor.element("NumberEditor14"), "255, 154, 218",
				"测试用例Control_NumberEditor_M2_009");
		// ====字体与大小====
		AssertUtil.checkFontName(NumberEditor.element("NumberEditor15"), "SimHei", "测试用例Control_NumberEditor_M2_010");
		AssertUtil.checkFontSize(NumberEditor.element("NumberEditor15"), "18px", "测试用例Control_NumberEditor_M2_010");
		// ====字体为斜体====
		AssertUtil.checkFontStyle(NumberEditor.element("NumberEditor17"), "italic", "测试用例Control_NumberEditor_M2_012");
		// ====字体为粗体====
		AssertUtil.checkFontWeight(NumberEditor.element("NumberEditor16"), "bold", "测试用例Control_NumberEditor_M2_011");
		// ====公共属性数值框保存====
		ToolBarButton.element("保存").click();
		CheckBoxUtil.checkChecked("CheckBox1", true, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor1"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor2"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor3"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor4"), false, "测试用例Control_NumberEditor_M2_013");

		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor9"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor11"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor7"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor8"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor13"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor14"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor15"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor16"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor17"), false, "测试用例Control_NumberEditor_M2_013");

		AssertUtil.checkRequired(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.uiCheck(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_013");

		AssertUtil.checkForeColor(NumberEditor.element("NumberEditor13"), "210, 20, 152",
				"测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkBackColor(NumberEditor.element("NumberEditor14"), "255, 154, 218",
				"测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontName(NumberEditor.element("NumberEditor15"), "SimHei", "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontSize(NumberEditor.element("NumberEditor15"), "18px", "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontStyle(NumberEditor.element("NumberEditor17"), "italic", "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontWeight(NumberEditor.element("NumberEditor16"), "bold", "测试用例Control_NumberEditor_M2_013");

		MainContainer.closeTab(1);
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);

		CheckBoxUtil.checkChecked("CheckBox1", true, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor1"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor2"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor3"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor4"), false, "测试用例Control_NumberEditor_M2_013");

		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor9"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor11"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor7"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor8"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor13"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor14"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor15"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor16"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor17"), false, "测试用例Control_NumberEditor_M2_013");

		AssertUtil.checkRequired(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_013");
		AssertUtil.uiCheck(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_013");

		AssertUtil.checkForeColor(NumberEditor.element("NumberEditor13"), "210, 20, 152",
				"测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkBackColor(NumberEditor.element("NumberEditor14"), "255, 154, 218",
				"测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontName(NumberEditor.element("NumberEditor15"), "SimHei", "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontSize(NumberEditor.element("NumberEditor15"), "18px", "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontStyle(NumberEditor.element("NumberEditor17"), "italic", "测试用例Control_NumberEditor_M2_013");
		AssertUtil.checkFontWeight(NumberEditor.element("NumberEditor16"), "bold", "测试用例Control_NumberEditor_M2_013");
		
		MainContainer.closeAllTab();

	}

}
