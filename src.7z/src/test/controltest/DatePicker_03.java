package test.controltest;



import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextAreaUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextArea;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DatePicker_03 extends AbstractTestScript {
	public void run() {
//		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
//		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DatePickerTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DatePickerTest/DatePicker_03View").dblClick();
		MainContainer.selectTab(0);

		//====序时簿查询====
		DatePicker.element("DatePicker1").input("20120101");
		DatePicker.element("DatePicker1_Comp2").input("20170101");	
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 2, "测试用例Control_DatePicker_M3_019");
		ListViewUtil.checkFormExsit("list", "查询字段1：", "2013-12-14", true, "测试用例Control_DatePicker_M3_019");
		ListViewUtil.checkFormExsit("list", "查询字段1：", "2016-12-13", true, "测试用例Control_DatePicker_M3_019");
		Button.element("cancel").click();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "", "测试用例Control_DatePicker_M3_019");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1_Comp2"), "", "测试用例Control_DatePicker_M3_019");
		DatePicker.element("DatePicker2").input("20120101050404");
		DatePicker.element("DatePicker2_Comp2").input("20180101050304");	
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 3, "测试用例Control_DatePicker_M3_019");
		ListViewUtil.checkFormExsit("list", "查询字段2：", "2013-12-14 03:15:08", true, "测试用例Control_DatePicker_M3_019");
		ListViewUtil.checkFormExsit("list", "查询字段2：", "2016-12-13 23:45:49", true, "测试用例Control_DatePicker_M3_019");
		ListViewUtil.checkFormExsit("list", "查询字段2：", "2017-06-04 03:51:46", true, "测试用例Control_DatePicker_M3_019");
		
		//====日期取值粘贴复制====
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		DatePicker.element("DatePicker7").paste("2015-06-12");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker7"), "2015-06-12", "测试用例Control_DatePicker_M3_021");
		DatePicker.element("DatePicker7").chooseFocus(0, 10).ctrlC();
		TextArea.element("TextArea1").click();
		TextArea.element("TextArea1").ctrlV();
		TextAreaUtil.checkInputValue(TextArea.element("TextArea1"), "2015-06-12", "测试用例Control_DatePicker_M3_021");
		DatePicker.element("DatePicker8").paste("2015-06-12 15:30:56");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker8"), "2015-06-12 15:30:56", "测试用例Control_DatePicker_M3_021");
		DatePicker.element("DatePicker8").chooseFocus(0, 19).ctrlC();
		TextArea.element("TextArea2").click();
		TextArea.element("TextArea2").ctrlV();
		TextAreaUtil.checkInputValue(TextArea.element("TextArea2"), "2015-06-12 15:30:56", "测试用例Control_DatePicker_M3_021");
		
		//====值改变事件在非编辑状态下不触发====
		ToolBarButton.element("保存").click();
		AssertUtil.checkEnabled(DatePicker.element("DatePicker7"), false,  "测试用例Control_DatePicker_M3_022");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker7"), "2015-06-12", "测试用例Control_DatePicker_M3_022");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker8"), false,  "测试用例Control_DatePicker_M3_022");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker8"), "2015-06-12 15:30:56", "测试用例Control_DatePicker_M3_022");
		AssertUtil.checkEnabled(TextArea.element("TextArea1"), false, "测试用例Control_DatePicker_M3_022");
		AssertUtil.checkEnabled(TextArea.element("TextArea2"), false, "测试用例Control_DatePicker_M3_022");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker9"), false,  "测试用例Control_DatePicker_M3_022");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker9"), "", "测试用例Control_DatePicker_M3_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor1"), false, "测试用例Control_DatePicker_M3_022");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "", "测试用例Control_DatePicker_M3_022");
		
		DatePicker.element("DatePicker9").click();
		DatePicker.element("DatePicker9").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "", "测试用例Control_DatePicker_M3_022");
		
		MainContainer.closeAllTab();
		
		
		
		
		
		
		
	}

}
