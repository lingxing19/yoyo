package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DropdownButtonUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.DropdownButton;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DropdownButton_01 extends AbstractTestScript{
	public void run() {
		//====可见性与可用性====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DropdownButtonTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DropdownButtonTest/DropdownButton_01View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton1"), false, "测试用例Control_DropdownButton_M11_001");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton2"), false, "测试用例Control_DropdownButton_M11_001");
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton3"), true, "测试用例Control_DropdownButton_M11_001");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton4"), true, "测试用例Control_DropdownButton_M11_001");
		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton1"), false, "测试用例Control_DropdownButton_M11_001");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton2"), false, "测试用例Control_DropdownButton_M11_001");
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton3"), false, "测试用例Control_DropdownButton_M11_001");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton4"), false, "测试用例Control_DropdownButton_M11_001");
		//====提示信息====
		AssertUtil.checkHovertext(DropdownButton.element("DropdownButton5"), "下拉按钮测试", "测试用例Control_DropdownButton_M11_002");
		//====垂直水平对齐====
		AssertUtil.checkVertical(DropdownButton.element("DropdownButton6"), "top",  "测试用例Control_DropdownButton_M11_003");
		AssertUtil.checkVertical(DropdownButton.element("DropdownButton7"), "middle", "测试用例Control_DropdownButton_M11_003");
		AssertUtil.checkVertical(DropdownButton.element("DropdownButton8"), "bottom", "测试用例Control_DropdownButton_M11_003");
		//====前景色====
		AssertUtil.checkForeColor(DropdownButton.element("DropdownButton9"), "255, 153, 102", "测试用例Control_DropdownButton_M11_004");
		//====背景色====
		AssertUtil.checkBackColor(DropdownButton.element("DropdownButton10"), "102, 153, 102", "测试用例Control_DropdownButton_M11_005");
		//====字体大小====
		AssertUtil.checkFontName(DropdownButton.element("DropdownButton11"), "SansSerif", "测试用例Control_DropdownButton_M11_006");
		AssertUtil.checkFontSize(DropdownButton.element("DropdownButton11"), "20px", "测试用例Control_DropdownButton_M11_006");
		//====粗体====
		AssertUtil.checkFontWeight(DropdownButton.element("DropdownButton12"), "bold", "测试用例Control_DropdownButton_M11_007");
		//====斜体====
		AssertUtil.checkFontStyle(DropdownButton.element("DropdownButton13"), "italic", "测试用例Control_DropdownButton_M11_008");
		//====图标====
		DropdownButtonUtil.checkIcon(DropdownButton.element("DropdownButton14"), true, "personal.png", "测试用例Control_DropdownButton_M11_009");
		//====下拉选项触发====
		DropdownButton.element("DropdownButton14").click();
		DropdownButtonUtil.checkItemsName(DropdownButton.element("DropdownButton14"),"子选项01分割线子选项02", "测试用例Control_DropdownButton_M11_010");
		DropdownButton.element("DropdownButton14").itemClick("子选项01");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("子选项1触发");
		ConfirmDialog.element().okClick();
		DropdownButton.element("DropdownButton14").click();
		DropdownButton.element("DropdownButton14").itemClick("子选项02");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("子选项2触发");
		ConfirmDialog.element().okClick();
		//====下拉按钮界面保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton1"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton2"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton3"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton4"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkForeColor(DropdownButton.element("DropdownButton9"), "255, 153, 102", "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkBackColor(DropdownButton.element("DropdownButton10"), "102, 153, 102", "测试用例Control_DropdownButton_M11_011");
		DropdownButtonUtil.checkIcon(DropdownButton.element("DropdownButton14"), true, "personal.png", "测试用例Control_DropdownButton_M11_011");
		MainContainer.closeAllTab();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DropdownButtonTest/DropdownButton_01View").dblClick();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton1"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton2"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkDisplayed(DropdownButton.element("DropdownButton3"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkEnabled(DropdownButton.element("DropdownButton4"), false, "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkForeColor(DropdownButton.element("DropdownButton9"), "255, 153, 102", "测试用例Control_DropdownButton_M11_011");
		AssertUtil.checkBackColor(DropdownButton.element("DropdownButton10"), "102, 153, 102", "测试用例Control_DropdownButton_M11_011");
		DropdownButtonUtil.checkIcon(DropdownButton.element("DropdownButton14"), true, "personal.png", "测试用例Control_DropdownButton_M11_011");
		MainContainer.closeAllTab();
		
		
		
		
		
	}

}
