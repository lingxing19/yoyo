package test.controltest;


import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ButtonUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ToolBarUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Button_01 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ButtonTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ButtonTest/Button_01View").dblClick();
		// ====可用性与可见性====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(Button.element("Button1"), false, "测试用例Control_Button_M9_001");
		AssertUtil.checkEnabled(Button.element("Button2"), false, "测试用例Control_Button_M9_001");
		AssertUtil.checkDisplayed(Button.element("Button3"), true, "测试用例Control_Button_M9_001");
		AssertUtil.checkEnabled(Button.element("Button4"), true, "测试用例Control_Button_M9_001");
		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(Button.element("Button1"), false, "测试用例Control_Button_M9_001");
		AssertUtil.checkEnabled(Button.element("Button2"), false, "测试用例Control_Button_M9_001");
		AssertUtil.checkDisplayed(Button.element("Button3"), false, "测试用例Control_Button_M9_001");
		AssertUtil.checkEnabled(Button.element("Button4"), false, "测试用例Control_Button_M9_001");
		// ====提示信息====
		AssertUtil.checkHovertext(Button.element("Button15"), "按钮测试", "测试用例Control_Button_M9_002");
		// ====点击事件====
		Button.element("Button5").click();
		AssertUtil.checkDisplayed(Label.element("Label1"), true, "测试用例Control_Button_M9_003");
		// ====图标====
		ButtonUtil.checkIsIcon(Button.element("Button14"), "basisui.png", true, "测试用例Control_Button_M9_004");
		// ====垂直水平对齐====
		AssertUtil.checkVertical(Button.element("Button6"), "top", "测试用例Control_Button_M9_005");
		AssertUtil.checkVertical(Button.element("Button7"), "middle", "测试用例Control_Button_M9_005");
		AssertUtil.checkVertical(Button.element("Button8"), "bottom", "测试用例Control_Button_M9_005");
		// ====前景色====
		AssertUtil.checkForeColor(Button.element("Button9"), "128, 102, 204", "测试用例Control_Button_M9_006");
		// ====背景色====
		AssertUtil.checkBackColor(Button.element("Button10"), "102, 153, 153", "测试用例Control_Button_M9_007");
		// ====字体大小====
		AssertUtil.checkFontName(Button.element("Button11"), "Microsoft YaHei", "测试用例Control_Button_M9_008");
		AssertUtil.checkFontSize(Button.element("Button11"), "22px", "测试用例Control_Button_M9_008");
		// ====粗体====
		AssertUtil.checkFontWeight(Button.element("Button12"), "bold", "测试用例Control_Button_M9_009");
		// ====斜体====
		AssertUtil.checkFontStyle(Button.element("Button13"), "italic", "测试用例Control_Button_M9_010");
		// ==== 操作集合中按钮基础运用====
		ToolBarUtil.checkButtonNames(ToolBar.element("main_toolbar"), "操作集合可见不可用自身禁用公共按钮","测试用例Control_Button_M9_011");
		ToolBarUtil.checkIsIcon(ToolBar.element("main_toolbar"),"optKey2","function.png",true,"测试用例Control_Button_M9_011");
		ToolBarUtil.checkIsDrop(ToolBar.element("main_toolbar"), "optKey2", true, "测试用例Control_Button_M9_011");
		ToolBarUtil.checkIsEnable(ToolBar.element("main_toolbar"), "optKey3", false, "测试用例Control_Button_M9_011");
		ToolBarUtil.checkIsDrop(ToolBar.element("main_toolbar"), "optKey3", true, "测试用例Control_Button_M9_011");
		ToolBarUtil.checkIsDrop(ToolBar.element("main_toolbar"), "optKey6", true, "测试用例Control_Button_M9_011");
		ToolBarUtil.checkIsDrop(ToolBar.element("main_toolbar"), "OptKey8", true, "测试用例Control_Button_M9_011");
		ToolBar.element("main_toolbar").click("optKey2");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("0BOKE");
		ConfirmDialog.element().okClick();
		ToolBar.element("main_toolbar").dropClick("optKey2");
		ToolBarUtil.checkIsShow(ToolBar.element("main_toolbar"), "optKey2", true, "测试用例Control_Button_M9_011");
		ToolBarUtil.checkItemName(ToolBar.element("main_toolbar"), "optKey2", "保存取消", "测试用例Control_Button_M9_011");
		ToolBar.element("main_toolbar").click("Save");
		AssertUtil.checkEnabled(Button.element("Button5"), false, "测试用例Control_Button_M9_011");
		ToolBar.element("main_toolbar").dropClick("optKey2");
		ToolBarUtil.checkIsShow(ToolBar.element("main_toolbar"), "optKey2", true, "测试用例Control_Button_M9_011");
		ToolBarUtil.checkItemName(ToolBar.element("main_toolbar"), "optKey2", "删除编辑关闭", "测试用例Control_Button_M9_011");
		ToolBar.element("main_toolbar").click("Edit");
		AssertUtil.checkEnabled(Button.element("Button5"), true, "测试用例Control_Button_M9_011");
		// ====操作集合父按钮可见不可用====
		ToolBar.element("main_toolbar").click("optKey3");
		DialogUtil.checkShowConfirmDialog();
		ToolBar.element("main_toolbar").dropClick("optKey3");
		ToolBarUtil.checkIsShow(ToolBar.element("main_toolbar"), "optKey3", false, "测试用例Control_Button_M9_012");
		// ====操作集合父按钮自身禁用====
		ToolBar.element("main_toolbar").click("optKey6");
		ToolBarUtil.checkIsShow(ToolBar.element("main_toolbar"), "optKey6", true, "测试用例Control_Button_M9_013");
		ToolBarUtil.checkItemName(ToolBar.element("main_toolbar"), "optKey6", "有效", "测试用例Control_Button_M9_013");
		ToolBar.element("main_toolbar").dropClick("optKey7");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("6BOKE");
		ConfirmDialog.element().okClick();
		// ====操作集合中子项使用RefKey====
		ToolBar.element("main_toolbar").click("OptKey8");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("AAA");
		ConfirmDialog.element().okClick();
		ToolBar.element("main_toolbar").dropClick("OptKey8");
		ToolBarUtil.checkIsShow(ToolBar.element("main_toolbar"), "OptKey8", true, "测试用例Control_Button_M9_014");
		ToolBarUtil.checkItemName(ToolBar.element("main_toolbar"), "OptKey8", "common按钮", "测试用例Control_Button_M9_014");
		ToolBar.element("main_toolbar").click("OptKey9");
		DialogUtil.checkShowConfirmDialog();
		DialogUtil.checkConfirmDialogText("BBB");
		ConfirmDialog.element().okClick();
		// ====操作集合中子项使用RefKey====
		ToolBar.element("main_toolbar").dropClick("optKey2");
		ToolBar.element("main_toolbar").click("Save");
		
		AssertUtil.checkDisplayed(Button.element("Button1"), false, "测试用例Control_Button_M9_015");
		AssertUtil.checkEnabled(Button.element("Button2"), false, "测试用例Control_Button_M9_015");
		AssertUtil.checkDisplayed(Button.element("Button3"), false, "测试用例Control_Button_M9_015");
		AssertUtil.checkEnabled(Button.element("Button4"), false, "测试用例Control_Button_M9_015");
		ButtonUtil.checkIsIcon(Button.element("Button14"), "basisui.png", true, "测试用例Control_Button_M9_015");
		AssertUtil.checkVertical(Button.element("Button6"), "top", "测试用例Control_Button_M9_015");
		AssertUtil.checkVertical(Button.element("Button7"), "middle", "测试用例Control_Button_M9_015");
		AssertUtil.checkVertical(Button.element("Button8"), "bottom", "测试用例Control_Button_M9_015");
		AssertUtil.checkForeColor(Button.element("Button9"), "128, 102, 204", "测试用例Control_Button_M9_015");
		AssertUtil.checkBackColor(Button.element("Button10"), "102, 153, 153", "测试用例Control_Button_M9_015");
		AssertUtil.checkFontName(Button.element("Button11"), "Microsoft YaHei", "测试用例Control_Button_M9_015");
		AssertUtil.checkFontSize(Button.element("Button11"), "22px", "测试用例Control_Button_M9_015");
		AssertUtil.checkFontWeight(Button.element("Button12"), "bold", "测试用例Control_Button_M9_015");
		AssertUtil.checkFontStyle(Button.element("Button13"), "italic", "测试用例Control_Button_M9_015");
		
		MainContainer.closeAllTab();
	}

}
