package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.PassWordUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.PasswordEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class PasswordEditor_01 extends AbstractTestScript{
	public void run() {
		//====可见性与可用性====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/PasswordEditorTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/PasswordEditorTest/PasswordEditor_01View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor1"), false, "测试用例Control_PasswordEditor_M12_001");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor3"), false, "测试用例Control_PasswordEditor_M12_001");
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor2"), true, "测试用例Control_PasswordEditor_M12_001");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor4"), true, "测试用例Control_PasswordEditor_M12_001");
		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor1"), false, "测试用例Control_PasswordEditor_M12_001");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor3"), false, "测试用例Control_PasswordEditor_M12_001");
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor2"), false, "测试用例Control_PasswordEditor_M12_001");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor4"), false, "测试用例Control_PasswordEditor_M12_001");
		//====提示信息====
		AssertUtil.checkHovertext(PasswordEditor.element("PasswordEditor5"), "密码框测试", "测试用例Control_PasswordEditor_M12_002");
		//====必填====
		AssertUtil.checkRequired(PasswordEditor.element("PasswordEditor6"), true, "测试用例Control_PasswordEditor_M12_003");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("必填： 不能为空");
		ErrorDialog.element().close();
		PasswordEditor.element("PasswordEditor6").input("123").pressEnterKey();
		AssertUtil.checkRequired(PasswordEditor.element("PasswordEditor6"), false, "测试用例Control_PasswordEditor_M12_003");
		PasswordEditor.element("PasswordEditor6").click().clear();
		AssertUtil.checkRequired(PasswordEditor.element("PasswordEditor6"), true, "测试用例Control_PasswordEditor_M12_003");
		Button.element("Button1").click();
		AssertUtil.checkRequired(PasswordEditor.element("PasswordEditor6"), false, "测试用例Control_PasswordEditor_M12_003");
		//====前景色====
		PasswordEditor.element("PasswordEditor7").input("123");
		AssertUtil.checkForeColor(PasswordEditor.element("PasswordEditor7"), "255, 102, 102", "测试用例Control_PasswordEditor_M12_004");
		//====背景色====
		AssertUtil.checkBackColor(PasswordEditor.element("PasswordEditor8"), "128, 102, 204", "测试用例Control_PasswordEditor_M12_005");
		//====左侧图标====
		PassWordUtil.checkPreIcon(PasswordEditor.element("PasswordEditor9"), true, "setting.png", "测试用例Control_PasswordEditor_M12_006");
		//====内嵌文本====
		PassWordUtil.checkEmbedText(PasswordEditor.element("PasswordEditor10"), "密码框：", "测试用例Control_PasswordEditor_M12_007");
		//====提示文本====
		PassWordUtil.checkPromptText(PasswordEditor.element("PasswordEditor11"),"请输入：","测试用例Control_PasswordEditor_M12_008");
		//====密码框界面保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor1"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor3"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor2"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor4"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkRequired(PasswordEditor.element("PasswordEditor6"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkForeColor(PasswordEditor.element("PasswordEditor7"), "255, 102, 102", "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkBackColor(PasswordEditor.element("PasswordEditor8"), "128, 102, 204", "测试用例Control_PasswordEditor_M12_009");
		PassWordUtil.checkPreIcon(PasswordEditor.element("PasswordEditor9"), true, "setting.png", "测试用例Control_PasswordEditor_M12_009");
		PassWordUtil.checkEmbedText(PasswordEditor.element("PasswordEditor10"), "密码框：", "测试用例Control_PasswordEditor_M12_009");
		MainContainer.closeAllTab();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/PasswordEditorTest/PasswordEditor_01View").dblClick();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor1"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor3"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkDisplayed(PasswordEditor.element("PasswordEditor2"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkEnabled(PasswordEditor.element("PasswordEditor4"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkRequired(PasswordEditor.element("PasswordEditor6"), false, "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkForeColor(PasswordEditor.element("PasswordEditor7"), "255, 102, 102", "测试用例Control_PasswordEditor_M12_009");
		AssertUtil.checkBackColor(PasswordEditor.element("PasswordEditor8"), "128, 102, 204", "测试用例Control_PasswordEditor_M12_009");
		PassWordUtil.checkPreIcon(PasswordEditor.element("PasswordEditor9"), true, "setting.png", "测试用例Control_PasswordEditor_M12_009");
		PassWordUtil.checkEmbedText(PasswordEditor.element("PasswordEditor10"), "密码框：", "测试用例Control_PasswordEditor_M12_009");
		MainContainer.closeAllTab();
		
		
		
	}

}
