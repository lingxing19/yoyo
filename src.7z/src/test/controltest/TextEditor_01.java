package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class TextEditor_01 extends AbstractTestScript {
	public void run() {
		// ====可用性与可见性====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/TextEditorTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/TextEditorTest/TextEditor_01View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "测试用例Control_TextEditor_M1_001");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor2"), false, "测试用例Control_TextEditor_M1_001");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor3"), true, "测试用例Control_TextEditor_M1_001");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor4"), true, "测试用例Control_TextEditor_M1_001");
		CheckBox.element("CheckBox1").click();
		CheckBoxUtil.checkChecked("CheckBox1", true, "测试用例Control_TextEditor_M1_001");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "测试用例Control_TextEditor_M1_001");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor2"), false, "测试用例Control_TextEditor_M1_001");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor3"), false, "测试用例Control_TextEditor_M1_001");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor4"), false, "测试用例Control_TextEditor_M1_001");
		// ====必填====
		AssertUtil.checkRequired(TextEditor.element("TextEditor5"), true, "测试用例Control_TextEditor_M1_002");
		Button.element("Button1").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "ABC", "测试用例Control_TextEditor_M1_002");
		AssertUtil.checkRequired(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_002");
		Button.element("Button2").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "", "测试用例Control_TextEditor_M1_002");
		AssertUtil.checkRequired(TextEditor.element("TextEditor5"), true, "测试用例Control_TextEditor_M1_002");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("必填 ： 不能为空");
		ErrorDialog.element().close();
		TextEditor.element("TextEditor5").input("字符串").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "字符串", "测试用例Control_TextEditor_M1_002");
		AssertUtil.checkRequired(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_002");
		// ====检查规则与错误描述====
		AssertUtil.uiCheck(TextEditor.element("TextEditor7"), true, "测试用例Control_TextEditor_M1_003");
		AssertUtil.checkErrorInfo(TextEditor.element("TextEditor7"), "'不为空'", "测试用例Control_TextEditor_M1_003");
		TextEditor.element("TextEditor7").input("自动化").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "自动化", "测试用例Control_TextEditor_M1_003");
		AssertUtil.uiCheck(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_003");
		Button.element("Button4").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "", "测试用例Control_TextEditor_M1_003");
		AssertUtil.uiCheck(TextEditor.element("TextEditor7"), true, "测试用例Control_TextEditor_M1_003");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("'不为空'");
		ErrorDialog.element().close();
		Button.element("Button3").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "ABC", "测试用例Control_TextEditor_M1_003");
		AssertUtil.uiCheck(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_003");
		// ====提示信息====
		AssertUtil.checkHovertext(TextEditor.element("TextEditor8"), "【控件自动化测试】", "测试用例Control_TextEditor_M1_004");
		// ====值改变事件====
		TextEditor.element("TextEditor10").input("Change").pressEnterKey();
		AssertUtil.checkForeColor(Label.element("Label4"), "128, 55, 204", "测试用例Control_TextEditor_M1_005");
		Button.element("Button5").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor17"), "SetValue", "测试用例Control_TextEditor_M1_005");
		AssertUtil.checkForeColor(Label.element("Lab_TextEditor17"), "32, 181, 57", "测试用例Control_TextEditor_M1_005");
		// ====默认值====
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor9"), "Change", "测试用例Control_TextEditor_M1_006");
		// ====默认值公式====
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor11"), "Change", "测试用例Control_TextEditor_M1_007");
		// ====前景色====
		AssertUtil.checkForeColor(TextEditor.element("TextEditor12"), "0, 93, 211", "测试用例Control_TextEditor_M1_008");
		// ====背景色====
		AssertUtil.checkBackColor(TextEditor.element("TextEditor13"), "244, 171, 0", "测试用例Control_TextEditor_M1_009");
		// ====字体与大小====
		AssertUtil.checkFontName(TextEditor.element("TextEditor14"), "KaiTi", "测试用例Control_TextEditor_M1_010");
		AssertUtil.checkFontSize(TextEditor.element("TextEditor14"), "25px", "测试用例Control_TextEditor_M1_010");
		// ====字体为斜体====
		AssertUtil.checkFontStyle(TextEditor.element("TextEditor15"), "italic", "测试用例Control_TextEditor_M1_011");
		// ====字体为粗体====
		AssertUtil.checkFontWeight(TextEditor.element("TextEditor16"), "bold", "测试用例Control_TextEditor_M1_012");
		// ====公共属性文本框保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor2"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor3"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor4"), false, "测试用例Control_TextEditor_M1_013");

		AssertUtil.checkEnabled(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor8"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor10"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor9"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor17"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor11"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor12"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor13"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor14"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor15"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor16"), false, "测试用例Control_TextEditor_M1_013");

		AssertUtil.checkRequired(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.uiCheck(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_013");

		AssertUtil.checkForeColor(TextEditor.element("TextEditor12"), "0, 93, 211", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkBackColor(TextEditor.element("TextEditor13"), "244, 171, 0", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontName(TextEditor.element("TextEditor14"), "KaiTi", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontSize(TextEditor.element("TextEditor14"), "25px", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontStyle(TextEditor.element("TextEditor15"), "italic", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontWeight(TextEditor.element("TextEditor16"), "bold", "测试用例Control_TextEditor_M1_013");

		MainContainer.closeTab(1);
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);

		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor2"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor3"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor4"), false, "测试用例Control_TextEditor_M1_013");

		AssertUtil.checkEnabled(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor8"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor10"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor9"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor17"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor11"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor12"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor13"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor14"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor15"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor16"), false, "测试用例Control_TextEditor_M1_013");

		AssertUtil.checkRequired(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_013");
		AssertUtil.uiCheck(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_013");

		AssertUtil.checkForeColor(TextEditor.element("TextEditor12"), "0, 93, 211", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkBackColor(TextEditor.element("TextEditor13"), "244, 171, 0", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontName(TextEditor.element("TextEditor14"), "KaiTi", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontSize(TextEditor.element("TextEditor14"), "25px", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontStyle(TextEditor.element("TextEditor15"), "italic", "测试用例Control_TextEditor_M1_013");
		AssertUtil.checkFontWeight(TextEditor.element("TextEditor16"), "bold", "测试用例Control_TextEditor_M1_013");

		MainContainer.closeAllTab();
	}

}
