package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class ComboBox_01 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/ComboBoxTest/ComboBox_01View").dblClick();
		// ====可用性与可见性====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(ComboBox.element("ComboBox1"), false, "测试用例Control_ComboBox_M4_001");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox2"), false, "测试用例Control_ComboBox_M4_001");
		AssertUtil.checkDisplayed(ComboBox.element("ComboBox3"), true, "测试用例Control_ComboBox_M4_001");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox4"), true, "测试用例Control_ComboBox_M4_001");

		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(ComboBox.element("ComboBox1"), false, "测试用例Control_ComboBox_M4_001");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox2"), false, "测试用例Control_ComboBox_M4_001");
		AssertUtil.checkDisplayed(ComboBox.element("ComboBox3"), false, "测试用例Control_ComboBox_M4_001");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox4"), false, "测试用例Control_ComboBox_M4_001");
		// ====提示信息====
		AssertUtil.checkHovertext(ComboBox.element("ComboBox5"), "下拉框测试", "测试用例Control_ComboBox_M4_002");
		// ====必填====
		AssertUtil.checkRequired(ComboBox.element("ComboBox6"), true, "测试用例Control_ComboBox_M4_003");
		ComboBox.element("ComboBox6").dropDownClick().itemClick("A");
		AssertUtil.checkRequired(ComboBox.element("ComboBox6"), false, "测试用例Control_ComboBox_M4_003");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "A", "测试用例Control_ComboBox_M4_003");
		ComboBox.element("ComboBox6").dropDownClick().itemClick("");
		AssertUtil.checkRequired(ComboBox.element("ComboBox6"), true, "测试用例Control_ComboBox_M4_003");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("必填： 不能为空");
		ErrorDialog.element().close();
		Button.element("Button1").click();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "B", "测试用例Control_ComboBox_M4_003");
		AssertUtil.checkRequired(ComboBox.element("ComboBox6"), false, "测试用例Control_ComboBox_M4_003");
		// ====检查规则与错误描述====
		AssertUtil.uiCheck(ComboBox.element("ComboBox7"), true, "测试用例Control_ComboBox_M4_004");
		ComboBox.element("ComboBox7").dropDownClick().itemClick("A");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox7"), "A", "测试用例Control_ComboBox_M4_004");
		AssertUtil.uiCheck(ComboBox.element("ComboBox7"), true, "测试用例Control_ComboBox_M4_004");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("值==C");
		ErrorDialog.element().close();
		Button.element("Button2").click();
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox7"), "C", "测试用例Control_ComboBox_M4_004");
		AssertUtil.uiCheck(ComboBox.element("ComboBox7"), false, "测试用例Control_ComboBox_M4_004");
		// ====默认值====
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox8"), "C", "测试用例Control_ComboBox_M4_005");
		// ====默认值公式====
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox9"), "B", "测试用例Control_ComboBox_M4_006");
		// ====前景色====
		AssertUtil.checkForeColor(ComboBox.element("ComboBox10"), "255, 234, 52", "测试用例Control_ComboBox_M4_007");
		// ====背景色====
		AssertUtil.checkBackColor(ComboBox.element("ComboBox11"), "164, 54, 255", "测试用例Control_ComboBox_M4_008");
		// ====字体与大小====
		AssertUtil.checkFontSize(ComboBox.element("ComboBox12"), "30px", "测试用例Control_ComboBox_M4_009");
		AssertUtil.checkFontName(ComboBox.element("ComboBox12"), "KaiTi", "测试用例Control_ComboBox_M4_009");
		// ====字体为粗体====
		AssertUtil.checkFontWeight(ComboBox.element("ComboBox13"), "bold", "测试用例Control_ComboBox_M4_010");
		// ====字体为斜体====
		AssertUtil.checkFontStyle(ComboBox.element("ComboBox14"), "italic", "测试用例Control_ComboBox_M4_011");
		// ====公共属性文本框保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkDisplayed(ComboBox.element("ComboBox1"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox2"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkDisplayed(ComboBox.element("ComboBox3"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox4"), false, "测试用例Control_ComboBox_M4_012");
		
		AssertUtil.checkEnabled(ComboBox.element("ComboBox6"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox7"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox8"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox9"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox10"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox11"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox12"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox13"), false, "测试用例Control_ComboBox_M4_012");
		AssertUtil.checkEnabled(ComboBox.element("ComboBox14"), false, "测试用例Control_ComboBox_M4_012");
		
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox6"), "B", "测试用例Control_ComboBox_M4_012");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox7"), "C","测试用例Control_ComboBox_M4_012");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox8"), "C","测试用例Control_ComboBox_M4_012");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox9"), "B","测试用例Control_ComboBox_M4_012");
		
		
		MainContainer.closeAllTab();
		
		
		
		
	}

}
