package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class NumberEditor_02 extends AbstractTestScript {
	public void run() {
		// ====数值框绑定数据列为整型====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/NumberEditorTest/NumberEditor_02View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "1,215",
				"测试用例Control_NumberEditor_M2_014");
		Button.element("Button1").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "-1,050",
				"测试用例Control_NumberEditor_M2_014");
		NumberEditor.element("NumberEditor1").clear();
		NumberEditor.element("NumberEditor1").input("123456.321").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "123,456,321",
				"测试用例Control_NumberEditor_M2_014");
		NumberEditor.element("NumberEditor1").paste("-5999.99").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "-6,000",
				"测试用例Control_NumberEditor_M2_014");
		// ====是否去尾零====
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "9,999.99",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "9,999.99000",
				"测试用例Control_NumberEditor_M2_015");
		Button.element("Button2").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "-1,111",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "-1,111.00000",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditor.element("NumberEditor2").clear();
		NumberEditor.element("NumberEditor3").clear();
		NumberEditor.element("NumberEditor2").input("3214.0001").pressEnterKey();
		NumberEditor.element("NumberEditor3").input("3214.0001").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "3,214.0001",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "3,214.00010",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditor.element("NumberEditor2").clear();
		NumberEditor.element("NumberEditor3").clear();
		NumberEditor.element("NumberEditor2").paste("888888.08800").pressEnterKey();
		NumberEditor.element("NumberEditor3").paste("888888.08800").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "888,888.088",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "888,888.08800",
				"测试用例Control_NumberEditor_M2_015");
		// ====数值精度====
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor4"), "3.2",
				"测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "55,555.3334",
				"测试用例Control_NumberEditor_M2_016");
		Button.element("Button3").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor4"), "-2.5",
				"测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "-20,031.6667",
				"测试用例Control_NumberEditor_M2_016");
		NumberEditor.element("NumberEditor4").clear();
		NumberEditor.element("NumberEditor5").clear();
		NumberEditor.element("NumberEditor4").input("123456.78999").pressEnterKey();
		NumberEditor.element("NumberEditor5").input("123456.78999").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor4"), "1.7",
				"测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "12,345.7899",
				"测试用例Control_NumberEditor_M2_016");
		NumberEditor.element("NumberEditor4").paste("99999.99").pressEnterKey();
		NumberEditor.element("NumberEditor5").paste("99999.99").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor4"), "", "测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "99,999.9900",
				"测试用例Control_NumberEditor_M2_016");
//暂不测
//		NumberEditor.element("NumberEditor16").input("100000000000000").pressEnterKey();
//		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor16"), "100,000,000,000,00.000", "测试用例Control_NumberEditor_M2_016   ");
		// ====进位规则====
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "6,543.13",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor7"), "5,614.124",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor8"), "564.1102",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor9"), "258.3692",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor10"), "213.321",
				"测试用例Control_NumberEditor_M2_017");
		Button.element("Button4").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "6,543.93",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor7"), "9,874.903",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor8"), "455.9002",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor9"), "-258.3691",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor10"), "-213.322",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditor.element("NumberEditor6").clear();
		NumberEditor.element("NumberEditor7").clear();
		NumberEditor.element("NumberEditor8").clear();
		NumberEditor.element("NumberEditor6").paste("-99999.991").pressEnterKey();
		NumberEditor.element("NumberEditor7").paste("-99999.9912").pressEnterKey();
		NumberEditor.element("NumberEditor8").paste("-99999.99003").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "-99,999.99",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor7"), "-99,999.992",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor8"), "-99,999.9900",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditor.element("NumberEditor9").clear();
		NumberEditor.element("NumberEditor10").clear();
		NumberEditor.element("NumberEditor9").paste("-99999.99028").pressEnterKey();
		NumberEditor.element("NumberEditor10").paste("-99999.9909").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor9"), "-99,999.9902",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor10"), "-99,999.991",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditor.element("NumberEditor9").clear();
		NumberEditor.element("NumberEditor10").clear();
		NumberEditor.element("NumberEditor9").paste("99999.99021").pressEnterKey();
		NumberEditor.element("NumberEditor10").paste("99999.9988").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor9"), "99,999.9903",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor10"), "99,999.998",
				"测试用例Control_NumberEditor_M2_017");
		// ====显示零值====
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor11"), "0.00",
				"测试用例Control_NumberEditor_M2_018");
		NumberEditor.element("NumberEditor11").clear();
		NumberEditor.element("NumberEditor11").input("0").pressEnterKey();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor11"), "0.00",
				"测试用例Control_NumberEditor_M2_018");
		// ====无组分割====
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor12"), "98745612300000.321456",
				"测试用例Control_NumberEditor_M2_019");
		Button.element("Button5").click();
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor12"), "-45678932101234.100100",
				"测试用例Control_NumberEditor_M2_019");
		// ====提示文本====
		NumberEditorUtil.checkPromptText(NumberEditor.element("NumberEditor13"), "数值框测试",
				"测试用例Control_NumberEditor_M2_020");
		NumberEditor.element("NumberEditor13").click();
		NumberEditorUtil.checkPromptText(NumberEditor.element("NumberEditor13"), "数值框测试",
				"测试用例Control_NumberEditor_M2_020");
		// ====组件属性数值框保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor1"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor2"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor3"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor4"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor7"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor8"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor9"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor10"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor11"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor12"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor13"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor14"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor15"), false, "测试用例Control_NumberEditor_M2_022");

		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "-6,000",
				"测试用例Control_NumberEditor_M2_014");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "888,888.088",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "888,888.08800",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor4"), "", "测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "99,999.9900",
				"测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "-99,999.99",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor7"), "-99,999.992",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor8"), "-99,999.9900",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor9"), "99,999.9903",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor10"), "99,999.998",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor11"), "0.00",
				"测试用例Control_NumberEditor_M2_018");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor12"), "-45678932101234.100100",
				"测试用例Control_NumberEditor_M2_019");
		
		MainContainer.closeTab(1);
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);
		
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor1"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor2"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor3"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor4"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor5"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor6"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor7"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor8"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor9"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor10"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor11"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor12"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor13"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor14"), false, "测试用例Control_NumberEditor_M2_022");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor15"), false, "测试用例Control_NumberEditor_M2_022");

		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "-6,000",
				"测试用例Control_NumberEditor_M2_014");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "888,888.088",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "888,888.08800",
				"测试用例Control_NumberEditor_M2_015");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor4"), "", "测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor5"), "99,999.9900",
				"测试用例Control_NumberEditor_M2_016");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor6"), "-99,999.99",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor7"), "-99,999.992",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor8"), "-99,999.9900",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor9"), "99,999.9903",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor10"), "99,999.998",
				"测试用例Control_NumberEditor_M2_017");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor11"), "0.00",
				"测试用例Control_NumberEditor_M2_018");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor12"), "-45678932101234.100100",
				"测试用例Control_NumberEditor_M2_019");
		MainContainer.closeAllTab();
		
	}

}
