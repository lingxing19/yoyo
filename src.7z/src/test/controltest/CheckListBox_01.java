package test.controltest;


import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckListBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CheckListBox_01 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckListBox").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckListBox/CheckListBox_01View").dblClick();
		// ====可用性与可见性====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(CheckListBox.element("CheckListBox1"), false, "测试用例Control_ CheckListBox_M5_001");
		AssertUtil.checkEnabled(CheckListBox.element("CheckListBox2"), false, "测试用例Control_ CheckListBox_M5_001");
		AssertUtil.checkDisplayed(CheckListBox.element("CheckListBox3"), true, "测试用例Control_ CheckListBox_M5_001");
		AssertUtil.checkEnabled(CheckListBox.element("CheckListBox4"), true, "测试用例Control_ CheckListBox_M5_001");

		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(CheckListBox.element("CheckListBox1"), false, "测试用例Control_ CheckListBox_M5_001");
		AssertUtil.checkEnabled(CheckListBox.element("CheckListBox2"), false, "测试用例Control_ CheckListBox_M5_001");
		AssertUtil.checkDisplayed(CheckListBox.element("CheckListBox3"), false, "测试用例Control_ CheckListBox_M5_001");
		AssertUtil.checkEnabled(CheckListBox.element("CheckListBox4"), false, "测试用例Control_ CheckListBox_M5_001");
		// ====必填====
		AssertUtil.checkRequired(CheckListBox.element("CheckListBox5"), true, "测试用例Control_ CheckListBox_M5_002");
		CheckListBox.element("CheckListBox5").dropDownClick();
		CheckListBox.element("CheckListBox5").itemClick("A");
		CheckListBox.element("CheckListBox5").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox5"), "A",
				"测试用例Control_ CheckListBox_M5_002");
		AssertUtil.checkRequired(CheckListBox.element("CheckListBox5"), false, "测试用例Control_ CheckListBox_M5_002");
		CheckListBox.element("CheckListBox5").dropDownClick();
		CheckListBox.element("CheckListBox5").itemClick("A");
		CheckListBox.element("CheckListBox5").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox5"), "", "测试用例Control_ CheckListBox_M5_002");
		AssertUtil.checkRequired(CheckListBox.element("CheckListBox5"), true, "测试用例Control_ CheckListBox_M5_002");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkShowErrorDialog("必填： 不能为空");
		ErrorDialog.element().close("关闭");
		Button.element("Button1").click();
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox5"), "B,C",
				"测试用例Control_ CheckListBox_M5_002");
		AssertUtil.checkRequired(CheckListBox.element("CheckListBox5"), false, "测试用例Control_ CheckListBox_M5_002");
		// ====检查规则与错误描述====
		AssertUtil.uiCheck(CheckListBox.element("CheckListBox6"), true, "测试用例Control_ CheckListBox_M5_003");
		CheckListBox.element("CheckListBox6").dropDownClick();
		CheckListBox.element("CheckListBox6").itemClick("A");
		CheckListBox.element("CheckListBox6").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox6"), "A",
				"测试用例Control_ CheckListBox_M5_003");
		AssertUtil.uiCheck(CheckListBox.element("CheckListBox6"), true, "测试用例Control_ CheckListBox_M5_003");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkShowErrorDialog("与必填相等");
		ErrorDialog.element().close("关闭");
		Button.element("Button2").click();
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox6"), "B,C",
				"测试用例Control_ CheckListBox_M5_003");
		AssertUtil.uiCheck(CheckListBox.element("CheckListBox6"), false, "测试用例Control_ CheckListBox_M5_003");
		// ====默认值====
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox7"), "A,C",
				"测试用例Control_ CheckListBox_M5_004");
		// ====默认值公式====
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox8"), "B,C",
				"测试用例Control_ CheckListBox_M5_005");
		// ====值改变事件====
		CheckListBox.element("CheckListBox9").dropDownClick();
		CheckListBox.element("CheckListBox9").itemClick("A").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox9"), "A",
				"测试用例Control_ CheckListBox_M5_006");
		AssertUtil.checkForeColor(Label.element("Label4"), "255, 0, 0", "测试用例Control_ CheckListBox_M5_006");
		Button.element("Button3").click();
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox10"), "A,B",
				"测试用例Control_ CheckListBox_M5_006");
		AssertUtil.checkBackColor(Label.element("Lab_CheckListBox10"), "255, 236, 8",
				"测试用例Control_ CheckListBox_M5_006");
		// ====提示信息====
		AssertUtil.checkHovertext(CheckListBox.element("CheckListBox11"), "多选下拉框测试",
				"测试用例Control_ CheckListBox_M5_007");
		// ====前景色====
		AssertUtil.checkForeColor(CheckListBox.element("CheckListBox12"), "255, 0, 0",
				"测试用例Control_ CheckListBox_M5_008");
		// ====背景色====
		AssertUtil.checkBackColor(CheckListBox.element("CheckListBox13"), "145, 61, 0",
				"测试用例Control_ CheckListBox_M5_009");

		MainContainer.closeAllTab();

	}

}
