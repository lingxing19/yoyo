package test.controltest;



import com.bokesoft.yes.autotest.common.util.CheckListBoxUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CheckListBox_03 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/CheckListBox/CheckListBox_03View").dblClick();
		// ====下拉项无caption也可存入value值====
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		CheckListBox.element("CheckListBox2").dropDownClick().itemClick("CAPTION2","");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox2"), "CAPTION2", true, "测试用例Control_ CheckListBox_M5_018");
		CheckListBoxUtil.checkChecked(CheckListBox.element("CheckListBox2"), "", true, "测试用例Control_ CheckListBox_M5_018");
		CheckListBox.element("CheckListBox2").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox2"), "CAPTION2,", "测试用例Control_ CheckListBox_M5_018");
        ToolBarButton.element("保存").click();
        CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox2"), "CAPTION2,", "测试用例Control_ CheckListBox_M5_018");
    	String[][] expTable = {{"2,3"}};
		DataBaseUtil.checkDataMatch("SELECT CheckListBox2 FROM CheckListBox_03Head", expTable, "测试用例CheckListBox_M5_018");
		// ====多选下拉框动态依赖====
		ToolBarButton.element("编辑").click();
		CheckListBox.element("CheckListBox3").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox3"), "深圳", "测试用例CheckListBox_M5_019");
		CheckListBox.element("CheckListBox3").itemClick("深圳").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox3"), "深圳", "测试用例CheckListBox_M5_019");
		CheckListBox.element("CheckListBox4").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox4"), "北京上海", "测试用例CheckListBox_M5_019");
		CheckListBox.element("CheckListBox4").itemClick("北京","上海").clickName("确定");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox4"), "北京,上海", "测试用例CheckListBox_M5_019");
		NumberEditor.element("NumberEditor1").clear();
		NumberEditor.element("NumberEditor1").input("3").pressEnterKey();
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox3"), "", "测试用例CheckListBox_M5_019");
		CheckListBox.element("CheckListBox3").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox3"), "重庆", "测试用例CheckListBox_M5_019");
		CheckListBox.element("CheckListBox3").backClick();
		DatePicker.element("DatePicker1").viewClick();
		DatePicker.element("DatePicker1").viewInput(2018, "十一月", 16);
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox4"), "", "测试用例CheckListBox_M5_019");
		CheckListBox.element("CheckListBox4").dropDownClick();
		CheckListBoxUtil.checkgetItemsValue(CheckListBox.element("CheckListBox4"), "北京", "测试用例CheckListBox_M5_019");
        MainContainer.closeAllTab();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
