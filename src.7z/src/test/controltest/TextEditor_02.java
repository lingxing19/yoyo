package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;
import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Text;

public class TextEditor_02 extends AbstractTestScript {
	public void run() {
		// ====文本框长度设置====

		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/TextEditorTest/TextEditor_02View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		Button.element("Button1").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"),
				"坚持总体国家安全观，是习近平新时代中国特色社会主义思想的重要内容。党的十九大报告强调，统筹发展和安全，增强忧患意识，做到居安思危，是我们党治国理政的一个重大原则。习近平同志围绕总体国家安全观发表的一系列重要论述，立意高远，内涵丰富，思想深邃，把我们党对国家安全的认识提升到了新的高度和境界，是指导新时代国家安全工作的强大思想武器，对于新时代坚持总体国家安全观，坚定不移走中国特色国家安全道路，完善国家安全体制机制，加强国家安全能力建设，有效维护国家安全，实现“两个一百年”奋斗目标、实现中华民族伟大复兴的中国梦，具有十分重要的意义。",
				"测试用例Control_TextEditor_M1_014");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "坚持总体国家安全观", "测试用例Control_TextEditor_M1_014");
		TextEditor.element("TextEditor1")
				.paste("坚持总体国家安全观，是习近平新时代中国特色社会主义思想的重要内容。党的十九大报告强调，统筹发展和安全，增强忧患意识，做到居安思危，是我们党治国理政的一个重大原则。习近平同志围绕总体国家安全观发表的一系列重要论述，立意高远，内涵丰富，思想深邃，把我们党对国家安全的认识提升到了新的高度和境界，是指导新时代国家安全工作的强大思想武器，对于新时代坚持总体国家安全观，坚定不移走中国特色国家安全道路，完善国家安全体制机制，加强国家安全能力建设，有效维护国家安全，实现“两个一百年”奋斗目标、实现中华民族伟大复兴的中国梦，具有十分重要的意义。")
				.pressEnterKey();
		TextEditor.element("TextEditor2")
				.paste("坚持总体国家安全观，是习近平新时代中国特色社会主义思想的重要内容。党的十九大报告强调，统筹发展和安全，增强忧患意识，做到居安思危，是我们党治国理政的一个重大原则。习近平同志围绕总体国家安全观发表的一系列重要论述，立意高远，内涵丰富，思想深邃，把我们党对国家安全的认识提升到了新的高度和境界，是指导新时代国家安全工作的强大思想武器，对于新时代坚持总体国家安全观，坚定不移走中国特色国家安全道路，完善国家安全体制机制，加强国家安全能力建设，有效维护国家安全，实现“两个一百年”奋斗目标、实现中华民族伟大复兴的中国梦，具有十分重要的意义。")
				.pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"),
				"坚持总体国家安全观，是习近平新时代中国特色社会主义思想的重要内容。党的十九大报告强调，统筹发展和安全，增强忧患意识，做到居安思危，是我们党治国理政的一个重大原则。习近平同志围绕总体国家安全观发表的一系列重要论述，立意高远，内涵丰富，思想深邃，把我们党对国家安全的认识提升到了新的高度和境界，是指导新时代国家安全工作的强大思想武器，对于新时代坚持总体国家安全观，坚定不移走中国特色国家安全道路，完善国家安全体制机制，加强国家安全能力建设，有效维护国家安全，实现“两个一百年”奋斗目标、实现中华民族伟大复兴的中国梦，具有十分重要的意义。",
				"测试用例Control_TextEditor_M1_014");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "坚持总体国家安全观", "测试用例Control_TextEditor_M1_014");
		TextEditor.element("TextEditor2").clear();
		TextEditor.element("TextEditor2").input("控件测试自定义表单文本框").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "控件测试自定义表单", "测试用例Control_TextEditor_M1_014");
		// ====去除首尾空格====
		Button.element("Button3").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor4"), "Being Young",
				"测试用例Control_TextEditor_M1_015");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor6"), "  Being Young  ",
				"测试用例Control_TextEditor_M1_015");
		TextEditor.element("TextEditor4").clear();
		TextEditor.element("TextEditor6").clear();
		TextEditor.element("TextEditor4").input("  A B C D  控件测试   ").pressEnterKey();
		TextEditor.element("TextEditor6").input("  A B C D  控件测试   ").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor4"), "A B C D  控件测试",
				"测试用例Control_TextEditor_M1_015");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor6"), "  A B C D  控件测试   ",
				"测试用例Control_TextEditor_M1_015");
		TextEditor.element("TextEditor4").paste("      Best Friend      ").pressEnterKey();
		TextEditor.element("TextEditor6").paste("      Best Friend      ").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor4"), "Best Friend",
				"测试用例Control_TextEditor_M1_015");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor6"), "      Best Friend      ",
				"测试用例Control_TextEditor_M1_015");
		// ====大小写转换====
		Button.element("Button4").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "ACBDEFGHK", "测试用例Control_TextEditor_M1_015");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "abcdefghk", "测试用例Control_TextEditor_M1_015");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor8"), "acbdEFghk  ABCDefGHK",
				"测试用例Control_TextEditor_M1_015");
		TextEditor.element("TextEditor5").clear();
		TextEditor.element("TextEditor7").clear();
		TextEditor.element("TextEditor8").clear();
		TextEditor.element("TextEditor5").input("aaaBBBccc").pressEnterKey();
		TextEditor.element("TextEditor7").input("DDDeeeFFF").pressEnterKey();
		TextEditor.element("TextEditor8").input("aBcDeFgHk").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "AAABBBCCC", "测试用例Control_TextEditor_M1_016");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "dddeeefff", "测试用例Control_TextEditor_M1_016");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor8"), "aBcDeFgHk", "测试用例Control_TextEditor_M1_016");
		TextEditor.element("TextEditor5").paste("aBcDeFgHk").pressEnterKey();
		TextEditor.element("TextEditor7").paste("aBcDeFgHk").pressEnterKey();
		TextEditor.element("TextEditor8").paste("aBcDeFgHk").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "ABCDEFGHK", "测试用例Control_TextEditor_M1_016");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "abcdefghk", "测试用例Control_TextEditor_M1_016");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor8"), "aBcDeFgHk", "测试用例Control_TextEditor_M1_016");
		// ====非法字符====
		Button.element("Button2").click();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "也", "测试用例Control_TextEditor_M1_017");
		TextEditor.element("TextEditor3").clear();
		TextEditor.element("TextEditor3").input("ABc，非法字符不可输入！").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "A，非法字符！", "测试用例Control_TextEditor_M1_017");
		TextEditor.element("TextEditor3").paste("F.Vd+@和粘贴复制=？").pressEnterKey();
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "Vd粘贴复制？", "测试用例Control_TextEditor_M1_017");
		// ====空值提示====
		TextEditorUtil.checkPromptText(TextEditor.element("TextEditor9"), "此编辑框现为空：", "测试用例Control_TextEditor_M1_018");
		// ====左侧图标====
		TextEditorUtil.checkPreIcon(TextEditor.element("TextEditor12"), true, "setting.png",
				"测试用例Control_TextEditor_M1_020");
		// ====左侧内嵌文本====
		TextEditorUtil.checkEmbedText(TextEditor.element("TextEditor13"), "文本输入：", "测试用例Control_TextEditor_M1_021");
		// ====回车事件====
		TextEditor.element("TextEditor14").click();
		TextEditorUtil.checkFocusOn("TextEditor14", true, "测试用例Control_TextEditor_M1_022");
		TextEditor.element("TextEditor14").pressEnterKey();
		TextEditorUtil.checkFocusOn("TextEditor14", false, "测试用例Control_TextEditor_M1_022");
		AssertUtil.checkForeColor(Label.element("Label4"), "230, 77, 77", "测试用例Control_TextEditor_M1_022");
		AssertUtil.checkBackColor(Label.element("Label4"), "255, 255, 77", "测试用例Control_TextEditor_M1_022");
		// ====保持焦点====
		TextEditor.element("TextEditor15").click();
		TextEditorUtil.checkFocusOn("TextEditor15", true, "测试用例Control_TextEditor_M1_023");
		TextEditor.element("TextEditor15").pressEnterKey();
		TextEditorUtil.checkFocusOn("TextEditor15", true, "测试用例Control_TextEditor_M1_023");
		// ====组件属性文本框保存====
		ToolBarButton.element("保存").click();
		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor2"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor4"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor6"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor8"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor3"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor9"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor10"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor11"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor12"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor13"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor14"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor15"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor16"), false, "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"),
				"坚持总体国家安全观，是习近平新时代中国特色社会主义思想的重要内容。党的十九大报告强调，统筹发展和安全，增强忧患意识，做到居安思危，是我们党治国理政的一个重大原则。习近平同志围绕总体国家安全观发表的一系列重要论述，立意高远，内涵丰富，思想深邃，把我们党对国家安全的认识提升到了新的高度和境界，是指导新时代国家安全工作的强大思想武器，对于新时代坚持总体国家安全观，坚定不移走中国特色国家安全道路，完善国家安全体制机制，加强国家安全能力建设，有效维护国家安全，实现“两个一百年”奋斗目标、实现中华民族伟大复兴的中国梦，具有十分重要的意义。",
				"测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "控件测试自定义表单", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor4"), "Best Friend",
				"测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor6"), "      Best Friend      ",
				"测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "ABCDEFGHK", "测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "abcdefghk", "测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor8"), "aBcDeFgHk", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "Vd粘贴复制？", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkPromptText(TextEditor.element("TextEditor9"), "此编辑框现为空：", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkPreIcon(TextEditor.element("TextEditor12"), true, "setting.png",
				"测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkEmbedText(TextEditor.element("TextEditor13"), "文本输入：", "测试用例Control_TextEditor_M1_024");

		AssertUtil.checkForeColor(Label.element("Label4"), "230, 77, 77", "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkBackColor(Label.element("Label4"), "255, 255, 77", "测试用例Control_TextEditor_M1_024");

		MainContainer.closeTab(1);
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);

		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor2"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor4"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor6"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor5"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor7"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor8"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor3"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor9"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor10"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor11"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor12"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor13"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor14"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor15"), false, "测试用例Control_TextEditor_M1_024");
		AssertUtil.checkEnabled(TextEditor.element("TextEditor16"), false, "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"),
				"坚持总体国家安全观，是习近平新时代中国特色社会主义思想的重要内容。党的十九大报告强调，统筹发展和安全，增强忧患意识，做到居安思危，是我们党治国理政的一个重大原则。习近平同志围绕总体国家安全观发表的一系列重要论述，立意高远，内涵丰富，思想深邃，把我们党对国家安全的认识提升到了新的高度和境界，是指导新时代国家安全工作的强大思想武器，对于新时代坚持总体国家安全观，坚定不移走中国特色国家安全道路，完善国家安全体制机制，加强国家安全能力建设，有效维护国家安全，实现“两个一百年”奋斗目标、实现中华民族伟大复兴的中国梦，具有十分重要的意义。",
				"测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "控件测试自定义表单", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor4"), "Best Friend",
				"测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor6"), "      Best Friend      ",
				"测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor5"), "ABCDEFGHK", "测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor7"), "abcdefghk", "测试用例Control_TextEditor_M1_024");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor8"), "aBcDeFgHk", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor3"), "Vd粘贴复制？", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkPromptText(TextEditor.element("TextEditor9"), "此编辑框现为空：", "测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkPreIcon(TextEditor.element("TextEditor12"), true, "setting.png",
				"测试用例Control_TextEditor_M1_024");

		TextEditorUtil.checkEmbedText(TextEditor.element("TextEditor13"), "文本输入：", "测试用例Control_TextEditor_M1_024");

		MainContainer.closeAllTab();

	}

}
