package test.controltest;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DatePicker_01 extends AbstractTestScript {
	public void run() {
		// ====可用性与可见性====
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DatePickerTest").click();
		MenuEntry.element("Yigo_Control/Yigo_ControlCustomBill/DatePickerTest/DatePicker_01View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker1"), false, "测试用例Control_DatePicker_M3_001");
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker2"), true, "测试用例Control_DatePicker_M3_001");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker3"), false, "测试用例Control_DatePicker_M3_001");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker4"), true, "测试用例Control_DatePicker_M3_001");
		CheckBox.element("CheckBox1").click();
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker1"), false, "测试用例Control_DatePicker_M3_001");
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker2"), false, "测试用例Control_DatePicker_M3_001");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker3"), false, "测试用例Control_DatePicker_M3_001");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker4"), false, "测试用例Control_DatePicker_M3_001");
		// ====必填====
		AssertUtil.checkRequired(DatePicker.element("DatePicker5"), true, "测试用例Control_DatePicker_M3_002");
		Button.element("Button1").click();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker5"), "2018-08-28 13:24:25",
				"测试用例Control_DatePicker_M3_002");
		AssertUtil.checkRequired(DatePicker.element("DatePicker5"), false, "测试用例Control_DatePicker_M3_002");
		DatePicker.element("DatePicker5").clear();
		AssertUtil.checkRequired(DatePicker.element("DatePicker5"), true, "测试用例Control_DatePicker_M3_002");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		waittime(100);
		DialogUtil.checkErrorDialogText("必填： 不能为空");
		ErrorDialog.element().close();
		DatePicker.element("DatePicker5").input("2018").input("1123").input("214112").pressEnterKey();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker5"), "2018-11-23 21:41:12",
				"测试用例Control_DatePicker_M3_002");
		AssertUtil.checkRequired(DatePicker.element("DatePicker5"), false, "测试用例Control_DatePicker_M3_002");
		// ====检查规则与错误描述====
		AssertUtil.uiCheck(DatePicker.element("DatePicker6"), true, "测试用例Control_DatePicker_M3_003");
		AssertUtil.checkErrorInfo(DatePicker.element("DatePicker6"), "不为空", "测试用例Control_DatePicker_M3_003");
		Button.element("Button2").click();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker6"), "2018-08-28 15:54:56",
				"测试用例Control_DatePicker_M3_003");
		AssertUtil.uiCheck(DatePicker.element("DatePicker6"), false, "测试用例Control_DatePicker_M3_003");
		DatePicker.element("DatePicker6").clear().pressEnterKey();
		AssertUtil.uiCheck(DatePicker.element("DatePicker6"), true, "测试用例Control_DatePicker_M3_003");
		ToolBarButton.element("保存").click();
		DialogUtil.checkShowErrorDialog();
		DialogUtil.checkErrorDialogText("不为空");
		ErrorDialog.element().close();
		DatePicker.element("DatePicker6").input("2016").input("0501").input("201846").pressEnterKey();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker6"), "2016-05-01 20:18:46",
				"测试用例Control_DatePicker_M3_003");
		AssertUtil.uiCheck(DatePicker.element("DatePicker6"), false, "测试用例Control_DatePicker_M3_003");
		// ====提示信息====
		AssertUtil.checkHovertext(DatePicker.element("DatePicker7"), "日期框测试", "测试用例Control_DatePicker_M3_004");
		// ====值改变事件====
		DatePicker.element("DatePicker8").input("2015").input("0630").input("121415").pressEnterKey();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker8"), "2015-06-30 12:14:15",
				"测试用例Control_DatePicker_M3_005");
		AssertUtil.checkForeColor(Label.element("Label3"), "255, 0, 0", "测试用例Control_DatePicker_M3_005");
		Button.element("Button3").click();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker17"), "2016-05-31",
				"测试用例Control_DatePicker_M3_005");
		AssertUtil.checkForeColor(Label.element("Lab_DatePicker17"), "255, 0, 0", "测试用例Control_DatePicker_M3_005");
		// ====默认值====
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker9"), "2018-11-11 15:30:21",
				"测试用例Control_DatePicker_M3_006");
		DatePicker.element("DatePicker9").viewClick();
		DatePicker.element("DatePicker9").viewClick();
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker9"), "2018-11-11 15:30:21",
				"测试用例Control_DatePicker_M3_006");
		// ====默认值公式====
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker10"), "2016-05-31 00:00:00",
				"测试用例Control_DatePicker_M3_007");
		// ====前景色====
		AssertUtil.checkForeColor(DatePicker.element("DatePicker11"), "163, 59, 255", "测试用例Control_DatePicker_M3_008");
		// ====背景色====
		AssertUtil.checkBackColor(DatePicker.element("DatePicker12"), "255, 99, 0", "测试用例Control_DatePicker_M3_009");
		// ====字体与大小====
		AssertUtil.checkFontName(DatePicker.element("DatePicker13"), "Microsoft YaHei",
				"测试用例Control_DatePicker_M3_010");
		AssertUtil.checkFontSize(DatePicker.element("DatePicker13"), "20px", "测试用例Control_DatePicker_M3_010");
		// ====字体为粗体====
		AssertUtil.checkFontWeight(DatePicker.element("DatePicker16"), "bold", "测试用例Control_DatePicker_M3_011");
		// ====字体为斜体====
		AssertUtil.checkFontStyle(DatePicker.element("DatePicker15"), "italic", "测试用例Control_DatePicker_M3_012");
		// ====公共属性文本框保存====
		ToolBarButton.element("保存").click();

		AssertUtil.checkDisplayed(DatePicker.element("DatePicker1"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker2"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker3"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker4"), false, "测试用例Control_DatePicker_M3_013");

		AssertUtil.checkEnabled(DatePicker.element("DatePicker5"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker6"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker7"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker8"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker17"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker9"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker10"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker11"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker12"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker13"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker15"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker16"), false, "测试用例Control_DatePicker_M3_013");

		AssertUtil.checkRequired(DatePicker.element("DatePicker5"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.uiCheck(DatePicker.element("DatePicker6"), false, "测试用例Control_DatePicker_M3_013");

		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker10"), "2016-05-31 00:00:00",
				"Control_DatePicker_M3_013");
		AssertUtil.checkForeColor(DatePicker.element("DatePicker11"), "163, 59, 255", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkBackColor(DatePicker.element("DatePicker12"), "255, 99, 0", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontName(DatePicker.element("DatePicker13"), "Microsoft YaHei",
				"测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontSize(DatePicker.element("DatePicker13"), "20px", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontWeight(DatePicker.element("DatePicker16"), "bold", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontStyle(DatePicker.element("DatePicker15"), "italic", "测试用例Control_DatePicker_M3_013");

		MainContainer.closeTab(1);
		MainContainer.selectTab(0);
		ListView.element("list").dbClick(1);
		MainContainer.selectTab(1);

		AssertUtil.checkDisplayed(DatePicker.element("DatePicker1"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker2"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker3"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker4"), false, "测试用例Control_DatePicker_M3_013");

		AssertUtil.checkEnabled(DatePicker.element("DatePicker5"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker6"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker7"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker8"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker17"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker9"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker10"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker11"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker12"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker13"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker15"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker16"), false, "测试用例Control_DatePicker_M3_013");

		AssertUtil.checkRequired(DatePicker.element("DatePicker5"), false, "测试用例Control_DatePicker_M3_013");
		AssertUtil.uiCheck(DatePicker.element("DatePicker6"), false, "测试用例Control_DatePicker_M3_013");

		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker10"), "2016-05-31 00:00:00",
				"Control_DatePicker_M3_013");
		AssertUtil.checkForeColor(DatePicker.element("DatePicker11"), "163, 59, 255", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkBackColor(DatePicker.element("DatePicker12"), "255, 99, 0", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontName(DatePicker.element("DatePicker13"), "Microsoft YaHei",
				"测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontSize(DatePicker.element("DatePicker13"), "20px", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontWeight(DatePicker.element("DatePicker16"), "bold", "测试用例Control_DatePicker_M3_013");
		AssertUtil.checkFontStyle(DatePicker.element("DatePicker15"), "italic", "测试用例Control_DatePicker_M3_013");

		MainContainer.closeAllTab();

	}

}
