package test.SaveData;


import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;




public class Case_SaveData_M1_002  extends AbstractTestScript{
	public void run(){
		//测试用例Case_SaveData_M1_002
		MenuEntry.element("M1/M1CustomBill").click();
		MenuEntry.element("M1/M1CustomBill/SD_M1_001View").dblClick();
		MainContainer.selectTab(0);
		System.out.println("============================================================");				
		//新增：SD_M1_001（空值）
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);		
		waittime(500);
		//输入第1行单元格cell1：1
		Grid.element("Grid1").cellDbInput("cell15", 1, "1").pressEnterKey();		
		//保存单据
		ToolBarButton.element("保存").click();	
		//选定当前页签
		System.out.println("============================================================");
		MainContainer.selectTab(1);	
		//获取单据编号NO
		String el = TextEditor.element("NO").getText();
		
		
		//检查空单元格数据保存
		GridUtil.checkCellValue("Grid1", "cell0_CheckBox", 1, "");
		GridUtil.checkCellValue("Grid1", "cell1_TextEditor", 1, "");
		GridUtil.checkCellValue("Grid1", "cell2_NumberEditor", 1, "");
		GridUtil.checkCellValue("Grid1", "cell3_Dict", 1, "");
		GridUtil.checkCellValue("Grid1", "cell4_Dict2", 1, "");
		GridUtil.checkCellValue("Grid1", "cell5_DynamicDict", 1, "");
		GridUtil.checkCellValue("Grid1", "cell6_DynamicDict", 1, "");
		GridUtil.checkCellValue("Grid1", "cell7_Combox", 1, "");
		GridUtil.checkCellValue("Grid1", "cell8_CheckListBox", 1, "");
		GridUtil.checkCellValue("Grid1", "cell9_DatePicker", 1, "");
		GridUtil.checkCellValue("Grid1", "cell10_UTCDatePicker", 1, "");		
		//关闭所有页签
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		// 重新打开刚刚保存的单据
		waittime(500);
		MenuEntry.element("M1/M1CustomBill").click();
		MenuEntry.element("M1/M1CustomBill/SD_M1_001View").dblClick();
		MainContainer.selectTab(0);
		//双击打开		
		ListView.element("list").dbClick("单据编号", el, "", "");
		MainContainer.selectTab(1);		
		//检查保存后的单元格数据是否正确
		GridUtil.checkCellValue("Grid1", "cell0_CheckBox", 1, "");
		GridUtil.checkCellValue("Grid1", "cell1_TextEditor", 1, "");
		GridUtil.checkCellValue("Grid1", "cell2_NumberEditor", 1, "");
		GridUtil.checkCellValue("Grid1", "cell3_Dict", 1, "");
		GridUtil.checkCellValue("Grid1", "cell4_Dict2", 1, "");
		GridUtil.checkCellValue("Grid1", "cell5_DynamicDict", 1, "");
		GridUtil.checkCellValue("Grid1", "cell6_DynamicDict", 1, "");
		GridUtil.checkCellValue("Grid1", "cell7_Combox", 1, "");
		GridUtil.checkCellValue("Grid1", "cell8_CheckListBox", 1, "");
		GridUtil.checkCellValue("Grid1", "cell9_DatePicker", 1, "");
		GridUtil.checkCellValue("Grid1", "cell10_UTCDatePicker", 1, "");

		//关闭所有页签
		MainContainer.closeAllTab();
		System.out.println("============================================================");	
	}

}