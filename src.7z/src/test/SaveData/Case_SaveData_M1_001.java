package test.SaveData;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.ui.Sleeper;

import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.CheckListBoxUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.RadioButtonUtil;
import com.bokesoft.yes.autotest.common.util.TextAreaUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.common.util.UTCDatePickerUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextArea;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.component.factory.UTCDatePicker;
import com.bokesoft.yes.autotest.script.AbstractTestScript;



public class Case_SaveData_M1_001  extends AbstractTestScript{
	public void run(){
		//测试用例Case_SaveData_M1_001

		MenuEntry.element("M1/M1CustomBill").click();
		MenuEntry.element("M1/M1CustomBill/SD_M1_001View").dblClick();
		MainContainer.selectTab(0);
		
		//新增：SD_M1_001（空值）		
		System.out.println("============================================================");
		ToolBarButton.element("新增").click();
		//保存单据
		MainContainer.selectTab(1);
		ToolBarButton.element("保存").click();		
		MainContainer.selectTab(1);
		//获取单据编号NO
		String el = TextEditor.element("NO").getText();		
//		检查保存单据信息
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "", "测试用例Case_SaveData_M1_001——TextEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "", "测试用例Case_SaveData_M1_001——NumberEditor1");
		DictUtil.checkInputValue("Dict1", "", "测试用例Case_SaveData_M1_001——Dict1");
		DictUtil.checkInputValue("Dict2", "", "测试用例Case_SaveData_M1_001——Dict2");
		DictUtil.checkInputValue("DynamicDict1", "", "测试用例Case_SaveData_M1_001——DynamicDict1");
		DictUtil.checkInputValue("DynamicDict2", "", "测试用例Case_SaveData_M1_001——DynamicDict2");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox3"), "", "测试用例Case_SaveData_M1_001——ComboBox3");		
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox1"), "", "测试用例Case_SaveData_M1_001——CheckListBox1");
		CheckBoxUtil.checkChecked("CheckBox1", false, "测试用例Case_SaveData_M1_001——CheckBox1");
		TextAreaUtil.checkInputValue(TextArea.element("TextArea1"), "", "测试用例Case_SaveData_M1_001——TextArea1");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "", "测试用例Case_SaveData_M1_001——DatePicker1");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker1"), "", "测试用例Case_SaveData_M1_001——UTCDatePicker1");

		//关闭所有页签
		MainContainer.closeAllTab();
		waittime(1000);
		System.out.println("============================================================");
		// 重新打开表单：SD001
		MenuEntry.element("M1/M1CustomBill").click();
		MenuEntry.element("M1/M1CustomBill/SD_M1_001View").dblClick();
		MainContainer.selectTab(0);
		//双击打开		
		ListView.element("list").dbClick("单据编号", el, "", "");
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "", "测试用例Case_SaveData_M1_001——TextEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "", "测试用例Case_SaveData_M1_001——NumberEditor1");
		DictUtil.checkInputValue("Dict1", "", "测试用例Case_SaveData_M1_001——Dict1");
		DictUtil.checkInputValue("Dict2", "", "测试用例Case_SaveData_M1_001——Dict2");
		DictUtil.checkInputValue("DynamicDict1", "", "测试用例Case_SaveData_M1_001——DynamicDict1");
		DictUtil.checkInputValue("DynamicDict2", "", "测试用例Case_SaveData_M1_001——DynamicDict2");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox3"), "", "测试用例Case_SaveData_M1_001——ComboBox3");		
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox1"), "", "测试用例Case_SaveData_M1_001——CheckListBox1");
		CheckBoxUtil.checkChecked("CheckBox1", false, "测试用例Case_SaveData_M1_001——CheckBox1");
		TextAreaUtil.checkInputValue(TextArea.element("TextArea1"), "", "测试用例Case_SaveData_M1_001——TextArea1");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "", "测试用例Case_SaveData_M1_001——DatePicker1");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker1"), "", "测试用例Case_SaveData_M1_001——UTCDatePicker1");
		
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		
		
	}

}