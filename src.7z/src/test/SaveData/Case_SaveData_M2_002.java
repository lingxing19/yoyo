package test.SaveData;



import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;




public class Case_SaveData_M2_002  extends AbstractTestScript{
	public void run(){
		//测试用例Case_SaveData_M2_002
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_001View").dblClick();
		MainContainer.selectTab(0);	
		//新增：SD_M2_001（正确值）
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);		
		//单击Button1按钮给控件赋值
		Button.element("Button1").click();
		//保存单据
		ToolBarButton.element("保存").click();	
		//选定当前页签
		MainContainer.selectTab(1);	
		//获取单据编号NO
		String el = TextEditor.element("NO").getText();
		System.out.println("============================================================");		
		//检查头控件数据保存
		GridUtil.checkGridCheckBoxChecked("Grid1", "cell0_CheckBox", 1, true,"Case_SaveData_M2_002");
		GridUtil.checkCellValue("Grid1", "cell1_TextEditor", 1, "a1");
		GridUtil.checkCellValue("Grid1", "cell2_NumberEditor", 1, "1.00");
		GridUtil.checkCellValue("Grid1", "cell3_Dict", 1, "H111 南汇");
		GridUtil.checkCellValue("Grid1", "cell4_Dict2", 1, "w2 w2");
		GridUtil.checkCellValue("Grid1", "cell5_DynamicDict", 1, "H1111 滴水湖");
		GridUtil.checkCellValue("Grid1", "cell6_DynamicDict", 1, "w3 w3");
		GridUtil.checkCellValue("Grid1", "cell7_Combox", 1, "status1");
		GridUtil.checkCellValue("Grid1", "cell8_CheckListBox", 1, "status1,status2");
		GridUtil.checkCellValue("Grid1", "cell9_DatePicker", 1, "2019-02-20 19:45:33");
		GridUtil.checkCellValue("Grid1", "cell10_UTCDatePicker", 1, "2019-02-20");		
		//关闭所有页签
		MainContainer.closeAllTab();
		// 重新打开刚刚保存的单据
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_001View").dblClick();
		MainContainer.selectTab(0);
		//双击打开		
		ListView.element("list").dbClick("单据编号", el, "", "");
		MainContainer.selectTab(1);		
		//检查保存后的单元格数据是否正确
		GridUtil.checkGridCheckBoxChecked("Grid1", "cell0_CheckBox", 1, true,"Case_SaveData_M2_002");
		GridUtil.checkCellValue("Grid1", "cell1_TextEditor", 1, "a1");
		GridUtil.checkCellValue("Grid1", "cell2_NumberEditor", 1, "1.00");
		GridUtil.checkCellValue("Grid1", "cell3_Dict", 1, "H111 南汇");
		GridUtil.checkCellValue("Grid1", "cell4_Dict2", 1, "w2 w2");
		GridUtil.checkCellValue("Grid1", "cell5_DynamicDict", 1, "H1111 滴水湖");
		GridUtil.checkCellValue("Grid1", "cell6_DynamicDict", 1, "w3 w3");
		GridUtil.checkCellValue("Grid1", "cell7_Combox", 1, "status1");
		GridUtil.checkCellValue("Grid1", "cell8_CheckListBox", 1, "status1,status2");
		GridUtil.checkCellValue("Grid1", "cell9_DatePicker", 1, "2019-02-20 19:45:33");
		GridUtil.checkCellValue("Grid1", "cell10_UTCDatePicker", 1, "2019-02-20");
		//关闭所有页签
		MainContainer.closeAllTab();
		System.out.println("============================================================");	
	}

}