package test.SaveData;


import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.CheckListBoxUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.RadioButtonUtil;
import com.bokesoft.yes.autotest.common.util.TextAreaUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.common.util.UTCDatePickerUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextArea;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.component.factory.UTCDatePicker;
import com.bokesoft.yes.autotest.script.AbstractTestScript;




public class Case_SaveData_M2_001  extends AbstractTestScript{
	public void run(){
		//测试用例Case_SaveData_M1_002
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_001View").dblClick();
		MainContainer.selectTab(0);			
		//新增：SD_M2_001（正确值）
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);		
		waittime(500);
		//单击Button1按钮给控件赋值
		Button.element("Button1").click();
		//保存单据
		ToolBarButton.element("保存").click();	
		//选定当前页签
		MainContainer.selectTab(1);	
		//获取单据编号NO
		String el = TextEditor.element("NO").getText();
		String e2 = "各位项目实施人员：凡是2019年1月——4月与项目有关的各类费用，没有在系统录入《项目费用申请单》的，请在4月30日之前补录到系统中，请注意以下事项：1、《项目费用申请单》头表的 【单据日期】一定是 费用发生当月或者 之前的日期。明细表的【会计期间】一定是业务发生的当月。2、2019年1月——4月公司代买飞机票，也需要填写《项目费用申请单》，需要飞机乘坐人补录到系统中，请参考附件。注意：         1)已经提交送审的《公司代买飞机票报销单》的，已经经过处理，自动生成《项目费用申请单》了，无需补录。         2)未填写《公司代买飞机票报销单》，或者已填写未送审的，请补录《项目费用申请单》。在补录过程中，有问题可以咨询部门内勤。从2019年5月份开始，费用申请单的单据日期将封闭，没有补录的人，无法再经过修改单据日期进行补录，从而无法进行费用报销。请大家务必重视！请大家务必重视！请大家务必重视！";
//		driver.quit();
		System.out.println("============================================================");		
		//检查头控件数据保存
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "a1", "测试用例Case_SaveData_M2_001——TextEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "1.00", "测试用例Case_SaveData_M2_001——NumberEditor1");
		DictUtil.checkInputValue("Dict1", "H111 南汇", "测试用例Case_SaveData_M2_001——Dict1");
		DictUtil.checkInputValue("Dict2", "w2 w2", "测试用例Case_SaveData_M2_001——Dict2");
		DictUtil.checkInputValue("DynamicDict1", "H1111 滴水湖", "测试用例Case_SaveData_M2_001——DynamicDict1");
		DictUtil.checkInputValue("DynamicDict2", "w3 w3", "测试用例Case_SaveData_M2_001——DynamicDict2");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "Dict1", "测试用例Case_SaveData_M2_001——ComboBox1(固定值)");		
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "status1", "测试用例Case_SaveData_M2_001——Status(状态值)");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox1"), "status1,status2", "测试用例Case_SaveData_M2_001——CheckListBox1");
		CheckBoxUtil.checkChecked("CheckBox1", true, "测试用例Case_SaveData_M2_001——CheckBox1");
		RadioButtonUtil.checkRadioBtChecked("RadioButton1", false, "测试用例Case_SaveData_M2_001——RadioButton1");
		RadioButtonUtil.checkRadioBtChecked("RadioButton2", true, "测试用例Case_SaveData_M2_001——RadioButton2");
		TextAreaUtil.checkInputValue(TextArea.element("TextArea1"), e2, "测试用例Case_SaveData_M2_001——TextArea1");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2019-02-20 19:45:33", "测试用例Case_SaveData_M2_001——DatePicker1");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker1"), "2019-02-20", "测试用例Case_SaveData_M2_001——UTCDatePicker1");
	
		//关闭所有页签
		MainContainer.closeAllTab();
		

		// 重新打开刚刚保存的单据
		
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_001View").dblClick();
		MainContainer.selectTab(0);
		//双击打开		
		ListView.element("list").dbClick("单据编号", el, "", "");
		MainContainer.selectTab(1);		
		//检查保存后的单元格数据是否正确
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "a1", "测试用例Case_SaveData_M2_001——TextEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "1.00", "测试用例Case_SaveData_M2_001——NumberEditor1");
		DictUtil.checkInputValue("Dict1", "H111 南汇", "测试用例Case_SaveData_M2_001——Dict1");
		DictUtil.checkInputValue("Dict2", "w2 w2", "测试用例Case_SaveData_M2_001——Dict2");
		DictUtil.checkInputValue("DynamicDict1", "H1111 滴水湖", "测试用例Case_SaveData_M2_001——DynamicDict1");
		DictUtil.checkInputValue("DynamicDict2", "w3 w3", "测试用例Case_SaveData_M2_001——DynamicDict2");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "Dict1", "测试用例Case_SaveData_M2_001——ComboBox1(固定值)");		
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "status1", "测试用例Case_SaveData_M2_001——Status(状态值)");
		CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox1"), "status1,status2", "测试用例Case_SaveData_M2_001——CheckListBox1");
		CheckBoxUtil.checkChecked("CheckBox1", true, "测试用例Case_SaveData_M2_001——CheckBox1");
		RadioButtonUtil.checkRadioBtChecked("RadioButton1", false, "测试用例Case_SaveData_M2_001——RadioButton1");
		RadioButtonUtil.checkRadioBtChecked("RadioButton2", true, "测试用例Case_SaveData_M2_001——RadioButton2");
		TextAreaUtil.checkInputValue(TextArea.element("TextArea1"), e2, "测试用例Case_SaveData_M2_001——TextArea1");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2019-02-20 19:45:33", "测试用例Case_SaveData_M2_001——DatePicker1");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker1"), "2019-02-20", "测试用例Case_SaveData_M2_001——UTCDatePicker1");

		//关闭所有页签
		MainContainer.closeAllTab();
		System.out.println("============================================================");	
	}

}