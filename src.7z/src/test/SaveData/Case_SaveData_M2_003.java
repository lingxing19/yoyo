package test.SaveData;


import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;




public class Case_SaveData_M2_003  extends AbstractTestScript{
	public void run(){
		//测试用例Case_SaveData_M1_002
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_001View").dblClick();
		MainContainer.selectTab(0);			
		//新增：SD_M2_001（正确值）
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);		
		waittime(500);
		//单击Button1按钮给控件赋值
		Button.element("Button1").click();
		//保存单据
		ToolBarButton.element("保存").click();	
		//选定当前页签
		MainContainer.selectTab(1);	
		//获取单据编号NO
		String el = TextEditor.element("NO").getText();
		System.out.println("============================================================");		
		//检查新编辑的下拉框，头控件数据保存
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox3"), "6", "测试用例Case_SaveData_M2_003——可编辑的ComboBox3(整型)");		
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "com21", "测试用例Case_SaveData_M2_003——可编辑的ComboBox5(字符串)");		
		//检查新编辑的下拉框，单元格数据保存
		GridUtil.checkCellValue("Grid1", "cell13_ComboBox", 1, "com21");
		GridUtil.checkCellValue("Grid1", "cell15_ComboBox", 1, "6");
		//关闭所有页签
		MainContainer.closeAllTab();
		// 重新打开刚刚保存的单据
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_001View").dblClick();
		MainContainer.selectTab(0);
		//双击打开		
		ListView.element("list").dbClick("单据编号", el, "", "");
		MainContainer.selectTab(1);		
		
		//检查保存后的新编辑的下拉框，头控件数据是否正确
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox3"), "6", "测试用例Case_SaveData_M2_003——可编辑的ComboBox3(整型)");		
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "com21", "测试用例Case_SaveData_M2_003——可编辑的ComboBox5(字符串)");
		//检查保存后的新编辑的下拉框，单元格数据是否正确
		GridUtil.checkCellValue("Grid1", "cell13_ComboBox", 1, "com21");
		GridUtil.checkCellValue("Grid1", "cell15_ComboBox", 1, "6");
		//关闭所有页签
		MainContainer.closeAllTab();
		System.out.println("============================================================");	
	}

}