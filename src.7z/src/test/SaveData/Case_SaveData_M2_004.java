package test.SaveData;


import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.MonthPickerUtil;
import com.bokesoft.yes.autotest.common.util.UTCDatePickerUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;
import com.bokesoft.yes.autotest.component.factory.UTCDatePicker;


public class Case_SaveData_M2_004  extends AbstractTestScript{
	public void run(){
		//测试用例Case_SaveData_M1_002
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_002View").dblClick();
		MainContainer.selectTab(0);	
		System.out.println(MainContainer.selectTab(0));
		//新增：SD_M2_001（正确值）
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);		
		waittime(500);
		
		//单击Button1按钮给控件赋值
		Button.element("Button1").click();
		//保存单据
		ToolBarButton.element("保存").click();	
		//选定当前页签
		MainContainer.selectTab(1);	
		//获取单据编号NO
		String el = TextEditor.element("NO").getText();
		System.out.println("============================================================");		
		//检查日期，头控件数据保存
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2019-02-20 19:45:33", "测试用例Case_SaveData_M2_004——DatePicker1");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2019-02-20", "测试用例Case_SaveData_M2_004——DatePicker2");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker1"), "2019-02-20 12:00:00", "测试用例Case_SaveData_M2_004——UTCDatePicker1");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker2"), "2019-02-20", "测试用例Case_SaveData_M2_004——UTCDatePicker2");
//		String e3 = driver.findElement(ById("mpInput_2_MonthPicker2"));
//		if (e3.equals("2019-06")) {
//			LogImpl.getInstance().info( "======检查成功 结果为:" + e3);
//			return;
//		}
//		LogImpl.getInstance().error( "======检查失败 预期结果为:" + e3 + "	实际结果为:" + e3);
//	};

		//		MonthPickerUtil.checkInputValue(MonthPicker.element("MonthPicker1"),"","测试用例Case_SaveData_M2_004——MonthPicker1");
//		TimePickerUtil.checkInputValue(TimePicker.element("TimePicker1"),"","测试用例Case_SaveData_M2_004——TimePicker1");
//		MonthPickerUtil.checkInputValue(MonthPicker.element("MonthPicker2"),"2019-06","测试用例Case_SaveData_M2_004——MonthPicker1");
//		TimePickerUtil.checkInputValue(TimePicker.element("TimePicker2"),"19:45","测试用例Case_SaveData_M2_004——TimePicker1");
//		TimePickerUtil.checkInputValue(TimePicker.element("TimePicker3"),"19:45:36","测试用例Case_SaveData_M2_004——TimePicker1");
				
		//检查日期，单元格数据保存
		GridUtil.checkCellValue("Grid1", "cell9_DatePicker", 1, "2019-02-20");
		GridUtil.checkCellValue("Grid1", "cell10_UTCDatePicker", 1, "2019-02-20 12:00:00");
		GridUtil.checkCellValue("Grid1", "cell15_MonthPicker", 1, "");
		GridUtil.checkCellValue("Grid1", "cell13_MonthPicker", 1, "2019-06");
		GridUtil.checkCellValue("Grid1", "cell16_TimePicker", 1, "");
		GridUtil.checkCellValue("Grid1", "cell14_TimePicker", 1, "19:45");
		GridUtil.checkCellValue("Grid1", "cell17_TimePicker", 1, "19:45:36");
		//关闭所有页签
		MainContainer.closeAllTab();
		// 重新打开刚刚保存的单据
		MenuEntry.element("M2/M2CustomBill").click();
		MenuEntry.element("M2/M2CustomBill/SD_M2_002View").dblClick();
		SearchBox.element().searchclick("SD_M2_002(整型日期)视图");
//		MainContainer.selectTab(0);
		//双击打开				
		ListView.element("list").dbClick("单据编号", el, "", "");
		MainContainer.selectTab(1);		
		
		//检查保存后的新编辑的下拉框，头控件数据是否正确
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2019-02-20 19:45:33", "测试用例Case_SaveData_M2_004——DatePicker1");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker2"), "2019-02-20", "测试用例Case_SaveData_M2_004——DatePicker2");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker1"), "2019-02-20 12:00:00", "测试用例Case_SaveData_M2_004——UTCDatePicker1");
		UTCDatePickerUtil.checkInputValue(UTCDatePicker.element("UTCDatePicker2"), "2019-02-20", "测试用例Case_SaveData_M2_004——UTCDatePicker2");
//		MonthPickerUtil.checkInputValue(MonthPicker.element("MonthPicker1"),"","测试用例Case_SaveData_M2_004——MonthPicker1");
//		TimePickerUtil.checkInputValue(TimePicker.element("TimePicker1"),"","测试用例Case_SaveData_M2_004——TimePicker1");
//		MonthPickerUtil.checkInputValue(MonthPicker.element("MonthPicker2"),"2019-06","测试用例Case_SaveData_M2_004——MonthPicker1");
//		TimePickerUtil.checkInputValue(TimePicker.element("TimePicker2"),"19:45","测试用例Case_SaveData_M2_004——TimePicker1");
//		TimePickerUtil.checkInputValue(TimePicker.element("TimePicker3"),"19:45:36","测试用例Case_SaveData_M2_004——TimePicker1");
			//检查保存后日期，单元格数据保存
		GridUtil.checkCellValue("Grid1", "cell9_DatePicker", 1, "2019-02-20");
		GridUtil.checkCellValue("Grid1", "cell10_UTCDatePicker", 1, "2019-02-20 12:00:00");
		GridUtil.checkCellValue("Grid1", "cell15_MonthPicker", 1, "");
		GridUtil.checkCellValue("Grid1", "cell13_MonthPicker", 1, "2019-06");
		GridUtil.checkCellValue("Grid1", "cell16_TimePicker", 1, "");
		GridUtil.checkCellValue("Grid1", "cell14_TimePicker", 1, "19:45");
		GridUtil.checkCellValue("Grid1", "cell17_TimePicker", 1, "19:45:36");
		//关闭所有页签
		MainContainer.closeAllTab();
		System.out.println("============================================================");	
	}

}