package test.SaveData;




import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextAreaUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextArea;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;


public class Case_SaveData_M3_001  extends AbstractTestScript{
	public void run(){
		//测试用例Case_SaveData_M3_001
		MenuEntry.element("M3/M3CustomBill").click();
		MenuEntry.element("M3/M3CustomBill/SD_M3_001View").dblClick();
		MainContainer.selectTab(0);			
		//新增：SD_M3_001（特殊值）
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);		
		waittime(500);
		//单击Button1按钮给控件赋值
		Button.element("Button1").click();
		//保存单据
		ToolBarButton.element("保存").click();	
		//选定当前页签
		MainContainer.selectTab(1);	
		//获取单据编号NO
		String el = TextEditor.element("NO").getText();
		System.out.println("============================================================");		
		//检查头控件数据保存
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "<font>你好</font>", "测试用例Case_SaveData_M3_001——TextEditor1");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "<font>你好</font>", "测试用例Case_SaveData_M3_001——ComboBox5");
		TextAreaUtil.checkInputValue(TextArea.element("TextArea1"), "<font>你好</font>", "测试用例Case_SaveData_M3_001——TextArea1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "0.00", "测试用例Case_SaveData_M3_001——NumberEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "99,999,999,999,999.99", "测试用例Case_SaveData_M3_001——NumberEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "-99,999,999,999,999.99", "测试用例Case_SaveData_M3_001——NumberEditor3");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "$与.", "测试用例Case_SaveData_M3_001——TextEditor2");
			
		//检查单元格数据保存
		GridUtil.checkCellValue("Grid1", "cell1_TextEditor", 1, "<font>你好</font>");
		GridUtil.checkCellValue("Grid1", "cell7_ComboxBox", 1, "<font>@@@</font>");
		GridUtil.checkCellValue("Grid1", "cell2_NumberEditor", 1, "0.00");
		GridUtil.checkCellValue("Grid1", "cell16_NumberEditor", 1, "99,999,999,999,999.99");
		GridUtil.checkCellValue("Grid1", "cell15_NumberEditor", 1, "-99,999,999,999,999.99");
		GridUtil.checkCellValue("Grid1", "cell10_TextEditor", 1, "$与.");
		//关闭所有页签
		MainContainer.closeAllTab();
		// 重新打开刚刚保存的单据
		waittime(1000);
		MenuEntry.element("M3/M3CustomBill/SD_M3_001View").dblClick();
		MainContainer.selectTab(0);			
		//双击打开		
		ListView.element("list").dbClick("单据编号", el, "", "");
		MainContainer.selectTab(1);	
		//检查头控件数据保存
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "<font>你好</font>", "测试用例Case_SaveData_M3_001——TextEditor1");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox5"), "<font>你好</font>", "测试用例Case_SaveData_M3_001——ComboBox5");
		TextAreaUtil.checkInputValue(TextArea.element("TextArea1"), "<font>你好</font>", "测试用例Case_SaveData_M3_001——TextArea1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "0.00", "测试用例Case_SaveData_M3_001——NumberEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "99,999,999,999,999.99", "测试用例Case_SaveData_M3_001——NumberEditor1");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor3"), "-99,999,999,999,999.99", "测试用例Case_SaveData_M3_001——NumberEditor3");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "$与.", "测试用例Case_SaveData_M3_001——TextEditor2");
		waittime(500);
		//检查单元格数据保存
		GridUtil.checkCellValue("Grid1", "cell1_TextEditor", 1, "<font>你好</font>");
		GridUtil.checkCellValue("Grid1", "cell7_ComboxBox", 1, "<font>@@@</font>");
		GridUtil.checkCellValue("Grid1", "cell2_NumberEditor", 1, "0.00");
		GridUtil.checkCellValue("Grid1", "cell16_NumberEditor", 1, "99,999,999,999,999.99");
		GridUtil.checkCellValue("Grid1", "cell15_NumberEditor", 1, "-99,999,999,999,999.99");
		GridUtil.checkCellValue("Grid1", "cell10_TextEditor", 1, "$与.");
		//关闭所有页签
		MainContainer.closeAllTab();
		System.out.println("============================================================");	
	}

}