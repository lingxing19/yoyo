package test.grid;


import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_007 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_007View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		waittime(1000);
	 
		//检查单元格的值是否正确
		GridUtil.checkCellValue("Grid1", "四舍五入", 1, "12,345.235");
		GridUtil.checkCellValue("Grid1", "舍入", 1, "12,345.234");
		GridUtil.checkCellValue("Grid1", "进位", 1, "12,345.24");
		GridUtil.checkCellValue("Grid1", "不分组", 1, "12345.23");
		GridUtil.checkCellValue("Grid1", "零值提示", 1, "为0值");
		GridUtil.checkCellValue("Grid1", "是整型", 1, "12,345");
		GridUtil.checkCellValue("Grid1", "显示零值", 1, "0.00");
		GridUtil.checkCellValue("Grid1", "1/0", 1, "#DIV/0");
		GridUtil.checkCelForeColor("Grid1", "负数前景色", 1, "230, 77, 77");
		
		//去尾零
		Grid.element("Grid1").cellInput("去尾零", 1, "123.00").pressEnterKey();
		GridUtil.checkCellValue("Grid1", "去尾零", 1, "123");
		//去尾零+零值+零值字符串
		GridUtil.checkCellValue("Grid1", "去尾零/零值/字符串", 1, "123");
		Grid.element("Grid1").cellInput("去尾零/零值/字符串", 1, "0").pressEnterKey();
		GridUtil.checkCellValue("Grid1", "去尾零/零值/字符串", 1, "abc");
		
	    //单元格【四舍五入】，输入“12345678901234.1234”
		Grid.element("Grid1").cellDbInput("四舍五入", 1, "12345678901234.1234").pressEnterKey();
		GridUtil.checkCellValue("Grid1", "四舍五入", 1, "1,234,567,890,123.123");
	    //点击保存
		ToolBar.element("ToolBar1").click("Save");
		
	    //校验头表保存值是否正确
		waittime(1000);
		String[][] expTable = {
									{"12345.2345600000"}};
		DataBaseUtil.checkDataMatch("SELECT NumberEditor1 FROM GT_M1_007", expTable, "测试用例CASE_GT_M1_007");
				
		//校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable1 = {
									{"1234567890123.123","12345.2340000000","12345.2400000000","12345.2300000000","12345.00","0.00"}};
		DataBaseUtil.checkDataMatch("SELECT TNum1,TNum2,TNum3,TNum4,cell1,cell2 FROM AgridNnmberDetail", expTable1, "测试用例CASE_GT_M1_007");
		MainContainer.closeAllTab();
	
		System.out.println("================================================================================================================");
	    
	
	
	
	
	}
}
