package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_009 extends AbstractTestScript {
	//列公式标题
	
		public void run(){
			MenuEntry.element("GridTest/GridTest").click();
			MenuEntry.element("GridTest/GridTest/M4").click();
			MenuEntry.element("GridTest/GridTest/M4/GT_M4_009View").dblClick();		
			MainContainer.selectTab(0);
			ToolBar.element("main_toolbar").click("New");
			MainContainer.selectTab(1);
			
			GridUtil.checkGridTitleName("detail", "上海");
		    GridUtil.checkGridExpColName("detail", "北京");
		}

}
