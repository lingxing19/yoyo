package test.grid;


import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_010 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_010View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
	
	
		//点击表格第一行【按钮1】
		Grid.element("detail_grid").cellButtonClick("按钮1", 1);
	    NumberEditorUtil.checkInputValue(NumberEditor.element("No1KeyLong"), "2,014.00", "测试用例CASE_GT_M1_010");
	    GridUtil.checkCellValue("detail_grid", "文本框", 1, "0.0005");
	    
	    //点击表格第一行【按钮2】
		Grid.element("detail_grid").cellButtonClick("按钮2", 1);
	    NumberEditorUtil.checkInputValue(NumberEditor.element("No1KeyLong"), "2,015.00", "测试用例CASE_GT_M1_010");
	    GridUtil.checkCellValue("detail_grid", "文本框", 1, "false");
	
        //【表格第一行，文本按钮1】，双击获得焦点，粘贴
	    Grid.element("detail_grid").dbPaste("文本按钮1", 1, "2BaAbBdDeE34").pressEnterKey();
	    GridUtil.checkCellValue("detail_grid", "文本按钮1", 1, "2BAb");
	    
	    //【表格第一行，文本按钮2】，双击获得焦点，粘贴  
	    Grid.element("detail_grid").dbPaste("文本按钮2", 1, "2BaAbBdDeE34").pressEnterKey();
	    GridUtil.checkCellValue("detail_grid", "文本按钮2", 1, "baabbdd");
	    
	    //【表格第一行，文本按钮3】，双击获得焦点，粘贴
	    Grid.element("detail_grid").dbPaste("文本按钮3", 1, "2BaAbBdDeE34").pressEnterKey();
	    GridUtil.checkCellValue("detail_grid", "文本按钮3", 1, "AADDEE34");
	
	    //点击表格第一行【文本按钮1】（右侧“...”）
	    Grid.element("detail_grid").cellTextButtonClick("文本按钮1", 1);
	    TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "2BAb", "测试用例CASE_GT_M1_010");
	
	    //点击表格第一行【文本按钮3】（右侧“...”）
	    Grid.element("detail_grid").cellTextButtonClick("文本按钮3", 1);
	    ConfirmDialog.element().close();

	    MainContainer.selectTab(0);
	    ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
	 
		//点击表格第一行[链接]
	    Grid.element("detail_grid").cellHyperLinkClick("链接", 1);
	
	    ConfirmDialog.element().close();
	
	    MainContainer.closeAllTab();
	
	    System.out.println("================================================================================================================");
	    
	}
}
