package test.grid;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M2_005 extends AbstractTestScript{
	public void run(){
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M2").click();
		MenuEntry.element("GridTest/GridTest/M2/GT_M2_005View").dblClick();		
		MainContainer.selectTab(0);
		//打开单据：1（单据编号）
		ListView.element("ListView1").dbClick(1);
		MainContainer.selectTab(1);	
		//单击列标题“数量”
		Grid.element("GT_M2_005Detail").GridColClick("数量");
		waittime(500);
		GridUtil.checkGridColValue("GT_M2_005Detail", "数量", "5,000.001002003004005001500");
		//单击列标题“数量”
		Grid.element("GT_M2_005Detail").GridColClick("数量");
		waittime(500);
		GridUtil.checkGridColValue("GT_M2_005Detail", "数量", "5,000.005004003002001001500");	
		//单击列标题“物料”
		Grid.element("GT_M2_005Detail").GridColClick("物料");
		GridUtil.checkGridColValue("GT_M2_005Detail", "物料", "null01 手机01 手机01 手机01 手机11 女装null");
		//单击列标题“物料”
		Grid.element("GT_M2_005Detail").GridColClick("物料");
		GridUtil.checkGridColValue("GT_M2_005Detail", "物料", "null11 女装01 手机01 手机01 手机01 手机null");
		//点击【编辑】
		ToolBar.element("main_toolbar").click("Edit1");
		//修改，数量—1：52.00
		Grid.element("GT_M2_005Detail").cellDbInput("数量", 1, "52").pressEnterKey();
		GridUtil.checkCellValue("GT_M2_005Detail", "数量", 1, "52.00");
		//修改，单价—1：博科
		Grid.element("GT_M2_005Detail").cellDbInput("单价", 1, "博科").pressEnterKey();
		GridUtil.checkCellValue("GT_M2_005Detail", "单价", 1, "博科");
		//点击 【保存】
		ToolBar.element("main_toolbar").click("Save");
		
		//校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable = {
									{"57000.00","19732","博科","52.00"}};
		DataBaseUtil.checkDataMatch("SELECT total,warehouse,txt,[1] FROM GT_M2_005Head", expTable, "测试用例CASE_GT_M2_005");
		MainContainer.closeAllTab();
	    
		System.out.println("================================================================================================================");
	    
	}
}
