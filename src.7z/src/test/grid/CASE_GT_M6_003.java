package test.grid;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M6_003 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M6").click();
		MenuEntry.element("GridTest/GridTest/M6/GT_M6_003View").dblClick();		
		MainContainer.selectTab(0);
	    //点击【新增】
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(1);
	    //在“物料”单元格输入：001 大众朗逸
	    Grid.element("GT_M6_003Detail").celDictClick("物料", 1).dictItemClick("001 大众朗逸");
	    NumberEditorUtil.checkInputValue(NumberEditor.element("L1"), "1.00", "");
        DictUtil.checkInputValue("BillArea1", "001 大众朗逸", "");
        ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "实体", "");
        AssertUtil.checkEnabled(Dict.element("Dict2"), false, "");
        GridUtil.checkColDisplayed("Grid1","销售额", false);
     
	    //输入，数量—1：10

        Grid.element("GT_M6_003Detail").cellDbInput("数量", 1, "10").pressEnterKey();
        waittime(500);
        GridUtil.cellUICheck("GT_M6_003Detail", "数量", 1, false);
        GridUtil.checkColDisplayed("Grid1","销售额", true);
        //输入，单价—1：5
        Grid.element("GT_M6_003Detail").cellDbInput("单价", 1, "5").pressEnterKey();
        GridUtil.cellUICheck("GT_M6_003Detail", "成本", 1, true);
        //修改，单价A：5000
        NumberEditor.element("NumberEditor2").clear().input("5000").pressEnterKey();
        GridUtil.cellUICheck("GT_M6_003Detail", "成本", 1, false);
        //修改，数量A：101
        NumberEditor.element("BillAmount1").clear().input("101").pressEnterKey();
        GridUtil.rowUICheck("GT_M6_003Detail", 1, true);
        //清空，数量A
        NumberEditor.element("BillAmount1").clear().pressEnterKey();
        GridUtil.rowUICheck("GT_M6_003Detail", 1, true);
        GridUtil.cellUICheck("GT_M6_003Detail", "成本", 1, true);
        GridUtil.cellUICheck("GT_M6_003Detail", "数量", 1, true);
        //输入，数量—1：101，物料A：002 奥迪
        Grid.element("GT_M6_003Detail").cellDbInput("数量", 1, "101");
        Dict.element("BillArea1").viewClick().itemClick("002 奥迪");
        NumberEditorUtil.checkInputValue(NumberEditor.element("L1"), "2.00", "");
        NumberEditorUtil.checkInputValue(NumberEditor.element("L2"), "2.00", "");
        //修改，类型A：电商
        ComboBox.element("ComboBox1").dropDownClick().itemClick("电商");
        AssertUtil.checkEnabled(Dict.element("Dict2"), true, "");
        GridUtil.checkCellEnabled("GT_M6_003Detail", "平台", 1, true);
        //选择，平台—1：京东
        Grid.element("GT_M6_003Detail").celDictClick("平台", 1).dictItemClick("京东");
        //子明细中输入2行数据
        Grid.element("Grid1").celDictClick("地区", 1).dictItemClick("a01 西安");
        Grid.element("Grid1").cellDbInput("销售额", 1, "1000");
        Grid.element("Grid1").celDictClick("地区", 2).dictItemClick("a03 南宁");
        Grid.element("Grid1").cellDbInput("销售额", 2, "2000");
        // 点击【保存】
        ToolBar.element("main_toolbar").click("Save");
        GridUtil.checkGridRowValue("GT_M6_003Detail", 1, " 奥迪101B5,000.00null电商京东");
        Grid.element("GT_M6_003Detail").cellClick("物料", 1);
        GridUtil.checkGridRowValue("Grid1", 1, "nulla01 西安1,000.00");
        GridUtil.checkGridRowValue("Grid1", 2, "nulla03 南宁2,000.00");
        MainContainer.closeAllTab();
        System.out.println("================================================================================================================");
	    
	}

}
