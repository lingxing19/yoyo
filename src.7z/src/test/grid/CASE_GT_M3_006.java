package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M3_006 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M3").click();
		MenuEntry.element("GridTest/GridTest/M3/GT_M3_006View").dblClick();		
		MainContainer.selectTab(0);
   	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(1);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 1, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "游客nullnull");
	
	    GridUtil.checkRowCount(Grid.element("Grid2"), 2, "");
	    GridUtil.checkGridRowValue("Grid2", 1, "A 北美nullnull");
	    GridUtil.checkGridRowValue("Grid2", 2, "B 东南亚nullnull");
		GridUtil.checkGridColValue("Grid1", "人员", "游客");
		GridUtil.checkGridColValue("Grid2", "仓库", "A 北美B 东南亚");
	    //头控件【Grid1查询过滤依赖值】选择：11052
		ComboBox.element("ComboBox2").dropDownClick().itemClick("11052");
		waittime(10000);
		GridUtil.checkRowCount(Grid.element("Grid1"), 6, "");
		GridUtil.checkGridRowValue("Grid1", 1, "游客nullnull");
		GridUtil.checkGridRowValue("Grid1", 2, "user1nullnull");
		GridUtil.checkGridRowValue("Grid1", 3, "user2nullnull");
		GridUtil.checkGridRowValue("Grid1", 4, "user3nullnull");
		GridUtil.checkGridRowValue("Grid1", 5, "user4nullnull");
		GridUtil.checkGridRowValue("Grid1", 6, "user5nullnull");
		GridUtil.checkGridColValue("Grid1", "人员", "游客user1user2user3user4user5");
	
		//头控件【Grid2字典过滤节点】输入：明细节点
		ComboBox.element("ComboBox3").dropDownClick().itemClick("明细节点");
		GridUtil.checkRowCount(Grid.element("Grid2"), 6, "");
		GridUtil.checkGridRowValue("Grid2", 1, "01 华东nullnull");
		GridUtil.checkGridRowValue("Grid2", 2, "02 华中nullnull");
		GridUtil.checkGridRowValue("Grid2", 3, "11 美国nullnull");
		GridUtil.checkGridRowValue("Grid2", 4, "12 加拿大nullnull");
		GridUtil.checkGridRowValue("Grid2", 5, "21 泰国nullnull");
		GridUtil.checkGridRowValue("Grid2", 6, "22 印尼nullnull");
		GridUtil.checkGridColValue("Grid2", "仓库", "01 华东02 华中11 美国12 加拿大21 泰国22 印尼");
	
		//录入Grid1：数量—1：1，数量—2：2，数量—3：3；备注—4：A，备注—5：B，备注—6：C
		Grid.element("Grid1").cellDbInput("数量", 1, "1");
		Grid.element("Grid1").cellDbInput("数量", 2, "2");
		Grid.element("Grid1").cellDbInput("数量", 3, "3");
		Grid.element("Grid1").cellDbInput("备注", 4, "A");
		Grid.element("Grid1").cellDbInput("备注", 5, "B");
		Grid.element("Grid1").cellDbInput("备注", 6, "C");
        //录入Grid2：数量—1：11，数量—2：22，数量—3：33；备注—4：AA，备注—5：BB，备注—6：CC
		Grid.element("Grid2").cellDbInput("数量", 1, "11");
		Grid.element("Grid2").cellDbInput("数量", 2, "22");
		Grid.element("Grid2").cellDbInput("数量", 3, "33");
		Grid.element("Grid2").cellDbInput("备注", 4, "AA");
		Grid.element("Grid2").cellDbInput("备注", 5, "BB");
		Grid.element("Grid2").cellDbInput("备注", 6, "CC");
		//点击【保存】
		ToolBar.element("ToolBar1").click("Save");
		GridUtil.checkRowCount(Grid.element("Grid1"), 6, "");
		GridUtil.checkRowCount(Grid.element("Grid2"), 6, "");
		GridUtil.checkGridRowValue("Grid1", 1, "游客1.00null");
		GridUtil.checkGridRowValue("Grid1", 2, "user12.00null");
		GridUtil.checkGridRowValue("Grid1", 3, "user23.00null");
		GridUtil.checkGridRowValue("Grid1", 4, "user3nullA");
		GridUtil.checkGridRowValue("Grid1", 5, "user4nullB");
		GridUtil.checkGridRowValue("Grid1", 6, "user5nullC");
		GridUtil.checkGridColValue("Grid1", "数量", "1.002.003.00nullnullnull");
		GridUtil.checkGridColValue("Grid1", "备注", "nullnullnullABC");
		
		GridUtil.checkGridRowValue("Grid2", 1, "01 华东11.00null");
		GridUtil.checkGridRowValue("Grid2", 2, "02 华中22.00null");
		GridUtil.checkGridRowValue("Grid2", 3, "11 美国33.00null");
		GridUtil.checkGridRowValue("Grid2", 4, "12 加拿大nullAA");
		GridUtil.checkGridRowValue("Grid2", 5, "21 泰国nullBB");
		GridUtil.checkGridRowValue("Grid2", 6, "22 印尼nullCC");
		GridUtil.checkGridColValue("Grid2", "数量", "11.0022.0033.00nullnullnull");
		GridUtil.checkGridColValue("Grid2", "备注", "nullnullnullAABBCC");
		MainContainer.closeAllTab();
		
		System.out.println("================================================================================================================");
	    
		
		
		
		
	}

}
