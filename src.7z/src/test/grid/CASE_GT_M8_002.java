package test.grid;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M8_002 extends AbstractTestScript {
	//多表查询
	public void run(){
		MenuEntry.element("GridTest/GridTest").click();
		waittime(5000);
		MenuEntry.element("GridTest/GridTest/M8").click();
		MenuEntry.element("GridTest/GridTest/M8/GT_M9_009View").dblClick();
		MainContainer.selectTab(0);
		waittime(500);
		DatePicker.element("DatePicker1").input("20190116");
		waittime(500);
		DatePicker.element("DatePicker1_Comp2").input("20190117");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 2, "CASE_GT_M8_002");
		ListViewUtil.checkValue("list", "日期1", 1, "2019-01-16");
		ListViewUtil.checkValue("list", "日期1", 2, "2019-01-17");
		ListViewUtil.CheckAllRows("ListView1", 2, "CASE_GT_M8_002");
		ListViewUtil.checkValue("ListView1", "日期1", 1, "2019-01-16");
		ListViewUtil.checkValue("ListView1", "日期1", 2, "2019-01-17");
		MainContainer.closeAllTab();
	}

}
