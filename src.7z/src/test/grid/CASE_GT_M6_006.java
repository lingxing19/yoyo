package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M6_006 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M6").click();
		MenuEntry.element("GridTest/GridTest/M6/GT_M6_006View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkRowCount(Grid.element("GT_M6_006Detail"), 4, "");
		GridUtil.checkGridRowValue("GT_M6_006Detail", 1, "01 手机01 华东1,000.003.00");
		GridUtil.checkGridRowValue("GT_M6_006Detail", 2, "03 笔记本B 东南亚2,000.0020.00");
		GridUtil.checkGridRowValue("GT_M6_006Detail", 3, "01 手机02 华中30.0060.00");
		GridUtil.checkGridRowValue("GT_M6_006Detail", 4, "02 耳机A 北美10.006.00");
		MainContainer.closeAllTab();
	
		System.out.println("================================================================================================================");
	    
	
	
	
	}

}
