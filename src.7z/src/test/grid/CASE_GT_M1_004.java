package test.grid;

import java.util.ArrayList;
import java.util.List;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.grid.BaseGridDictItem;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_004 extends AbstractTestScript{
	public void run() {
		waittime(500);
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_004View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		
		//点击：表格【Check1】:检查字典各节点是否正确
		waittime(500);
		List<BaseGridDictItem> expList = new ArrayList<BaseGridDictItem>();
		List<BaseGridDictItem> list=Grid.element("GT_M1_004Detail").celDictClick("Check1", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
		GridUtil.checkGridDictItemFiled(expList, list, "测试用例CASE_GT_M1_004");			
		GridUtil.checkGridDictRootNode("GT_M1_004Detail", "物料", "测试用例CASE_GT_M1_004");
		
		expList.clear();
		List<BaseGridDictItem> list1=Grid.element("GT_M1_004Detail").dictExpandItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机",1,0));		
		expList.add(new BaseGridDictItem("02 耳机",1,0));
		expList.add(new BaseGridDictItem("03 笔记本",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list1, "测试用例CASE_GT_M1_004");	
		
		expList.clear();
		List<BaseGridDictItem> list2=Grid.element("GT_M1_004Detail").dictExpandItemClick("B 服装类").getChildren(false);
 		expList.add(new BaseGridDictItem("11 女装",1,0));		
  		expList.add(new BaseGridDictItem("12 男装",1,0));
   		expList.add(new BaseGridDictItem("13 童装",1,0));
		GridUtil.checkGridDictItemFiled(expList, list2, "测试用例CASE_GT_M1_004");	
		
//		expList.clear();
//		List<BaseGridDictItem> list3=Grid.element("GT_M1_004Detail").dictExpandItemClick("C 食品类").getChildren(false);
//		GridUtil.checkGridDictItemFiled(expList, list3, "测试用例CASE_GT_M1_004");	
		
		//选择：B 服装类
		Grid.element("GT_M1_004Detail").dictItemClick("B 服装类");
		GridUtil.checkCellValue("GT_M1_004Detail", "Check1", 1, "B 服装类");
		//勾选：头控件【是否过滤物料】
		CheckBox.element("CheckBox1").click();
		GridUtil.checkCellValue("GT_M1_004Detail", "Check1", 1, "");
		//点击：表格【Check1】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list4=Grid.element("GT_M1_004Detail").celDictClick("Check1", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		GridUtil.checkGridDictItemFiled(list4, expList, "测试用例CASE_GT_M1_004");
		GridUtil.checkGridDictRootNode("GT_M1_004Detail", "物料", "测试用例CASE_GT_M1_004");
		//头控件【Depend1】选择“仓库”
		RadioButton.element("RadioButton2").click();
		//点击：表格【Check1】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list5=Grid.element("GT_M1_004Detail").celDictClick("Check1", 1).getChildren(true);
		expList.add(new BaseGridDictItem("01 华东",1,0));	
 		expList.add(new BaseGridDictItem("02 华中",1,0));	
		expList.add(new BaseGridDictItem("A 北美",1,1));
  		expList.add(new BaseGridDictItem("B 东南亚",1,1));
		GridUtil.checkGridDictItemFiled(expList, list5, "测试用例CASE_GT_M1_004");			
		GridUtil.checkGridDictRootNode("GT_M1_004Detail", "仓库", "测试用例CASE_GT_M1_004");
		
		expList.clear();
		List<BaseGridDictItem> list6=Grid.element("GT_M1_004Detail").dictExpandItemClick("A 北美").getChildren(false);
		expList.add(new BaseGridDictItem("11 美国",1,0));		
		expList.add(new BaseGridDictItem("12 加拿大",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list6, "测试用例CASE_GT_M1_004");	
		
		expList.clear();
		List<BaseGridDictItem> list7=Grid.element("GT_M1_004Detail").dictExpandItemClick("B 东南亚").getChildren(false);
 		expList.add(new BaseGridDictItem("21 泰国",1,0));		
  		expList.add(new BaseGridDictItem("22 印尼",1,0));
		GridUtil.checkGridDictItemFiled(expList, list7, "测试用例CASE_GT_M1_004");	
		//选择：11 美国
		Grid.element("GT_M1_004Detail").dictItemClick("11 美国");
		GridUtil.checkCellValue("GT_M1_004Detail", "Check1", 1, "11 美国");
		//勾选：当前行【是否过滤仓库】
		Grid.element("GT_M1_004Detail").cellCheckboxClick("是否过滤仓库", 1);
		GridUtil.checkGridCheckBoxChecked("GT_M1_004Detail", "是否过滤仓库", 1, true, "测试用例CASE_GT_M1_004");
		GridUtil.checkCellValue("GT_M1_004Detail", "Check1", 1, "");
		//点击：表格【Check1】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list8=Grid.element("GT_M1_004Detail").celDictClick("Check1", 1).getChildren(true);
		expList.add(new BaseGridDictItem("01 华东",1,0));	
 		expList.add(new BaseGridDictItem("02 华中",1,0));	
		expList.add(new BaseGridDictItem("A 北美",1,1));
  		expList.add(new BaseGridDictItem("B 东南亚",1,1));
		GridUtil.checkGridDictItemFiled(expList, list8, "测试用例CASE_GT_M1_004");			
		GridUtil.checkGridDictRootNode("GT_M1_004Detail", "仓库", "测试用例CASE_GT_M1_004");
		
		expList.clear();
		List<BaseGridDictItem> list9=Grid.element("GT_M1_004Detail").dictExpandItemClick("A 北美").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list9, "测试用例CASE_GT_M1_004");	
		
		expList.clear();
		List<BaseGridDictItem> list10=Grid.element("GT_M1_004Detail").dictExpandItemClick("B 东南亚").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list10, "测试用例CASE_GT_M1_004");	
		//点击：表格【Check2】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list11=Grid.element("GT_M1_004Detail").celDictClick("Check2", 1).getChildren(true);
		expList.add(new BaseGridDictItem("01 华东",1,0));	
 		expList.add(new BaseGridDictItem("02 华中",1,0));	
		expList.add(new BaseGridDictItem("A 北美",1,1));
  		expList.add(new BaseGridDictItem("B 东南亚",1,1));
		GridUtil.checkGridDictItemFiled(expList, list11, "测试用例CASE_GT_M1_004");			
		GridUtil.checkGridDictRootNode("GT_M1_004Detail", "仓库", "测试用例CASE_GT_M1_004");
		
		expList.clear();
		List<BaseGridDictItem> list12=Grid.element("GT_M1_004Detail").dictExpandItemClick("A 北美").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list12, "测试用例CASE_GT_M1_004");	
		
		expList.clear();
		List<BaseGridDictItem> list13=Grid.element("GT_M1_004Detail").dictExpandItemClick("B 东南亚").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list13, "测试用例CASE_GT_M1_004");	
		//选择： 02 华中
		Grid.element("GT_M1_004Detail").dictItemClick("02 华中");
		GridUtil.checkCellValue("GT_M1_004Detail", "Check2", 1, "02 华中");
		//当前行单元格【Depend2】选择“物料”
		Grid.element("GT_M1_004Detail").celComboClick("Depend2", 1).comboItemClick("物料");
		GridUtil.checkCellValue("GT_M1_004Detail", "Depend2", 1, "物料");
		GridUtil.checkCellValue("GT_M1_004Detail","Check2", 1, "");
		
		expList.clear();
		List<BaseGridDictItem> list14=Grid.element("GT_M1_004Detail").celDictClick("Check2", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));
		GridUtil.checkGridDictItemFiled(expList, list14, "测试用例CASE_GT_M1_004");			
		GridUtil.checkGridDictRootNode("GT_M1_004Detail", "物料", "测试用例CASE_GT_M1_004");
		
		//添加2行明细,点击保存
		Grid.element("GT_M1_004Detail").celDictClick("Check1", 2).dictItemClick("02 华中");
		Grid.element("GT_M1_004Detail").celDictClick("Check2", 3).dictItemClick("A 北美");
		ToolBar.element("main_toolbar").click("Save");
		
	    //校验头表保存值是否正确
		waittime(1000);
		String[][] expTable = {
									{"1","Warehouse"}};
		DataBaseUtil.checkDataMatch("SELECT CheckBox1,r FROM GT_M1_004Head", expTable, "测试用例CASE_GT_M1_004");
			
		//校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable1 = {
									{"1","0","Material","0"},
									{"0","10004","Warehouse","0"},
									{"0","0","Warehouse","19732"}};
		DataBaseUtil.checkDataMatch("SELECT c1,TText,d2,ch FROM GT_M1_004Detail", expTable1, "测试用例CASE_GT_M1_004");
		MainContainer.closeAllTab();
			
		System.out.println("================================================================================================================");
	    
		
		
		
		
		
	}
		
}
