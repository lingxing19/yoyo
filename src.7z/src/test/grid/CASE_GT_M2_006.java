package test.grid;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M2_006 extends AbstractTestScript {

	public void run() {

		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M2").click();
		MenuEntry.element("GridTest/GridTest/M2/GT_M2_006View").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);
		// 固定行绑定头表数据源
		Grid.element("detail").cellInput("数值", 1, "456");
		Grid.element("detail").celDictClick("字典", 1).dictItemClick("002 奥迪");

		// 头控件绑定明细表数据源
		Grid.element("detail").cellInput("文本", 2, "A");
		Grid.element("detail").cellInput("数值", 2, "123");
		Grid.element("detail").celDictClick("字典", 2).dictItemClick("001 大众朗逸");
		Grid.element("detail").cellDbInput("日期", 2, "20181116").pressEnterKey();
		Grid.element("detail").celComboClick("下拉框", 2).comboItemClick("B");

		ToolBar.element("ToolBar1").click("Save");
		//ToolBar.element("ToolBar1").click("Edit");
		//MainContainer.selectTab(1);

		GridUtil.checkCellValue("detail", "数值", 1, "456.00");
		GridUtil.checkCellValue("detail", "字典", 1, "002 奥迪");
		
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "A", "");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "123.00", "");
		DictUtil.checkInputValue("Dict1", "001 大众朗逸", "");
		DatePickerUtil.checkInputValue(DatePicker.element("DatePicker1"), "2018-11-16 00:00:00", "");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "B", "");
		
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
		
		

	}

}
