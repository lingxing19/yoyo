package test.grid;


import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

import sun.java2d.windows.GDIRenderer;

public class CASE_GT_M1_005 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_005View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);
		
		//【基础编辑】
		GridUtil.checkGridComboBoxItemsValue("detail", "基础编辑", 1, "上海北京深圳ABCD", "测试用例CASE_GT_M1_005");
		
		Grid.element("detail").celViewClose("基础编辑", 1);
		//选择：深圳
		Grid.element("detail").celComboClick("基础编辑", 1).comboItemClick("深圳");
		GridUtil.checkCellValue("detail", "基础编辑", 1, "深圳");
		//输入：b
		Grid.element("detail").cellClear("基础编辑", 1).cellDbInput("基础编辑", 1, "b");
		GridUtil.checkGridComboBoxAutoItemsValue("detail", "B", "测试用例CASE_GT_M1_005");
		//选择：B
		Grid.element("detail").gridComboAutoItemClick("B");
		GridUtil.checkCellValue("detail", "基础编辑", 1, "B");
		//【可编辑】
		Grid.element("detail").celComboClick("可编辑", 1).comboItemClick("上海");
		GridUtil.checkCellValue("detail", "可编辑", 1, "上海");
		Grid.element("detail").cellDbClick("可编辑", 1).cellClear("可编辑", 1).pressEnterKey();
		GridUtil.checkCellValue("detail", "可编辑", 1, "");
		
		//【整型+可编辑】
		Grid.element("detail").celComboClick("整型+可编辑", 1).comboItemClick("上海");
		GridUtil.checkCellValue("detail", "整型+可编辑", 1, "上海");
		Grid.element("detail").cellDbClick("整型+可编辑", 1).cellClear("整型+可编辑",1).cellDbInput("整型+可编辑", 1, "123").pressEnterKey();
		GridUtil.checkCellValue("detail", "整型+可编辑", 1, "123");
		
		//下拉框来源：表达式
		GridUtil.checkGridComboBoxItemsValue("Grid1", "表达式", 1, "ABCDEFG","测试用例CASE_GT_M1_005" );
		
		//下拉框来源：查询常量
		GridUtil.checkGridComboBoxItemsValue("Grid1", "查询常量", 1, "深圳广州", "测试用例CASE_GT_M1_005");
		
		//下拉框来源：查询公式
		GridUtil.checkGridComboBoxItemsValue("Grid1", "查询公式", 1, "广州", "测试用例CASE_GT_M1_005");
		
		//下拉框来源：状态集合
		GridUtil.checkGridComboBoxItemsValue("Grid1", "状态集合", 1, "ABCDEFG", "测试用例CASE_GT_M1_005");
		
		//下拉框来源：参数组
		GridUtil.checkGridComboBoxItemsValue("Grid1", "参数组", 1, "上海北京深圳广州", "测试用例CASE_GT_M1_005");
		
		//下拉框来源依赖
		Grid.element("Grid2").cellDbClick("数量", 1).cellInput("数量", 1, "2");
		GridUtil.checkGridComboBoxItemsValue("Grid2", "查询字段依赖", 1, "广州", "测试用例CASE_GT_M1_005");
		GridUtil.checkGridComboBoxItemsValue("Grid2", "表达式依赖", 1, "ABCDEFG", "测试用例CASE_GT_M1_005");
		
		Grid.element("Grid1").celComboClick("表达式", 1).comboItemClick("B");
		Grid.element("Grid1").celComboClick("查询常量", 1).comboItemClick("深圳");
		Grid.element("Grid1").celComboClick("查询公式", 1).comboItemClick("广州");
		Grid.element("Grid1").celComboClick("状态集合", 1).comboItemClick("A");
		Grid.element("Grid1").celComboClick("参数组", 1).comboItemClick("北京");
		Grid.element("Grid2").celComboClick("查询字段依赖", 1).comboItemClick("广州");
		Grid.element("Grid2").celComboClick("表达式依赖", 1).comboItemClick("B");
		
		
		ToolBar.element("ToolBar1").click("Save");
		
	    
			
		//校验明细表GT_M1_005Detail保存值是否正确
		waittime(1000);
		String[][] expTable1 = {
									{"5","","123"},
									};
		DataBaseUtil.checkDataMatch("SELECT comb1,comb2,comb3 FROM GT_M1_005Detail", expTable1, "测试用例CASE_GT_M1_005");
		MainContainer.closeAllTab();
		
		//检验明细表GT_M1_005Detail2保存值是否正确
		waittime(1000);
		String[][] expTable2 = {
									{"6","深圳","广州","5"},
									};
		DataBaseUtil.checkDataMatch("SELECT comb_1,comb_2,comb_3,comb_5 FROM GT_M1_005Detail2", expTable2, "测试用例CASE_GT_M1_005");
		MainContainer.closeAllTab();
		
		//检验明细表GT_M1_005Detail3保存值是否正确
		waittime(1000);
		String[][] expTable3 = {
									{"2.00","广州","6"},
									};
		DataBaseUtil.checkDataMatch("SELECT Num1,comb_8,comb_9 FROM GT_M1_005Detail3", expTable3, "测试用例CASE_GT_M1_005");
		MainContainer.closeAllTab();
		
		System.out.println("================================================================================================================");
	    
		
		
		
		
		
		
	}
}
