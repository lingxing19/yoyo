package test.grid;



import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.DictView;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;


public class CASE_GT_M3_005 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M3").click();
		MenuEntry.element("GridTest/GridTest/M3/GT_M3_005").dblClick();		
		MainContainer.selectTab(0);
		//点击【新增】
	    ToolBar.element("main_toolbar").click("New");
	    MainContainer.selectTab(1);
	    
	    GridUtil.checkGridRowValue("detail", 1, "a05 洛阳null单价总价备注");
	    GridUtil.checkGridRowValue("detail", 2, "a04 济南null单价总价备注");
	    GridUtil.checkGridRowValue("detail", 3, "a03 南宁null单价总价备注");
	    GridUtil.checkGridRowValue("detail", 4, "a02 内蒙古null单价总价备注");
	    GridUtil.checkGridRowValue("detail", 5, "a01 西安null单价总价备注");
	
	
	    MainContainer.closeAllTab();
	
	
	    System.out.println("================================================================================================================");
	    
	
	
	
	
	
	
	
	
	
	
	
	}

}
