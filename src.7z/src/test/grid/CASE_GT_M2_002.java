package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M2_002 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M2").click();
		MenuEntry.element("GridTest/GridTest/M2/GT_M2_002View").dblClick();		
		MainContainer.selectTab(0);
		
		//打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "测试用例CASE_GT_M2_002");
		MainContainer.selectTab(1);		
	    GridUtil.checkGridColNames("GT_M2_002Detail", "选择物料数量单价总价");
	    waittime(500);
	    //物料列背景色
	    GridUtil.checkCelBackColor("GT_M2_002Detail", "物料", 1, "77, 128, 77");
	    waittime(500);
	    //数量列前景色，右边
	    GridUtil.checkCelForeColor("GT_M2_002Detail", "数量", 1, "204, 51, 51"); 
	    GridUtil.checkGridHalign("GT_M2_002Detail", "数量", 1, "right");
	    //“单价”列：居中
	    GridUtil.checkGridHalign("GT_M2_002Detail", "单价", 1, "center");
	    //点击【编辑】
	    ToolBar.element("main_toolbar").click("Edit1");
	    GridUtil.checkRowCount(Grid.element("GT_M2_002Detail"), 5,"");
	    GridUtil.checkPagerControl("GT_M2_002Detail", "最佳列宽");
	    //拖拉选中，数量—2：200 至 总价—4：880
	    Grid.element("GT_M2_002Detail").dragAndDrop("数量", 2, "总价", 4);
	
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	
	
	
	}
}
