package test.grid;

import java.awt.event.MouseEvent;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

import sun.java2d.windows.GDIRenderer;

public class CASE_GT_M2_001 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M2").click();
		MenuEntry.element("GridTest/GridTest/M2/GT_M2_001View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		
		NumberEditorUtil.checkInputValue(NumberEditor.element("N1"), "1", "测试用例CASE_GT_M2_001");
		
		//单击，物料
		Grid.element("GT_M2_001Detail").cellClick("物料", 1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N3"), "1", "测试用例CASE_GT_M2_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("N5"), "1", "测试用例CASE_GT_M2_001");
		
		//单击，物料
		Grid.element("GT_M2_001Detail").cellClick("物料", 1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N3"), "2", "测试用例CASE_GT_M2_001");
		
		//选择：01手机
		Grid.element("GT_M2_001Detail").celDictClick("物料", 1).dictExpandItemClick("A 电子类").dictItemClick("01 手机");
		GridUtil.checkCellValue("GT_M2_001Detail","物料", 1, "01 手机");
		NumberEditorUtil.checkInputValue(NumberEditor.element("N1"), "2", "测试用例CASE_GT_M2_001");
		
		waittime(500);
		
		//删除当前行
		Grid.element("GT_M2_001Detail").cellCheckboxClick("选择", 1).deleteRowClick();
		waittime(500);
		GridUtil.checkRowCount(Grid.element("GT_M2_001Detail"), 1,"");
		waittime(500);
		
		//双击，数量


		Grid.element("GT_M2_001Detail").celldoubleClick("数量", 1);
		//Grid.element("GT_M2_001Detail").cellClick("数量", 1);
		waittime(1000);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N4"), "1", "测试用例CASE_GT_M2_001");
		waittime(1000);
		
		//关闭已打开的Tab页
		MainContainer.closeTab(1);
		
		//打开单据：1（单据编号）
		MainContainer.selectTab(0);
		ListView.element("ListView1").dbClick("单据编号", "1", "", "测试用例CASE_GT_M2_001");
		
		//点击【编辑】
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		
		//焦点切换到空白行单元格
		Grid.element("GT_M2_001Detail").cellClick("物料 ", 5);
		
		//点击表格下方符号“+”
		Grid.element("GT_M2_001Detail").addRowClick();
		GridUtil.checkRowCount(Grid.element("GT_M2_001Detail"), 6,"");
		
		//焦点切换到第二行的单元格
		Grid.element("GT_M2_001Detail").cellClick("物料 ", 2);
		//点击表格下方符号“+”
		Grid.element("GT_M2_001Detail").addRowClick();
		GridUtil.checkRowCount(Grid.element("GT_M2_001Detail"), 7,"");
        //点击表格下方符号“-”
		Grid.element("GT_M2_001Detail").cellCheckboxClick("选择", 2).deleteRowClick();
		GridUtil.checkRowCount(Grid.element("GT_M2_001Detail"), 6,"");
		//焦点切换到第三行的单元格
		Grid.element("GT_M2_001Detail").cellClick("物料 ", 3);
		//点击表格下方符号“↑”
		Grid.element("GT_M2_001Detail").upRowClick();
		GridUtil.checkCellValue("GT_M2_001Detail", "物料 ", 2, "01 手机");
		GridUtil.checkCellValue("GT_M2_001Detail", "物料 ", 3, "03 笔记本");
		//焦点切换到第一行的单元格
		Grid.element("GT_M2_001Detail").cellClick("物料 ", 1);
		//点击表格下方符号“↓”
		Grid.element("GT_M2_001Detail").downRowClick();
		GridUtil.checkCellValue("GT_M2_001Detail", "物料 ", 1, "01 手机");
		GridUtil.checkCellValue("GT_M2_001Detail", "物料 ", 2, "02 耳机");
		Grid.element("GT_M2_001Detail").customOptClick();
		ConfirmDialog.element().close();
		//点击【保存】
		ToolBar.element("main_toolbar").click("Save");
        GridUtil.checkGridColValue("GT_M2_001Detail", "数量", "1234");
        //点击【编辑】
    	ToolBar.element("main_toolbar").click("Edit1");
    	/*
    	Grid.element("GT_M2_001Detail").dragAndDrop("物料", 1, "物料状态", 4).ctrlC();
    	waittime(1000);
    	Grid.element("GT_M2_001Detail").cellClick("数量", 1);  
    	waittime(1000);
    	Grid.element("GT_M2_001Detail").cellClick("物料", 5).ctrlV();
    	waittime(1000);
    	*/
    	
    	//方向键结束编辑
    	Grid.element("GT_M2_001Detail").cellDbInput("数量", 5, "123").pressLeftKey();
    	GridUtil.checkRowCount(Grid.element("GT_M2_001Detail"), 6, "");
		//点击【保存】
		ToolBar.element("main_toolbar").click("Save");
    	
    	
		//点击新增
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(2);
		//新增状态下空白行不能被删除
		Grid.element("GT_M2_001Detail").selectRowClick("选择", 1);
		Grid.element("GT_M2_001Detail").deleteRowClick();
		
		Grid.element("GT_M2_001Detail").celDictClick("物料", 1).dictItemClick("001 大众朗逸");
		GridUtil.checkCellValue("GT_M2_001Detail", "物料 ", 1, "001 大众朗逸");
		Grid.element("GT_M2_001Detail").cellDbInput("数量", 1, "1").pressEnterKey();
		GridUtil.checkCellValue("GT_M2_001Detail", "数量 ", 1, "1");
		//点击【保存】
		ToolBar.element("main_toolbar").click("Save");
		GridUtil.checkGirdOptDisplayed("GT_M2_001Detail", "添加新记录", false);
		GridUtil.checkGirdOptDisplayed("GT_M2_001Detail", "删除所选记录", false);
		GridUtil.checkGirdOptDisplayed("GT_M2_001Detail", "上移数据行", false);
		GridUtil.checkGirdOptDisplayed("GT_M2_001Detail", "下移数据行", false);
		//点击【编辑】
		ToolBar.element("main_toolbar").click("Edit1");
		//删除：$序号$1，这行
		Grid.element("GT_M2_001Detail").selectRowClick("选择",1);
		Grid.element("GT_M2_001Detail").deleteRowClick();

		Grid.element("GT_M2_001Detail").celDictClick("物料", 1).dictItemClick("002 奥迪");
		GridUtil.checkCellValue("GT_M2_001Detail", "物料 ", 1, "002 奥迪");
		Grid.element("GT_M2_001Detail").cellDbInput("数量", 1, "2").pressEnterKey();
		GridUtil.checkCellValue("GT_M2_001Detail", "数量 ", 1, "2");
		
		Grid.element("GT_M2_001Detail").selectRowClick("选择",1);
		Grid.element("GT_M2_001Detail").deleteRowClick();
		
		Grid.element("GT_M2_001Detail").celDictClick("物料", 1).dictItemClick("001 大众朗逸");
		GridUtil.checkCellValue("GT_M2_001Detail", "物料 ", 1, "001 大众朗逸");
		Grid.element("GT_M2_001Detail").cellDbInput("数量", 1, "1").pressEnterKey();
		GridUtil.checkCellValue("GT_M2_001Detail", "数量 ", 1, "1");
		
		//点击【保存】
		ToolBar.element("main_toolbar").click("Save");
		GridUtil.checkRowCount(Grid.element("GT_M2_001Detail"), 1,"");
		GridUtil.checkCellValue("GT_M2_001Detail","物料" , 1, "001 大众朗逸");
		GridUtil.checkCellValue("GT_M2_001Detail", "数量", 1, "1");
		
		//给选择字段值
		ToolBar.element("main_toolbar").click("Edit1");
		Grid.element("GT_M2_001Detail").cellClick("给选择字段值", 1);
		GridUtil.checkGridCheckBoxChecked("GT_M2_001Detail", "选择", 1, true, "");
		
		MainContainer.closeAllTab();
		
		System.out.println("================================================================================================================");
	    
		
	}
}
