package test.grid;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_001 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_001View").dblClick();		
		MainContainer.selectTab(0);
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(1);
	    AssertUtil.uiCheck(NumberEditor.element("N1"), true, "");
	    GridUtil.cellUICheck("GT_M7_001Detail", "3", 1, true);
	    GridUtil.cellUICheck("GT_M7_001Detail", "4", 1, true);
	    GridUtil.cellUICheck("GT_M7_001Detail", "5", 2, true);
	    //【Depend1】输入：100
	    NumberEditor.element("Depend1").input("100").pressEnterKey();
	    GridUtil.cellUICheck("GT_M7_001Detail", "3", 1, false);
	    //输入，物料—2：A 电子类
	    Grid.element("GT_M7_001Detail").celDictClick("3", 2).dictItemClick("A 电子类");
	    //输入，数量—2：1000
	    Grid.element("GT_M7_001Detail").cellDbInput("4", 2, "1000").pressEnterKey();
	    AssertUtil.uiCheck(NumberEditor.element("N1"), false, "");
	    GridUtil.cellUICheck("GT_M7_001Detail", "4", 1, false);
	    //输入，入库日期—1：100
	    Grid.element("GT_M7_001Detail").cellDbInput("5", 1, "100").pressEnterKey();
	    GridUtil.cellUICheck("GT_M7_001Detail", "5", 2, false);
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkGridRowValue("GT_M7_001Detail", 1, "固定行nullnull100.00nullnullnull");
	    GridUtil.checkGridRowValue("GT_M7_001Detail", 2, "nullA 电子类1,000nullnullnullnull");
	    
	    MainContainer.closeTab(1);
	    MainContainer.selectTab(0);
	    waittime(500);
	    ListView.element("ListView1").dbClick("单据编号","1","","");
	    waittime(500);
	    MainContainer.selectTab(1);
	    ToolBar.element("main_toolbar").click("Edit1");
	    GridUtil.checkRowCount(Grid.element("GT_M7_001Detail"), 11, "CASE_GT_M7_001");
	    GridUtil.checkGridColValue("GT_M7_001Detail", "4", "100.00100100200300400500600700800null");
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	}

}
