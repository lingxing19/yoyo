package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M3_003 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M3").click();
		MenuEntry.element("GridTest/GridTest/M3/GT_M3_003View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    GridUtil.checkRowCount(Grid.element("GT_M3_003Detail"), 18, "");
	    GridUtil.checkGridRowValue("GT_M3_003Detail", 3, "01 华东001 大众朗逸100.00100.00Bnull");
	    GridUtil.checkGridRowValue("GT_M3_003Detail", 4, "01 华东001 大众朗逸500.00500.00Bnull");
	    GridUtil.checkGridRowValue("GT_M3_003Detail", 6, "01 华东002 奥迪200.00200.00Bnull");
	    GridUtil.checkGridRowValue("GT_M3_003Detail", 7, "01 华东002 奥迪600.00700.00Bnull");
	    GridUtil.checkGridRowValue("GT_M3_003Detail", 8, "01 华东002 奥迪600.00600.00Bnull");

	    
	    ToolBar.element("main_toolbar").click("Edit1");
	    GridUtil.checkCellEnabled("GT_M3_003Detail", "物料", 1, false);
	    
	
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
}
