package test.grid;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_006 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_006View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);
		//【基础编辑】
		GridUtil.checkGridCheckListItemsValue("detail", "基础编辑", 1, "上海北京深圳广州5678910ABCD", "测试用例CASE_GT_M1_006");
		//勾选：上海，10，A
		Grid.element("detail").checkListItemClick("上海","10","A").clickName("确定");
		GridUtil.checkCellValue("detail", "基础编辑", 1, "上海,10,A");
		Grid.element("detail").celCheckListClick("基础编辑", 1);
		GridUtil.checkGridCheckListItemChecked("detail", new String[]{"上海","10","A"},true, "测试用例CASE_GT_M1_006");
		Grid.element("detail").celViewClose("基础编辑", 1);
	
		//反选:10
		Grid.element("detail").celCheckListClick("基础编辑", 1).checkListItemClick("10").clickName("确定");
		GridUtil.checkCellValue("detail", "基础编辑", 1, "上海,A");
		Grid.element("detail").celCheckListClick("基础编辑", 1);
		GridUtil.checkGridCheckListItemChecked("Grid1", new String[]{"上海","A"},true, "测试用例CASE_GT_M1_006");
		Grid.element("detail").celViewClose("基础编辑", 1);

		
		
		//多选下拉框来源
		//表达式
		GridUtil.checkGridCheckListItemsValue("Grid1", "表达式", 1, "ABCDEFG", "测试用例CASE_GT_M1_006");
		Grid.element("Grid1").celViewClose("表达式", 1);
		//查询常量
		GridUtil.checkGridCheckListItemsValue("Grid1", "查询常量", 1, "深圳广州", "测试用例CASE_GT_M1_006");
		Grid.element("Grid1").celViewClose("查询常量", 1);
		//查询公式
		GridUtil.checkGridCheckListItemsValue("Grid1", "查询公式", 1, "广州", "测试用例CASE_GT_M1_006");
		Grid.element("Grid1").celViewClose("查询公式", 1);
		//状态集合
		GridUtil.checkGridCheckListItemsValue("Grid1", "状态集合", 1, "ABCDEFG", "测试用例CASE_GT_M1_006");
		Grid.element("Grid1").celViewClose("状态集合", 1);
		//参数组
		GridUtil.checkGridCheckListItemsValue("Grid1", "参数组", 1, "上海北京深圳广州", "测试用例CASE_GT_M1_006");
		Grid.element("Grid1").celViewClose("参数组", 1);
		
		//多选择下拉框来源依赖
		Grid.element("Grid2").cellDbInput("数值", 1, "2");
		//查询字段依赖
		GridUtil.checkGridCheckListItemsValue("Grid2", "查询字段依赖", 1, "广州", "测试用例CASE_GT_M1_006");
		Grid.element("Grid2").celViewClose("查询字段依赖", 1);
		//表达式依赖
		GridUtil.checkGridCheckListItemsValue("Grid2", "表达式依赖", 1, "ABCDEFG", "测试用例CASE_GT_M1_006");
		Grid.element("Grid2").celViewClose("表达式依赖", 1);

		
		Grid.element("Grid1").celCheckListClick("表达式", 1).checkListItemClick("A").clickName("确定");
		
		Grid.element("Grid1").celCheckListClick("查询常量", 1).checkListItemClick("深圳").clickName("确定");
		
		Grid.element("Grid1").celCheckListClick("查询公式", 1).checkListItemClick("广州").clickName("确定");
		
		Grid.element("Grid2").celCheckListClick("查询字段依赖", 1).checkListItemClick("广州").clickName("确定");
		
		
		ToolBar.element("ToolBar1").click("Save");
		
	    //校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable = {
									{"1,11"}
									};
		DataBaseUtil.checkDataMatch("SELECT checklistbox1 FROM GT_M1_006Detail", expTable, "测试用例CASE_GT_M1_006");
			

		waittime(1000);
		String[][] expTable1 = {
									{"5","深圳","广州"}
									};
		DataBaseUtil.checkDataMatch("SELECT checklistbox2,checklistbox3,checklistbox4 FROM GT_M1_006Detail2", expTable1, "测试用例CASE_GT_M1_006");
		MainContainer.closeAllTab();
		
		waittime(1000);
		String[][] expTable2 = {
									{"2.00","广州"}
									};
		DataBaseUtil.checkDataMatch("SELECT Num1,checklistbox8 FROM GT_M1_006Detail3", expTable2, "测试用例CASE_GT_M1_006");
		MainContainer.closeAllTab();
		
		System.out.println("================================================================================================================");
	    
		
		
	}

}
