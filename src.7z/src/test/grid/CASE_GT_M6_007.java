package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M6_007 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M6").click();
		MenuEntry.element("GridTest/GridTest/M6/GT_M6_007View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
	    ListView.element("list").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    //单击，数量—1：100.00
	    Grid.element("GT_M6_007Detail").cellClick("数量", 1);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 1, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "a02 内蒙古101.00M1");
	    //单击，Grid1销售额—1：101.00
	    Grid.element("Grid1").cellClick("G1销售额", 1);
	    GridUtil.checkRowCount(Grid.element("detail_grid2"), 1, "");
	    GridUtil.checkGridRowValue("detail_grid2", 1, "AC1a02 内蒙古60.00");
	    //单击，数量—3：300.00
	    Grid.element("GT_M6_007Detail").cellClick("数量", 3);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 4, "");
	    GridUtil.checkRowCount(Grid.element("detail_grid2"), 0, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "a05 洛阳111.00a1");
	    GridUtil.checkGridRowValue("Grid1", 2, "a05 洛阳222.00a2");
	    GridUtil.checkGridRowValue("Grid1", 3, "a05 洛阳333.00a3");
	    GridUtil.checkGridRowValue("Grid1", 4, "a05 洛阳444.00a4");
	    //单击，Grid1销售额—1：111.00
	    Grid.element("Grid1").cellClick("G1销售额", 1);
	    GridUtil.checkRowCount(Grid.element("detail_grid2"), 3, "");
	    GridUtil.checkGridRowValue("detail_grid2", 1, "C1a05 洛阳100.00");
	    GridUtil.checkGridRowValue("detail_grid2", 2, "C2a05 洛阳10.00");
	    GridUtil.checkGridRowValue("detail_grid2", 3, "C3a05 洛阳1.00");
	    //单击，Grid1销售额—2：222.00
	    Grid.element("Grid1").cellClick("G1销售额", 2);
	    GridUtil.checkRowCount(Grid.element("detail_grid2"), 4, "");
	    GridUtil.checkGridRowValue("detail_grid2", 1, "CC1a01 西安2.00");
	    GridUtil.checkGridRowValue("detail_grid2", 2, "CC2a01 西安20.00");
	    GridUtil.checkGridRowValue("detail_grid2", 3, "CC3a01 西安100.00");
	    GridUtil.checkGridRowValue("detail_grid2", 4, "CC4a01 西安100.00");
	    //【编辑】
	    ToolBar.element("main_toolbar").click("Edit1");
	    Grid.element("GT_M6_007Detail").cellDbInput("物料", 4, "A4");
	    Grid.element("GT_M6_007Detail").cellDbInput("数量", 4, "100");
	    Grid.element("GT_M6_007Detail").celDictClick("仓库", 4).dictItemClick("B 东南亚");
	    //对应Grid1，输入
	    Grid.element("Grid1").celDictClick("G1地区", 1).dictItemClick("a04 济南");
	    Grid.element("Grid1").cellDbInput("G1销售额", 1, "10");
	    Grid.element("Grid1").cellDbInput("G1物料", 1, "VIVO");
	    //对应Grid2，输入
	    Grid.element("detail_grid2").cellDbInput("G2公司", 1, "AB");
	    Grid.element("detail_grid2").celDictClick("G2地区", 1).dictItemClick("a04 济南");
	    Grid.element("detail_grid2").cellDbInput("G2数量", 1, "20");
	    //【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkRowCount(Grid.element("GT_M6_007Detail"), 4, "");
	    Grid.element("GT_M6_007Detail").cellClick("数量", 4);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 1, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "a04 济南10.00VIVO");
	    Grid.element("Grid1").cellClick("G1地区", 1);
	    GridUtil.checkRowCount(Grid.element("detail_grid2"), 1, "");
	    GridUtil.checkGridRowValue("detail_grid2", 1, "ABa04 济南20.00");
	    
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	    
	    
	}
}
