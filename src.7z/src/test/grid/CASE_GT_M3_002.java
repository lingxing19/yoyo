package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M3_002 extends AbstractTestScript{
	public void run() {
	MenuEntry.element("GridTest/GridTest").click();
	MenuEntry.element("GridTest/GridTest/M3").click();
	MenuEntry.element("GridTest/GridTest/M3/GT_M3_002View").dblClick();		
	MainContainer.selectTab(0);
	//打开单据：1（单据编号）
	ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	MainContainer.selectTab(1);
	GridUtil.checkGridColValue("GT_M3_002Detail", "数量", "7700100100.00100600600.0060070007,000.00700077002000900300.00600.009001100500.00600.0011002000");
    GridUtil.checkGridColValue("GT_M3_002Detail", "金额", "1908080.00807070.00704040.004019024015070.0080.001509030.0060.0090240");
	//新增一张单据
    MainContainer.selectTab(0);
    ToolBar.element("Main_Toolbar").click("New");
    MainContainer.selectTab(2);
    Grid.element("GT_M3_002Detail").celDictClick("仓库", 3).dictItemClick("01 华东");
    Grid.element("GT_M3_002Detail").cellDbInput("数量", 3, "100");
    Grid.element("GT_M3_002Detail").cellDbInput("金额", 3, "50");
    Grid.element("GT_M3_002Detail").cellDbInput("数量", 4, "100");
    Grid.element("GT_M3_002Detail").cellDbInput("金额", 4, "50");
    Grid.element("GT_M3_002Detail").celDictClick("仓库", 5).dictExpandItemClick("A 北美").dictItemClick("11 美国");
    Grid.element("GT_M3_002Detail").cellDbInput("数量", 5, "50");
    Grid.element("GT_M3_002Detail").cellDbInput("金额", 5, "100");
    Grid.element("GT_M3_002Detail").cellDbInput("数量", 6, "50");
    Grid.element("GT_M3_002Detail").cellDbInput("金额", 6, "100");
    Grid.element("GT_M3_002Detail").celDictClick("仓库", 7).dictExpandItemClick("B 东南亚").dictItemClick("21 泰国");
    Grid.element("GT_M3_002Detail").cellDbInput("数量", 7, "200");
    Grid.element("GT_M3_002Detail").cellDbInput("金额", 7, "150");
    Grid.element("GT_M3_002Detail").cellDbInput("数量", 8, "200");
    Grid.element("GT_M3_002Detail").cellDbInput("金额", 8, "150").pressEnterKey();
    GridUtil.checkGridColValue("GT_M3_002Detail", "数量", "700700100.00100.0050.0050.00200.00200.00null700700nullnullnullnullnull");
    GridUtil.checkGridColValue("GT_M3_002Detail", "金额", "60060050.0050.00100.00100.00150.00150.00null600600nullnullnullnullnull");
    Grid.element("GT_M3_002Detail").cellClick("序号", 7).deleteRowClick();
    GridUtil.checkGridColValue("GT_M3_002Detail", "数量", "500500100.00100.0050.0050.00200.00null50050000null500500");
    GridUtil.checkGridColValue("GT_M3_002Detail", "金额", "45045050.0050.00100.00100.00150.00null45045000null450450");
    //点击【保存】
	ToolBar.element("main_toolbar").click("Save");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 1, "仓库合计1null10050nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 2, "null物料合计110050nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 3, "01 华东null100.0050.00Bnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 4, "null物料合计210050nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 5, "仓库合计2null10050nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 6, "仓库合计1null150150nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 7, "null物料合计1150150nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 8, "nullnull100.0050.00Bnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 9, "nullnull50.00100.00Bnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 10, "null物料合计2150150nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 11, "仓库合计2null150150nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 12, "仓库合计1null50100nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 13, "null物料合计150100nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 14, "11 美国null50.00100.00Bnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 15, "null物料合计250100nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 16, "仓库合计2null50100nullnull");
    GridUtil.checkGridRowValue("GT_M3_002Detail", 17, "仓库合计1null200150nullnull");
    
    GridUtil.checkGridColValue("GT_M3_002Detail", "数量", "100100100.00100100150150100.0050.00150150505050.005050200200200.00200200");
	GridUtil.checkGridColValue("GT_M3_002Detail", "金额", "505050.00505015015050.00100.00150150100100100.00100100150150150.00150150");
	MainContainer.closeAllTab();
	System.out.println("================================================================================================================");
    
	
	
	}
}
