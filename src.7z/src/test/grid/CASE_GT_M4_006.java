package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_006 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_006View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    GridUtil.checkGridExpColNum("GT_M4_006Detail", "成绩", 3);
	    GridUtil.checkGridExpColNum("GT_M4_006Detail", "数量", 3);
	    GridUtil.checkGridExpColName("GT_M4_006Detail", "月初月中月末上午下午晚上");
	    
	    GridUtil.checkRowCount(Grid.element("GT_M4_006Detail"), 18, "");
	    GridUtil.checkGridExpColValue("GT_M4_006Detail", "月初", "1.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.00");
	    GridUtil.checkGridExpColValue("GT_M4_006Detail", "月中", "1.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.00");
	    GridUtil.checkGridExpColValue("GT_M4_006Detail", "月末", "1.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.001.00");
	    GridUtil.checkGridExpColValue("GT_M4_006Detail", "上午", "222222222222222222");
	    GridUtil.checkGridExpColValue("GT_M4_006Detail", "下午", "222222222222222222");
	    GridUtil.checkGridExpColValue("GT_M4_006Detail", "晚上", "222222222222222222");
	    MainContainer.closeAllTab();
	
	    System.out.println("================================================================================================================");
	    
	
	
	
	
	}

}
