package test.grid;

import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M5_001 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M5").click();
		MenuEntry.element("GridTest/GridTest/M5/GT_M5_001View").dblClick();		
		MainContainer.selectTab(0);

		//点击【新增】
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		Grid.element("GT_M5_001Head").cellDbInput("文本编辑框", 1, "YYYYY");
		Grid.element("GT_M5_001Head").cellDbInput("数值编辑框", 1, "60000");
		Grid.element("GT_M5_001Head").cellDPViewInput("日期选择框", 1, 2017, 01, 01, 10, 58, 30);
		Grid.element("GT_M5_001Head").cellCheckboxClick("复选框", 2);
		Grid.element("GT_M5_001Head").celCheckListClick("多选下拉框", 2).checkListItemClick("C","D");
		Grid.element("GT_M5_001Head").celComboClick("下拉框", 2).comboItemClick("经理");
		Grid.element("GT_M5_001Head").celDictClick("字典仓库", 2).dictItemClick("A 北美");
		Grid.element("GT_M5_001Head").cellDbInput("文本按钮", 3, "AD");
		ToolBar.element("main_toolbar").click("Save");
		GridUtil.checkGridRowValue("GT_M5_001Head", 1, "YYYYY60,0002017-01-01 10:58:30nullnullnullnullnullnullnull");
		GridUtil.checkGridRowValue("GT_M5_001Head", 2, "nullnullnullnullC,D经理nullA 北美nullnull");	 
		GridUtil.checkGridRowValue("GT_M5_001Head", 3, "nullnullnullnullnullnullnullnullAD按钮");
		ToolBar.element("main_toolbar").click("Edit");
		Grid.element("GT_M5_001Head").cellTextButtonClick("文本按钮", 3);
		DialogUtil.checkShowConfirmDialog();
		ConfirmDialog.element().close();
		Grid.element("GT_M5_001Head").cellButtonClick("按钮", 3);
		DialogUtil.checkShowConfirmDialog();
		ConfirmDialog.element().close();
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
	    
		
		
	}
}
