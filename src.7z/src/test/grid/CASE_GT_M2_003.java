package test.grid;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M2_003 extends AbstractTestScript{

	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M2").click();
		MenuEntry.element("GridTest/GridTest/M2/GT_M2_003View").dblClick();		
		MainContainer.selectTab(0);
	
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick(1);
		MainContainer.selectTab(1);
		//数量：99，背景色为 蓝紫色
		GridUtil.checkCelBackColor("GT_M2_003Detail", "数量", 1, "128, 153, 255");
		waittime(500);
	    //序号—2，行背景色为 红色，其他行背景色为  绿色
		GridUtil.checkRowBackColor("GT_M2_003Detail", "物料", 2, "204, 51, 51");
		waittime(500);
		GridUtil.checkRowBackColor("GT_M2_003Detail", "物料", 1, "153, 204, 153");
		waittime(500);
		GridUtil.checkRowBackColor("GT_M2_003Detail", "物料", 3, "153, 204, 153");
		waittime(500);
		GridUtil.checkRowBackColor("GT_M2_003Detail", "物料", 4, "153, 204, 153");
		waittime(500);
		
		GridUtil.checkRowBackColor("GT_M2_003Detail", "物料", 5, "153, 204, 153");
	    //点击【编辑】
		ToolBar.element("main_toolbar").click("Edit1");
		GridUtil.checkRowCount(Grid.element("GT_M2_003Detail"), 6,"");
	    Grid.element("GT_M2_003Detail").cellClick("物料", 1);
	    //单击，左下角“+”
	    Grid.element("GT_M2_003Detail").addRowClick();
	    GridUtil.checkRowCount(Grid.element("GT_M2_003Detail"), 7,"");
	    GridUtil.checkCellValue("GT_M2_003Detail", "物料", 2, "a");
	    //拖拉选中，物料—2，数量—2
	    Grid.element("GT_M2_003Detail").dragAndDrop("物料", 2, "数量", 2);
	    GridUtil.checkCelBackColor("GT_M2_003Detail","物料 ", 2, "197, 229, 248");
	    Grid.element("GT_M2_003Detail").cellDbInput("物料",1,"a").pressEnterKey();
	    GridUtil.checkCellValue("GT_M2_003Detail", "物料", 1, "a");
	    //录入，数量—1:10
	    Grid.element("GT_M2_003Detail").cellDbInput("数量", 1, "10").pressEnterKey();
	    GridUtil.checkCelBackColor("GT_M2_003Detail", "数量", 1, "255, 204, 230");
	    GridUtil.checkCelBackColor("GT_M2_003Detail", "数量", 2, "128, 153, 255");
	    //【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkCelBackColor("GT_M2_003Detail", "数量", 1, "128, 153, 255");			
		//校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable = {
									{"a","99","7.00","2"},
									{"b","101","8.00","3"},
									{"c","1","4.00","4"},
									{"d","2","4.00","5"},
									{"e","3","4.00","6"},
									{"a","10","0.00","1"}};
		DataBaseUtil.checkDataMatch("SELECT TText,TNumber,Price,Sequence FROM GT_M2_003Detail", expTable, "测试用例CASE_GT_M2_003");
		MainContainer.closeAllTab();
	    
		System.out.println("================================================================================================================");
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	
	
	}
}
