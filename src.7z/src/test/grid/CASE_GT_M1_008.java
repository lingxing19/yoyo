package test.grid;

import org.apache.commons.lang3.ObjectUtils.Null;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_008 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_008View").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);

		// 基础编辑
		Grid.element("detail").cellInput("基础编辑", 1, "abc123").pressEnterKey();
		Grid.element("detail").cellClick("基础编辑", 1).pressDeleteKey();
		GridUtil.checkCellValue("detail", "基础编辑", 1, "");
		Grid.element("detail").cellDbInput("基础编辑", 1, "abc123").pressEnterKey();
		Grid.element("detail").cellDbClick("基础编辑", 1).pressBackspaceKey(0, 3);
		waittime(500);
		Grid.element("detail").cellDbClick("基础编辑", 1).pressEnterKey();
		Grid.element("detail").cellClick("基础编辑", 1);
		GridUtil.checkCellValue("detail", "基础编辑", 1, "abc");
		
		Grid.element("detail").cellDbClick("默认值", 1).ctrlC();

		// 单击,粘贴
		/*
		Grid.element("Grid1").cellClick("粘贴2", 1).ctrlV();
		waittime(1000);
		GridUtil.checkCellValue("Grid1", "粘贴2", 1, "aBc123上海博科");
		*/

		// 双击,粘贴
		waittime(1000);
		Grid.element("Grid1").cellDbClick("粘贴3", 1).ctrlV().pressEnterKey();
		waittime(1000);
		GridUtil.checkCellValue("Grid1", "粘贴3", 1, "aBc123上海博科");

		// 最大长度
		Grid.element("detail").cellInput("最大长度", 1, "aaaaaaaaaa").pressEnterKey();
		GridUtil.checkCellValue("detail", "最大长度", 1, "aaaaaaaa");
		// 非法字符
		Grid.element("detail").cellInput("非法字符", 1, "aAbBcCdD").pressEnterKey();
		GridUtil.checkCellValue("detail", "非法字符", 1, "AbcCdD");
		// 去除空格
		Grid.element("detail").cellInput("去除空格", 1, "    abc").pressEnterKey();
		GridUtil.checkCellValue("detail", "去除空格", 1, "abc");
		// 全小写
		Grid.element("detail").cellInput("全小写", 1, "AAAAA").pressEnterKey();
		GridUtil.checkCellValue("detail", "全小写", 1, "aaaaa");
		// 全大写
		Grid.element("detail").cellInput("全大写", 1, "aaaaa").pressEnterKey();
		GridUtil.checkCellValue("detail", "全大写", 1, "AAAAA");
		// 空值提示aAbBeEfF1234
		Grid.element("detail").cellDbClick("空值提示", 1).getPromptText();
		GridUtil.checkPromptText("detail", "空值提示", "不能为空", "测试用例CASE_GT_M1_008");
		
		// 默认值
		GridUtil.checkCellValue("detail", "默认值", 1, "aBc123上海博科");

		// 点击【保存】
		ToolBar.element("ToolBar1").click("Save");
		// 校验明细表1保存值是否正确
		waittime(1000);
		String[][] expTable = { { "abc", "aaaaaaaa", "AbcCdD", "abc", "aaaaa", "AAAAA", "aBc123上海博科" } };
		DataBaseUtil.checkDataMatch("SELECT text1,text2,text3,text4,text5,text6,text8 FROM GT_M1_008Detail", expTable,
				"测试用例CASE_GT_M1_008");

		// 校验明细表2保存值是否正确
		waittime(1000);
		String[][] expTable1 = { {},{ "aBc123上海博科" } };
		DataBaseUtil.checkDataMatch("SELECT text_4 FROM detail2", expTable1, "测试用例CASE_GT_M1_008");
		MainContainer.closeAllTab();

		System.out.println(
				"================================================================================================================");

	}
}
