package test.grid;


import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_002 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_002View").dblClick();		
		MainContainer.selectTab(0);
		//打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    //“备注”列下方有三列扩展：“苏宁易购”、“京东”、“天猫”
	    GridUtil.checkGridExpColNum("GT_M4_002Detail", "备注", 3);
	    GridUtil.checkGridExpColName("GT_M4_002Detail", "京东苏宁易购天猫");
	    GridUtil.checkRowCount(Grid.element("GT_M4_002Detail"), 18, "");
	    GridUtil.checkGridExpColValue("GT_M4_002Detail", "京东", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	    GridUtil.checkGridExpColValue("GT_M4_002Detail", "苏宁易购","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	    GridUtil.checkGridExpColValue("GT_M4_002Detail", "天猫", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	    //点击【新增】
	    MainContainer.selectTab(0);
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(2);
	    Grid.element("GT_M4_002Detail").cellDbInput("2", 1, "一");
	    Grid.element("GT_M4_002Detail").cellDbInput("4", 1, "中国");
	    Grid.element("GT_M4_002Detail").cellDbInput("5", 1, "美国");
	    Grid.element("GT_M4_002Detail").cellDbInput("6", 1, "韩国");
	    
	    Grid.element("GT_M4_002Detail").cellDbInput("2", 2, "二");
	    Grid.element("GT_M4_002Detail").cellDbInput("4", 2, "上海");
	    Grid.element("GT_M4_002Detail").cellDbInput("5", 2, "法国");
	    Grid.element("GT_M4_002Detail").cellDbInput("6", 2, "日本");
	   
	    Grid.element("GT_M4_002Detail").cellDbInput("2", 3, "三");
	    Grid.element("GT_M4_002Detail").cellDbInput("4", 3, "南京");
	    Grid.element("GT_M4_002Detail").cellDbInput("5", 3, "加拿大");
	    Grid.element("GT_M4_002Detail").cellDbInput("6", 3, "越南");
	    
	    Grid.element("GT_M4_002Detail").cellDbInput("2", 4, "四");
	    Grid.element("GT_M4_002Detail").cellDbInput("4", 4, "北京");
	    Grid.element("GT_M4_002Detail").cellDbInput("5", 4, "泰国");
	    Grid.element("GT_M4_002Detail").cellDbInput("6", 4, "英国");
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkGridExpColValue("GT_M4_002Detail", "京东", "中国上海南京北京");
	    GridUtil.checkGridExpColValue("GT_M4_002Detail", "苏宁易购","美国法国加拿大泰国");
	    GridUtil.checkGridExpColValue("GT_M4_002Detail", "天猫", "韩国日本越南英国");
	    MainContainer.closeAllTab();
	    
	    System.out.println("================================================================================================================");
	    
	    
	    
	    
	    
	
	}
	
}
