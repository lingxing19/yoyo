package test.grid;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_009 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_009View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		
		GridUtil.checkCellValue("detail_grid", "日期1", 1, "2017-12-14");	
		GridUtil.checkCellValue("detail_grid", "日期3", 1, "2017-12-18 01:13:13");
		GridUtil.checkCellValue("detail_grid", "UTC日期3", 1, "2018-01-23");
		GridUtil.checkCellValue("detail_grid", "UTC日期4", 1, "2018-01-23 01:01:23");
		GridUtil.checkCellValue("detail_grid", "日期4", 1, "2017");
		
		//表格日期默认值打开关闭不新增行
		Grid.element("detail_grid").cellDateViewClick("日期2", 1).pressEnterKey();
		GridUtil.checkRowCount(Grid.element("detail_grid"), 1, "测试用例CASE_GT_M1_009");
		Grid.element("detail_grid").cellDateViewClick("UTC日期1", 1).pressEnterKey();
		GridUtil.checkRowCount(Grid.element("detail_grid"), 1, "测试用例CASE_GT_M1_009");
		
		//【UTC日期1】
		Grid.element("detail_grid").cellDbInput("UTC日期1", 1, "20150101").pressEnterKey();
		GridUtil.checkCellValue("detail_grid", "UTC日期1", 1, "2015-01-01");
		//【UTC日期2】
		Grid.element("detail_grid").cellDbInput("UTC日期2", 1, "20150102112211").pressEnterKey();
		GridUtil.checkCellValue("detail_grid", "UTC日期2", 1, "2015-01-02 11:22:11");
		//【年月控件】
		Grid.element("Grid1").cellDbInput("年月-日期2", 1, "20196").pressEnterKey();
		GridUtil.checkCellValue("Grid1", "年月-日期2", 1, "2019-06");
		
		
		//賦空值符串
		Button.element("Button1").click();
		GridUtil.checkCellValue("detail_grid", "日期1", 1, "");
		GridUtil.checkCellValue("detail_grid", "日期3", 1, "");
		ToolBar.element("main_toolbar").click("Save");
		waittime(1000);
		String[][] expTable = {
				{"1",null,null,"20150101","20150102112211"}
		};
		DataBaseUtil.checkDataMatch("SELECT Sequence,N1,N4,UTC1,UTC2 FROM GT_M1_009Detail2", expTable, "测试用例CASE_GT_M1_009");
		
		MainContainer.closeAllTab();
		
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_009View").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		
		Grid.element("detail_grid").cellClick("按钮列", 1);
		GridUtil.checkCellValue("detail_grid", "日期1", 1, "");
		GridUtil.checkCellValue("detail_grid", "日期3", 1, "");
		ToolBar.element("main_toolbar").click("Save");
		
		String[][] expTable1 = {
				{"1",null,null,"20150101","20150102112211"},
				{"1",null,null,"20181217",""}
		};
		DataBaseUtil.checkDataMatch("SELECT Sequence,N1,N4,UTC1,UTC2 FROM GT_M1_009Detail2", expTable1, "测试用例CASE_GT_M1_009");
		

		MainContainer.closeAllTab();
		
		System.out.println("================================================================================================================");
	    
		
		
		
		
		
		
		
	}
}
