package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_001 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_001View").dblClick();		
		MainContainer.selectTab(0);
		//打开单据：1（单据编号）
   	    ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    GridUtil.checkGridExpColNum("GT_M4_001Detail", "成绩", 3);
	    GridUtil.checkGridExpColName("GT_M4_001Detail", "科目一科目二科目三");
	    waittime(500);
	    GridUtil.checkRowCount(Grid.element("GT_M4_001Detail"), 21, "");
	    GridUtil.checkGridExpColValue("GT_M4_001Detail", "科目一", "11.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.00");
	    GridUtil.checkGridExpColValue("GT_M4_001Detail", "科目二", "11.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.00");
	    GridUtil.checkGridExpColValue("GT_M4_001Detail", "科目三", "11.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.0011.00");
	    //切换到视图：GT_M4_001
	    MainContainer.selectTab(0);
	    //点击【新增】
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(2);
	    //输入一行数据：a     程序员     1.00     1.00       1.00 
        Grid.element("GT_M4_001Detail").cellDbInput("2", 1, "a");
        Grid.element("GT_M4_001Detail").cellDbInput("4", 1, "1");
        Grid.element("GT_M4_001Detail").cellDbInput("5", 1, "1");
        Grid.element("GT_M4_001Detail").cellDbInput("6", 1, "1").pressEnterKey();
       
        //切换焦点到第二行
        Grid.element("GT_M4_001Detail").cellDbInput("2", 2, "a").pressEnterKey();
        //界面检查规则不通过
        GridUtil.allUiCheck("GT_M4_001Detail", true);
        GridUtil.checkAllErrorInfo("GT_M4_001Detail","不可重复");
        //修改当前行“姓名”单元格的值为：“a1”
        Grid.element("GT_M4_001Detail").cellDbInput("2", 2, "a1").pressEnterKey();
        //界面检查规则通过
        GridUtil.allUiCheck("GT_M4_001Detail", false);
        MainContainer.closeAllTab();
        
        System.out.println("================================================================================================================");
	    
        
        
        
        
        
	
	}
}
