package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_011 extends AbstractTestScript {
	
	public void run(){
		MenuEntry.element("GridTest/GridTest").click();
		waittime(5000);
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_015View").dblClick();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "GT_M7_01520181225000001", "", "");
		MainContainer.selectTab(1);
		
		GridUtil.checkRowCount(Grid.element("detail"), 3, "CASE_GT_M7_011-树形表格层级打开检查成功");
		
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
	}

}
