package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;


public class CASE_GT_M7_006 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_013View").dblClick();	
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "GT_M7_01320181010000001", "", "测试用例CASE_GT_M7_006");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Edit");
		waittime(500);
		
		//树形表格不展开1
		GridUtil.checkRowCount(Grid.element("detail"), 5, "测试用例CASE_GT_M7_006");
		Grid.element("detail").rowTreeExpand("物料", 1);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 5);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 8);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 10);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 13);
		GridUtil.checkRowCount(Grid.element("detail"), 15, "测试用例CASE_GT_M7_006");
		
		MainContainer.closeAllTab();
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_014View").dblClick();	
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "GT_M7_01420181010000001", "", "测试用例CASE_GT_M7_006");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Edit");
		waittime(500);
		
		//树形表格不展开2
		GridUtil.checkRowCount(Grid.element("detail"), 5, "测试用例CASE_GT_M7_006");
		Grid.element("detail").rowTreeExpand("物料", 1);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 5);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 9);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 34);
		waittime(500);
		Grid.element("detail").rowTreeExpand("物料", 42);
		GridUtil.checkRowCount(Grid.element("detail"), 50, "测试用例CASE_GT_M7_006");


	
		MainContainer.closeAllTab();
	
		System.out.println("================================================================================================================");
	    
	
	
	
	
	
	
	
	
	
	
	}
}
