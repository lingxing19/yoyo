package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_007 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_008View").dblClick();	
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);
		//全局检查
		GridUtil.allUiCheck("GT_M7_008Detail", true);
		Grid.element("GT_M7_008Detail").cellClick("物料", 1);
		Grid.element("GT_M7_008Detail").addRowClick();
		Grid.element("GT_M7_008Detail").addRowClick();
		GridUtil.allUiCheck("GT_M7_008Detail", false);
		
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
	}

}
