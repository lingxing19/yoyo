package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_002 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_002View").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);

		GridUtil.rowUICheck("GT_M7_002Detail", 1, true);
		GridUtil.cellUICheck("GT_M7_002Detail", "2", 1, true);
		GridUtil.cellUICheck("GT_M7_002Detail", "4", 1, true);
		// 【Depend1】输入：100
		NumberEditor.element("Depend1").input("100").pressEnterKey();
		waittime(1000);
		GridUtil.rowUICheck("GT_M7_002Detail", 1, true);
		GridUtil.cellUICheck("GT_M7_002Detail", "2", 1, false);
		GridUtil.checkColDisplayed("GT_M7_002Detail", "必填", false);
		// 【数量】：100
		Grid.element("GT_M7_002Detail").cellDbInput("3", 1, "100").pressEnterKey();
		GridUtil.rowUICheck("GT_M7_002Detail", 1, false);
		// 【Depend2】输入：200
		Grid.element("GT_M7_002Detail").cellDbInput("5", 1, "100").pressEnterKey();
		GridUtil.cellUICheck("GT_M7_002Detail", "4", 1, false);
		// 【Depend1】输入：101
		NumberEditor.element("Depend1").clear();
		waittime(500);
		NumberEditor.element("Depend1").input("101").pressEnterKey();
		waittime(500);
		GridUtil.checkColDisplayed("GT_M7_002Detail", "必填", true);
		// 【必填】输入：100
		Grid.element("GT_M7_002Detail").cellDbInput("必填", 1, "100");

		ToolBar.element("main_toolbar").click("Save");
		GridUtil.checkBaseGridRowValue("GT_M7_002Detail", 1, "1null100null100.00100");
		MainContainer.closeAllTab();

		System.out.println(
				"================================================================================================================");

	}
}
