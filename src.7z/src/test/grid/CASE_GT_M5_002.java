package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M5_002 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M5").click();
		MenuEntry.element("GridTest/GridTest/M5/GT_M5_002View").dblClick();		
		MainContainer.selectTab(0);
		//打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    
	    GridUtil.checkGridColValue("GT_M5_002Detail", "7", "6.0015.0060.00150.00-6.00-15.006.0015.006.0015.006.0015.006.0015.006.0015.006.0015.00336");
	    GridUtil.checkGridColValue("GT_M5_002Detail", "17","54.00540.00-54.00520.005,400.00540.0054.00540.0054.00540.0054.00540.0054.00540.0054.00540.0054.00540.00null");
	    //点击【新增】
	    MainContainer.selectTab(0);
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(2);
	    
	    Grid.element("GT_M5_002Detail").cellDbInput("2", 1, "a").cellDbInput("3", 1, "1").cellDbInput("4", 1, "1").cellDbInput("5", 1, "1").cellDbInput("6", 1, "1").cellDbInput("8", 1, "1").cellDbInput("9", 1, "1").cellDbInput("10", 1, "1").cellDbInput("11", 1, "1").cellDbInput("12", 1, "1").cellDbInput("13", 1, "1").cellDbInput("14", 1, "1").cellDbInput("15", 1, "1").cellDbInput("16", 1, "1");
	    Grid.element("GT_M5_002Detail").cellDbInput("2", 2, "b").cellDbInput("3", 2, "2").cellDbInput("4", 2, "2").cellDbInput("5", 2, "2").cellDbInput("6", 2, "2").cellDbInput("8",2, "2").cellDbInput("9", 2, "2").cellDbInput("10",2, "2").cellDbInput("11", 2, "2").cellDbInput("12", 2, "2").cellDbInput("13", 2, "2").cellDbInput("14",2, "2").cellDbInput("15", 2, "2").cellDbInput("16", 2, "2");
	    Grid.element("GT_M5_002Detail").cellDbInput("2", 3, "c").cellDbInput("3", 3, "3").cellDbInput("4",3, "3").cellDbInput("5", 3, "3").cellDbInput("6", 3, "3").cellDbInput("8",3, "3").cellDbInput("9", 3, "3").cellDbInput("10",3, "3").cellDbInput("11", 3, "3").cellDbInput("12", 3, "3").cellDbInput("13", 3, "3").cellDbInput("14",3, "3").cellDbInput("15", 3, "3").cellDbInput("16", 3, "3").pressEnterKey();
	    GridUtil.checkGridColValue("GT_M5_002Detail", "3","123null6");
	    GridUtil.checkGridColValue("GT_M5_002Detail", "7", "3.006.009.00null18");
	    GridUtil.checkGridColValue("GT_M5_002Detail", "17", "9.0018.0027.00nullnull");
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkGridColValue("GT_M5_002Detail", "3","1236");
	    GridUtil.checkGridColValue("GT_M5_002Detail", "7", "3.006.009.0018");
	    GridUtil.checkGridColValue("GT_M5_002Detail", "17", "9.0018.0027.00null");
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	    
	    
	    
	}
}
