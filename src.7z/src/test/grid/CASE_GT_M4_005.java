package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_005 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_005View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    //“工作职务”列后面有三列扩展：“科目一”、“科目二”、“科目三”，上方无标题
	    GridUtil.checkGridExpColTitle("GT_M4_005Detail", "序号姓名工作职务科目一科目二科目三仓库");
	    //“仓库”下方有三列扩展：“月初”、“月中”、“月末”
	    GridUtil.checkGridExpColNum("GT_M4_005Detail", "仓库", 3);
	    GridUtil.checkGridExpColName("GT_M4_005Detail", "月初月中月末");
	    //表格显示21行数据
	    GridUtil.checkRowCount(Grid.element("GT_M4_005Detail"), 21, "");
	    //“科目一”、“科目二”、“科目三”列中单元格的值为“A,B”
	    GridUtil.checkGridColValue("GT_M4_005Detail", "4", "A,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,B");
	    GridUtil.checkGridColValue("GT_M4_005Detail", "5", "A,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,B");
	    GridUtil.checkGridColValue("GT_M4_005Detail", "6", "A,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,BA,B");
	    //“仓库”下方的扩展列的单元格的值为“B 东南亚”
	    GridUtil.checkGridExpColValue("GT_M4_005Detail", "月初", "B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚");
	    GridUtil.checkGridExpColValue("GT_M4_005Detail", "月中", "B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚");
	    GridUtil.checkGridExpColValue("GT_M4_005Detail", "月末", "B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚B 东南亚");
	    //点击【新增】
	    MainContainer.selectTab(0);
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(2);
	    //表格中新增4行列扩展单元格中输入数据（多选下拉框、字典）
	    Grid.element("GT_M4_005Detail").cellDbInput("2", 1, "1");
	    Grid.element("GT_M4_005Detail").celCheckListClick("4", 1).checkListItemClick("A","B");
	    Grid.element("GT_M4_005Detail").celCheckListClick("5", 1).checkListItemClick("C","D");
	    Grid.element("GT_M4_005Detail").celCheckListClick("6", 1).checkListItemClick("E","F");
	    Grid.element("GT_M4_005Detail").celDictClick("7", 1).dictItemClick("01 华东");
	    Grid.element("GT_M4_005Detail").celDictClick("8", 1).dictItemClick("02 华中");
	    Grid.element("GT_M4_005Detail").celDictClick("9", 1).dictExpandItemClick("A 北美").dictItemClick("11 美国");
	    
	    Grid.element("GT_M4_005Detail").cellDbInput("2", 2, "12");
	    Grid.element("GT_M4_005Detail").celCheckListClick("4", 2).checkListItemClick("A","B");
	    Grid.element("GT_M4_005Detail").celCheckListClick("5", 2).checkListItemClick("C","D");
	    Grid.element("GT_M4_005Detail").celCheckListClick("6", 2).checkListItemClick("E","F");
	    Grid.element("GT_M4_005Detail").celDictClick("7", 2).dictItemClick("01 华东");
	    Grid.element("GT_M4_005Detail").celDictClick("8", 2).dictItemClick("02 华中");
	    Grid.element("GT_M4_005Detail").celDictClick("9", 2).dictExpandItemClick("A 北美").dictItemClick("11 美国");
	    
	    Grid.element("GT_M4_005Detail").cellDbInput("2", 3, "123");
	    Grid.element("GT_M4_005Detail").celCheckListClick("4", 3).checkListItemClick("A","B");
	    Grid.element("GT_M4_005Detail").celCheckListClick("5", 3).checkListItemClick("C","D");
	    Grid.element("GT_M4_005Detail").celCheckListClick("6", 3).checkListItemClick("E","F");
	    Grid.element("GT_M4_005Detail").celDictClick("7", 3).dictItemClick("01 华东");
	    Grid.element("GT_M4_005Detail").celDictClick("8", 3).dictItemClick("02 华中");
	    Grid.element("GT_M4_005Detail").celDictClick("9", 3).dictExpandItemClick("A 北美").dictItemClick("11 美国");
	    
	    Grid.element("GT_M4_005Detail").cellDbInput("2", 4, "1234");
	    Grid.element("GT_M4_005Detail").celCheckListClick("4", 4).checkListItemClick("A","B");
	    Grid.element("GT_M4_005Detail").celCheckListClick("5", 4).checkListItemClick("C","D");
	    Grid.element("GT_M4_005Detail").celCheckListClick("6", 4).checkListItemClick("E","F");
	    Grid.element("GT_M4_005Detail").celDictClick("7", 4).dictItemClick("01 华东");
	    Grid.element("GT_M4_005Detail").celDictClick("8", 4).dictItemClick("02 华中");
	    Grid.element("GT_M4_005Detail").celDictClick("9", 4).dictExpandItemClick("A 北美").dictItemClick("11 美国");
	    
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkGridColValue("GT_M4_005Detail", "4", "A,BA,BA,BA,B");
	    GridUtil.checkGridColValue("GT_M4_005Detail", "5", "C,DC,DC,DC,D");
	    GridUtil.checkGridColValue("GT_M4_005Detail", "6", "E,FE,FE,FE,F");
	    GridUtil.checkGridExpColValue("GT_M4_005Detail", "月初", "01 华东01 华东01 华东01 华东");
	    GridUtil.checkGridExpColValue("GT_M4_005Detail", "月中", "02 华中02 华中02 华中02 华中");
	    GridUtil.checkGridExpColValue("GT_M4_005Detail", "月末", "11 美国11 美国11 美国11 美国");
	    MainContainer.closeAllTab();
	
	    System.out.println("================================================================================================================");
	    
	}	

}
