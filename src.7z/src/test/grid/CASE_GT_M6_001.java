package test.grid;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M6_001 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M6").click();
		MenuEntry.element("GridTest/GridTest/M6/GT_M6_001View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
	    ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	
	    GridUtil.checkRowCount(Grid.element("GT_M6_001Detail1"), 3, "");
	    GridUtil.checkGridRowValue("GT_M6_001Detail1", 1, "001 大众朗逸1,000");
	    GridUtil.checkGridRowValue("GT_M6_001Detail1", 2, "A 电子类2,000");
	    GridUtil.checkGridRowValue("GT_M6_001Detail1", 3, "02 耳机3,000");
	    
	    //单击选中：值为“02 耳机”的单元格
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 3);
	    
	    GridUtil.checkRowCount(Grid.element("Grid1"), 4, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla03 南宁5,000.000.1D,E2016-12-08 14:15:57nullggg");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla04 济南6,000.000.3C,F,G2016-12-08 14:16:18nullfff");
	    GridUtil.checkGridRowValue("Grid1", 3, "nulla05 洛阳7,000.000.1F,G2016-12-08 14:16:34nulleee");
	    GridUtil.checkGridRowValue("Grid1", 4, "nulla03 南宁8,000.000.3C,F,G2016-12-23 14:16:55nullaaa");
	    //单击选中：值为“A电子类 ”的单元格
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 2);
	
	    GridUtil.checkRowCount(Grid.element("Grid1"), 3, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla04 济南40,000.000.3C2016-12-08 14:14:13nullccccc");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla03 南宁60,000.000.1D,E2018-01-01 14:14:34nullDDDD");
	    GridUtil.checkGridRowValue("Grid1", 3, "nulla04 济南8,000.000.1D2016-12-07 14:15:04null二二二");
	    //单击选中：值为“001 大众朗逸  ”的单元格
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 1);
		
	    GridUtil.checkRowCount(Grid.element("Grid1"), 3, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla01 西安10,000.000.1B,C2016-12-08 14:10:31nullaaaa");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla02 内蒙古20,000.000.3D,E2016-12-08 14:10:53nullbbbb");
	    GridUtil.checkGridRowValue("Grid1", 3, "nulla03 南宁30,000.000.1F,G2016-12-08 14:11:15nullcccc");
	    //勾选 全选
	    Grid.element("Grid1").selectAllClick("选择");
	    GridUtil.checkAllSelected(Grid.element("Grid1"), "选择",true);
	
	    //反选 第二行子明细
	    Grid.element("Grid1").selectRowClick("选择",2);
	    GridUtil.checkRowSelected(Grid.element("Grid1"),"选择", true, 1); 
	    GridUtil.checkRowSelected(Grid.element("Grid1"),"选择", false, 2); 
	    GridUtil.checkRowSelected(Grid.element("Grid1"), "选择",true, 3); 
	
	    //单击选中：值为“A电子类 ”的单元格
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 2);
	    Grid.element("Grid1").selectAllClick("选择");
	    GridUtil.checkAllSelected(Grid.element("Grid1"),"选择", true);
	    //单击选中：值为“001 大众朗逸  ”的单元格
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 1);
	    GridUtil.checkRowSelected(Grid.element("Grid1"),"选择", true, 1); 
	    GridUtil.checkRowSelected(Grid.element("Grid1"),"选择", false, 2); 
	    GridUtil.checkRowSelected(Grid.element("Grid1"),"选择", true, 3); 
	    //修改子明细中各单元格的值
	    ToolBar.element("main_toolbar").click("Edit1");
	    Grid.element("Grid1").celComboClick("税率", 1).comboItemClick("0.3");
	    Grid.element("Grid1").cellDbInput("销售额", 2, "100");
	    Grid.element("Grid1").celDictClick("地区", 3).dictItemClick("a04 济南");
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 1);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 3, "");
	    GridUtil.checkRowSelected(Grid.element("Grid1"), "选择",true, 1); 
	    GridUtil.checkRowSelected(Grid.element("Grid1"), "选择",false, 2); 
	    GridUtil.checkRowSelected(Grid.element("Grid1"),"选择", true, 3); 
	    GridUtil.checkGridRowValue("Grid1", 1, "truea01 西安10,000.000.3B,C2016-12-08 14:10:31nullaaaa");
	    GridUtil.checkGridRowValue("Grid1", 2, "falsea02 内蒙古100.000.3D,E2016-12-08 14:10:53nullbbbb");
	    GridUtil.checkGridRowValue("Grid1", 3, "truea04 济南30,000.000.1F,G2016-12-08 14:11:15nullcccc");
	    
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 2);
	    GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 3, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "truea04 济南40,000.000.3C2016-12-08 14:14:13nullccccc");
	    GridUtil.checkGridRowValue("Grid1", 2, "truea03 南宁60,000.000.1D,E2018-01-01 14:14:34nullDDDD");
	    GridUtil.checkGridRowValue("Grid1", 3, "truea04 济南8,000.000.1D2016-12-07 14:15:04null二二二");
	    
        Grid.element("GT_M6_001Detail1").cellClick("物料", 3);
        GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", false);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 4, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla03 南宁5,000.000.1D,E2016-12-08 14:15:57nullggg");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla04 济南6,000.000.3C,F,G2016-12-08 14:16:18nullfff");
	    GridUtil.checkGridRowValue("Grid1", 3, "nulla05 洛阳7,000.000.1F,G2016-12-08 14:16:34nulleee");
	    GridUtil.checkGridRowValue("Grid1", 4, "nulla03 南宁8,000.000.3C,F,G2016-12-23 14:16:55nullaaa");
	    
	    //点击【编辑】
	    ToolBar.element("main_toolbar").click("Edit1");
	    Grid.element("GT_M6_001Detail1").cellClick("物料", 2).deleteRowClick();
	    //ConfirmDialog.element().yesClick();
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkRowCount(Grid.element("GT_M6_001Detail1"), 2, "");
	    //校验头表保存值是否正确
	    waittime(1000);
		String[][] expTable = {
									{"1"}};
		DataBaseUtil.checkDataMatch("SELECT BillNO FROM GT_M6_001Head", expTable, "测试用例CASE_GT_M6_001");
		//校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable1 = {
									{"30739","30738","18982","1000"},
									{"30749","30738","10006","3000"}};
		DataBaseUtil.checkDataMatch("SELECT OID,SOID,TText,TNumber FROM GT_M6_001Detail", expTable1, "测试用例CASE_GT_M6_001");
		//校验子明细表保存值是否正确
		waittime(1000);
		String[][] expTable2 = {
									{"30741","30738","30739","13614","10000.00","0.32","B,C","1","aaaa"},
									{"30742","30738","30739","13615","100.00","0.32","D,E","1","bbbb"},
									{"30743","30738","30739","13617","30000.00","0.10","F,G","1","cccc"},
									{"30750","30738","30749","13616","5000.00","0.10","D,E","1","ggg"},
									{"30751","30738","30749","13617","6000.00","0.32","C,F,G","0","fff"},
									{"30752","30738","30749","13631","7000.00","0.10","F,G","0","eee"},
		                            {"30753","30738","30749","13616","8000.00","0.32","C,F,G","1","aaa"}};
		DataBaseUtil.checkDataMatch("SELECT OID,SOID,POID,Area,SaleAmount,Fee,State,Ee,Memo FROM GT_M6_001SubDetail", expTable2, "测试用例CASE_GT_M6_001");
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
	    
	}
	
	

}
