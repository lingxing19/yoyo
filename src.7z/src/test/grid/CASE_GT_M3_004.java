package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M3_004 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M3").click();
		MenuEntry.element("GridTest/GridTest/M3/GT_M3_004View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
		MainContainer.selectTab(1);
	    GridUtil.checkRowCount(Grid.element("GT_M3_004Detail"), 11, "");
	    GridUtil.checkGridRowValue("GT_M3_004Detail", 1, "01 华东001 大众朗逸100.00100.00Bnull");

	    GridUtil.checkGridRowValue("GT_M3_004Detail", 3, "01 华东002 奥迪200.00200.00Bnull");
	    GridUtil.checkGridRowValue("GT_M3_004Detail", 4, "01 华东002 奥迪500.00500.00Bnull");
	    GridUtil.checkGridRowValue("GT_M3_004Detail", 5, "01 华东002 奥迪600.00600.00Bnull");
	    GridUtil.checkGridRowValue("GT_M3_004Detail", 6, "null物料合计21300nullnullnull");
	    GridUtil.checkGridRowValue("GT_M3_004Detail", 7, "仓库合计2null1400nullnullnull");
	   
	    
	
	
	    MainContainer.closeAllTab();
	
	
	
	    System.out.println("================================================================================================================");
	    
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
