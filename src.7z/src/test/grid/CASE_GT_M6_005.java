package test.grid;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.CheckListBoxUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M6_005 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M6").click();
		MenuEntry.element("GridTest/GridTest/M6/GT_M6_008View").dblClick();		
		MainContainer.selectTab(0);
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(1);
	    
	    GridUtil.rowUICheck("GT_M6_008Detail", 1, true);
	    GridUtil.checkCellValue("GT_M6_008Detail", "物料状态", 1, "B");
	    //输入，物料A：002 奥迪
	    Dict.element("BillArea1").viewClick().itemClick("002 奥迪");
	    waittime(500);
	    GridUtil.checkCellValue("GT_M6_008Detail", "物料", 1, "002 奥迪");
	    waittime(500);
	    DictUtil.checkInputValue("BillArea1", "002 奥迪", "");
	    waittime(500);
	    CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox1"), "B", "");
	    waittime(500);
	    AssertUtil.checkEnabled(CheckListBox.element("CheckListBox1"), false, "");
	    waittime(500);
	    AssertUtil.uiCheck(NumberEditor.element("NumberEditor1"), true, "");
	    
	    //输入，数量A：100
	    NumberEditor.element("BillAmount1").input("100").pressEnterKey();
	    waittime(500);
	    GridUtil.rowUICheck("GT_M6_008Detail", 1, false);
	    GridUtil.checkCellValue("GT_M6_008Detail", "数量", 1, "100");
	    GridUtil.cellUICheck("GT_M6_008Detail", "成本", 1, false);
	    
	    //输入，单价A：11
	    NumberEditor.element("NumberEditor2").input("11").pressEnterKey();
	    AssertUtil.uiCheck(NumberEditor.element("NumberEditor1"), false, "");
	    
	    //修改，类型A：实体
	    ComboBox.element("ComboBox1").dropDownClick().itemClick("实体");
	    GridUtil.checkCellEnabled("GT_M6_008Detail", "电商平台", 1, true);
	    AssertUtil.checkEnabled(Dict.element("Dict1"), false, "");
	    
	    //清空，物料—1，中的值
	    Grid.element("GT_M6_008Detail").cellClear("物料", 1).pressEnterKey();
	    waittime(500);
	    GridUtil.cellUICheck("GT_M6_008Detail", "物料", 1, false);
	    AssertUtil.uiCheck(NumberEditor.element("BillArea1"), true, "");
	    
	    Dict.element("BillArea1").viewClick().itemClick("002 奥迪");
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    waittime(500);
	    GridUtil.checkBaseGridRowValue("GT_M6_008Detail", 1, "1002 奥迪10011.00null实体nullB");
	    Grid.element("GT_M6_008Detail").cellClick("物料", 1);
	    DictUtil.checkInputValue("BillArea1", "002 奥迪", "");
	    NumberEditorUtil.checkInputValue(NumberEditor.element("BillAmount1"), "100.00", "");
	    ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox1"), "实体", "");
	    CheckListBoxUtil.checkInputValue(CheckListBox.element("CheckListBox1"), "B", "");
	    NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor2"), "11.00", "");
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	
	
	}
}
