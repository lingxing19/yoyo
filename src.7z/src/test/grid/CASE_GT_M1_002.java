package test.grid;

import java.util.ArrayList;
import java.util.List;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.grid.BaseGridDictItem;
import com.bokesoft.yes.autotest.script.AbstractTestScript;
import com.sun.swing.internal.plaf.basic.resources.basic;

public class CASE_GT_M1_002 extends AbstractTestScript{

	public void run() {
		waittime(500);
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_002View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);

		//点击：表格【依赖头控件】 :检查字典各节点是否正确	
		List<BaseGridDictItem> expList = new ArrayList<BaseGridDictItem>();
		List<BaseGridDictItem> list=Grid.element("GT_M1_002Detail").celDictClick("4", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
		GridUtil.checkGridDictItemFiled(expList, list, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		
		//选择节点：A 电子类
		Grid.element("GT_M1_002Detail").dictItemClick("A 电子类");
		GridUtil.checkCellValue("GT_M1_002Detail", "4", 1, "A 电子类");
		//勾选：头控件【是否过滤】
		CheckBox.element("CheckBox1").click();
		GridUtil.checkCellValue("GT_M1_002Detail", "4", 1, "");
		//点击：表格【Check1】	
		expList.clear();
		List<BaseGridDictItem> list1=Grid.element("GT_M1_002Detail").celDictClick("4", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list1, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		//【Check1】选“001 大众朗逸”
		Grid.element("GT_M1_002Detail").dictItemClick("001 大众朗逸");
		GridUtil.checkCellValue("GT_M1_002Detail","4", 1,"001 大众朗逸");
		//勾销：头控件【是否过滤】
		CheckBox.element("CheckBox1").click();
		GridUtil.checkCellValue("GT_M1_002Detail", "4", 1, "");
		//点击：表格【Check2】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list2=Grid.element("GT_M1_002Detail").celDictClick("5", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
   		
		GridUtil.checkGridDictItemFiled(expList, list2, "测试用例CASE_GT_M1_002");	
		
		expList.clear();
		List<BaseGridDictItem> list3=Grid.element("GT_M1_002Detail").dictExpandItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机",1,0));		
		expList.add(new BaseGridDictItem("02 耳机",1,0));
		expList.add(new BaseGridDictItem("03 笔记本",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list3, "测试用例CASE_GT_M1_002");	
		
		expList.clear();
		List<BaseGridDictItem> list4=Grid.element("GT_M1_002Detail").dictExpandItemClick("B 服装类").getChildren(false);
 		expList.add(new BaseGridDictItem("11 女装",1,0));		
  		expList.add(new BaseGridDictItem("12 男装",1,0));
   		expList.add(new BaseGridDictItem("13 童装",1,0));
		GridUtil.checkGridDictItemFiled(expList, list4, "测试用例CASE_GT_M1_002");	
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		//选择节点：01 手机
		Grid.element("GT_M1_002Detail").dictItemClick("01 手机");
		GridUtil.checkCellValue("GT_M1_002Detail", "5", 1, "01 手机");
		//勾选：当前行【是否过滤】
		Grid.element("GT_M1_002Detail").cellCheckboxClick("2", 1);
		GridUtil.checkGridCheckBoxChecked("GT_M1_002Detail", "2", 1, true, "测试用例CASE_GT_M1_002");
		GridUtil.checkCellValue("GT_M1_002Detail", "5", 1, "");
		waittime(500);
		//点击：表格【依赖单元格】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list5=Grid.element("GT_M1_002Detail").celDictClick("5", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
		GridUtil.checkGridDictItemFiled(expList, list5, "测试用例CASE_GT_M1_002");		
		
		expList.clear();
		List<BaseGridDictItem> list6=Grid.element("GT_M1_002Detail").dictExpandItemClick("A 电子类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list6, "测试用例CASE_GT_M1_002");	
		
		expList.clear();
		List<BaseGridDictItem> list7=Grid.element("GT_M1_002Detail").dictExpandItemClick("B 服装类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list7, "测试用例CASE_GT_M1_002");		
		
		expList.clear();
		List<BaseGridDictItem> list9=Grid.element("GT_M1_002Detail").dictExpandItemClick("C 食品类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list9, "测试用例CASE_GT_M1_002");	
		
		expList.clear();
		List<BaseGridDictItem> list25 = Grid.element("GT_M1_002Detail").dictExpandItemClick("D 生活类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list25, "测试用例CASE_GT_M1_002");
		
		expList.clear();
		List<BaseGridDictItem> list26 = Grid.element("GT_M1_002Detail").dictExpandItemClick("E 交通工具").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list26, "测试用例CASE_GT_M1_002");
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		
		//点击：表格【AND】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem>list10=Grid.element("GT_M1_002Detail").celDictClick("6", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));
 		GridUtil.checkGridDictItemFiled(list10, expList, "测试用例CASE_GT_M1_002");
 		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
 		
 		//点击：表格【OR】:检查字典各节点是否正确
 		expList.clear();
 		List<BaseGridDictItem>list11=Grid.element("GT_M1_002Detail").celDictClick("7", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
   		
		GridUtil.checkGridDictItemFiled(expList, list11, "测试用例CASE_GT_M1_002");		
		
		expList.clear();
		List<BaseGridDictItem> list12=Grid.element("GT_M1_002Detail").dictExpandItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机",1,0));		
		expList.add(new BaseGridDictItem("02 耳机",1,0));
		expList.add(new BaseGridDictItem("03 笔记本",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list12, "测试用例CASE_GT_M1_002");	
		
		expList.clear();
		List<BaseGridDictItem> list13=Grid.element("GT_M1_002Detail").dictExpandItemClick("B 服装类").getChildren(false);
 		expList.add(new BaseGridDictItem("11 女装",1,0));		
  		expList.add(new BaseGridDictItem("12 男装",1,0));
   		expList.add(new BaseGridDictItem("13 童装",1,0));
		GridUtil.checkGridDictItemFiled(expList, list13, "测试用例CASE_GT_M1_002");		
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		
		//点击：表格【常量】:检查字典各节点是否正确
 		expList.clear();
 		List<BaseGridDictItem>list15=Grid.element("GT_M1_002Detail").celDictClick("8", 1).getChildren(true);
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
		GridUtil.checkGridDictItemFiled(expList, list15, "测试用例CASE_GT_M1_002");		
		
		expList.clear();
		List<BaseGridDictItem> list16=Grid.element("GT_M1_002Detail").dictExpandItemClick("A 电子类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list16, "测试用例CASE_GT_M1_002");	
		
		expList.clear();
		List<BaseGridDictItem> list17=Grid.element("GT_M1_002Detail").dictExpandItemClick("B 服装类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list17, "测试用例CASE_GT_M1_002");		
		
		expList.clear();
		List<BaseGridDictItem> list18=Grid.element("GT_M1_002Detail").dictExpandItemClick("C 食品类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list18, "测试用例CASE_GT_M1_002");
		
		expList.clear();
		List<BaseGridDictItem> list32 = Grid.element("GT_M1_002Detail").dictExpandItemClick("D 生活类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list32, "测试用例CASE_GT_M1_002");
		
		expList.clear();
		List<BaseGridDictItem> list33 = Grid.element("GT_M1_002Detail").dictExpandItemClick("E 交通工具").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list32, "测试用例CASE_GT_M1_002");
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		
		//点击：表格【表达式】：检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem>list19=Grid.element("GT_M1_002Detail").celDictClick("9", 1).getChildren(true);	
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list19, "测试用例CASE_GT_M1_002");		
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		
		//【过滤条件】选择:1;勾选：头控件【是否过滤】
		ComboBox.element("Depend1").dropDownClick().itemClick("1");
		CheckBox.element("CheckBox1").click();
		
		//点击：表格【AND】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list20=Grid.element("GT_M1_002Detail").celDictClick("6", 1).getChildren(true);	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
	    GridUtil.checkGridDictItemFiled(expList, list20, "测试用例CASE_GT_M1_002");		
		
		expList.clear();
		List<BaseGridDictItem> list21=Grid.element("GT_M1_002Detail").dictExpandItemClick("A 电子类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list21, "测试用例CASE_GT_M1_002");	
		
		expList.clear();
		List<BaseGridDictItem> list22=Grid.element("GT_M1_002Detail").dictExpandItemClick("B 服装类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list22, "测试用例CASE_GT_M1_002");		
		
		expList.clear();
		List<BaseGridDictItem> list23=Grid.element("GT_M1_002Detail").dictExpandItemClick("C 食品类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list23, "测试用例CASE_GT_M1_002");
		
		expList.clear();
		List<BaseGridDictItem> list35=Grid.element("GT_M1_002Detail").dictExpandItemClick("D 生活类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list35, "测试用例CASE_GT_M1_002");
		
		expList.clear();
		List<BaseGridDictItem> list36=Grid.element("GT_M1_002Detail").dictExpandItemClick("E 交通工具").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list36, "测试用例CASE_GT_M1_002");
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		
		//点击：表格【or】,查看节点
		expList.clear();
		List<BaseGridDictItem> list37 = Grid.element("GT_M1_002Detail").celDictClick("7", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
   		GridUtil.checkGridDictItemFiled(expList, list37, "测试用例CASE_GT_M1_002");
   		
   		expList.clear();
   		List<BaseGridDictItem> list38 = Grid.element("GT_M1_002Detail").dictExpandItemClick("A 电子类").getChildren(false);
   		GridUtil.checkGridDictItemFiled(expList, list38, "测试用例CASE_GT_M1_002");
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		
		//单元格【过滤条件】选择:非0值
		Grid.element("GT_M1_002Detail").celComboClick("3", 1).comboItemClick("18473");
		GridUtil.checkCellValue("GT_M1_002Detail", "3", 1, "18473");
		//点击：表格【Check2】:检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list24=Grid.element("GT_M1_002Detail").celDictClick("5", 1).getChildren(true);
	    GridUtil.checkGridDictItemFiled(expList, list24, "测试用例CASE_GT_M1_002");	
		GridUtil.checkGridDictRootNode("GT_M1_002Detail", "物料", "测试用例CASE_GT_M1_002");
		Grid.element("GT_M1_002Detail").celViewClose("5", 1);
		
		//添加2行明细

		Grid.element("GT_M1_002Detail").celDictClick("6", 2).dictItemClick("A 电子类");
		Grid.element("GT_M1_002Detail").celDictClick("7", 3).dictItemClick("001 大众朗逸");
		
		//点击保存
		ToolBar.element("main_toolbar").click("Save");
		
	    //校验头表保存值是否正确
		waittime(1000);
		String[][] expTable = {
									{"1","1"}};
		DataBaseUtil.checkDataMatch("SELECT Dict1,CheckBox1 FROM GT_M1_002Head", expTable, "测试用例CASE_GT_M1_002");
		
	    //校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable1 = {
									{"0","0","1","18473"},
									{"18473","0","0",""},
									{"0","18982","0",""}};
		DataBaseUtil.checkDataMatch("SELECT check3,check4,checkbox,combox FROM GT_M1_002Detail", expTable1, "测试用例CASE_GT_M1_002");
		MainContainer.closeAllTab();
		
		
		System.out.println("================================================================================================================");
	    
		
		
		
		
		
		
		
	}

}
