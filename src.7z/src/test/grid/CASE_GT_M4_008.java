package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_008 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_008View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("list").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    GridUtil.checkGridNestExpColTitle1("detail_grid", "序号人员排班表");
	    GridUtil.checkGridNestExpColTitle2("detail_grid", "北京上海广州");
		
	    GridUtil.checkGridExpColNum("detail_grid", "北京", 2);
	    GridUtil.checkGridExpColNum("detail_grid", "上海", 2);
	    GridUtil.checkGridExpColNum("detail_grid", "广州", 2);
	    GridUtil.checkGridExpColName("detail_grid", "上午下午上午下午上午下午");
		
	    GridUtil.checkRowCount(Grid.element("detail_grid"), 14, "");
	    

	    GridUtil.checkGridColValue("detail_grid", "3", "truetruetruetruetruetruetruetruetruetruetruetruetruetrue");
	    GridUtil.checkGridColValue("detail_grid", "4", "falsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalse");
	    GridUtil.checkGridColValue("detail_grid", "5", "truetruetruetruetruetruetruetruetruetruetruetruetruetrue");
	    GridUtil.checkGridColValue("detail_grid", "6", "falsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalse");
	    GridUtil.checkGridColValue("detail_grid", "7", "truetruetruetruetruetruetruetruetruetruetruetruetruetrue");
	    GridUtil.checkGridColValue("detail_grid", "8", "falsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalsefalse");
		
		//点击【新增】
	    MainContainer.selectTab(0);
	    ToolBar.element("main_toolbar").click("New");
	    MainContainer.selectTab(2);

	    Grid.element("detail_grid").cellCheckboxClick("3", 1);
	    Grid.element("detail_grid").cellCheckboxClick("4", 2);
	    Grid.element("detail_grid").cellCheckboxClick("5", 3);
	    Grid.element("detail_grid").cellCheckboxClick("6", 4);
	    Grid.element("detail_grid").cellCheckboxClick("7", 5);
	    Grid.element("detail_grid").cellCheckboxClick("8", 6);
		
		//点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkGridColValue("detail_grid", "3", "truefalsefalsefalsefalsefalsenullnullnullnullnullnullnullnull");
	    GridUtil.checkGridColValue("detail_grid", "4", "falsetruefalsefalsefalsefalsenullnullnullnullnullnullnullnull");
	    GridUtil.checkGridColValue("detail_grid", "5", "falsefalsetruefalsefalsefalsenullnullnullnullnullnullnullnull");
	    GridUtil.checkGridColValue("detail_grid", "6", "falsefalsefalsetruefalsefalsenullnullnullnullnullnullnullnull");
	    GridUtil.checkGridColValue("detail_grid", "7", "falsefalsefalsefalsetruefalsenullnullnullnullnullnullnullnull");
	    GridUtil.checkGridColValue("detail_grid", "8", "falsefalsefalsefalsefalsetruenullnullnullnullnullnullnullnull");
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
	    
		
		
		
		
		
		
		
	}

}
