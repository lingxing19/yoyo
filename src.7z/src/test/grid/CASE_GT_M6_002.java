package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M6_002 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M6").click();
		MenuEntry.element("GridTest/GridTest/M6/GT_M6_002View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
	    ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
		//明细中有3行数据
	    GridUtil.checkRowCount(Grid.element("GT_M6_002Detail"), 3, "");
	    GridUtil.checkGridRowValue("GT_M6_002Detail", 1, "01 手机null02 华中nullB");
	    GridUtil.checkGridRowValue("GT_M6_002Detail", 2, "02 耳机null01 华东nullB");
	    GridUtil.checkGridRowValue("GT_M6_002Detail", 3, "03 笔记本null01 华东nullB");
	    //选中“01 手机”所在行
	    Grid.element("GT_M6_002Detail").cellClick("物料", 1);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 1, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla01 西安3,000.0001 手机02 华中");
	    //切换到“02  耳机”所在行
	    Grid.element("GT_M6_002Detail").cellClick("物料", 2);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 1, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla03 南宁5,000.0002 耳机01 华东");
	    //切换到“03  笔记本”所在行
	    Grid.element("GT_M6_002Detail").cellClick("物料", 3);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 3, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla03 南宁400.0003 笔记本01 华东");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla01 西安300.0003 笔记本01 华东");
	    GridUtil.checkGridRowValue("Grid1", 3, "nulla04 济南400.0003 笔记本01 华东");
	    MainContainer.closeAllTab();
	    //打开视图：002
		MenuEntry.element("GridTest/GridTest/M6/M6_002View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    //选中“01 手机”所在行
	    Grid.element("GT_M6_002Detail").cellClick("物料", 1);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 6, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla04 济南400.00002 奥迪01 华东");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla05 洛阳444.00001 大众朗逸02 华中");
	    GridUtil.checkGridRowValue("Grid1", 3, "nulla04 济南600.0001 手机01 华东");
	    GridUtil.checkGridRowValue("Grid1", 4, "nulla01 西安3,000.0001 手机02 华中");
	    GridUtil.checkGridRowValue("Grid1", 5, "nulla03 南宁666.00B 服装类02 华中");	                                            
	    GridUtil.checkGridRowValue("Grid1", 6, "nulla05 洛阳777.00B 服装类02 华中");
	    //切换到“02  耳机”所在行
	    Grid.element("GT_M6_002Detail").cellClick("物料", 2);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 2, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla03 南宁5,000.0002 耳机01 华东");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla02 内蒙古6,000.0002 耳机02 华中");
	    //切换到“03  笔记本”所在行
	    Grid.element("GT_M6_002Detail").cellClick("物料", 3);
	    GridUtil.checkRowCount(Grid.element("Grid1"), 4, "");
	    GridUtil.checkGridRowValue("Grid1", 1, "nulla03 南宁400.0003 笔记本01 华东");
	    GridUtil.checkGridRowValue("Grid1", 2, "nulla01 西安300.0003 笔记本01 华东");
	    GridUtil.checkGridRowValue("Grid1", 3, "nulla04 济南400.0003 笔记本01 华东");
	    GridUtil.checkGridRowValue("Grid1", 4, "nulla02 内蒙古500.0003 笔记本02 华中");
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	}

}
