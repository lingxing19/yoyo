package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_007 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_007View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("list").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    GridUtil.checkGridNestExpColTitle1("detail_grid", "序号部门排班表");
	    GridUtil.checkGridNestExpColTitle2("detail_grid", "北京上海广州");
	    
	    GridUtil.checkGridExpColNum("detail_grid", "北京", 2);
	    GridUtil.checkGridExpColNum("detail_grid", "上海", 2);
	    GridUtil.checkGridExpColNum("detail_grid", "广州", 2);
	    GridUtil.checkGridExpColName("detail_grid", "上午人员下午人员上午人员下午人员上午人员下午人员");
	
	    GridUtil.checkRowCount(Grid.element("detail_grid"), 5, "");
	
	    GridUtil.checkGridColValue("detail_grid", "3", "user1 user1user1 user1user1 user1user1 user1user1 user1");
	    GridUtil.checkGridColValue("detail_grid", "4", "user1 user1user1 user1user1 user1user1 user1user1 user1");
	    GridUtil.checkGridColValue("detail_grid", "5", "user1 user1user1 user1user1 user1user1 user1user1 user1");
	    GridUtil.checkGridColValue("detail_grid", "6", "user1 user1user1 user1user1 user1user1 user1user1 user1");
	    GridUtil.checkGridColValue("detail_grid", "7", "user1 user1user1 user1user1 user1user1 user1user1 user1");
	    GridUtil.checkGridColValue("detail_grid", "8", "user1 user1user1 user1user1 user1user1 user1user1 user1");
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	}

}
