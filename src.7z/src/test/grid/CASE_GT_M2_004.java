package test.grid;

import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M2_004 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M2").click();
		MenuEntry.element("GridTest/GridTest/M2/GT_M2_004View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		
		//行选模式
		Grid.element("GT_M2_004Detail").cellClick("物料", 1).checkRowSelect(1);
		
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
		
		
	}
}
