package test.grid;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M8_001 extends AbstractTestScript {
	//自定义查询
	public void run(){
		MenuEntry.element("GridTest/GridTest").click();
		waittime(5000);
		MenuEntry.element("GridTest/GridTest/M8").click();
		MenuEntry.element("GridTest/GridTest/M8/GT_M8_008View").dblClick();
		MainContainer.selectTab(0);
		ComboBox.element("ComboBox1").dropDownClick().itemClick("按状态");
		ComboBox.element("ComboBox2").dropDownClick().itemClick("B");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 1, "CASE_GT_M8_001");
		ListViewUtil.checkValue("list","单据状态", 1,"B");
		Button.element("cancel").click();
		ComboBox.element("ComboBox1").dropDownClick().itemClick("按单号");
		TextEditor.element("TextEditor1").input("GT_M8_00820181022000004");
		Button.element("Query").click();
		ListViewUtil.CheckAllRows("list", 1, "CASE_GT_M8_001");
		ListViewUtil.checkValue("list","单据编号", 1,"GT_M8_00820181022000004");
		MainContainer.closeAllTab();
	}

}
