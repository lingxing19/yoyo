package test.grid;

import java.util.ArrayList;
import java.util.List;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.grid.BaseGridDictItem;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_003 extends AbstractTestScript{
	public void run() {
		waittime(500);
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_003View").dblClick();		
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		
		//点击：表格【依赖头控件】:检查字典各节点是否正确
		waittime(500);
		List<BaseGridDictItem> expList = new ArrayList<BaseGridDictItem>();
		List<BaseGridDictItem> list=Grid.element("GT_M1_003Detail").celDictClick("4", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
   		
		GridUtil.checkGridDictItemFiled(expList, list, "测试用例CASE_GT_M1_003");			
		GridUtil.checkGridDictRootNode("GT_M1_003Detail", "物料", "测试用例CASE_GT_M1_003");
		
		expList.clear();
		List<BaseGridDictItem> list1=Grid.element("GT_M1_003Detail").dictExpandItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机",1,0));		
		expList.add(new BaseGridDictItem("02 耳机",1,0));
		expList.add(new BaseGridDictItem("03 笔记本",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list1, "测试用例CASE_GT_M1_003");	
		
		expList.clear();
		List<BaseGridDictItem> list2=Grid.element("GT_M1_003Detail").dictExpandItemClick("B 服装类").getChildren(false);
 		expList.add(new BaseGridDictItem("11 女装",1,0));		
  		expList.add(new BaseGridDictItem("12 男装",1,0));
   		expList.add(new BaseGridDictItem("13 童装",1,0));
		GridUtil.checkGridDictItemFiled(expList, list2, "测试用例CASE_GT_M1_003");	
		
		//选择节点：A 电子类
		Grid.element("GT_M1_003Detail").dictItemClick("A 电子类");
		GridUtil.checkCellValue("GT_M1_003Detail", "4", 1, "A 电子类");
		
		//勾选：头控件【是否过滤】
		CheckBox.element("CheckBox1").click();
		GridUtil.checkCellValue("GT_M1_003Detail", "4", 1, "");
		
		//点击：表格【依赖头控件】:检查字典各节点是否正确
		waittime(500);
		expList.clear();
		List<BaseGridDictItem> list4=Grid.element("GT_M1_003Detail").celDictClick("4", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list4, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_003Detail", "物料", "测试用例CASE_GT_M1_003");
		
		//点击：表格【依赖单元格】:检查字典各节点是否正确
		waittime(500);
		expList.clear();
		List<BaseGridDictItem> list5=Grid.element("GT_M1_003Detail").celDictClick("5", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
   		
		GridUtil.checkGridDictItemFiled(expList, list5, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_003Detail", "物料", "测试用例CASE_GT_M1_003");
		
		expList.clear();
		List<BaseGridDictItem> list6=Grid.element("GT_M1_003Detail").dictExpandItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机",1,0));		
		expList.add(new BaseGridDictItem("02 耳机",1,0));
		expList.add(new BaseGridDictItem("03 笔记本",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list6, "测试用例CASE_GT_M1_003");	
		
		expList.clear();
		List<BaseGridDictItem> list7=Grid.element("GT_M1_003Detail").dictExpandItemClick("B 服装类").getChildren(false);
 		expList.add(new BaseGridDictItem("11 女装",1,0));		
  		expList.add(new BaseGridDictItem("12 男装",1,0));
   		expList.add(new BaseGridDictItem("13 童装",1,0));
		GridUtil.checkGridDictItemFiled(expList, list7, "测试用例CASE_GT_M1_003");	
		
		//选择节点：01 手机
		Grid.element("GT_M1_003Detail").dictItemClick("01 手机");
		GridUtil.checkCellValue("GT_M1_003Detail", "5", 1, "01 手机");
		//勾选：当前行【是否过滤】
		Grid.element("GT_M1_003Detail").cellCheckboxClick("2", 1);
		GridUtil.checkGridCheckBoxChecked("GT_M1_003Detail", "2", 1, true, "测试用例CASE_GT_M1_003");
		GridUtil.checkCellValue("GT_M1_003Detail", "5", 1, "");
		//点击：表格【Check2】:检查字典各节点是否正确
		waittime(500);
		expList.clear();
		List<BaseGridDictItem> list9=Grid.element("GT_M1_003Detail").celDictClick("5", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
   		
		GridUtil.checkGridDictItemFiled(expList, list9, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_003Detail", "物料", "测试用例CASE_GT_M1_003");
		
		expList.clear();
		List<BaseGridDictItem> list10=Grid.element("GT_M1_003Detail").dictExpandItemClick("A 电子类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list10, "测试用例CASE_GT_M1_003");	
		
		expList.clear();
		List<BaseGridDictItem> list11=Grid.element("GT_M1_003Detail").dictExpandItemClick("B 服装类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list11, "测试用例CASE_GT_M1_003");	
		
		expList.clear();
		List<BaseGridDictItem> list12=Grid.element("GT_M1_003Detail").dictExpandItemClick("C 食品类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list12, "测试用例CASE_GT_M1_003");	
		
		//点击：表格【AND】：检查字典各节点是否正确
		waittime(500);
		expList.clear();
		List<BaseGridDictItem> list13=Grid.element("GT_M1_003Detail").celDictClick("6", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list13, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_003Detail", "物料", "测试用例CASE_GT_M1_003");
		
		//点击：表格【常量】:检查字典各节点是否正确
		waittime(500);
		expList.clear();
		List<BaseGridDictItem> list14=Grid.element("GT_M1_003Detail").celDictClick("8", 1).getChildren(true);
		expList.add(new BaseGridDictItem("A 电子类",1,1));
  		expList.add(new BaseGridDictItem("B 服装类",1,1));
   		expList.add(new BaseGridDictItem("C 食品类",1,1));
   		expList.add(new BaseGridDictItem("D 生活类",1,1));
   		expList.add(new BaseGridDictItem("E 交通工具",1,1));
   		
		GridUtil.checkGridDictItemFiled(expList, list14, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_003Detail", "物料", "测试用例CASE_GT_M1_003");
		
		expList.clear();
		List<BaseGridDictItem> list15=Grid.element("GT_M1_003Detail").dictExpandItemClick("A 电子类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list15, "测试用例CASE_GT_M1_003");	
		
		expList.clear();
		List<BaseGridDictItem> list16=Grid.element("GT_M1_003Detail").dictExpandItemClick("B 服装类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list16, "测试用例CASE_GT_M1_003");	
		
		expList.clear();
		List<BaseGridDictItem> list17=Grid.element("GT_M1_003Detail").dictExpandItemClick("C 食品类").getChildren(false);
		GridUtil.checkGridDictItemFiled(expList, list17, "测试用例CASE_GT_M1_003");	
		
		//点击：表格【表达式】:检查字典各节点是否正确
		waittime(500);
		expList.clear();
		List<BaseGridDictItem> list18=Grid.element("GT_M1_003Detail").celDictClick("9", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸",1,0));	
 		expList.add(new BaseGridDictItem("002 奥迪",1,0));	
		GridUtil.checkGridDictItemFiled(expList, list18, "测试用例CASE_GT_M1_002");			
		GridUtil.checkGridDictRootNode("GT_M1_003Detail", "物料", "测试用例CASE_GT_M1_003");
		
		//添加2行明细;点击保存
		Grid.element("GT_M1_003Detail").celDictClick("4", 2).dictItemClick("001 大众朗逸");
		Grid.element("GT_M1_003Detail").celDictClick("5", 3).dictItemClick("002 奥迪");
		ToolBar.element("main_toolbar").click("Save");
		
	    //校验头表保存值是否正确
		waittime(1000);
		String[][] expTable = {
									{"1"}};
		DataBaseUtil.checkDataMatch("SELECT CheckBox1 FROM GT_M1_003Head", expTable, "测试用例CASE_GT_M1_003");
		
	    //校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable1 = {
									{"0","0","true"},
									{"18982","0",""},
									{"0","18983",""}};
		DataBaseUtil.checkDataMatch("SELECT check1,check2,checkbox FROM GT_M1_003Detail", expTable1, "测试用例CASE_GT_M1_003");
		MainContainer.closeAllTab();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		System.out.println("================================================================================================================");
	    
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
