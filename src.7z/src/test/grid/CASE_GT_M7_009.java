package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_009 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_011View").dblClick();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "GT_M7_01120181019000001", "", "测试用例CASE_GT_M7_009");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Edit");
		waittime(500);
		
		//表格前台过滤-and
		Dict.element("Dict1").viewClick().itemClick("A 电子类");
		waittime(500);
		GridUtil.checkRowCount(Grid.element("detail"), 9, "测试用例CASE_GT_M7_009");
		GridUtil.checkGridColValue("detail", "物料1", "A 电子类A 电子类A 电子类A 电子类A 电子类A 电子类A 电子类A 电子类null");
		DatePicker.element("DatePicker1").input("20181017").pressEnterKey();
		waittime(500);
		GridUtil.checkRowCount(Grid.element("detail"), 6, "测试用例CASE_GT_M7_009");
		GridUtil.checkGridColValue("detail", "物料1", "A 电子类A 电子类A 电子类A 电子类A 电子类null");
		GridUtil.checkGridColValue("detail", "日期", "2018-10-19 00:00:002018-10-19 00:00:002018-10-20 00:00:002018-10-18 00:00:002018-10-21 00:00:00null");
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
	}
}
