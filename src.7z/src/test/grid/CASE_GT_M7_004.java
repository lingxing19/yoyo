package test.grid;


import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TabPanel;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_004 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_004View").dblClick();		
		MainContainer.selectTab(0);
		//打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
		MainContainer.selectTab(1);
		waittime(500);
		
	    //Tab页渲染
	    GridUtil.checkCelForeColor("GT_M7_004Detail", "数量", 2, "204, 51, 51");
	    //点击【编辑】
	    ToolBar.element("main_toolbar").click("Edit1");
		GridUtil.checkPageCount(Grid.element("GT_M7_004Detail"), 4);
	    GridUtil.checkGridRowValue("GT_M7_004Detail", 1, "nullnullanullA 北美");
	    GridUtil.checkGridRowValue("GT_M7_004Detail", 8, "nullnull1500null1500");
	    Grid.element("GT_M7_004Detail").pageClick(2);
        GridUtil.checkGridRowValue("GT_M7_004Detail", 1, "nullnullanullA 北美");
	    GridUtil.checkGridRowValue("GT_M7_004Detail", 8, "nullnull4000null8000");
	    Grid.element("GT_M7_004Detail").pageClick(3);
        GridUtil.checkGridRowValue("GT_M7_004Detail", 1, "nullnullanullA 北美");
	    GridUtil.checkGridRowValue("GT_M7_004Detail", 8, "nullnull6500null19500");
	    Grid.element("GT_M7_004Detail").pageClick(4);
        GridUtil.checkGridRowValue("GT_M7_004Detail", 1, "nullnullanullA 北美");
	    GridUtil.checkGridRowValue("GT_M7_004Detail", 7, "nullnull7000null28000");
	    NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "57,000.00", "");
	    //表格第1页：全选
	    Grid.element("GT_M7_004Detail").pageClick(1);
	    Grid.element("GT_M7_004Detail").selectAllClick("选择");
	    GridUtil.checkAllSelected(Grid.element("GT_M7_004Detail"), "选择", true);


	    //表格第2页：全选
	    Grid.element("GT_M7_004Detail").pageClick(2);
	    Grid.element("GT_M7_004Detail").selectAllClick("选择");
	    GridUtil.checkAllSelected(Grid.element("GT_M7_004Detail"), "选择", true);
	    Grid.element("GT_M7_004Detail").pageClick(1);
	    GridUtil.checkAllSelected(Grid.element("GT_M7_004Detail"), "选择", true);
	    //输入一行新的数据：001 大众朗逸   101   1.0
	    Grid.element("GT_M7_004Detail").celDictClick("物料", 7).dictItemClick("001 大众朗逸");
	    Grid.element("GT_M7_004Detail").cellDbInput("数量", 7, "101");
	    Grid.element("GT_M7_004Detail").cellDbInput("单价", 7, "1.0").pressEnterKey();
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    Grid.element("GT_M7_004Detail").pageClick(4);
	    GridUtil.checkGridRowValue("GT_M7_004Detail", 7, "nullnull7101null28101");
	    NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "57,101.00", "");
	    //选择明细表：页码总数为3
	    TabPanel.element("TabPanel1").selectTab(1);
	    waittime(500);
	    GridUtil.checkCelForeColor("Grid1", "单价", 2, "204, 51, 51");
	    GridUtil.checkPageCount(Grid.element("Grid1"), 3);
	    //将明细表【页码总数为3】切换到最后一页
	    Grid.element("Grid1").toLastClick();
	    GridUtil.checkGridPagesNum("Grid1", "345");
	    //切换回第一页
	    Grid.element("Grid1").toFirstClick();
	    Grid.element("Grid1").pageClick(1);
	    GridUtil.checkCurrentPageNum(Grid.element("Grid1"), 1);
	    //选择明细表：页码总数为6
	    TabPanel.element("TabPanel1").selectTab(2);
	    GridUtil.checkPageCount(Grid.element("Grid2"), 6);
	    //将明细表【页码总数为6】切换到最后一页
	    Grid.element("Grid2").toLastClick();
	    GridUtil.checkGridPagesNum("Grid2", "456789");
	    //切换回第一页
	    Grid.element("Grid2").toFirstClick();
	    GridUtil.checkGridPagesNum("Grid2", "123456");
	    MainContainer.closeAllTab();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_004").dblClick();		
		MainContainer.selectTab(0);
		//头控件“物料”中选择：01 手机
		Dict.element("Dict1").viewClick().expandClick("A 电子类").itemClick("01 手机");
		//点击【查询】
		Button.element("Button1").click();
		GridUtil.checkPageCount(Grid.element("Grid1"), 4);
		GridUtil.checkGridRowValue("Grid1", 1, "nullnullnullnullA 北美");
		GridUtil.checkGridRowValue("Grid1", 8, "nullnull1900null2500");
		Grid.element("Grid1").pageClick(2);
		GridUtil.checkGridRowValue("Grid1", 8, "nullnull4500null10100");
		Grid.element("Grid1").pageClick(3);
		GridUtil.checkGridRowValue("Grid1", 8, "nullnull7000null22600");
		Grid.element("Grid1").pageClick(4);
		GridUtil.checkGridRowValue("Grid1", 6, "nullnull5400null21600");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "56,800.00", "");
		//表格第1页：全选 
		Grid.element("Grid1").pageClick(1);
		Grid.element("Grid1").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		//表格第2页：全选
		Grid.element("Grid1").pageClick(2);
		Grid.element("Grid1").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		
		Grid.element("Grid1").pageClick(1);
		GridUtil.checkAllSelected(Grid.element("Grid1"), "选择", true);
		
		MainContainer.closeAllTab();
		
		
		
		System.out.println("================================================================================================================");
	    
		
		
	}
	
}
