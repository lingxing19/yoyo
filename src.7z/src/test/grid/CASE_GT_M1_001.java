package test.grid;

import java.util.ArrayList;
import java.util.List;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.DictQueryBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.grid.BaseGridDictItem;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M1_001 extends AbstractTestScript {

	public void run() {

		MenuEntry.element("GridTest/GridTest").click();
		waittime(5000);
		MenuEntry.element("GridTest/GridTest/M1").click();
		MenuEntry.element("GridTest/GridTest/M1/GT_M1_001View").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(1);
		// 【Depend1】选择根节点:A 电子类（根节点依赖头控件）
		Dict.element("Dict1").viewClick().itemClick("A 电子类");
		DictUtil.checkInputValue("Dict1", "A 电子类", "测试用例CASE_GT_M1_001");
		// 检查字典各节点是否正确
		waittime(500);
		List<BaseGridDictItem> expList = new ArrayList<BaseGridDictItem>();
		List<BaseGridDictItem> list = Grid.element("GT_M1_001Detail").celDictClick("字典1", 1).getChildren(true);
		expList.add(new BaseGridDictItem("01 手机", 1, 0));
		expList.add(new BaseGridDictItem("02 耳机", 1, 0));
		expList.add(new BaseGridDictItem("03 笔记本", 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "A 电子类", "测试用例CASE_GT_M1_001");

		// 【Depend2】选择根节点：B 服装类（根节点依赖单元格）
		Grid.element("GT_M1_001Detail").celDictClick("根节点2", 1).dictItemClick("B 服装类");
		GridUtil.checkCellValue("GT_M1_001Detail", "根节点2", 1, "B 服装类");
		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list1 = Grid.element("GT_M1_001Detail").celDictClick("字典2", 1).getChildren(true);
		expList.add(new BaseGridDictItem("11 女装", 1, 0));
		expList.add(new BaseGridDictItem("12 男装", 1, 0));
		expList.add(new BaseGridDictItem("13 童装", 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list1, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "B 服装类", "测试用例CASE_GT_M1_001");

		// 【Depend3】选择根节点：002 奥迪
		Grid.element("GT_M1_001Detail").celDictClick("根节点3", 1).dictItemClick("002 奥迪");
		GridUtil.checkCellValue("GT_M1_001Detail", "根节点3", 1, "002 奥迪");
		waittime(500);
		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list2 = Grid.element("GT_M1_001Detail").celDictClick("字典3", 1).getChildren(true);
		GridUtil.checkGridDictItemFiled(expList, list2, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "002 奥迪", "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list3 = Grid.element("GT_M1_001Detail").celDictClick("平台(启用)", 1).getChildren(true);
		expList.add(new BaseGridDictItem("京东", 1, 0));
		expList.add(new BaseGridDictItem("苏宁易购", 1, 0));
		expList.add(new BaseGridDictItem("天猫", 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list3, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "平台", "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list4 = Grid.element("GT_M1_001Detail").celDictClick("平台(启用、停用)", 1).getChildren(true);
		expList.add(new BaseGridDictItem("饿了么", 0, 0));
		expList.add(new BaseGridDictItem("京东", 1, 0));
		expList.add(new BaseGridDictItem("苏宁易购", 1, 0));
		expList.add(new BaseGridDictItem("天猫", 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list4, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "平台", "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list5 = Grid.element("GT_M1_001Detail").celDictClick("平台(作废)", 1).getChildren(true);
		expList.add(new BaseGridDictItem("聚美优品", 2, 0));
		GridUtil.checkGridDictItemFiled(expList, list5, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "平台", "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list6 = Grid.element("GT_M1_001Detail").celDictClick("联动", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸", 1, 0, 0));
		expList.add(new BaseGridDictItem("002 奥迪", 1, 0, 0));
		expList.add(new BaseGridDictItem("A 电子类", 1, 1, 0));
		expList.add(new BaseGridDictItem("B 服装类", 1, 1, 0));
		expList.add(new BaseGridDictItem("C 食品类", 1, 1, 0));
		expList.add(new BaseGridDictItem("D 生活类", 1, 1, 0));
		expList.add(new BaseGridDictItem("E 交通工具", 1, 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list6, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "物料", "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list7 = Grid.element("GT_M1_001Detail").dictExpandItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机", 1, 0, 0));
		expList.add(new BaseGridDictItem("02 耳机", 1, 0, 0));
		expList.add(new BaseGridDictItem("03 笔记本", 1, 0, 0));
		GridUtil.checkGridDictItemFiled(expList, list7, "测试用例CASE_GT_M1_001");

		// 勾选节点"A 电子类"
		Grid.element("GT_M1_001Detail").dictItemCheckClick("A 电子类");
		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list8 = Grid.element("GT_M1_001Detail").gridDictItemClick("A 电子类").getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸", 1, 0, 0));
		expList.add(new BaseGridDictItem("002 奥迪", 1, 0, 0));
		expList.add(new BaseGridDictItem("A 电子类", 1, 1, 1));
		expList.add(new BaseGridDictItem("B 服装类", 1, 1, 0));
		expList.add(new BaseGridDictItem("C 食品类", 1, 1, 0));
		expList.add(new BaseGridDictItem("D 生活类", 1, 1, 0));
		expList.add(new BaseGridDictItem("E 交通工具", 1, 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list8, "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list9 = Grid.element("GT_M1_001Detail").gridDictItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机", 1, 0, 1));
		expList.add(new BaseGridDictItem("02 耳机", 1, 0, 1));
		expList.add(new BaseGridDictItem("03 笔记本", 1, 0, 1));
		GridUtil.checkGridDictItemFiled(expList, list9, "测试用例CASE_GT_M1_001");

		GridUtil.checkGridDictRootState("GT_M1_001Detail", "2", "测试用例CASE_GT_M1_001");

		Grid.element("GT_M1_001Detail").dictExpandItemClick("B 服装类");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list10 = Grid.element("GT_M1_001Detail").gridDictItemClick("B 服装类").getChildren(false);
		expList.add(new BaseGridDictItem("11 女装", 1, 0, 0));
		expList.add(new BaseGridDictItem("12 男装", 1, 0, 0));
		expList.add(new BaseGridDictItem("13 童装", 1, 0, 0));
		GridUtil.checkGridDictItemFiled(expList, list10, "测试用例CASE_GT_M1_001");

		// 勾选其子节点
		Grid.element("GT_M1_001Detail").dictItemCheckClick("11 女装").dictItemCheckClick("12 男装")
				.dictItemCheckClick("13 童装");
		waittime(500);
		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list11 = Grid.element("GT_M1_001Detail").gridDictItemClick("B 服装类").getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸", 1, 0, 0));
		expList.add(new BaseGridDictItem("002 奥迪", 1, 0, 0));
		expList.add(new BaseGridDictItem("A 电子类", 1, 1, 1));
		expList.add(new BaseGridDictItem("B 服装类", 1, 1, 1));
		expList.add(new BaseGridDictItem("C 食品类", 1, 1, 0));
		expList.add(new BaseGridDictItem("D 生活类", 1, 1, 0));
		expList.add(new BaseGridDictItem("E 交通工具", 1, 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list11, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootState("GT_M1_001Detail", "2", "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list17 = Grid.element("GT_M1_001Detail").gridDictItemClick("B 服装类").getChildren(false);
		expList.add(new BaseGridDictItem("11 女装", 1, 0, 1));
		expList.add(new BaseGridDictItem("12 男装", 1, 0, 1));
		expList.add(new BaseGridDictItem("13 童装", 1, 0, 1));
		GridUtil.checkGridDictItemFiled(expList, list17, "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list12 = Grid.element("GT_M1_001Detail").celDictClick("不联动", 1).getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸", 1, 0, 0));
		expList.add(new BaseGridDictItem("002 奥迪", 1, 0, 0));
		expList.add(new BaseGridDictItem("A 电子类", 1, 1, 0));
		expList.add(new BaseGridDictItem("B 服装类", 1, 1, 0));
		expList.add(new BaseGridDictItem("C 食品类", 1, 1, 0));
		expList.add(new BaseGridDictItem("D 生活类", 1, 1, 0));
		expList.add(new BaseGridDictItem("E 交通工具", 1, 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list12, "测试用例CASE_GT_M1_001");
		GridUtil.checkGridDictRootNode("GT_M1_001Detail", "物料", "测试用例CASE_GT_M1_001");

		// 勾选节点"A 电子类"
		Grid.element("GT_M1_001Detail").dictItemCheckClick("A 电子类");

		// 检查字典各节点是否正确
		GridUtil.checkGridDictRootState("GT_M1_001Detail", "0", "测试用例CASE_GT_M1_001");

		expList.clear();
		List<BaseGridDictItem> list14 = Grid.element("GT_M1_001Detail").gridDictItemClick("A 电子类").getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸", 1, 0, 0));
		expList.add(new BaseGridDictItem("002 奥迪", 1, 0, 0));
		expList.add(new BaseGridDictItem("A 电子类", 1, 1, 1));
		expList.add(new BaseGridDictItem("B 服装类", 1, 1, 0));
		expList.add(new BaseGridDictItem("C 食品类", 1, 1, 0));
		expList.add(new BaseGridDictItem("D 生活类", 1, 1, 0));
		expList.add(new BaseGridDictItem("E 交通工具", 1, 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list14, "测试用例CASE_GT_M1_001");

		expList.clear();
		List<BaseGridDictItem> list13 = Grid.element("GT_M1_001Detail").dictExpandItemClick("A 电子类").getChildren(false);
		expList.add(new BaseGridDictItem("01 手机", 1, 0, 0));
		expList.add(new BaseGridDictItem("02 耳机", 1, 0, 0));
		expList.add(new BaseGridDictItem("03 笔记本", 1, 0, 0));
		GridUtil.checkGridDictItemFiled(expList, list13, "测试用例CASE_GT_M1_001");

		// 勾选"B 服装类"其子节点
		expList.clear();
		List<BaseGridDictItem> list15 = Grid.element("GT_M1_001Detail").dictExpandItemClick("B 服装类").getChildren(false);
		expList.add(new BaseGridDictItem("11 女装", 1, 0, 0));
		expList.add(new BaseGridDictItem("12 男装", 1, 0, 0));
		expList.add(new BaseGridDictItem("13 童装", 1, 0, 0));
		GridUtil.checkGridDictItemFiled(expList, list15, "测试用例CASE_GT_M1_001");

		Grid.element("GT_M1_001Detail").dictItemCheckClick("11 女装").dictItemCheckClick("12 男装")
				.dictItemCheckClick("13 童装");

		// 检查字典各节点是否正确
		GridUtil.checkGridDictRootState("GT_M1_001Detail", "0", "测试用例CASE_GT_M1_001");

		expList.clear();
		List<BaseGridDictItem> list16 = Grid.element("GT_M1_001Detail").gridDictItemClick("B 服装类").getChildren(true);
		expList.add(new BaseGridDictItem("001 大众朗逸", 1, 0, 0));
		expList.add(new BaseGridDictItem("002 奥迪", 1, 0, 0));
		expList.add(new BaseGridDictItem("A 电子类", 1, 1, 1));
		expList.add(new BaseGridDictItem("B 服装类", 1, 1, 0));
		expList.add(new BaseGridDictItem("C 食品类", 1, 1, 0));
		expList.add(new BaseGridDictItem("D 生活类", 1, 1, 0));
		expList.add(new BaseGridDictItem("E 交通工具", 1, 1, 0));
		GridUtil.checkGridDictItemFiled(expList, list16, "测试用例CASE_GT_M1_001");

		// 检查字典各节点是否正确
		expList.clear();
		List<BaseGridDictItem> list18 = Grid.element("GT_M1_001Detail").gridDictItemClick("B 服装类").getChildren(false);
		expList.add(new BaseGridDictItem("11 女装", 1, 0, 1));
		expList.add(new BaseGridDictItem("12 男装", 1, 0, 1));
		expList.add(new BaseGridDictItem("13 童装", 1, 0, 1));
		GridUtil.checkGridDictItemFiled(expList, list18, "测试用例CASE_GT_M1_001");

		// 层次字典自动完成
		Grid.element("GT_M1_001Detail").cellDbInput("层次自动完成", 1, "1").pressEnterKey();
		DictQueryBox.element("1", "column10").queryBoxButtonClick("取消");
		Grid.element("GT_M1_001Detail").cellDbInput("层次自动完成", 1, "001").pressEnterKey();
		GridUtil.checkCellValue("GT_M1_001Detail", "层次自动完成", 1, "001 大众朗逸");

		// 字典加载策略（LoadType）

		Grid.element("Grid1").celDictClick("LoadType", 1).dictItemClick("A 电子类");

		GridUtil.checkGridDictItemDisableSelect("Grid1", "LoadType", 1, "A 电子类", true, "CASE_GT_M1_001");
		// TextField
		Grid.element("Grid1").celDictClick("TextField", 1).dictItemClick("001 大众朗逸");
		GridUtil.checkCellValue("Grid1", "TextField", 1, "001");
		Grid.element("Grid1").cellClear("TextField", 1);
		Grid.element("Grid1").celDictClick("TextField", 1).dictItemClick("002 奥迪");
		GridUtil.checkCellValue("Grid1", "TextField", 1, "002");
		// FormulaText
		Grid.element("Grid1").celDictClick("FormulaText", 1).dictItemClick("001 大众朗逸");
		GridUtil.checkCellValue("Grid1", "FormulaText", 1, "001--大众朗逸");

		// 添加2行明细
		Grid.element("GT_M1_001Detail").celDictClick("字典1", 2).dictItemClick("01 手机");
		Grid.element("GT_M1_001Detail").celDictClick("字典2", 3).dictItemClick("C 食品类");

		// 点击保存
		ToolBar.element("main_toolbar").click("Save");

		// 校验头表保存值是否正确
		waittime(1000);
		String[][] expTable = { { "18473" } };
		DataBaseUtil.checkDataMatch("SELECT Dict1 FROM GT_M1_001Head", expTable, "测试用例CASE_GT_M1_001");

		// 校验明细表保存值是否正确
		waittime(1000);
		String[][] expTable1 = { { "18474", "0", "0", "18983" }, { "0", "10005", "0", "0" },
				{ "0", "0", "18984", "0" } };
		DataBaseUtil.checkDataMatch("SELECT D1,D2,D3,D4 FROM GT_M1_001Detail", expTable1, "测试用例CASE_GT_M1_001");
		MainContainer.closeAllTab();
		System.out.println(
				"================================================================================================================");

	}

}
