package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_010 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_012View").dblClick();
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "GT_M7_01220181019000003", "", "测试用例CASE_GT_M7_010");
		MainContainer.selectTab(1);
		waittime(500); 
		
		//表格前台过滤-or
		GridUtil.checkRowCount(Grid.element("detail"), 3, "测试用例CASE_GT_M7_010");
		GridUtil.checkGridColValue("detail", "物料", "A 电子类nullnull");
		GridUtil.checkGridColValue("detail", "数量", "null2.002.00");
		
		MainContainer.closeAllTab();
		System.out.println("================================================================================================================");
		
	}
}
