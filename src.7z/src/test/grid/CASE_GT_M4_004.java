package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_004 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_004View").dblClick();		
		MainContainer.selectTab(0);
	    //打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
	    MainContainer.selectTab(1);
	    //扩展列上方没有标题列
	    GridUtil.checkExpColNoTitle("GT_M4_004Detail", true);
	    //“工作职务”列后面有三列扩展：“科目一”、“科目二”、“科目三”
	    GridUtil.checkGridColNames("GT_M4_004Detail", "序号姓名工作职务科目一科目二科目三");
		//表格显示18行数据
	    GridUtil.checkRowCount(Grid.element("GT_M4_004Detail"), 18, "");
	    GridUtil.checkGridColValue("GT_M4_004Detail", "科目一", "AAAAAAAAAAAAAAAAAA");
	    GridUtil.checkGridColValue("GT_M4_004Detail", "科目二", "AAAAAAAAAAAAAAAAAA");
	    GridUtil.checkGridColValue("GT_M4_004Detail", "科目三", "AAAAAAAAAAAAAAAAAA");
	    //点击【新增】
	    MainContainer.selectTab(0);
	    ToolBar.element("Main_Toolbar").click("New");
	    MainContainer.selectTab(2);
	    Grid.element("GT_M4_004Detail").cellDbInput("姓名", 1, "1");
	    Grid.element("GT_M4_004Detail").celComboClick("科目一", 1).comboItemClick("B");
	    Grid.element("GT_M4_004Detail").celComboClick("科目二", 1).comboItemClick("C");
	    Grid.element("GT_M4_004Detail").celComboClick("科目三", 1).comboItemClick("D");
		
	    Grid.element("GT_M4_004Detail").cellDbInput("姓名", 2, "12");
	    Grid.element("GT_M4_004Detail").celComboClick("科目一", 2).comboItemClick("B");
	    Grid.element("GT_M4_004Detail").celComboClick("科目二", 2).comboItemClick("C");
	    Grid.element("GT_M4_004Detail").celComboClick("科目三", 2).comboItemClick("D");
	    
	    Grid.element("GT_M4_004Detail").cellDbInput("姓名", 3, "123");
	    Grid.element("GT_M4_004Detail").celComboClick("科目一", 3).comboItemClick("B");
	    Grid.element("GT_M4_004Detail").celComboClick("科目二", 3).comboItemClick("C");
	    Grid.element("GT_M4_004Detail").celComboClick("科目三", 3).comboItemClick("D");
	    
	    Grid.element("GT_M4_004Detail").cellDbInput("姓名", 4, "1234");
	    Grid.element("GT_M4_004Detail").celComboClick("科目一", 4).comboItemClick("B");
	    Grid.element("GT_M4_004Detail").celComboClick("科目二", 4).comboItemClick("C");
	    Grid.element("GT_M4_004Detail").celComboClick("科目三", 4).comboItemClick("D");
	    
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    GridUtil.checkGridColValue("GT_M4_004Detail", "科目一", "BBBB");
	    GridUtil.checkGridColValue("GT_M4_004Detail", "科目二", "CCCC");
	    GridUtil.checkGridColValue("GT_M4_004Detail", "科目三", "DDDD");
	  
	    MainContainer.closeAllTab();
	    System.out.println("================================================================================================================");
	    
	    
	    
	    
	    
	    
	    
	    
	}
	

}
