package test.grid;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_003 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_003View").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);

		GridUtil.checkGridDisplayed("detail", false);
		// 【NumberEditor1】输入：1
		waittime(500);
		NumberEditor.element("NumberEditor1").input("1").pressEnterKey();
		NumberEditor.element("NumberEditor1").pressEnterKey();
		GridUtil.checkGridDisplayed("detail", true);
		GridUtil.checkRowCount(Grid.element("detail"), 1, "");
		GridUtil.checkCellEnabled("detail", "2", 1, false);
		GridUtil.checkCellEnabled("detail", "3", 1, false);
		GridUtil.checkCellEnabled("detail", "4", 1, false);
		GridUtil.checkCellEnabled("detail", "5", 1, false);
		GridUtil.checkCellEnabled("detail", "6", 1, false);
		GridUtil.cellRequiredCheck("detail", "9", 1, true);
		// 勾选【CheckBox1】，单击：按钮—1
		CheckBox.element("CheckBox1").click();
		waittime(500);
		Grid.element("detail").cellButtonClick("2", 1);
		waittime(1000);
		DialogUtil.checkConfirmDialogText("普通列可用ok");
		ConfirmDialog.element().okClick();
		// 勾选【CheckBox2】
		CheckBox.element("CheckBox2").click();
		GridUtil.checkCellEnabled("detail", "3", 1, true);
		// 勾选【CheckBox3】
		CheckBox.element("CheckBox3").click();
		GridUtil.checkCellEnabled("detail", "4", 1, true);
		GridUtil.checkCellEnabled("detail", "5", 1, true);
		GridUtil.checkCellEnabled("detail", "6", 1, true);
		// 勾选【CheckBox4】
		CheckBox.element("CheckBox4").click();
		GridUtil.checkGridExpColTitle("detail", "序号按钮CELL1column2column4column5CELL7column10");
		// 选择，CELL7—1：Guest 游客，【保存】
		Grid.element("detail").celDictClick("10", 1).dictItemClick("Guest 游客");
		ToolBar.element("ToolBar1").click("Save");
		DialogUtil.checkErrorDialogText("CELL4 -必须填写-");
		ErrorDialog.element().close();
		// 输入，column52—1：3
		Grid.element("detail").cellDbInput("8", 1, "3").pressEnterKey();
		GridUtil.checkCellValue("detail", "7", 1, "3");
		// 勾选【CheckBox5】
		CheckBox.element("CheckBox5").click();
		GridUtil.checkGridExpColName("detail", "A1A2A3CELL4column52column53");
		GridUtil.cellRequiredCheck("detail", "8", 2, true);
		// 点击【保存】
		ToolBar.element("ToolBar1").click("Save");
		//输，column10:88
		//Grid.element("detail").cellDbInput("11", 1, "88").pressEnterKey();
		//GridUtil.checkCellValue("detail", "11", 1, "88");
		GridUtil.checkCellEnabled("detail", "12", 1, true);
		
		GridUtil.checkRowCount(Grid.element("detail"), 1, "");
		MainContainer.closeAllTab();

		System.out.println(
				"================================================================================================================");

	}
}
