package test.grid;

import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M7_008 extends AbstractTestScript{
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M7").click();
		MenuEntry.element("GridTest/GridTest/M7/GT_M7_008View").dblClick();	
		MainContainer.selectTab(0);
	    //点击【新增】
		ToolBar.element("main_toolbar").click("New");
        MainContainer.selectTab(1);  
        GridUtil.allUiCheck("GT_M7_008Detail", true);
        GridUtil.checkAllErrorInfo("GT_M7_008Detail", "表格行数不能小于2!");
        //ToolBar.element("main_toolbar").click("Save");
	    //DialogUtil.checkErrorDialogText("表格行数不能小于2!");
	    //ErrorDialog.element().close();
	    //勾选表格第一行，点表格下方"+"
	    Grid.element("GT_M7_008Detail").cellCheckboxClick("选择", 1);
	    Grid.element("GT_M7_008Detail").addRowClick();
	    GridUtil.allUiCheck("GT_M7_008Detail", false);
	    //点击【保存】
	    ToolBar.element("main_toolbar").click("Save");
	    //点击【编辑】
	    ToolBar.element("main_toolbar").click("Edit1");
	    GridUtil.allUiCheck("GT_M7_008Detail", true);
	    GridUtil.checkAllErrorInfo("GT_M7_008Detail", "表格行数不能小于2!");
	
	
	
	    MainContainer.closeAllTab();
	
	
	    System.out.println("================================================================================================================");
	    
	
	
	
	
	}
}
