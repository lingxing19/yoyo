package test.grid;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_GT_M4_003 extends AbstractTestScript {
	public void run() {
		MenuEntry.element("GridTest/GridTest").click();
		MenuEntry.element("GridTest/GridTest/M4").click();
		MenuEntry.element("GridTest/GridTest/M4/GT_M4_003View").dblClick();
		MainContainer.selectTab(0);
		// 打开单据：1（单据编号）
		ListView.element("ListView1").dbClick("单据编号", "1", "", "");
		MainContainer.selectTab(1);
		
		
		ToolBar.element("main_toolbar").click("Edit");

		// 列扩展隐藏
		NumberEditor.element("NumberEditor1").input("1");
		Button.element("Button1").click();
		waittime(500);
		// “时间”列下方有三列扩展：“考勤”、“项目”、“绩效”
		GridUtil.checkGridExpColNum("GT_M4_003Detail", "时间", 3);
		GridUtil.checkGridExpColName("GT_M4_003Detail", "考勤出勤缺席");
		waittime(500);
		// 表格显示21行数据
		GridUtil.checkRowCount(Grid.element("GT_M4_003Detail"), 22, "");
		// 扩展列中单元格的时间均为“2016-12-07 14:17:52”（无空白单元格）
		GridUtil.checkGridExpColValue("GT_M4_003Detail", "考勤",
				"2016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-072016-12-07");
		waittime(500);
		GridUtil.checkGridExpColValue("GT_M4_003Detail", "项目",
				"");
		waittime(500);
		GridUtil.checkGridExpColValue("GT_M4_003Detail", "绩效",
				"");

		NumberEditor.element("NumberEditor1").clear().input("2");
		Button.element("Button1").click();
		waittime(500);
		GridUtil.checkGridExpColNum("GT_M4_003Detail", "时间", 1);
		GridUtil.checkGridExpColName("GT_M4_003Detail", "项目");
		// 点击【新增】
		MainContainer.selectTab(0);
		ToolBar.element("Main_Toolbar").click("New");
		MainContainer.selectTab(2);

		waittime(500);

		Grid.element("GT_M4_003Detail").cellDbInput("2", 1, "a1").pressEnterKey();
		waittime(2000);
		GridUtil.checkCellValue("GT_M4_003Detail", "2", 1, "a1");

		MainContainer.closeAllTab();

		System.out.println(
				"================================================================================================================");

	}

}
