package test.test1;

import org.apache.commons.codec.binary.Base32;
import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.component.grid.BaseGrid;
import com.bokesoft.yes.autotest.script.AbstractTestScript;



public class Case_DependValue_M1_002  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DependValue_M1_001

		MenuEntry.element("DependValue/CustomBill").click();
		MenuEntry.element("DependValue/CustomBill/Depend_001View").dblClick();	
//		新增：（M7_001a）必填组件不可见时报错
		System.out.println("============================================================");	
		ToolBarButton.element("新增").click();
		waittime(500);
		MainContainer.selectTab(1);
		AssertUtil.getAllErrorInfo("","测试用例Case_DependValue_M1_001——界面顶部显示红条");
		
		MainContainer.closeAllTab();		
		System.out.println("============================================================");
		
		
		
	}

}