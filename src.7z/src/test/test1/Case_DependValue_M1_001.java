package test.test1;

import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;



public class Case_DependValue_M1_001  extends AbstractTestScript{
	public void run(){
		//测试用例Case_DependValue_M1_001

		MenuEntry.element("DependValue/CustomBill").click();
		MenuEntry.element("DependValue/CustomBill/DV_M7_001aView").dblClick();	
//		新增：（M7_001a）必填组件不可见时报错
		System.out.println("============================================================");	
		ToolBarButton.element("新增").click();
		waittime(500);
		MainContainer.selectTab(1);
//勾选【不可见】,界面顶部显示"TextEditor2 is required"。
		CheckBox.element("CheckBox1").click();
		AssertUtil.getAllErrorInfo("TextEditor2 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'TextEditor2 is required'。");
//		AssertUtil.checkDisplayed(TextEditor.element("TextEditor2"), false, "测试用例Case_DependValue_M1_001");
//		String a1 = driver.findElement(By.xpath("//*[@id='2_main']/div[1]/label")).getText();
//		AssertUtil.check(a1, "TextEditor2 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'TextEditor2 is required'。");
//		勾销【不可见】
		CheckBox.element("CheckBox1").click();
//		[TextEditor2]存在必填标识——可见性依赖CheckBox
		AssertUtil.checkRequired(TextEditor.element("TextEditor2"), true, "测试用例Case_DependValue_M1_001");
//空白位置
		String dian1 = "//*[@id='2_TVisibleHeadTab1SubTab1']/table/tbody/tr[16]/td[2]";
		
//		必填字典不可见——可见性依赖TextEditor
		TextEditor.element("TextEditor3").input("1");
		driver.findElement(By.xpath(dian1)).click();
		waittime(500);
		AssertUtil.getAllErrorInfo("Dict1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'Dict1 is required'。");
//		String a2 = driver.findElement(By.xpath("//*[@id='2_main']/div[1]/label")).getText();
//		AssertUtil.check(a2, "Dict1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'Dict1 is required'。");
//		TextEditor1——可见性依赖TextEditor
		TextEditor.element("TextEditor3").click().clear();
		TextEditor.element("TextEditor3").input("2");
		driver.findElement(By.xpath(dian1)).click();
		AssertUtil.getAllErrorInfo( "TextEditor1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'TextEditor1 is required'。");
//		String a3 = driver.findElement(By.xpath("//*[@id='2_main']/div[1]/label")).getText();
//		AssertUtil.check(a3, "TextEditor1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'TextEditor1 is required'。");
//		NumberEditor1 ——可见性依赖TextEditor
		TextEditor.element("TextEditor3").click().clear();
		TextEditor.element("TextEditor3").input("3");
		driver.findElement(By.xpath(dian1)).click();
		AssertUtil.getAllErrorInfo( "NumberEditor1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'NumberEditor1 is required'。");
//		String a4 = driver.findElement(By.xpath("//*[@id='2_main']/div[1]/label")).getText();
//		AssertUtil.check(a4, "NumberEditor1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'NumberEditor1 is required'。");
//		界面顶部提示"ComboBox1 is required"——可见性依赖RadioButton
		TextEditor.element("TextEditor3").click().clear();
		RadioButton.element("RadioButton4").click();
//		String a5 = driver.findElement(By.xpath("//*[@id='2_main']/div[1]/label")).getText();
		AssertUtil.getAllErrorInfo("ComboBox1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'ComboBox1 is required'。");
//		AssertUtil.check(a5, "ComboBox1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'ComboBox1 is required'。");
//		界面顶部提示"ComboBox1 重现"——可见性依赖RadioButton
		RadioButton.element("RadioButton1").click();
		AssertUtil.checkDisplayed(ComboBox.element("ComboBox1"), true, "测试用例Case_DependValue_M1_001-8ComboBox1重现");
//		AssertUtil.getAllErrorInfo("","测试用例Case_DependValue_M1_001——顶部提示消失");

		//		DatePicker可见性依赖TextEditor
		TextEditor.element("TextEditor3").click().clear();
		TextEditor.element("TextEditor3").input("5");
		driver.findElement(By.xpath(dian1)).click();
//		String a6 = driver.findElement(By.xpath("//*[@id='2_main']/div[1]/label")).getText();
//		AssertUtil.check(a6, "DatePicker1 -必须填写-", "测试用例Case_DependValue_M1_001——界面顶部显示'DatePicker1 is required'。");
//		AssertUtil.checkDisplayed(ComboBox.element("DatePicker1"), false, "测试用例Case_DependValue_M1_001-DatePicker1不可见");
		AssertUtil.getAllErrorInfo("DatePicker1 -必须填写-","测试用例Case_DependValue_M1_001——弹框提示：CheckListBox1 不能为空。");

		//		CheckListBox可见性依赖TextEditor
		TextEditor.element("TextEditor3").click().clear();
		TextEditor.element("TextEditor3").input("6");
		driver.findElement(By.xpath(dian1)).click();
//		String a7 = driver.findElement(By.xpath("//*[@id='2_main']/div[1]/label")).getText();
//		AssertUtil.check(a7, "CheckListBox1 -必须填写-", "测试用例Case_DependValue_M1_001——CheckListBox1不可见。");
//		AssertUtil.checkDisplayed(ComboBox.element("CheckListBox1"), false, "测试用例Case_DependValue_M1_001-CheckListBox1不可见");
		AssertUtil.getAllErrorInfo("CheckListBox1 -必须填写-","测试用例Case_DependValue_M1_001——弹框提示：CheckListBox1 不能为空。");

		//      单击顶部提示，右侧"X"
		driver.findElement(By.xpath("//*[@id='2_main']/div[1]/span")).click();
//		[保存]会提示报错
		ToolBarButton.element("保存").click();	
		AssertUtil.showErrorDialog("CheckListBox1 -必须填写-");
//		关闭
		MainContainer.closeAllTab();		
		System.out.println("============================================================");
		
		
		
	}

}