package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_021 extends AbstractTestScript {
	public void run() {
		/*
		 * 加签多人顺序执行
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/BatchEndorseTask_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", true, "测试用例CASE_WorkFlow_M12_021");
		ListView.element("list").dbClick("单据编号", "BET_g20181023002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//点击启动流程
		ToolBar.element("ToolBar1").click("BatchEndorseTask_013_op1");//提交
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", true, "测试用例CASE_WorkFlow_M12_021");
		ListView.element("list").dbClick("单据编号", "BET_g20181023002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BatchEndorseTask_013_op1");//提交
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", true, "测试用例CASE_WorkFlow_M12_021");
		ListView.element("list").dbClick("单据编号", "BET_g20181023002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");//加签多人同时
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", false, "测试用例CASE_WorkFlow_M12_021");
		waittime(500);
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", false, "测试用例CASE_WorkFlow_M12_021");
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", true, "测试用例CASE_WorkFlow_M12_021");
		ListView.element("list").dbClick("单据编号", "BET_g20181023002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BatchEndorseTask_013_op1");//提交
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", true, "测试用例CASE_WorkFlow_M12_021");
		ListView.element("list").dbClick("单据编号", "BET_g20181023002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BatchEndorseTask_013_op1");//提交
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "BET_g20181023002", true, "测试用例CASE_WorkFlow_M12_021");
		ListView.element("list").dbClick("单据编号", "BET_g20181023002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BatchEndorseTask_013_op1");//提交
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}