package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M5_010 extends AbstractTestScript {
	public void run() {
		/*
		 * 审批节点撤销、创建、完成事件
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_004View").dblClick();
		MainContainer.selectTab(1);
		// 检查打开视图
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211010", true, "CASE_WorkFlow_M5_010");
		ListView.element("list").dbClick("单据编号", "SP_b20180211010", "", "");
		MainContainer.selectTab(2);
		// 点击启动流程
		ToolBar.element("ToolBar1").click("BPM");
		// 点击基本信息
		ToolBar.element("ToolBar1").click("operation3");
		ToolBar.element("ToolBar1").checkButtonExist("撤销已提交审批", true);// 检查“撤销已提交审批”存在
		ToolBar.element("ToolBar1").click("InverseState");// 点击“撤销已提交审批”
		ToolBar.element("ToolBar1").checkButtonExist("基本信息", true);
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "BBB", "CASE_WorkFlow_M5_010");// 检查文本框值为“BBB”
		// 点击基本信息
		ToolBar.element("ToolBar1").click("operation3");
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211010", true, "测试用例CASE_WorkFlow_M5_010");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211010", "", "");
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "AAA", "CASE_WorkFlow_M5_010");// 检查文本框值为“AAA”
		ToolBar.element("ToolBar1").click("operation1");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "CCC", "CASE_WorkFlow_M5_010");// 检查文本框值为“BBB”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211010", true, "测试用例CASE_WorkFlow_M5_010");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211010", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation6");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
	}
}
