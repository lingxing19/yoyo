package test.workflow;


import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M4_006 extends AbstractTestScript {

	public void run() {
		/*
		 * 会签节点创建、完成事件
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);//定位第一个页面
		//打开视图
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/HQThrough_003View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211002", true, "CASE_WorkFlow_M4_006");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211002", "", ""); 
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//启动流程
		ToolBar.element("ToolBar1").click("HQThrough_003_op1");//点击“提交1”
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "AAA", "CASE_WorkFlow_M4_006");//检查文本框值为“AAA”
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		//“我的待办事宜”打开单据HQ_a20180211002
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211002", true, "CASE_WorkFlow_M4_006");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "BBB", "CASE_WorkFlow_M4_006");//检查文本框值为“AAA”
		waittime(1000);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211002", true, "CASE_WorkFlow_M4_006");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211002", true, "CASE_WorkFlow_M4_006");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");//检查下拉框状态为“审批通过”
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
	}
}
