package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M5_017 extends AbstractTestScript{
	public void run(){
		/*
		 * 辅助会签任务加签,不隐藏父工作项
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_004View").dblClick();
		MainContainer.selectTab(1);
		//检查打开视图
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211002", true, "CASE_WorkFlow_M5_017");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211002", "", "");  
		MainContainer.selectTab(2);
		//点击启动流程
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("operation3");
		waittime(500);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211002", true, "CASE_WorkFlow_M5_017");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("启动辅助任务", true);
		ToolBar.element("ToolBar1").click("operation4");
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemCheckClick("user4 user4").itemCheckClick("user5 user5").itemCheckClick("user6 user6").dictButtonClick("确定");//字典下拉多选
		DictUtil.checkInputValue("Dict1", "user4 user4,user5 user5,user6 user6", "CASE_WorkFlow_M5_017");
		QueryBoxDialog.element().determineClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		MainContainer.selectTab(1);		
		logOut();
		
		doLogin("user6", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M5_017");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");//加签
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user7 user7");
		DictUtil.checkInputValue("Dict1","user7 user7", "");
		QueryBoxDialog.element().determineClick();//点击“确定”按钮
		waittime(1000);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		waittime(500);
		MainContainer.closeAllTab();
	
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", false, "CASE_WorkFlow_M5_017");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M5_017");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//辅助审批
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M5_017");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//辅助审批
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		GridUtil.checkCellValue("detail_grid", "操作员", 4, "user6 user6");
		GridUtil.checkCellValue("detail_grid", "工作项状态", 4, "已经完成");
//		GridUtil.checkCellValue("detail_grid", "操作员", 7, "user6 user6");
//		GridUtil.checkCellValue("detail_grid", "工作项状态", 7, "已经完成");
		QueryBoxDialog.element().close();
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211002", true, "CASE_WorkFlow_M5_017");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//提交2
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211002", true, "CASE_WorkFlow_M5_017");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation6");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
		System.out.println("--------------------------------------------------------------");
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_004View").dblClick();
		MainContainer.selectTab(1);
		//检查打开视图
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211003", true, "CASE_WorkFlow_M5_017");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211003", "", "");  
		MainContainer.selectTab(2);
		//点击启动流程
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("operation3");
		waittime(500);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211003", true, "CASE_WorkFlow_M5_017");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("启动辅助任务", true);
		ToolBar.element("ToolBar1").click("operation4");
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemCheckClick("user4 user4").itemCheckClick("user5 user5").itemCheckClick("user6 user6").dictButtonClick("确定");//字典下拉多选
		DictUtil.checkInputValue("Dict1", "user4 user4,user5 user5,user6 user6", "CASE_WorkFlow_M5_017");
		QueryBoxDialog.element().determineClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		MainContainer.selectTab(1);		
		logOut();
		
		doLogin("user6", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M5_017");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");//加签
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user7 user7");
		DictUtil.checkInputValue("Dict1","user7 user7", "");
		QueryBoxDialog.element().determineClick();//点击“确定”按钮
		waittime(1000);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		waittime(500);
	    MainContainer.closeAllTab();
		
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", false, "CASE_WorkFlow_M5_017");
		logOut();
		
		doLogin("user7", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M5_017");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//辅助通过
		logOut();
		
		doLogin("user6", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M5_017");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//辅助通过
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M5_017");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//辅助通过
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211003", true, "CASE_WorkFlow_M5_011");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//提交2
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211003", true, "CASE_WorkFlow_M5_011");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation6");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}
