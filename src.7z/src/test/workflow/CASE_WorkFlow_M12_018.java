package test.workflow;

import com.bokesoft.yes.autotest.component.factory.DictView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_018  extends AbstractTestScript {
	public void run() {
		/*
		 * 字典绑定流程
		 */
		doLogin("admin", "");
		waittime(7000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/DictBPM").dblClick();
		MainContainer.selectTab(1);
		DictView.element().itemClick("abc");
		ToolBar.element("main_toolbar").click("BPM");//启动流程
		ToolBar.element("main_toolbar").click("DictBPM_op1");//提交
		ToolBar.element("main_toolbar").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}