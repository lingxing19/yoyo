package test.workflow;

import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M2_008 extends AbstractTestScript {

	public void run() {
		/*分支审批选择节点驳回直送
		 * user1审批
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/FHNotThrough_001View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211008", true, "测试用例CASE_WorkFlow_M2_008");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211008", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("operation1");
		//ToolBar.element("ToolBar1").click("");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		/*
		 * user2审批
		 */
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211008", true, "测试用例CASE_WorkFlow_M2_008");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211008", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("FHNotThrough_001_op1");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		/*user3审批
		 * 不通过驳回
		 */
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211008", true, "测试用例CASE_WorkFlow_M2_008");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211008", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");
		logOut();

		/*user1查看驳回信息
		 * 直送
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211008", true, "测试用例CASE_WorkFlow_M2_008");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211008", "", "");
		MainContainer.selectTab(1);
		ToolBarButton.element("审批记录").click();
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		ToolBar.element("ToolBar1").click("operation1");
		DialogUtil.checkQueryBoxDialog();
		CheckBox.element("CheckBox1").click();
		CheckBoxUtil.checkChecked("CheckBox1", true, "测试用例FHNotThrough_001_2");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();

		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211008", true, "测试用例CASE_WorkFlow_M2_008");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211008", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();

		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211008", true, "测试用例CASE_WorkFlow_M2_008");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211008", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("FHNotThrough_001_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		System.out.println("==============================================================M2_008分支审批选择节点驳回直送");
	}

}

