package test.workflow;

import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M8_001 extends AbstractTestScript {

	public void run() {
		/*
		 * 用户超时自动通过
		 */
		System.out.println("================================超时机制启动流程");
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/YHTimeoutThrough_001View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "YH_c20180211001", true, "测试用例YHTimeoutThrough_001");	
		ListView.element("list").dbClick("单据编号", "YH_c20180211001", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		waittime(1000);
		MainContainer.closeAllTab();
		
		/*
		 * 审批超时自动通过
		 */
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/SPTimeoutThrough_002View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_c20180211001", true, "测试用例SPTimeoutThrough_002");	
		ListView.element("list").dbClick("单据编号", "SP_c20180211001", "", "");  
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BPM"); 
		waittime(1000);
		MainContainer.closeAllTab();
		
		/*
		 * 会签超时自动通过
		 */
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/HQTimeoutThrough_003View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_c20180211001", true, "测试用例HQTimeoutThrough_003");	
		ListView.element("list").dbClick("单据编号", "HQ_c20180211001", "", "");  
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BPM");
		waittime(1000);
		MainContainer.closeAllTab();
		
		/*
		 * 审批单次自动任务
		 */
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/SPTimeoutSingle_006View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_c20180211001", true, "测试用例SPTimeoutSingle_006");	
		ListView.element("list").dbClick("单据编号", "SP2_c20180211001", "", "");  
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BPM");
		waittime(1000);
		MainContainer.closeAllTab();
		logOut();
		/*
		 * 审批循环自动任务
		 */
//		MenuEntry.element("wf1/CustomBill").click();
//		MenuEntry.element("wf1/CustomBill/Timeout").click();
//		MenuEntry.element("wf1/CustomBill/Timeout/SPTimeoutCycle_007View").dblClick();
//		MainContainer.selectTab(0);
//		ListViewUtil.checkFormExsit("list", "单据编号", "SP3_c20180211001", true, "测试用例SPTimeoutCycle_007");	
//		ListView.element("list").dbClick("单据编号", "SP3_c20180211001", "", "");  
//		MainContainer.selectTab(1);
//		ToolBar.element("ToolBar1").click("BPM"); 
//		logOut();
//		waittime(1000);
		
		/*审批超时自动驳回
		 * user1审批
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/SPTimeoutReject_004View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP1_c20180211001", true, "测试用例SPTimeoutRejected_004");	
		ListView.element("list").dbClick("单据编号", "SP1_c20180211001", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("SPTimeoutRejected_005_op1");
		logOut();
		waittime(1000);
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP1_c20180211001", true, "测试用例SPTimeoutRejected_004");	
		ListView.element("list").dbClick("单据编号", "SP1_c20180211001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("SPTimeoutRejected_005_op1");
		logOut();
		waittime(1000);
		/*
		 * 会签自动驳回
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/HQTimeoutReject_005View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ1_c20180211001", true, "测试用例HQTimeoutRejectd_005");	
		ListView.element("list").dbClick("单据编号", "HQ1_c20180211001", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("HQTimeoutRejectd_005_op1");
		logOut();
		waittime(1000);
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ1_c20180211001", true, "测试用例HQTimeoutRejectd_005");	
		ListView.element("list").dbClick("单据编号", "HQ1_c20180211001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQTimeoutRejectd_005_op1");
		logOut();
		/*
		 * 辅助任务超时自动通过（#1308 2.0.2sp2）
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_004View").dblClick();
		MainContainer.selectTab(1);
		// 检查打开视图
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211015", true, "CASE_WorkFlow_M5_013");
		ListView.element("list").dbClick("单据编号", "SP_b20180211015", "", "");
		MainContainer.selectTab(2);
		// 点击启动流程
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("operation3");// 提交1
		logOut();

		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211015", true, "测试用例CASE_WorkFlow_M5_013");
		ListView.element("list").dbClick("单据编号", "SP_b20180211015", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");// 启动辅助审批
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user3 user3");
		DictUtil.checkInputValue("Dict1", "user3 user3", "");
		QueryBoxDialog.element().determineClick();// 点击“确定”按钮
		waittime(500);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		MainContainer.selectTab(1);
		logOut();

		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task1", true, "CASE_WorkFlow_M5_013");
		logOut();
		
//		/**
//		 * 超时代理结束时间
//		 */
//		doLogin("user1", "");
//		waittime(4000);
//		MainContainer.selectTab(0);
//		MenuEntry.element("Common/workflow").click();
//		MenuEntry.element("Common/workflow/NewItem").dblClick();
//		MainContainer.selectTab(1);
//		ToolBar.element("main_toolbar").click("Save");// 添加代理授权
//		DialogUtil.checkQueryBoxDialog();
//		ComboBox.element("delegateType").dropDownClick().itemClick("代理");
//		ComboBox.element("objectType").dropDownClick().itemClick("操作员");
//
//		// 代理操作员：下拉选择user4
//		Dict.element("tgtOperatorID").viewClick().itemClick("user4 user4");
//		DictUtil.checkInputValue("tgtOperatorID", "user4 user4", "");
//		// 结束时间为开始时间后10分钟
//		DatePicker.element("endTime").inputNextMinute().pressEnterKey();
//		// 源操作员：下拉选择user1
//		Dict.element("SrcOperatorID").viewClick().itemClick("user1 user1");
//		DictUtil.checkInputValue("SrcOperatorID", "user1 user1", "");
//		// Dict.element("Dict1").itemClick("user3 user3");
//		QueryBoxDialog.element().determineClick();
//
//		// 打开表单启动流程
//		MenuEntry.element("wf2/CustomBill2").click();
//		MenuEntry.element("wf2/CustomBill2/Agent").click();
//		MenuEntry.element("wf2/CustomBill2/Agent/SPAgent_012View").dblClick();
//		MainContainer.selectTab(2);
//		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426016", true, "测试用例CASE_WorkFlow_M11_017");
//		ListView.element("list").dbClick("单据编号", "Ag2_f20180426016", "", "");
//		MainContainer.selectTab(3);
//		ToolBar.element("ToolBar1").click("BPM");
//		MainContainer.closeAllTab();
//		// 待办检查视图存在
//		MenuEntry.element("Common/workflow").click();
//		MenuEntry.element("Common/workflow/ToDoList").dblClick();
//		MainContainer.selectTab(0);
//		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426016", false, "测试用例CASE_WorkFlow_M11_017");
//		logOut();
//
//		doLogin("user4", "");
//		waittime(4000);
//		MainContainer.selectTab(0);
//		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426016", true, "测试用例CASE_WorkFlow_M11_017");
//		logOut();

	}
}