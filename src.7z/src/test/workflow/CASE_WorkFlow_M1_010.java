package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M1_010 extends AbstractTestScript {

	public void run() {
		// 多人审批通过
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ManyApproval_010View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "MA_a20180211001", true, "测试用例CASE_WorkFlow_M1_011");
		ListView.element("list").dbClick("单据编号", "MA_a20180211001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("通过", true);
		ToolBar.element("ToolBar1").checkButtonExist("不通过", true);
		ToolBar.element("ToolBar1").click("ManyApproval_010_op1");
		waittime(1000);
		logOut();

		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MA_a20180211001", true, "测试用例CASE_WorkFlow_M1_011");
		ListView.element("list").dbClick("单据编号", "MA_a20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("通过", true);
		ToolBar.element("ToolBar1").checkButtonExist("不通过", true);
		ToolBar.element("ToolBar1").click("ManyApproval_010_op1");
		logOut();

		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MA_a20180211001", true, "测试用例CASE_WorkFlow_M1_011");
		ListView.element("list").dbClick("单据编号", "MA_a20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("通过", true);
		ToolBar.element("ToolBar1").checkButtonExist("不通过", true);
		ToolBar.element("ToolBar1").click("ManyApproval_010_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		System.out.println("========================================================M1_011多人审批通过");

		// 多人审批不通过
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ManyApproval_010View").dblClick();
		waittime(500);
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "MA_a20180211002", true, "测试用例CASE_WorkFlow_M1_012");
		ListView.element("list").dbClick("单据编号", "MA_a20180211002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("通过", true);
		ToolBar.element("ToolBar1").checkButtonExist("不通过", true);
		ToolBar.element("ToolBar1").click("ManyApproval_010_op1");
		waittime(1000);
		logOut();

		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MA_a20180211002", true, "测试用例CASE_WorkFlow_M1_012");
		ListView.element("list").dbClick("单据编号", "MA_a20180211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("通过", true);
		ToolBar.element("ToolBar1").checkButtonExist("不通过", true);
		ToolBar.element("ToolBar1").click("ManyApproval_010_op1");
		logOut();

		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MA_a20180211002", true, "测试用例CASE_WorkFlow_M1_012");
		ListView.element("list").dbClick("单据编号", "MA_a20180211002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("通过", true);
		ToolBar.element("ToolBar1").checkButtonExist("不通过", true);
		ToolBar.element("ToolBar1").click("operation1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批不通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		System.out.println("==========================================================M1_012多人审批不通过");
	}

}

