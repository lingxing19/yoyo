package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M4_008 extends AbstractTestScript{
	public void run(){
		/*
		 * 会签节点完成、成立 、通过：比例
		 * 审批通过
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/HQProportion_003View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426001", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426001", "", ""); 
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//启动流程
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		waittime(500);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426001", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426001", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
		/*
		 * 审批不通过
		 * 
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/HQProportion_003View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426002", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426002", "", ""); 
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//启动流程
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		waittime(1000);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426002", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426002", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426002", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426002", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//点击“否决”
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批不通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
		/*
		 * 审批不成立
		 * 
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/HQProportion_003View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426003", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426003", "", ""); 
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//启动流程
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426003", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426003", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At1_e20180426003", true, "CASE_WorkFlow_M4_008");	
		ListView.element("list").dbClick("单据编号", "At1_e20180426003", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");//点击“否决”
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批不成立", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}

}
