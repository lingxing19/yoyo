package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M9_001 extends AbstractTestScript{
	public void run(){
		/*
		 * 数据映射实例结束
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/MapEnd1_007View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "At2_e20180426001", true, "测试用例CASE_WorkFlow_M9_001");	
		ListView.element("list").dbClick("单据编号", "At2_e20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("main_toolbar").click("BPM");
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/MapEnd2_007View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At2_e20180426001", true, "测试用例CASE_WorkFlow_M9_001");	
		ListView.element("list").dbClick("单据编号", "At2_e20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("BPM");
//		ToolBar.element("ToolBar1").checkButtonExist("提交1", true);
		ToolBar.element("main_toolbar").click("MapDataSave_008_1_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		waittime(1000);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/MapEnd1_007View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At2_e20180426001", true, "测试用例CASE_WorkFlow_M1_007");	
		ListView.element("list").dbClick("单据编号", "At2_e20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").checkButtonExist("提交", true);
		ToolBar.element("main_toolbar").click("MapStartThrough_008_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("main_toolbar").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}

}
