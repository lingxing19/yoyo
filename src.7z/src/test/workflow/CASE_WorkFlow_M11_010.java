package test.workflow;

import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M11_010 extends AbstractTestScript {
	public void run() {
		/*
		 * 授权操作员 
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "代理编号", "6", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").ButtonClick("操作", 6);// 视图点击“启用”按钮
		// 打开表单启动流程
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Agent").click();
		MenuEntry.element("wf2/CustomBill2/Agent/SPAgent_012View").dblClick();
		MainContainer.selectTab(2);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426010", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426010", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("BPM");
		MainContainer.closeAllTab();
		// 待办检查视图存在
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426010", true, "测试用例CASE_WorkFlow_M11_010");
		logOut();

		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426010", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426010", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("SPAgent_012_op1");// 提交1
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426010", false, "测试用例CASE_WorkFlow_M11_010");
		logOut();

		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426010", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426010", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("SPAgent_012_op1");// 提交2
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "代理编号", "6", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").ButtonClick("操作", 6);// 视图点击“停用”按钮
		waittime(1000);
		logOut();

		/**
		 * 新增授权
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Save");// 添加代理授权
		DialogUtil.checkQueryBoxDialog();
		ComboBox.element("delegateType").dropDownClick().itemClick("授权");
		ComboBox.element("objectType").dropDownClick().itemClick("操作员");

		// 代理操作员：下拉选择user4
		Dict.element("tgtOperatorID").viewClick().itemClick("user4 user4");
		DictUtil.checkInputValue("tgtOperatorID", "user4 user4", "");
		// 勾选始终有效
		CheckBox.element("alwaysValid").click();
		CheckBoxUtil.checkChecked("alwaysValid", true, "测试用例CASE_WorkFlow_M1_001");
		// 源操作员：下拉选择user1
		Dict.element("SrcOperatorID").viewClick().itemClick("user1 user1");
		DictUtil.checkInputValue("SrcOperatorID", "user1 user1", "");
		// Dict.element("Dict1").itemClick("user3 user3");
		QueryBoxDialog.element().determineClick();
		// 打开表单启动流程
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Agent").click();
		MenuEntry.element("wf2/CustomBill2/Agent/SPAgent_012View").dblClick();
		MainContainer.selectTab(2);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426011", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426011", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("BPM");
		MainContainer.closeAllTab();
		// 待办检查视图存在
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426011", true, "测试用例CASE_WorkFlow_M11_010");
		logOut();

		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426011", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426011", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("SPAgent_012_op1");// 提交1
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426011", false, "测试用例CASE_WorkFlow_M11_010");
		logOut();

		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426011", true, "测试用例CASE_WorkFlow_M11_010");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426011", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("SPAgent_012_op1");// 提交2
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListView.element("list").ButtonClick("删除", 12);// 视图点击“删除”按钮	
		waittime(1000);
		logOut();
	}
}
