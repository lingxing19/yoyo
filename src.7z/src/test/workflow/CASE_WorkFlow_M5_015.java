package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M5_015 extends AbstractTestScript {

	public void run() {
		/*
		 * 静态驳回上一步 #1581 2.0.3sp1/10.29
		 * user1审批
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_006View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_b20181029001", true, "测试用例CASE_WorkFlow_M5_015");	
		ListView.element("list").dbClick("单据编号", "SP2_b20181029001", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("operation1");
		waittime(1000);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_b20181029001", true, "测试用例CASE_WorkFlow_M5_015");	
		ListView.element("list").dbClick("单据编号", "SP2_b20181029001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_b20181029001", true, "测试用例CASE_WorkFlow_M5_015");	
		ListView.element("list").dbClick("单据编号", "SP2_b20181029001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");//转交
		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
		Dict.element("Dict1").viewClick().itemClick("user4 user4");
		DictUtil.checkInputValue("Dict1","user4 user4", "");
		//ToolBar.element("ToolBar1").click("");
		QueryBoxDialog.element().determineClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_b20181029001", true, "测试用例CASE_WorkFlow_M5_015");	
		ListView.element("list").dbClick("单据编号", "SP2_b20181029001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");//驳回上一步
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_b20181029001", true, "CASE_WorkFlow_M5_015");	
		ListView.element("list").dbClick("单据编号", "SP2_b20181029001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//提交2
		waittime(500);
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_b20181029001", true, "CASE_WorkFlow_M5_015");	
		ListView.element("list").dbClick("单据编号", "SP2_b20181029001", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//提交3
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}
