package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_019 extends AbstractTestScript {
	public void run() {
		/*
		 * 管理员干预流程ManualTransferByWID
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Intervene_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010001", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("optKey3");//点击启动流程ManualTransferByWID
		ToolBar.element("ToolBar1").click("Intervene_013_op1");//提交
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010001", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("optKey1");//ManualTransferByWID
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		GridUtil.checkCellValue("detail_grid", "工作项的名称", 4, "审批任务1");
		GridUtil.checkCellValue("detail_grid", "工作项状态", 4, "尚未完成");
		waittime(1000);
		QueryBoxDialog.element().close();
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010001", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Intervene_013_op1");//提交
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010001", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Intervene_013_op1");//提交
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
		/*
		 * 管理员干预流程ManualTransferByNodeID()
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Intervene_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010002", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//点击启动流程ManualTransferByNodeID()
		ToolBar.element("ToolBar1").click("Intervene_013_op1");//提交
		waittime(500);
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Intervene_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010002", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("optKey2");//ManualTransferByNodeID()
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		GridUtil.checkCellValue("detail_grid", "工作项的名称", 4, "审批任务1");
		GridUtil.checkCellValue("detail_grid", "工作项状态", 4, "尚未完成");
		waittime(1000);
		QueryBoxDialog.element().close();
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010002", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Intervene_013_op1");//提交
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex15_g20181010002", true, "测试用例CASE_WorkFlow_M12_019");
		ListView.element("list").dbClick("单据编号", "Ex15_g20181010002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Intervene_013_op1");//提交
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
	}
}
