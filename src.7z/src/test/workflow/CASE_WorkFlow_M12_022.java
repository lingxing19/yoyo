package test.workflow;

import com.bokesoft.yes.autotest.common.util.CheckBoxUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.CheckListBox;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_022 extends AbstractTestScript{
	
	public void run(){
		/**
		 * BatchCommitWorkitemByWID3,三个参数
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/SPThrough_004View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122001", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		waittime(500);
		MainContainer.closeTab(2);
		waittime(500);
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122002", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		waittime(500);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension1").click();
		MenuEntry.element("wf2/CustomBill2/Extension1/batchcommitworkitembywid").dblClick();
		MainContainer.selectTab(0);
		CheckListBox.element("CheckListBox1").dropDownClick().itemClick("1","2").clickName("确定");
//		CheckListBox.element("CheckListBox1").dropDownClick().pressEnterKey();
		waittime(500);
		ToolBar.element("ToolBar1").click("BatchCommitWorkitemByWID3");
		waittime(500);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/SPThrough_004View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122001", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122001", "", "");
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(500);
		MainContainer.closeTab(1);
		waittime(500);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122002", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122002", "", "");
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(500);
		MainContainer.closeAllTab();
		logOut();
		
		/**
		 * BatchCommitWorkitemByWID4,四个参数
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/SPThrough_004View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122003", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122003", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		MainContainer.closeTab(2);
		waittime(500);
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122004", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122004", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		waittime(500);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension1").click();
		MenuEntry.element("wf2/CustomBill2/Extension1/batchcommitworkitembywid").dblClick();
		MainContainer.selectTab(0);
		Grid.element("detail").cellCheckboxClick("选择", 1);
		Grid.element("detail").cellCheckboxClick("选择", 2);
		waittime(500);
		ToolBar.element("ToolBar1").click("BatchCommitWorkitemByWID4");
		waittime(500);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/SPThrough_004View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122003", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122003", "", "");
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(500);
		MainContainer.closeTab(1);
		waittime(500);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20181122004", true, "测试用例CASE_WorkFlow_M12_022");
		ListView.element("list").dbClick("单据编号", "SP_a20181122004", "", "");
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}

}
