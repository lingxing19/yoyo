package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M5_009 extends AbstractTestScript {

	public void run() {
		/*审批选择节点转交驳回开始节点直送
		 * user1审批
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_004View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211009", true, "测试用例CASE_WorkFlow_M5_009");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211009", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("operation3");
		waittime(1000);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211009", true, "测试用例CASE_WorkFlow_M5_009");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211009", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("TransferTask");//转交
		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
		Dict.element("Dict1").viewClick().itemClick("user4 user4");
		DictUtil.checkInputValue("Dict1","user4 user4", "");
		//ToolBar.element("ToolBar1").click("");
		QueryBoxDialog.element().determineClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211009", true, "测试用例CASE_WorkFlow_M5_009");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211009", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation5");//驳回开始节点
		logOut();
		
		//user1直送1
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211009", true, "测试用例CASE_WorkFlow_M5_009");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211009", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		ToolBar.element("ToolBar1").click("optKey3");//直送
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211009", true, "测试用例CASE_WorkFlow_M5_009");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211009", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211009", true, "测试用例CASE_WorkFlow_M5_009");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211009", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation6");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		System.out.println("=============================================================M5_009审批选择节点驳回开始节点直送");
	}

}
