package test.workflow;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M1_009 extends AbstractTestScript {
	public void run() {
		/*
		 *  多人任务顺序
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ManyTasks1_009View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "MT1_a20180211001", true, "测试用例CASE_WorkFlow_M1_009");
		ListView.element("list").dbClick("单据编号", "MT1_a20180211001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("提交", true);
		ToolBar.element("ToolBar1").click("ManyTasks_op1");
		logOut();

		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MT1_a20180211001", true, "测试用例CASE_WorkFlow_M1_009");
		ListView.element("list").dbClick("单据编号", "MT1_a20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("提交", true);
		ToolBar.element("ToolBar1").click("ManyTasks_op1");
		logOut();

		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ManyTasks1_009View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "MT1_a20180211002", true, "测试用例CASE_WorkFlow_M1_009");
		ListView.element("list").dbClick("单据编号", "MT1_a20180211002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("提交", false);
		logOut();
		System.out.println("=======================================================M1_009多人任务顺序");
		
		// 多人任务逆序
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ManyTasks2_009View").dblClick();

		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "MT2_a20180211001", true, "测试用例CASE_WorkFlow_M1_010");
		ListView.element("list").dbClick("单据编号", "MT2_a20180211001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("提交", true);
		// AssertUtil.checkDisplayed((AbstractComponent)
		// ToolBarButton.element("提交"), true,"");
		ToolBar.element("ToolBar1").click("ManyTasks_op1");
		logOut();

		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MT2_a20180211001", true, "测试用例CASE_WorkFlow_M1_010");
		ListView.element("list").dbClick("单据编号", "MT2_a20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("提交", true);
		ToolBar.element("ToolBar1").click("ManyTasks_op1");
		waittime(1000);
		logOut();
		System.out.println("========================================================M1_010多人任务逆序");
	}

}

