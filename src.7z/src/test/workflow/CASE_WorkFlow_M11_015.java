package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M11_015 extends AbstractTestScript {
	public void run() {
		/*
		 * 代理两个节点（无参与者自动略个过）
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "代理编号", "10", true, "测试用例CASE_WorkFlow_M11_015");
		ListView.element("list").ButtonClick("操作", 10);// 视图点击“启用”按钮
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "代理编号", "11", true, "测试用例CASE_WorkFlow_M11_015");
		ListView.element("list").ButtonClick("操作", 11);// 视图点击“启用”按钮
		// 打开表单启动流程
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Agent").click();
		MenuEntry.element("wf2/CustomBill2/Agent/NoParticipants_012View").dblClick();
		MainContainer.selectTab(2);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag1_f20180426001", true, "测试用例CASE_WorkFlow_M11_015");
		ListView.element("list").dbClick("单据编号", "Ag1_f20180426001", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("BPM");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag1_f20180426001", false, "测试用例CASE_WorkFlow_M11_015");
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListView.element("list").ButtonClick("操作", 10);// 视图点击“停用”按钮
		waittime(1000);
		ListView.element("list").ButtonClick("操作", 11);
		waittime(1000);
		logOut();
	}
}
