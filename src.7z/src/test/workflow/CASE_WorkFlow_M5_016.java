package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M5_016 extends AbstractTestScript{
	public void run(){
		/*
		 * 辅助审批任务加签
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_004View").dblClick();
		MainContainer.selectTab(1);
		//检查打开视图
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211001", true, "CASE_WorkFlow_M5_016");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211001", "", "");  
		MainContainer.selectTab(2);
		//点击启动流程
		ToolBar.element("ToolBar1").click("BPM"); 
		waittime(500);
		ToolBar.element("ToolBar1").click("operation3");
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211001", true, "CASE_WorkFlow_M5_016");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("启动辅助审批", true);
		ToolBar.element("ToolBar1").click("operation2");
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user3 user3");
		DictUtil.checkInputValue("Dict1","user3 user3", "");
		QueryBoxDialog.element().determineClick();//点击“确定”按钮
		waittime(1000);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		MainContainer.selectTab(1);
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task1", true, "CASE_WorkFlow_M5_016");
		ListView.element("list").dbClick("工作项名称", "task1", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");//加签
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user4 user4");
		DictUtil.checkInputValue("Dict1","user4 user4", "");
		QueryBoxDialog.element().determineClick();//点击“确定”按钮
		waittime(1000);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		MainContainer.selectTab(1);
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task1", true, "CASE_WorkFlow_M5_016");
		ListView.element("list").dbClick("工作项名称", "task1", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//辅助审批
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task1", true, "CASE_WorkFlow_M5_016");
		ListView.element("list").dbClick("工作项名称", "task1", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//辅助审批
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211001", true, "CASE_WorkFlow_M5_016");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//提交2
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20181211001", true, "CASE_WorkFlow_M5_016");	
		ListView.element("list").dbClick("单据编号", "SP_b20181211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation6");//提交3
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}
