package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_017 extends AbstractTestScript {
	public void run() {
		/*
		 * 召回流程（#1390 2.0.2sp2）
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/SaveDoc_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426005", true, "测试用例CASE_WorkFlow_M12_017");
		ListView.element("list").dbClick("单据编号", "Ex4_g20180426005", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("召回流程", true);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		ToolBar.element("ToolBar1").click("RecallInstance");//点击召回流程按钮
		ToolBar.element("ToolBar1").checkButtonExist("启动流程", true);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "初始", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}
