package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M1_004 extends AbstractTestScript {
	public void run() {
		/*
		 * 审批任务通过
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/SPThrough_004View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_a20180211001", true, "测试用例CASE_WorkFlow_M1_004");
		ListView.element("list").dbClick("单据编号", "SP_a20180211001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("通过", true);
		ToolBar.element("ToolBar1").click("SPThrough_op1");
		ToolBar.element("ToolBar1").checkButtonExist("撤销", true);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		ToolBar.element("ToolBar1").click("InverseState");//点击撤销
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "EEE", "");
		logOut();
		System.out.println("==========================================================M1_004审批任务通过");
	}
}