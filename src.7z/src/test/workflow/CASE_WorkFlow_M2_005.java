package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.TabPanel;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M2_005  extends AbstractTestScript {

	public void run() {
		/*分支节点转办
		 * user1转办user5
		 */
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/FHNotThrough_001View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211005", true, "测试用例CASE_WorkFlow_M2_005");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211005", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("operation1");
		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
		waittime(1000);
		TabPanel.element("TabPanel1").selectTab(2);
		Dict.element("Dict2").viewClick();
		waittime(1000);
		Dict.element("Dict2").itemClick("user5 user5");
		DictUtil.checkInputValue("Dict2","user5 user5", "");
		//ToolBar.element("ToolBar1").click("");
		QueryBoxDialog.element().determineClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
	
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211005", true, "测试用例CASE_WorkFlow_M2_005");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211005", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211005", true, "测试用例CASE_WorkFlow_M2_005");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211005", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("FHNotThrough_001_op1");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211005", true, "测试用例CASE_WorkFlow_M2_005");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211005", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "FH_b20180211005", true, "测试用例CASE_WorkFlow_M2_005");	
		ListView.element("list").dbClick("单据编号", "FH_b20180211005", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("FHNotThrough_001_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		System.out.println("=============================================================M2_005分支节点转办");
	}

}
