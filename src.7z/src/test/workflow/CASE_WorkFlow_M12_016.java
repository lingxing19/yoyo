package test.workflow;

import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_016 extends AbstractTestScript{
	public void run() {
		/*
		 * 定义流程外任务
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_006View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_b20181102001", true, "测试用例CASE_WorkFlow_M12_016");	
		ListView.element("list").dbClick("单据编号", "SP2_b20181102001", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("operation3");
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user4 user4");
		DictUtil.checkInputValue("Dict1", "user4 user4", "");
		QueryBoxDialog.element().determineClick();// 点击“确定”按钮
		waittime(500);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("operation2");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task1", true, "测试用例CASE_WorkFlow_M12_016");	
		ListView.element("list").dbClick("工作项名称", "task1", "", "");  
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
		GridUtil.checkCellValue("detail_grid", "工作项的名称", 3, "task1");
		GridUtil.checkCellValue("detail_grid", "工作项状态", 3, "已经完成");
		QueryBoxDialog.element().close();
		logOut();
	
	}
}
