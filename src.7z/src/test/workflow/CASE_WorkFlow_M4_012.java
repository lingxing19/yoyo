package test.workflow;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M4_012 extends AbstractTestScript{
	public void run(){
		/*
		 * 驳回审批节点不可直送
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/HQNotThrough_003View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211008", true, "CASE_WorkFlow_M4_012");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211008", "", ""); 
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//启动流程
		ToolBar.element("ToolBar1").click("operation3");
		waittime(1000);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211008", true, "CASE_WorkFlow_M4_012");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211008", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQNotThrough_003_op1");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211008", true, "CASE_WorkFlow_M4_012");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211008", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation5");//点击“驳回不可直送”
		logOut();
		
		//驳回不可直送，后续工作项被锁定
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211008", false, "CASE_WorkFlow_M4_012");	
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211008", false, "CASE_WorkFlow_M4_012");	
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211008", true, "CASE_WorkFlow_M4_012");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211008", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");//点击“直送”
		ErrorDialog.element().close();
		logOut();
		
		
	}
}
