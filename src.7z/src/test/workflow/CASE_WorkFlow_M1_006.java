package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M1_006 extends AbstractTestScript{
	public void run() {
		/*
		 * 子流程通过
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ZLCThrough1_006View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "ZLC1_a20180211001", true, "测试用例CASE_WorkFlow_M1_006");	
		ListView.element("list").dbClick("单据编号", "ZLC1_a20180211001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").checkButtonExist("提交1", true);
		ToolBar.element("ToolBar1").click("ZLCThrough_009_op1");
		waittime(1000);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ZLCThrough2_006View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "ZLC1_a20180211001", true, "测试用例CASE_WorkFlow_M1_006");	
		ListView.element("list").dbClick("单据编号", "ZLC1_a20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("提交", true);
		ToolBar.element("ToolBar1").click("ZLCThrough_009_1_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		MainContainer.closeAllTab();

		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ZLCThrough1_006View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "ZLC1_a20180211001", true, "测试用例CASE_WorkFlow_M1_006");	
		ListView.element("list").dbClick("单据编号", "ZLC1_a20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("提交2", true);
		ToolBar.element("ToolBar1").click("ZLCThrough_009_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(1000);
		logOut();
		System.out.println("==========================================================M1_006子流程通过");
	}

}
