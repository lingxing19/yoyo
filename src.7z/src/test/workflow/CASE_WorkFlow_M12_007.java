package test.workflow;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_007 extends AbstractTestScript {
	public void run() {
		/*
		 * 提交保存
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/SaveDoc_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426001", true, "测试用例CASE_WorkFlow_M12_007");
		ListView.element("list").dbClick("单据编号", "Ex4_g20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("Edit");
		TextEditor.element("T_Memo").input("1111");
		ToolBar.element("ToolBar1").click("SaveDoc_013_op1");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "1111", "");
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426001", true, "测试用例CASE_WorkFlow_M12_007");
		ListView.element("list").dbClick("单据编号", "Ex4_g20180426001", "", "");
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "1111", "");
		logOut();
	}

}
