package test.workflow;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.LabelUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M10_002 extends AbstractTestScript {
	public void run() {
		/*
		 * 流程节点权限叠加
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/permissions_011View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "At4_e20180426002", true, "测试用例CASE_WorkFlow_M10_002");
		ListView.element("list").dbClick("单据编号", "At4_e20180426002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		MainContainer.closeAllTab();

		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/permissions_011View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At4_e20180426002", true, "测试用例CASE_WorkFlow_M10_002");
		ListView.element("list").dbClick("单据编号", "At4_e20180426002", "", "");
		MainContainer.selectTab(1);
		// 工具栏操作1不可见
		ToolBar.element("ToolBar1").checkButtonExist("操作1", false);
		// 头控件1文本、2数值不可见
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor1"), false, "");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor1"), false, "");
		// 明细表13字典、14按钮不可见
		GridUtil.checkGridHidColName("detail", "序号选择11数值12文本");

		ToolBar.element("ToolBar1").click("Permissions_011_op1");// 提交
		// 操作2：不可见
		ToolBar.element("ToolBar1").checkButtonExist("操作2", false);
		// 3日期、4图片：不可见
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker1"), false, "");
		AssertUtil.checkDisplayed(Dict.element("Dict1"), false, "");
		// 11数值、12文本：不可见
		GridUtil.checkGridHidColName("detail", "序号选择13字典14按钮");

		ToolBar.element("ToolBar1").click("Permissions_011_op1");// 提交
		// 检查操作1、操作2可用
		ToolBar.element("ToolBar1").checkButtonExist("操作1", true);
		ToolBar.element("ToolBar1").click("opt1");
		LabelUtil.checkInputValue(Label.element("Label1"), "1", "");
		ToolBar.element("ToolBar1").checkButtonExist("操作2", true);
		ToolBar.element("ToolBar1").click("opt2");
		LabelUtil.checkInputValue(Label.element("Label1"), "2", "");
		// 头控件全可见
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor1"), true, "");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor1"), true, "");
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker1"), true, "");
		AssertUtil.checkDisplayed(Dict.element("Dict1"), true, "");
		// 头控件不可用
		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor1"), false, "");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker1"), false, "");
		AssertUtil.checkEnabled(Dict.element("Dict1"), false, "");
		// 明细表全可见
		// GridUtil.checkGridRowValue("detail", 1, "null20.00nullnullnull");
		GridUtil.checkGridHidColName("detail", "序号选择11数值12文本13字典14按钮");
		// 明细单元格不可用
		// GridUtil.checkGridEnabled("detail", false);
		GridUtil.checkCellEnabled("detail", "11数值", 1, false);
		GridUtil.checkCellEnabled("detail", "12文本", 1, false);
		GridUtil.checkCellEnabled("detail", "13字典", 1, false);
		GridUtil.checkCellEnabled("detail", "14按钮", 1, false);

		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Attribute").click();
		MenuEntry.element("wf2/CustomBill2/Attribute/permissions_011View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "At4_e20180426002", true, "测试用例CASE_WorkFlow_M10_002");
		ListView.element("list").dbClick("单据编号", "At4_e20180426002", "", "");
		MainContainer.selectTab(1);
		// 检查操作1、操作2可用
		ToolBar.element("ToolBar1").checkButtonExist("操作1", true);
		ToolBar.element("ToolBar1").click("opt1");
		LabelUtil.checkInputValue(Label.element("Label1"), "1", "");
		ToolBar.element("ToolBar1").checkButtonExist("操作2", true);
		ToolBar.element("ToolBar1").click("opt2");
		LabelUtil.checkInputValue(Label.element("Label1"), "2", "");
		// 头控件全可见
		AssertUtil.checkDisplayed(TextEditor.element("TextEditor1"), true, "");
		AssertUtil.checkDisplayed(NumberEditor.element("NumberEditor1"), true, "");
		AssertUtil.checkDisplayed(DatePicker.element("DatePicker1"), true, "");
		AssertUtil.checkDisplayed(Dict.element("Dict1"), true, "");
		// 头控件不可用
		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), false, "");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor1"), false, "");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker1"), false, "");
		AssertUtil.checkEnabled(Dict.element("Dict1"), false, "");
		// 明细表全可见
		// GridUtil.checkGridRowValue("detail", 1, "null20.00nullnullnull");
		GridUtil.checkGridHidColName("detail", "序号选择11数值12文本13字典14按钮");
		// 明细单元格不可用
		// GridUtil.checkGridEnabled("detail", false);
		GridUtil.checkCellEnabled("detail", "11数值", 1, false);
		GridUtil.checkCellEnabled("detail", "12文本", 1, false);
		GridUtil.checkCellEnabled("detail", "13字典", 1, false);
		GridUtil.checkCellEnabled("detail", "14按钮", 1, false);

		ToolBar.element("ToolBar1").click("Edit");
		// 检查操作1、操作2可用
		ToolBar.element("ToolBar1").checkButtonExist("操作1", true);
		ToolBar.element("ToolBar1").click("opt1");
		LabelUtil.checkInputValue(Label.element("Label1"), "1", "");
		ToolBar.element("ToolBar1").checkButtonExist("操作2", true);
		ToolBar.element("ToolBar1").click("opt2");
		LabelUtil.checkInputValue(Label.element("Label1"), "2", "");
		// 头控件全可用
		AssertUtil.checkEnabled(TextEditor.element("TextEditor1"), true, "");
		AssertUtil.checkEnabled(NumberEditor.element("NumberEditor1"), true, "");
		AssertUtil.checkEnabled(DatePicker.element("DatePicker1"), true, "");
		AssertUtil.checkEnabled(Dict.element("Dict1"), true, "");
		//明细单元格全可用
		GridUtil.checkCellEnabled("detail", "11数值", 1, true);
		GridUtil.checkCellEnabled("detail", "12文本", 1, true);
		GridUtil.checkCellEnabled("detail", "13字典", 1, true);
		GridUtil.checkCellEnabled("detail", "14按钮", 1, true);
		logOut();

	}

}
