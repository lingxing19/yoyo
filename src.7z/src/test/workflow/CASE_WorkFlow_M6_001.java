package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M6_001 extends AbstractTestScript {

	public void run() {
		/*选择节点不通过
		 * user1审批
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/XZNotThrough_005View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "XZ_b20180211001", true, "测试用例CASE_WorkFlow_M6_001");	
		ListView.element("list").dbClick("单据编号", "XZ_b20180211001", "", "");  
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").click("XZNotThrough_005_op1");
		//ToolBar.element("ToolBar1").click("");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "XZ_b20180211001", true, "测试用例CASE_WorkFlow_M6_001");	
		ListView.element("list").dbClick("单据编号", "XZ_b20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("XZNotThrough_005_op1");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		/*user3审批
		 * 不通过驳回
		 */
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "XZ_b20180211001", true, "测试用例CASE_WorkFlow_M6_001");	
		ListView.element("list").dbClick("单据编号", "XZ_b20180211001", "", "");
		MainContainer.selectTab(1);
		//基本信息
		ToolBar.element("ToolBar1").click("XZNotThrough_005_op1");
		waittime(1000);
		DialogUtil.checkQueryBoxDialog();
		ComboBox.element("ComboBox1").dropDownClick();
		ComboBox.element("ComboBox1").itemClick("审批任务1");
		QueryBoxDialog.element().rejectedClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "XZ_b20180211001", true, "测试用例CASE_WorkFlow_M6_001");	
		ListView.element("list").dbClick("单据编号", "XZ_b20180211001", "", "");
		ToolBarButton.element("审批记录").click();
		ScreenShot.takeScreenShot(driver);
		//waittime(1000);
		QueryBoxDialog.element().close();
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("XZNotThrough_005_op1");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "XZ_b20180211001", true, "测试用例CASE_WorkFlow_M6_001");	
		ListView.element("list").dbClick("单据编号", "XZ_b20180211001", "", "");
		waittime(1000);
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("XZNotThrough_005_op1");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "XZ_b20180211001", true, "测试用例CASE_WorkFlow_M6_001");	
		ListView.element("list").dbClick("单据编号", "XZ_b20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("XZNotThrough_005_op1");
		QueryBoxDialog.element().ThroughClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		System.out.println("===============================================================M6_001选择节点驳回");
	}

}
