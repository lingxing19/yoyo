package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_003 extends AbstractTestScript {

	public void run() {
		/*
		 * 审批嵌套
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Nested_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "任务1", "");
		waittime(1000);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "任务2", "");
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例FHNotThrough_001_1");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("no");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "驳回", "");
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "任务1", "");
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "任务3", "");
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("yes");
		TextEditorUtil.checkInputValue(TextEditor.element("T_Memo"), "审批", "");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		/*
		 * 撤销他人操作（函数）
		 */
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		Grid.element("detail_grid").cellButtonClick("撤销(他人)", 1);//任务4撤销（他人）
		waittime(1000);
		QueryBoxDialog.element().close();
		waittime(1000);
		MainContainer.closeAllTab();
//		waittime(1000);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		Grid.element("detail_grid").cellButtonClick("撤销(他人)", 2);//审批撤销（他人）
		waittime(1000);
		QueryBoxDialog.element().close();
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
//		MenuEntry.element("Common/workflow").click();
//		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Nested_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		Grid.element("detail_grid").cellButtonClick("撤销(他人)", 3);//任务1撤销（他人）
		waittime(1000);
		QueryBoxDialog.element().close();
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("yes");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Nested_013_op1");
		logOut();
		
		/*
		 * 撤销本人操作
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Nested_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		Grid.element("detail_grid").cellButtonClick("撤销（本人）", 2);//审批撤销本人
		waittime(1000);
		ErrorDialog.element().close();
		QueryBoxDialog.element().close();
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Nested_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		Grid.element("detail_grid").cellButtonClick("撤销（本人）", 1);//任务4撤销本人
		waittime(1000);
		QueryBoxDialog.element().close();
		waittime(1000);
		MainContainer.closeAllTab();
		//查看待办
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		ListView.element("list").dbClick("单据编号", "Ex2_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		Grid.element("detail_grid").cellButtonClick("撤销（本人）", 2);//任务4撤销本人
		waittime(1000);
		QueryBoxDialog.element().close();
		
		//查看待办
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex2_g20180426001", true, "测试用例CASE_WorkFlow_M12_003");	
		logOut();
	}
}
