package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M4_007 extends AbstractTestScript{
	public void run(){
		/*
		 * 会签节点辅助任务
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/HQThrough_003View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211003", true, "CASE_WorkFlow_M4_007");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211003", "", ""); 
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//启动流程
		ToolBar.element("ToolBar1").click("HQThrough_003_op1");//点击“提交1”
		waittime(1000);
		logOut();
		
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		//“我的待办事宜”打开单据HQ_a20180211003
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211003", true, "CASE_WorkFlow_M4_007");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("启动辅助审批", true);//检查工具按钮“启动辅助审批”存在
		ToolBar.element("ToolBar1").click("operation3");//点击“启动辅助审批”
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user4 user4");
		DictUtil.checkInputValue("Dict1","user4 user4", "");
		QueryBoxDialog.element().determineClick();//点击“确定”按钮
		waittime(1000);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		MainContainer.selectTab(1);
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task1", true, "CASE_WorkFlow_M4_007");
		ListView.element("list").dbClick("工作项名称", "task1", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("辅助审批", true);//检查工具按钮“辅助审批”存在
		ToolBar.element("ToolBar1").click("operation1");//点击“辅助审批”
		logOut();
		
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		//“我的待办事宜”打开单据HQ_a20180211003
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211003", true, "CASE_WorkFlow_M4_007");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("启动辅助任务", true);//检查工具按钮“启动辅助任务”存在
		ToolBar.element("ToolBar1").click("operation4");//点击“启动辅助任务”
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemClick("user4 user4");
		DictUtil.checkInputValue("Dict1","user4 user4", "");
		QueryBoxDialog.element().determineClick();//点击“确定”按钮
		waittime(1000);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		MainContainer.selectTab(1);
//		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task2", true, "CASE_WorkFlow_M4_007");
		ListView.element("list").dbClick("工作项名称", "task2", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("辅助任务", true);//检查工具按钮“辅助任务”存在
		ToolBar.element("ToolBar1").click("operation1");//点击“辅助任务”
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211003", true, "CASE_WorkFlow_M4_007");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//提交
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		//“我的待办事宜”打开单据HQ_a20180211003
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211003", true, "CASE_WorkFlow_M4_007");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("启动辅助会签", true);//检查工具按钮“启动辅助会签”存在
		ToolBar.element("ToolBar1").click("operation5");//点击“启动辅助会签”
		DialogUtil.checkQueryBoxDialog();
		Dict.element("Dict1").viewClick();
		Dict.element("Dict1").itemCheckClick("user4 user4").itemCheckClick("user5 user5").itemCheckClick("user6 user6").dictButtonClick("确定");//字典下拉多选
		DictUtil.checkInputValue("Dict1", "user4 user4,user5 user5,user6 user6", "CASE_WorkFlow_M4_007");
		QueryBoxDialog.element().determineClick();//点击“确定”按钮
		waittime(1000);
		ConfirmDialog.element().yesClick();//点击“是”按钮
		MainContainer.selectTab(1);
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M4_007");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("辅助通过", true);//检查工具按钮“辅助通过”存在
		ToolBar.element("ToolBar1").click("operation1");//点击“辅助高铁”
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task3", true, "CASE_WorkFlow_M4_007");
		ListView.element("list").dbClick("工作项名称", "task3", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("辅助通过", true);//检查工具按钮“辅助通过”存在
		ToolBar.element("ToolBar1").click("operation1");//点击“辅助通过”
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		//“我的待办事宜”打开单据HQ_a20180211003
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211003", true, "CASE_WorkFlow_M4_007");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		//“我的待办事宜”打开单据HQ_a20180211003
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_a20180211003", true, "CASE_WorkFlow_M4_007");	
		ListView.element("list").dbClick("单据编号", "HQ_a20180211003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		}
}
