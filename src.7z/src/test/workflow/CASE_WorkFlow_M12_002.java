package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_002 extends AbstractTestScript {

	public void run() {
		/*
		 * 流程迁移
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/Migration_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex1_g20180426001", true, "测试用例CASE_WorkFlow_M12_002");
		ListView.element("list").dbClick("单据编号", "Ex1_g20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("Edit");
		Button.element("Button1").click();
		waittime(500);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "a", "测试用例CASE_WorkFlow_M12_002");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "b", "测试用例CASE_WorkFlow_M12_002");
		NumberEditorUtil.checkInputValue(NumberEditor.element("NumberEditor1"), "500", "测试用例CASE_WorkFlow_M12_002");
		ToolBar.element("ToolBar1").click("Save");
		waittime(1000);
		String[][] expTable = { { "Ex1_g20180426001", "0", "a", "b", "500" } };

		DataBaseUtil.checkDataMatch("SELECT NO, Status, TextEditor1, TextEditor2, NumberEditor1 FROM Migration_013Head",
				expTable, "测试用例CASE_WorkFlow_M12_002");
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("WF_MG_001_op1");
		 DialogUtil.checkQueryBoxDialog();
		QueryBoxDialog.element().ThroughClick();
		MainContainer.selectTab(2);
		ComboBoxUtil.checkInputValue(ComboBox.element("Status"), "审批通过", "");
		String[][] expTable1 = { {"a", "b", "500" } };

		DataBaseUtil.checkDataMatch("SELECT TextEditor1, TextEditor2, NumberEditor1 FROM WFMigration_013Head WHERE oid > -1",
				expTable1, "测试用例CASE_WorkFlow_M12_002");
		
		ToolBar.element("ToolBar1").click("Delete");
		
		String[][] expTable2 = {};

		DataBaseUtil.checkDataMatch("SELECT TextEditor1, TextEditor2, NumberEditor1 FROM Migration_013Head",
				expTable2, "测试用例CASE_WorkFlow_M12_002");
		logOut();
	}

}
