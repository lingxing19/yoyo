package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.DictUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M5_012 extends AbstractTestScript{
	public void run(){
		/*
		 * 审批选择节点驳回开始节点转交
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/SPNotThrough_004View").dblClick();
		MainContainer.selectTab(1);
		//检查打开视图
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", "");  
		MainContainer.selectTab(2);
		//点击启动流程
		ToolBar.element("ToolBar1").click("BPM"); 
		ToolBar.element("ToolBar1").checkButtonExist("提交1", true);
		ToolBar.element("ToolBar1").click("operation3");//提交1
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("提交2", true);
		ToolBar.element("ToolBar1").click("operation1");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("驳回开始节点", true);
		ToolBar.element("ToolBar1").click("operation5");//点击驳回开始节点
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
		GridUtil.checkCellValue("detail_grid", "工作项的名称", 5, "开始节点");//新增任务1
		GridUtil.checkCellValue("detail_grid", "工作项状态", 5, "尚未完成");//尚未完成
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("TransferTask");//转交
		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
		Dict.element("Dict1").viewClick().itemClick("user2 user2");
		DictUtil.checkInputValue("Dict1","user2 user2", "");
		//ToolBar.element("ToolBar1").click("");
		QueryBoxDialog.element().determineClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BPM"); 
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");//提交1 
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");//提交2 
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211014", true, "CASE_WorkFlow_M5_012");	
		ListView.element("list").dbClick("单据编号", "SP_b20180211014", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation6");//提交3 
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}
