package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.LabelUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Label;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_008 extends AbstractTestScript {
	public void run() {
		/*
		 * 界面公式
		 */
		doLogin("user1", "");
		waittime(7000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/SaveDoc_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426002", true, "测试用例CASE_WorkFlow_M12_008");
		ListView.element("list").dbClick("单据编号", "Ex4_g20180426002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("operation5");
		ToolBar.element("ToolBar1").click("operation6");
		ToolBar.element("ToolBar1").click("operation7");
		LabelUtil.checkInputValue(Label.element("Label1"), "1", "");
		LabelUtil.checkInputValue(Label.element("Label2"), "1", "");
		LabelUtil.checkInputValue(Label.element("Label3"), "SaveDoc_013", "");
		ToolBar.element("ToolBar1").click("operation8");
		DialogUtil.checkQueryBoxDialog();
		Button.element("Button1").click();
		Button.element("Button2").click();
		Button.element("Button3").click();
		waittime(1000);
		LabelUtil.checkInputValue(Label.element("Label1"), "1", "");
		LabelUtil.checkInputValue(Label.element("Label2"), "1", "");
		LabelUtil.checkInputValue(Label.element("Label3"), "SaveDoc_013", "");
		waittime(1000);
		QueryBoxDialog.element().close();
		waittime(500);
		ConfirmDialog.element().yesClick();
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("operation1");//暂停
		ToolBar.element("ToolBar1").click("SaveDoc_013_op1");//提交1
		ErrorDialog.element().close();
		ToolBar.element("ToolBar1").click("operation2");//恢复
		ToolBar.element("ToolBar1").click("SaveDoc_013_op1");//提交1
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批中", "");
		ToolBar.element("ToolBar1").click("InverseState");//撤销已提交审批
		ToolBar.element("ToolBar1").click("operation3");//结束
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		GridUtil.checkCellValue("detail_grid", "流程状态", 1, "已结束");//任务1为完成
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").checkButtonExist("复活", true);//检查复活按钮
		ToolBar.element("ToolBar1").click("ReviveInstance");//复活
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
		GridUtil.checkCellValue("detail_grid", "工作项状态", 2, "尚未完成");//任务1未完成
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(500);
		MainContainer.closeAllTab();
		
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426002", true, "测试用例CASE_WorkFlow_M12_008");
		ListView.element("list").dbClick("单据编号", "Ex4_g20180426002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");//结束
//		GridUtil.checkCellValue("detail_grid", "流程状态", 1, "已结束");//任务1为完成
	    MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("重启流程", true);//检查重启流程按钮
		ToolBar.element("ToolBar1").click("RestartInstance");//重启流程
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();
//		GridUtil.checkCellValue("detail_grid", "工作项状态", 2, "尚未完成");//任务1未完成
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(500);
		MainContainer.closeAllTab();
		
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426002", true, "测试用例CASE_WorkFlow_M12_008");
		MainContainer.closeTab(0);
		//终止流程
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/SaveDoc_013View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426003", true, "测试用例CASE_WorkFlow_M12_008");
		ListView.element("list").dbClick("单据编号", "Ex4_g20180426003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("operation4");//终止
		waittime(500);
		MainContainer.closeAllTab();
		
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex4_g20180426003", false, "测试用例CASE_WorkFlow_M12_008");
		logOut();
		waittime(1000);
	}

}
