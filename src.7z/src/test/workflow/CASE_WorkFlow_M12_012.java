package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_012 extends AbstractTestScript {
	public void run() {
		/*
		 * 同一个单据启动不同流程
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/WF_001View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex6_g20180426003", true, "测试用例CASE_WorkFlow_M12_012");
		ListView.element("list").dbClick("单据编号", "Ex6_g20180426003", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("WF_001_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(1000);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/WF_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex6_g20180426004", true, "测试用例CASE_WorkFlow_M12_012");
		ListView.element("list").dbClick("单据编号", "Ex6_g20180426004", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Start002");
		ToolBar.element("ToolBar1").click("WF_002_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		waittime(1000);
		MainContainer.closeAllTab();
		
		//启动流程StartInstance();processKey为空
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/WF_009View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex14_g20180426001", true, "测试用例CASE_WorkFlow_M12_012");
		ListView.element("list").dbClick("单据编号", "Ex14_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Start009");
		ToolBar.element("ToolBar1").click("WF_001_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		logOut();
	}
}
