package test.workflow;


import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M8_002 extends AbstractTestScript {

	public void run() {
		/*
		 * 用户超时自动通过
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/YHTimeoutThrough_001View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "YH_c20180211001", true, "测试用例YHTimeoutThrough_001");
		ListView.element("list").dbClick("单据编号", "YH_c20180211001", "", "");
		MainContainer.selectTab(2);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		MainContainer.closeAllTab();
		/*
		 * 审批超时自动通过
		 */
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/SPTimeoutThrough_002View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP_c20180211001", true, "测试用例SPTimeoutThrough_002");
		ListView.element("list").dbClick("单据编号", "SP_c20180211001", "", "");
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		MainContainer.closeAllTab();

		/*
		 * 会签超时自动通过
		 */
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Timeout").click();
		MenuEntry.element("wf1/CustomBill/Timeout/HQTimeoutThrough_003View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_c20180211001", true, "测试用例HQTimeoutThrough_003");
		ListView.element("list").dbClick("单据编号", "HQ_c20180211001", "", "");
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		MainContainer.closeAllTab();

		/*
		 * 审批单次自动任务
		 */
		
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP2_c20180211001", true, "测试用例SPTimeoutSingle_006");
		ListView.element("list").dbClick("单据编号", "SP2_c20180211001", "", "");
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("Count"), "1", "");
		MainContainer.closeAllTab();
		logOut();
		/*
		 * 审批循环自动任务
		 */
//		MenuEntry.element("Common/workflow").click();
//		MenuEntry.element("Common/workflow/ToDoList").dblClick();
//		MainContainer.selectTab(0);
//		ListViewUtil.checkFormExsit("list", "单据编号", "SP3_c20180211001", true, "测试用例SPTimeoutCycle_007");
//		ListView.element("list").dbClick("单据编号", "SP3_c20180211001", "", "");
//		MainContainer.selectTab(1);
//		TextEditorUtil.checkInputValue(TextEditor.element("Count"), "3", "");
		// ComboBoxUtil.checkInputValue(ComboBox.element("Count"), "1", "");
//		logOut();

		/*
		 * 审批超时自动驳回 
		 * user1直送
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP1_c20180211001", true, "测试用例SPTimeoutRejected_004");
		ListView.element("list").dbClick("单据编号", "SP1_c20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		ToolBar.element("ToolBar1").click("operation1");
		logOut();

		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "SP1_c20180211001", true, "测试用例SPTimeoutRejected_004");
		ListView.element("list").dbClick("单据编号", "SP1_c20180211001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("SPTimeoutRejected_005_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
		/*
		 * 会签自动驳回
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ1_c20180211001", true, "测试用例HQTimeoutRejectd_005");	
		ListView.element("list").dbClick("单据编号", "HQ1_c20180211001", "", ""); 
		MainContainer.selectTab(1);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "初始", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
		
		/*
		 * 辅助任务超时自动通过
		 */
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "工作项名称", "task1", false, "CASE_WorkFlow_M5_013");
//		MainContainer.selectTab(0);
//		// 检查打开视图
//		ListViewUtil.checkFormExsit("list", "单据编号", "SP_b20180211015", true, "CASE_WorkFlow_M5_013");
//		ListView.element("list").dbClick("单据编号", "SP_b20180211015", "", "");
//		MainContainer.selectTab(1);
//		ToolBar.element("ToolBar1").click("operation6");// 提交3
//		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
//		ToolBar.element("ToolBar1").click("ShowAuditDetil");
//		ScreenShot.takeScreenShot(driver);
//		QueryBoxDialog.element().close();
		logOut();
		
//		/*
//		 * 查看代理超时时间审批项
//		 */
//		doLogin("user1", "");
//		waittime(4000);
//		MainContainer.selectTab(0);
//		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426016", true, "测试用例CASE_WorkFlow_M11_017");
//		logOut();
//
//		doLogin("user4", "");
//		waittime(4000);
//		MainContainer.selectTab(0);
//		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426016", false, "测试用例CASE_WorkFlow_M11_017");
//		logOut();
//
//		doLogin("user1", "");
//		waittime(4000);
//		MainContainer.selectTab(0);
//		MenuEntry.element("Common/workflow").click();
//		MenuEntry.element("Common/workflow/NewItem").dblClick();
//		MainContainer.selectTab(1);
//		ListView.element("list").ButtonClick("删除", 12);// 视图点击“停用”按钮
//		waittime(1000);
//		logOut();
	}
}
