package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Button;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_010 extends AbstractTestScript {
	public void run() {
		/*
		 * 分配任务，取消任务
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/TaskAllocation_013View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", true, "测试用例CASE_WorkFlow_M12_010");
		ListView.element("list").dbClick("单据编号", "Ex5_g20180426001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		waittime(1000);
		MainContainer.closeAllTab();
		//检查单据不存在
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", false, "测试用例CASE_WorkFlow_M12_010");
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", false, "测试用例CASE_WorkFlow_M12_010");
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", false, "测试用例CASE_WorkFlow_M12_010");
		//分配任务给user1
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension1").click();
		MenuEntry.element("wf2/CustomBill2/Extension1/DistributeView").dblClick();
		MainContainer.selectTab(1);
		ComboBox.element("processKey").dropDownClick().itemClick("TaskAllocation_013");
		Button.element("Button1").click();
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "操作员", "Admin 系统管理员", true, "测试用例CASE_WorkFlow_M12_010");
		ListViewUtil.checkFormExsit("ListView1", "操作员", "user1 user1", true, "测试用例CASE_WorkFlow_M12_010");
		ListViewUtil.checkFormExsit("ListView1", "操作员", "user2 user2", true, "测试用例CASE_WorkFlow_M12_010");
		ListView.element("ListView1").ButtonClick("操作", 2);// 视图点击“分配”按钮
		waittime(1000);
		logOut();
		
		//user1查看分配存在
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", true, "测试用例CASE_WorkFlow_M12_010");
		//取消分配任务
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension1").click();
		MenuEntry.element("wf2/CustomBill2/Extension1/DistributeView").dblClick();
		MainContainer.selectTab(1);
		ComboBox.element("processKey").dropDownClick().itemClick("TaskAllocation_013");
		Button.element("Button1").click();
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "操作员", "Admin 系统管理员", true, "测试用例CASE_WorkFlow_M12_010");
		ListViewUtil.checkFormExsit("ListView1", "操作员", "user1 user1", true, "测试用例CASE_WorkFlow_M12_010");
		ListViewUtil.checkFormExsit("ListView1", "操作员", "user2 user2", true, "测试用例CASE_WorkFlow_M12_010");
		ListView.element("ListView1").ButtonClick("操作", 2);// 视图点击“取消分配”按钮
		waittime(1000);
		MainContainer.closeAllTab();
		
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/ToDoList").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", false, "测试用例CASE_WorkFlow_M12_010");
		MainContainer.closeTab(0);
		
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension1").click();
		MenuEntry.element("wf2/CustomBill2/Extension1/DistributeView").dblClick();
		MainContainer.selectTab(0);
		ComboBox.element("processKey").dropDownClick().itemClick("TaskAllocation_013");
		Button.element("Button1").click();
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "操作员", "Admin 系统管理员", true, "测试用例CASE_WorkFlow_M12_010");
		ListViewUtil.checkFormExsit("ListView1", "操作员", "user1 user1", true, "测试用例CASE_WorkFlow_M12_010");
		ListViewUtil.checkFormExsit("ListView1", "操作员", "user2 user2", true, "测试用例CASE_WorkFlow_M12_010");
		ListView.element("ListView1").ButtonClick("操作", 1);// 视图点击“分配”按钮
		waittime(1000);
		logOut();
		
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", true, "测试用例CASE_WorkFlow_M12_010");
		ListView.element("list").dbClick("单据编号", "Ex5_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("TaskAllocation_013_op1");
		logOut();
		
		/**
		 * 抢占任务
		 */
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", true, "测试用例CASE_WorkFlow_M12_011");
		ListView.element("list").dbClick("单据编号", "Ex5_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation1");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", false, "测试用例CASE_WorkFlow_M12_010");
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", false, "测试用例CASE_WorkFlow_M12_010");
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", true, "测试用例CASE_WorkFlow_M12_011");
		ListView.element("list").dbClick("单据编号", "Ex5_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", true, "测试用例CASE_WorkFlow_M12_011");
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex5_g20180426001", true, "测试用例CASE_WorkFlow_M12_011");
		ListView.element("list").dbClick("单据编号", "Ex5_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("TaskAllocation_013_op1");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}

}
