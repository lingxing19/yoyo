package test.workflow;

import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M4_010 extends AbstractTestScript{
	public void run(){
		/*
		 * 多人驳回审批节点直送撤销直送
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/NotThrough").click();
		MenuEntry.element("wf1/CustomBill/NotThrough/HQNotThrough_003View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", ""); 
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");//启动流程
		ToolBar.element("ToolBar1").click("operation3");
		waittime(1000);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQNotThrough_003_op1");//点击“提交”
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "测试用例CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", "");
		MainContainer.selectTab(1);
		//基本信息
		ToolBar.element("ToolBar1").click("operation4");
		waittime(2000);
		DialogUtil.checkQueryBoxDialog();
		ComboBox.element("ComboBox1").dropDownClick();
		ComboBox.element("ComboBox1").itemClick("任务1");
		QueryBoxDialog.element().rejectedClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "测试用例CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", "");
		MainContainer.selectTab(1);
		//基本信息
		ToolBar.element("ToolBar1").click("operation4");
		waittime(1000);
		DialogUtil.checkQueryBoxDialog();
		ComboBox.element("ComboBox1").dropDownClick();
		ComboBox.element("ComboBox1").itemClick("任务1");
		QueryBoxDialog.element().rejectedClick();
		waittime(1000);
		ConfirmDialog.element().yesClick();
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", ""); 
		MainContainer.selectTab(1);
//		ToolBar.element("ToolBar1").checkButtonExist("驳回", true);
//		ToolBar.element("ToolBar1").click("operation5");//点击驳回
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
		GridUtil.checkCellValue("detail_grid", "工作项的名称", 7, "任务1");//新增任务1
		GridUtil.checkCellValue("detail_grid", "工作项状态", 7, "尚未完成");//尚未完成
		QueryBoxDialog.element().close();
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation2");//点击直送
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
//		DialogUtil.checkQueryBoxDialog();//基本信息弹出框
//		GridUtil.checkCellValue("detail_grid", "操作员", 5, "user3 user3");//user3任务
//		GridUtil.checkCellValue("detail_grid", "工作项状态", 5, "尚未完成");//尚未完成
//		GridUtil.checkCellValue("detail_grid", "操作员", 3, "user4 user4");//user4任务
//		GridUtil.checkCellValue("detail_grid", "工作项状态", 3, "尚未完成");//尚未完成
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
//		ToolBar.element("ToolBar1").click("InverseState");//撤销
//		ToolBar.element("ToolBar1").click("operation2");//直送
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "HQ_b20180211006", true, "CASE_WorkFlow_M4_010");	
		ListView.element("list").dbClick("单据编号", "HQ_b20180211006", "", ""); 
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("HQThrough_011_op1");//点击“提交”
		logOut();
		
	}
}
