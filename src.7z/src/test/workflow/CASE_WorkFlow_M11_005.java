package test.workflow;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M11_005 extends AbstractTestScript {
	public void run() {
		/*
		 * 代理转办
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "代理编号", "1", true, "测试用例CASE_WorkFlow_M11_005");
		ListView.element("list").ButtonClick("操作", 1);// 视图点击“启用”按钮
		ListViewUtil.checkFormExsit("list", "代理编号", "5", true, "测试用例CASE_WorkFlow_M11_005");
		ListView.element("list").ButtonClick("操作", 5);// 视图点击“启用”按钮
		// 打开表单启动流程
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Agent").click();
		MenuEntry.element("wf2/CustomBill2/Agent/SPAgent_012View").dblClick();
		MainContainer.selectTab(2);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426006", true, "测试用例CASE_WorkFlow_M11_005");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426006", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("BPM");
		waittime(1000);
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426006", true, "测试用例CASE_WorkFlow_M11_005");
		ListView.element("list").dbClick("单据编号", "Ag2_f20180426006", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("SPAgent_012_op1");// 提交1
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ag2_f20180426006", false, "测试用例CASE_WorkFlow_M11_005");
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListView.element("list").ButtonClick("操作", 1);// 视图点击“停用”按钮
		waittime(1000);
		ListView.element("list").ButtonClick("操作", 5);
		waittime(1000);
		logOut();
	}
}
