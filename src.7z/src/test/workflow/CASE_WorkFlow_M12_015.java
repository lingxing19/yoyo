package test.workflow;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M12_015 extends AbstractTestScript {

	public void run() {
		/*
		 * 根据条件返回多个用户可审批
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/WF_007View").dblClick();
		MainContainer.selectTab(1);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(2);
		TextEditor.element("T_BillNO").input("WF_007");
		NumberEditor.element("Numb1").input("500");
		waittime(1000);
//		Grid.element("Grid1").cellInput("入库数量", 1, "500");
		Grid.element("Grid1").cellDbInput("入库数量", 1, "500");
		
		ToolBar.element("ToolBar1").click("Save");
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("WF_007_op1");
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "WF_007", true, "测试用例CASE_WorkFlow_M12_015");
		ListView.element("list").dbClick("单据编号", "WF_007", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("审批", true);
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "WF_007", true, "测试用例CASE_WorkFlow_M12_015");
		ListView.element("list").dbClick("单据编号", "WF_007", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").checkButtonExist("审批", true);
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "WF_007", false, "测试用例CASE_WorkFlow_M12_015");
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "WF_007", false, "测试用例CASE_WorkFlow_M12_015");
		logOut();
	}

}
