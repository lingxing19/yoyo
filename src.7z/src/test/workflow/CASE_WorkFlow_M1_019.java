package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M1_019 extends AbstractTestScript {

	public void run() {
		/*
		 * 多人审批顺序新增参与者insert
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf1/CustomBill").click();
		MenuEntry.element("wf1/CustomBill/Through").click();
		MenuEntry.element("wf1/CustomBill/Through/ManyApprovalOrderView").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "MAO_a20181012001", true, "测试用例CASE_WorkFlow_M1_019");
		ListView.element("list").dbClick("单据编号", "MAO_a20181012001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("ManyApprovalOrder_op1");//提交
		logOut();
		
		doLogin("user2", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MAO_a20181012001", true, "测试用例CASE_WorkFlow_M1_019");
		ListView.element("list").dbClick("单据编号", "MAO_a20181012001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("operation3");//insert中间插入参与者
		ToolBar.element("ToolBar1").click("ManyApprovalOrder_op1");//提交
		logOut();
		
		doLogin("user6", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MAO_a20181012001", true, "测试用例CASE_WorkFlow_M1_019");
		ListView.element("list").dbClick("单据编号", "MAO_a20181012001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ManyApprovalOrder_op1");//提交
		logOut();
		
		doLogin("user7", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MAO_a20181012001", true, "测试用例CASE_WorkFlow_M1_019");
		ListView.element("list").dbClick("单据编号", "MAO_a20181012001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ManyApprovalOrder_op1");//提交
		waittime(500);
		logOut();
		
		doLogin("user3", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MAO_a20181012001", true, "测试用例CASE_WorkFlow_M1_019");
		ListView.element("list").dbClick("单据编号", "MAO_a20181012001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ManyApprovalOrder_op1");//提交
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MAO_a20181012001", true, "测试用例CASE_WorkFlow_M1_019");
		ListView.element("list").dbClick("单据编号", "MAO_a20181012001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ManyApprovalOrder_op1");//提交
		logOut();
		
		doLogin("user5", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "MAO_a20181012001", true, "测试用例CASE_WorkFlow_M1_019");
		ListView.element("list").dbClick("单据编号", "MAO_a20181012001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ManyApprovalOrder_op1");//提交
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		ToolBar.element("ToolBar1").click("ShowAuditDetil");
		ScreenShot.takeScreenShot(driver);
		QueryBoxDialog.element().close();
		logOut();
	}
}
