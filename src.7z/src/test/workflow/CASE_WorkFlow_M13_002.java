package test.workflow;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M13_002 extends AbstractTestScript{
	public void run(){
		/*
		 * 手动配对节点（二开）
		 */
		doLogin("admin", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Second").click();
		MenuEntry.element("wf2/CustomBill2/Second/ManualMatching_014View").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "单据编号", "Se1_h20180504001", true, "测试用例CASE_WorkFlow_M13_002");
		ListView.element("list").dbClick("单据编号", "Se1_h20180504001", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("Edit");//编辑
		NumberEditor.element("Join").input("14");
		ToolBar.element("ToolBar1").click("Save");//保存
		ToolBar.element("ToolBar1").click("ManualMatchingNode_014_op1");//提交
		NumberEditorUtil.checkInputValue(NumberEditor.element("Fork"), "2", "");
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf2/CustomBill2/Second").click();
		MenuEntry.element("wf2/CustomBill2/Second/ManualMatching_014View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Se1_h20180504002", true, "测试用例CASE_WorkFlow_M13_002");
		ListView.element("list").dbClick("单据编号", "Se1_h20180504002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("BPM");
		ToolBar.element("ToolBar1").click("Edit");//编辑
		NumberEditor.element("Join").input("38");
		ToolBar.element("ToolBar1").click("Save");//保存
		ToolBar.element("ToolBar1").click("ManualMatchingNode_014_op1");//提交
		NumberEditorUtil.checkInputValue(NumberEditor.element("Fork"), "37", "");
		logOut();
		
		
	}

}
