package test.workflow;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenShot {
	
	public static void takeScreenShot(WebDriver driver){
		
		File screenShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        //截屏图片保存到路径以及取名
		try{
			FileUtils.copyFile(screenShotFile, new File("screenshot/" + getDataPath() + "/" + getCurrentDateTime() + ".jpg"));
        //以图片当前时间为名称保存到当前日期的目录下
		}catch(IOException e){
			e.printStackTrace();
        //I/O异常处理			
		}
	}
	public static String getCurrentDateTime(){
        //得到当前时间
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss");
        //格式化日期，精确到秒
		return df.format(new Date());	
	}
	
	public static File getDataPath(){
        //得到当前日期，格式的路径
		Date date = new Date();
		String path = new SimpleDateFormat("yyyyMMdd").format(date);
        //格式化日期精确到天
		File f = new File(path);
        //创建以当前日期为名称的文件夹
		return f;
		
	}

} 
