package test.workflow;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_WorkFlow_M11_014 extends AbstractTestScript {
	public void run() {
		/*
		 * 一个表单两个流程
		 */
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "代理编号", "1", true, "测试用例CASE_WorkFlow_M11_014");
		ListView.element("list").ButtonClick("操作", 1);// 视图点击“启用”按钮
		// 打开表单启动流程
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/WF_001View").dblClick();
		MainContainer.selectTab(2);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex6_g20180426001", true, "测试用例CASE_WorkFlow_M11_014");
		ListView.element("list").dbClick("单据编号", "Ex6_g20180426001", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("BPM");//启动启动WF_001
		waittime(1000);
		MainContainer.closeAllTab();
		
		MenuEntry.element("wf2/CustomBill2").click();
		MenuEntry.element("wf2/CustomBill2/Extension").click();
		MenuEntry.element("wf2/CustomBill2/Extension/WF_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex6_g20180426002", true, "测试用例CASE_WorkFlow_M11_014");
		ListView.element("list").dbClick("单据编号", "Ex6_g20180426002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("Start002");//启动WF_002
		waittime(1000);
		logOut();
		
		doLogin("user4", "");
		waittime(4000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex6_g20180426001", true, "测试用例CASE_WorkFlow_M11_014");
		ListView.element("list").dbClick("单据编号", "Ex6_g20180426001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("WF_001_op1");//点击【提交（WF_001）】
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		MainContainer.closeTab(1);
		waittime(1000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "Ex6_g20180426002", true, "测试用例CASE_WorkFlow_M11_014");
		ListView.element("list").dbClick("单据编号", "Ex6_g20180426002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("WF_002_op1");//点击【提交（WF_001）】
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过", "");
		logOut();
		
		doLogin("user1", "");
		waittime(4000);
		MainContainer.selectTab(0);
		MenuEntry.element("Common/workflow").click();
		MenuEntry.element("Common/workflow/NewItem").dblClick();
		MainContainer.selectTab(1);
		ListViewUtil.checkFormExsit("list", "代理编号", "1", true, "测试用例CASE_WorkFlow_M11_014");
		ListView.element("list").ButtonClick("操作", 1);// 视图点击“停用”按钮
		waittime(1000);
		logOut();
	}
}
