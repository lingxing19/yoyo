package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M1_009 extends AbstractTestScript {
	
	public void run(){
		//允许数据迁移过程更改分组字段的值 
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/Stock_02View").dblClick();
		MainContainer.selectTab(0);
		//检查是否存在“单据编号”是“STOCK_0220180807000001”的表单
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCK_0220180807000001", true, "测试用例Case_DataMig_M1_009");		
		ListView.element("list").dbClick("单据编号", "STOCK_0220180807000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		//点击【状态转换】后，查看数据库
		String[][] expTable = {
				{"-1", "-1.00"},
				{"10771", "100.00"},
			};		
		DataBaseUtil.checkDataMatch("select Material, Qty from stock02", expTable, "测试用例Case_DataMig_M1_009");
		System.out.println("============================================================");
		//检查是否存在“单据编号”是“STOCK_0220180807000002”的表单
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCK_0220180807000002", true, "测试用例Case_DataMig_M1_009");		
		ListView.element("list").dbClick("单据编号", "STOCK_0220180807000002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		//点击【状态转换】后，查看数据库
		String[][] expTable2 = {
				{"-1", "-1.00"},
				{"10771", "150.00"},
			};		
		DataBaseUtil.checkDataMatch("select Material, Qty from stock02", expTable2, "测试用例Case_DataMig_M1_009");
		System.out.println("============================================================");
		//更改分组字段值
		ToolBar.element("ToolBar1").click("Edit");
		Grid.element("Grid1").celDictClick("物料", 1).dictItemClick("2 手机");
		ToolBar.element("ToolBar1").click("Save");
		waittime(1000);
		//点击【保存】后，查看数据库
		String[][] expTable3 = {
				{"-1", "-1.00"},
				{"10771", "100.00"},
				{"10772", "50.00"},
			};		
		DataBaseUtil.checkDataMatch("select Material, Qty from stock02", expTable3, "测试用例Case_DataMig_M1_009");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		
		
	}

}
