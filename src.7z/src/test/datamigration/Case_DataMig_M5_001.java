package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M5_001 extends AbstractTestScript{
	
	public void run(){
		
		//期间结转指定分组执行
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_From03AView").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FROM03A20180507000001", true, "测试用例Case_DataMig_M5_001");	
		ListView.element("list").dbClick("单据编号", "DMIG_FROM03A20180507000001", "", "");
		MainContainer.selectTab(1);
		//点击【状态转换】
		ToolBar.element("ToolBar1").click("ConvertStatus");
		waittime(1000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FROM03A20180507000002", true, "测试用例Case_DataMig_M5_001");	
		ListView.element("list").dbClick("单据编号", "DMIG_FROM03A20180507000002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FROM03A20180507000003", true, "测试用例Case_DataMig_M5_001");	
		ListView.element("list").dbClick("单据编号", "DMIG_FROM03A20180507000003", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FROM03A20180507000004", true, "测试用例Case_DataMig_M5_001");	
		ListView.element("list").dbClick("单据编号", "DMIG_FROM03A20180507000004", "", "");
		MainContainer.selectTab(4);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		String[][] expTable = {
				{"-1", "-1", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10771", "201803", "0.00", "100.00", "100.00", "0.00", "100.00"},	
				{"10771", "201804", "0.00", "10.00", "10.00", "0.00", "10.00"},
				{"10772", "201804", "0.00", "200.00", "200.00", "0.00", "200.00"},
				{"10771", "201805", "0.00", "20.00", "20.00", "0.00", "20.00"},			
		};
		DataBaseUtil.checkDataMatch("SELECT Material, Out_DatePicker, In_Amount, Out_Amount, Amount, A1, A2 FROM DMig_TG03", expTable, "测试用例Case_DataMig_M5_001");
		System.out.println("============================================================");
		//点击【期间月结转】，查看数据库
		ToolBar.element("ToolBar1").click("RollData1");
		waittime(1000);
		String[][] expTable2 = {
				{"-1", "-1", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10771", "201803", "0.00", "100.00", "100.00", "0.00", "100.00"},
				{"10771", "201804", "0.00", "10.00", "10.00", "100.00", "110.00"},
				{"10772", "201804", "0.00", "200.00", "200.00", "0.00", "200.00"},
				{"10771", "201805", "0.00", "20.00", "20.00", "0.00", "20.00"},
					
		};
		DataBaseUtil.checkDataMatch("SELECT Material, Out_DatePicker, In_Amount, Out_Amount, Amount, A1, A2 FROM DMig_TG03", expTable2, "测试用例Case_DataMig_M5_001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
