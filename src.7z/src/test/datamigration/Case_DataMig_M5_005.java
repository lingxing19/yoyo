package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M5_005 extends AbstractTestScript {

	public void run() {

		// 期间结转（策略）
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form03_3View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM03_320181102000001", true, "测试用例Case_DataMig_M5_005");
		ListView.element("list").dbClick("单据编号", "DMIG_FORM03_320181102000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus");// 状态转换
		waittime(1000);
		String[][] expTable = {
				{ "10771", "2018-10-30 00:00:00.000", "99.00", "99.00", "0.00", "0.00", "0.00", "0.00" }, };
		DataBaseUtil.checkDataMatch(
				"SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, Amount_begin, Amount_end FROM DMig_Form03_3_Obj1_delta",
				expTable, "测试用例Case_DataMig_M5_005");
		System.out.println("============================================================");

		// 点击【期间日结转（策略）】，查看数据库查看数据库DMig_Form03_3_Obj1_delta
		ToolBar.element("ToolBar1").click("RollData3");// 期间日结转
		waittime(1000);
		String[][] expTable1 = {};
		DataBaseUtil.checkDataMatch(
				"SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, Amount_begin, Amount_end FROM DMig_Form03_3_Obj1_delta",
				expTable1, "测试用例Case_DataMig_M5_005");
		System.out.println("============================================================");
		
		// 点击【期间日结转（策略）】，带条件查看数据库查看数据库DMig_Form03_3_Obj1
		waittime(1000);
		String[][] expTable2 = {
				{ "10771", "2018-10-30 00:00:00.000", "99.00", "99.00", "0.00", "99.00", "0.00", "99.00"},
				{ "10771", "2018-10-31 00:00:00.000", "0.00", "0.00", "99.00", "99.00", "99.00", "99.00"},};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, "
				+ "Amount_begin, Amount_end FROM  DMig_Form03_3_Obj1 WHERE BillDate IN"
				+ "('2018-10-30 00:00:00.000','2018-10-31 00:00:00.000')", expTable2, "测试用例Case_DataMig_M5_005");
		MainContainer.closeAllTab();
		System.out.println("============================================================");

		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form03_3View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM03_320181102000002", true, "测试用例Case_DataMig_M5_005");
		ListView.element("list").dbClick("单据编号", "DMIG_FORM03_320181102000002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus"); // 状态转换
		waittime(1000);
		String[][] expTable3 = {
				{ "10771", "2018-10-31 00:00:00.000", "100.00", "100.00", "0.00", "0.00", "0.00", "0.00"},};
		DataBaseUtil.checkDataMatch(
				"SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, Amount_begin, Amount_end FROM DMig_Form03_3_Obj1_delta",
				expTable3, "测试用例Case_DataMig_M5_005");
		System.out.println("============================================================");

		// 点击【期间日结转（策略）】，查看数据库查看数据库DMig_Form03_3_Obj1_delta
		ToolBar.element("ToolBar1").click("RollData3");
		waittime(1000);
		String[][] expTable4 = {};
		DataBaseUtil.checkDataMatch(
				"SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, Amount_begin, Amount_end FROM DMig_Form03_3_Obj1_delta",
				expTable4, "测试用例Case_DataMig_M5_005");
		System.out.println("============================================================");

		// 点击【期间日结转（策略）】，带条件查看数据库查看数据库DMig_Form03_3_Obj1
		waittime(1000);
		String[][] expTable5 = {
				{ "10771", "2018-10-30 00:00:00.000", "99.00", "99.00", "0.00", "99.00", "0.00", "99.00"},
				{ "10771", "2018-10-31 00:00:00.000", "100.00", "100.00", "99.00", "199.00", "99.00", "199.00"},
				{ "10771", "2018-11-01 00:00:00.000", "0.00", "0.00", "199.00", "199.00", "199.00", "199.00"},};
		DataBaseUtil.checkDataMatch(
				"SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, "
						+ "Amount_begin, Amount_end FROM DMig_Form03_3_Obj1 WHERE BillDate IN"
						+ "('2018-10-30 00:00:00.000','2018-10-31 00:00:00.000','2018-11-01 00:00:00.000')",
				expTable5, "测试用例Case_DataMig_M5_005");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
	}
}
