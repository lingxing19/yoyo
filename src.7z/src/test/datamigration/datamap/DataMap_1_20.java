package test.datamap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_20 extends AbstractTestScript {
	
	public void run() {
		
		//M1用例编号_CASE_DM_M1_050
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/Src_FD1View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		TextEditor.element("TextEditor2").input("10011102");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "10011102", "测试用例CASE_DM_M1_050");
		TextEditor.element("TextEditor1").dbClick().input("A2");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "A2", "测试用例CASE_DM_M1_050");
		ComboBox.element("ComboBox2").dropDownClick().itemClick("无关注+无推送");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox2"), "无关注+无推送", "测试用例CASE_DM_M1_050");
		Grid.element("Grid1").cellDbInput("文本", 1, "a");
		Grid.element("Grid1").celComboClick("下拉框", 1).comboItemClick("初始");
		Grid.element("Grid1").celDictClick("字典", 1).dictItemClick("user1 user1");
		Grid.element("Grid1").cellDbInput("数值", 1, "223").pressTabKey();
		Grid.element("Grid1").cellClick("反填", 1);
		GridUtil.checkGridRowValue("Grid1", 1, "nulla初始user1 user1223.00null");
		Grid.element("Grid1").cellDbInput("文本", 2, "b");
		Grid.element("Grid1").celComboClick("下拉框", 2).comboItemClick("初始");
		Grid.element("Grid1").celDictClick("字典", 2).dictItemClick("user1 user1");
		Grid.element("Grid1").cellDbInput("数值", 2, "223").pressTabKey();
		Grid.element("Grid1").cellClick("反填", 1);
		GridUtil.checkGridRowValue("Grid1", 2, "nullb初始user1 user1223.00null");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单7");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("list", "文本1", "A2", 0, "测试用例CASE_DM_M1_050");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单7");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "10011102", true, "测试用例CASE_DM_M1_050");
		ListView.element("list").dbClick("单据编号", "10011102", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		Grid.element("Grid1").cellDbInput("文本", 3, "c");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单7");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("list", "文本1", "A2", 1, "测试用例CASE_DM_M1_050");
		ListView.element("list").dbClick();
		MainContainer.selectTab(3);
		GridUtil.checkCellValue("Grid1", "文本", 1, "c");
		ToolBar.element("main_toolbar").click("Edit1");
		Grid.element("Grid1").cellClick("行复制", 1);
		GridUtil.checkCellValue("Grid1", "文本", 1, "c");
		GridUtil.checkCellValue("Grid1", "文本", 2, "value1");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单7");
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		TextEditor.element("TextEditor2").input("10011103");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "10011103", "测试用例CASE_DM_M1_050");
		TextEditor.element("TextEditor1").dbClick().input("A3");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "A3", "测试用例CASE_DM_M1_050");
		ComboBox.element("ComboBox2").dropDownClick().itemClick("无关注+推送");
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox2"), "无关注+推送", "测试用例CASE_DM_M1_050");
		Grid.element("Grid1").cellDbInput("文本", 1, "a");
		Grid.element("Grid1").celComboClick("下拉框", 1).comboItemClick("初始");
		Grid.element("Grid1").celDictClick("字典", 1).dictItemClick("user1 user1");
		Grid.element("Grid1").cellDbInput("数值", 1, "223").pressTabKey();
		Grid.element("Grid1").cellClick("反填", 1);
		GridUtil.checkGridRowValue("Grid1", 1, "nulla初始user1 user1223.00null");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单7");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("list", "文本1", "A3", 1, "测试用例CASE_DM_M1_050");
		ListView.element("list").dbClick();
		MainContainer.selectTab(3);
		ToolBar.element("main_toolbar").click("Edit1");
		Grid.element("Grid1").cellClick("行复制", 1);
		GridUtil.checkCellValue("Grid1", "文本", 1, "a");
		GridUtil.checkCellValue("Grid1", "数值", 1, "223.00");
		GridUtil.checkCellValue("Grid1", "文本", 2, "value1");
		GridUtil.checkCellValue("Grid1", "数值", 2, "223.00");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
