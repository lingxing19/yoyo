package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_001 extends AbstractTestScript {
    public void run() { 
		
		//M1用例编号_CASE_DM_M1_001
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		//检查源单1中100101单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100101", true, "测试用例CASE_DM_M1_001");
		//双击打开单据100101
		ListView.element("list").dbClick("单据编号", "100101", "", "");
		MainContainer.selectTab(1);
		//检查源单1-100101单据明细行第1行的值
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		//检查源单1-100101单据明细行第2行的值
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null30.003.0090.00上海笔记本");
		
		System.out.println("============================================================");
		
		//勾选单据明细
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_001");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100101", 1, "测试用例CASE_DM_M1_001");
		ListView.element("ListView1").dbClick("单据编号", "100101", "", "");
		MainContainer.selectTab(1);
		//检查目标单中单据明细第1行值
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 1, "null50002.0010000.00北京电脑nullDataMap_00110,00310,002");
		//检查目标单中单据明细第2行值
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 2, "null303.0090.00上海笔记本nullDataMap_00110,00410,002");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}
}
