package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_047 extends AbstractTestScript {
    public void run() {
		//M1用例编号_CASE_DM_M1_047
//		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
//		MenuEntry.element("DataMap/DataMap/M1_DetailManual/SrcMapCondAuto").dblClick();
//		MainContainer.selectTab(0);
//		Grid.element("detail_grid").pageClick(3);
//		GridUtil.checkCurrentPageNum(Grid.element("detail_grid"), 3);
//		GridUtil.checkGridRowValue("detail_grid", 10, "");
//		GridUtil.checkGridRowValue("detail_grid", 11, "");
//		GridUtil.checkGridRowValue("detail_grid", 12, "");
		
	}
}
