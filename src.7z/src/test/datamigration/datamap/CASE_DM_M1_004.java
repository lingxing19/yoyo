package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_004 extends AbstractTestScript {
    public void run() { 
		
		//M1用例编号_CASE_DM_M1_004
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		ToolBar.element("main_toolbar").click("Delete");
		DialogUtil.checkShowErrorDialog("单据数据不能修改（OID为10009的数据行存在已映射数据）");
		ErrorDialog.element().close();
		waittime(1000);
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}
}
