package test.datamap;

import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_18 extends AbstractTestScript {
	
	public void run() {
		
		//M1用例编号_CASE_DM_M1_042-源单1-100122
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100122", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100122", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.005,000.00上海电脑");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("DataMap_035");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100122", 1, "测试用例CASE_DM_M1_042");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-5000");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100122", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100122", "", "");
		MainContainer.selectTab(5);
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("DataMap_035");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_042-源单1-100123
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100123", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100123", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.005,000.00上海电脑");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("DataMap_035");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-5000");
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "-1199");
		ToolBar.element("Main_Toolbar").click("Save");
		DialogUtil.checkShowErrorDialog("映射数量小于最小映射量");
		ErrorDialog.element().close();
		Grid.element("Grid_Tag_Detail").cellClear("入库数量", 1);
		Grid.element("Grid_Tag_Detail").cellInput("入库数量", 1, "-4900");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100123", 1, "测试用例CASE_DM_M1_042");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-4900");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100122", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100122", "", "");
		MainContainer.selectTab(5);
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("DataMap_035");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_042-源单1-100124
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100124", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100124", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.407,000.00上海电脑");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("DataMap_035");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-5000");
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "-3500");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100124", 1, "测试用例CASE_DM_M1_042");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-3500");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单1");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100124", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100124", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.407,000.00上海电脑");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("DataMap_035");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-1500");
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "-1200");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100124", 2, "测试用例CASE_DM_M1_042");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-1200");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单1");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100124", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100124", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.407,000.00上海电脑");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("DataMap_035");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-1300");
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "-1200");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100124", 3, "测试用例CASE_DM_M1_042");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "-1200");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单1");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100124", true, "测试用例CASE_DM_M1_042");
		ListView.element("list").dbClick("单据编号", "100124", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.407,000.00上海电脑");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("DataMap_035");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
