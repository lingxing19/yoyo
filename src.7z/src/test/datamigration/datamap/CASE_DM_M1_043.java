package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_043 extends AbstractTestScript {
    public void run() {
		//M1用例编号_CASE_DM_M1_043
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100221ui", true, "测试用例CASE_DM_M1_043");
		ListView.element("ListView1").dbClick("单据编号", "100221ui", "", "");
		MainContainer.selectTab(1);
		Grid.element("Grid_Src_Detail").pageClick(1);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null1,0001.001,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null2,0005.0010,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 3, "null3,0005.0015,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 4, "null4,0001.004,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 5, "null5,0005.0025,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 6, "null6,0005.0030,000.00上海电脑nullnullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		Grid.element("Grid_Src_Detail").pageClick(2);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 2);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null7,0005.0035,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null8,0005.0040,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 3, "null9,0005.0045,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 4, "null1,0005.005,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 5, "null1,1005.005,500.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 6, "null1,2005.006,000.00上海电脑nullnullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_012");
		MainContainer.selectTab(2);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 13, "测试用例CASE_DM_M1_043");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100221ui", 1, "测试用例CASE_DM_M1_043");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
	}
}
