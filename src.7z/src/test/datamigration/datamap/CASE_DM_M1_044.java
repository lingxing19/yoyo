package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_044 extends AbstractTestScript {
    public void run() {
    	//M1用例编号_CASE_DM_M1_044
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListViewUtil.checkFormExsit("list", "单据编号", "100221db", true, "测试用例CASE_DM_M1_044");
    	ListView.element("list").dbClick("单据编号", "100221db", "", "");
    	MainContainer.selectTab(1);
    	Grid.element("Grid_Src_Detail").pageClick(1);
    	GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 1);
    	Grid.element("Grid_Src_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
    	Grid.element("Grid_Src_Detail").pageClick(2);
    	GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 2);
    	Grid.element("Grid_Src_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
    	ToolBar.element("main_toolbar").click("Datamap_003");
    	MainContainer.selectTab(2);
//    	     GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 15, "测试用例CASE_DM_M1_044");
    	GridUtil.checkPageCount(Grid.element("Grid_Tag_Detail"), 2);
    	Grid.element("Grid_Tag_Detail").pageClick(1);
    	GridUtil.checkCurrentPageNum(Grid.element("Grid_Tag_Detail"), 1);
    	GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 13, "测试用例CASE_DM_M1_044");
    	Grid.element("Grid_Tag_Detail").pageClick(2);
    	GridUtil.checkCurrentPageNum(Grid.element("Grid_Tag_Detail"), 2);
    	GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 4, "测试用例CASE_DM_M1_044");
    	ToolBar.element("Main_Toolbar").click("Save");
    	SearchBox.element().searchclick("目标单1");
    	MainContainer.selectTab(3);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100221db", 1, "测试用例CASE_DM_M1_044");
    	MainContainer.closeAllTab();
    			
    	System.out.println("============================================================");
	}
}
