package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_048 extends AbstractTestScript {
    public void run() {
		//M1用例编号_CASE_DM_M1_048
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		ToolBar.element("main_toolbar").click("New");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		Grid.element("Grid_Src_Detail").cellDbInput("入库数量", 1, "100");
		ToolBar.element("main_toolbar").click("Save");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Data_Map");
		MainContainer.selectTab(2);
		AssertUtil.checkRequired(TextEditor.element("TextEditor1"), true, "测试用例CASE_DM_M1_048");
		ToolBar.element("Main_Toolbar").click("Save");
		DialogUtil.checkShowErrorDialog("TextEditor1 不能为空");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}
}
