package test.datamap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_19 extends AbstractTestScript {
	
	
	public void run() {
		
		//M1用例编号_CASE_DM_M1_043
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100221ui", true, "测试用例CASE_DM_M1_043");
		ListView.element("ListView1").dbClick("单据编号", "100221ui", "", "");
		MainContainer.selectTab(1);
		Grid.element("Grid_Src_Detail").pageClick(1);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null1,0001.001,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null2,0005.0010,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 3, "null3,0005.0015,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 4, "null4,0001.004,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 5, "null5,0005.0025,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 6, "null6,0005.0030,000.00上海电脑nullnullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		Grid.element("Grid_Src_Detail").pageClick(2);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 2);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null7,0005.0035,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null8,0005.0040,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 3, "null9,0005.0045,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 4, "null1,0005.005,000.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 5, "null1,1005.005,500.00上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 6, "null1,2005.006,000.00上海电脑nullnullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_012");
		MainContainer.selectTab(2);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 13, "测试用例CASE_DM_M1_043");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100221ui", 1, "测试用例CASE_DM_M1_043");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_044
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100221db", true, "测试用例CASE_DM_M1_044");
		ListView.element("list").dbClick("单据编号", "100221db", "", "");
		MainContainer.selectTab(1);
		Grid.element("Grid_Src_Detail").pageClick(1);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 1);
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		Grid.element("Grid_Src_Detail").pageClick(2);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Src_Detail"), 2);
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_003");
		MainContainer.selectTab(2);
//		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 15, "测试用例CASE_DM_M1_044");
		GridUtil.checkPageCount(Grid.element("Grid_Tag_Detail"), 2);
		Grid.element("Grid_Tag_Detail").pageClick(1);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Tag_Detail"), 1);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 13, "测试用例CASE_DM_M1_044");
		Grid.element("Grid_Tag_Detail").pageClick(2);
		GridUtil.checkCurrentPageNum(Grid.element("Grid_Tag_Detail"), 2);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 4, "测试用例CASE_DM_M1_044");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100221db", 1, "测试用例CASE_DM_M1_044");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_045
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100224", true, "测试用例CASE_DM_M1_045");
		ListView.element("list").dbClick("单据编号", "100224", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.005,000.00上海电脑");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null5000.002.1010,500.00上海电脑");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 3, "null5000.003.1015,500.00上海电脑");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("AutoMap");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100224", 1, "测试用例CASE_DM_M1_045");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_046
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/Src_FD1View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		TextEditor.element("TextEditor2").input("10011101");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "10011101", "测试用例CASE_DM_M1_046");
		TextEditor.element("TextEditor1").dbClick().input("A1");
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "A1", "测试用例CASE_DM_M1_046");
		ComboBox.element("ComboBox2").dropDownClick().itemClick("关注+无推送");
		waittime(1000);
		ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox2"), "关注+无推送", "测试用例CASE_DM_M1_046");
		Grid.element("Grid1").cellDbInput("文本", 1, "a");
		Grid.element("Grid1").celComboClick("下拉框", 1).comboItemClick("初始");
		Grid.element("Grid1").celDictClick("字典", 1).dictItemClick("user1 user1");
		Grid.element("Grid1").cellDbInput("数值", 1, "223");
		Grid.element("Grid1").cellClick("反填", 1);
		GridUtil.checkGridRowValue("Grid1", 1, "nulla初始user1 user1223.00null");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单7");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("list", "文本1", "A1", 1, "测试用例CASE_DM_M1_046");
		ListView.element("list").dbClick();
		MainContainer.selectTab(3);
		ToolBar.element("main_toolbar").click("Edit1");
		Grid.element("Grid1").cellClick("行复制", 1);
		GridUtil.checkCellValue("Grid1", "文本", 1, "a");
		GridUtil.checkCellValue("Grid1", "文本", 2, "value1");
		GridUtil.checkCellValue("Grid1", "数值", 1, "223.00");
		GridUtil.checkCellValue("Grid1", "数值", 2, "223.00");
		ToolBar.element("main_toolbar").click("Save");
		DialogUtil.checkShowErrorDialog("映射数量已超量");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
