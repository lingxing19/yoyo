package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_046 extends AbstractTestScript {
    public void run() {
    	//M1用例编号_CASE_DM_M1_046
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/Src_FD1View").dblClick();
    	MainContainer.selectTab(0);
    	ToolBarButton.element("新增").click();
    	MainContainer.selectTab(1);
    	TextEditor.element("TextEditor2").input("10011101");
    	TextEditorUtil.checkInputValue(TextEditor.element("TextEditor2"), "10011101", "测试用例CASE_DM_M1_046");
    	TextEditor.element("TextEditor1").dbClick().input("A1");
    	TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "A1", "测试用例CASE_DM_M1_046");
    	ComboBox.element("ComboBox2").dropDownClick().itemClick("关注+无推送");
    	waittime(1000);
    	ComboBoxUtil.checkInputValue(ComboBox.element("ComboBox2"), "关注+无推送", "测试用例CASE_DM_M1_046");
    	Grid.element("Grid1").cellDbInput("文本", 1, "a");
    	Grid.element("Grid1").celComboClick("下拉框", 1).comboItemClick("初始");
    	Grid.element("Grid1").celDictClick("字典", 1).dictItemClick("user1 user1");
    	Grid.element("Grid1").cellDbInput("数值", 1, "223");
    	Grid.element("Grid1").cellClick("反填", 1);
    	GridUtil.checkGridRowValue("Grid1", 1, "nulla初始user1 user1223.00null");
    	ToolBar.element("main_toolbar").click("Save");
    	SearchBox.element().searchclick("目标单7");
    	MainContainer.selectTab(2);
    	ListViewUtil.checkFormCount("list", "文本1", "A1", 1, "测试用例CASE_DM_M1_046");
    	ListView.element("list").dbClick();
    	MainContainer.selectTab(3);
    	ToolBar.element("main_toolbar").click("Edit1");
    	Grid.element("Grid1").cellClick("行复制", 1);
    	GridUtil.checkCellValue("Grid1", "文本", 1, "a");
    	GridUtil.checkCellValue("Grid1", "文本", 2, "value1");
    	GridUtil.checkCellValue("Grid1", "数值", 1, "223.00");
    	GridUtil.checkCellValue("Grid1", "数值", 2, "223.00");
    	ToolBar.element("main_toolbar").click("Save");
    	DialogUtil.checkShowErrorDialog("映射数量已超量");
    	ErrorDialog.element().close();
    	MainContainer.closeAllTab();
    			
    	System.out.println("============================================================");
	}
}
