package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M5_003 extends AbstractTestScript {
    public void run() {
		//M5用例编号_CASE_DM_M5_003
		MenuEntry.element("DataMap/DataMap/M5_SDManual").click();
		MenuEntry.element("DataMap/DataMap/M5_SDManual/DM_Src_M5_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "500103", true, "测试用例CASE_DM_M5_003");
		ListView.element("list").dbClick("单据编号", "500103", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Detail_Grid", "2", 1, "A");
		Grid.element("Detail_Grid").cellClick("2", 1);
		GridUtil.checkCellValue("Grid_Src_Detail", "3", 1, "2,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "3", 2, "3,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "3", 3, "4,000");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "2", true);
		GridUtil.checkCellValue("Detail_Grid", "2", 2, "B");
		Grid.element("Detail_Grid").cellClick("2", 2);
		GridUtil.checkCellValue("Grid_Src_Detail", "3", 1, "5,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "3", 2, "6,000");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "2", true);
		ToolBar.element("main_toolbar").click("DataMap_5003");
		MainContainer.selectTab(2);
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单5001");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("list", "单据编号", "500103", 1, "测试用例CASE_DM_M5_003");
		ListView.element("list").dbClick("单据编号", "500103", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Detail_Grid", "公司", 1, "A");
		GridUtil.checkCellValue("Detail_Grid", "总数量", 1, "8,000.00");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "3,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Detail_Grid", "公司", 2, "B");
		GridUtil.checkCellValue("Detail_Grid", "总数量", 2, "9,000.00");
		Grid.element("Detail_Grid").cellClick("公司", 2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "6,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Detail_Grid", "公司", 3, "A");
		GridUtil.checkCellValue("Detail_Grid", "总数量", 3, "8,000.00");
		Grid.element("Detail_Grid").cellClick("公司", 3);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "4,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
    }
}
