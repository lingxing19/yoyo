package test.datamap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_12 extends AbstractTestScript {
	
	public void run() {
		
		//M1用例编号_CASE_DM_M1_029
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100203", true, "测试用例CASE_DM_M1_029");
		ListView.element("ListView1").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null10,000nullnull上海电脑nullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null8,000nullnull北京笔记本nullnullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_015");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "5000");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 2, "4000");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100203", true, "测试用例CASE_DM_M1_029");
		ListView.element("ListView1").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(2);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100203", 1, "测试用例CASE_DM_M1_029");
		ListView.element("ListView1").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(3);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "5,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "4,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 2, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "笔记本");
		Grid.element("Grid_Tag_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Tag_Detail"), "选择", true);
		ToolBar.element("Main_Toolbar").click("Datamap_016");
		MainContainer.selectTab(4);
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag2_Detail").cellDbInput("入库数量", 1, "2,000");
		GridUtil.checkGridComboBoxItemsValue("Grid_Tag2_Detail", "物料仓库", 1, "上海北京天津深圳", "测试用例CASE_DM_M1_029");
		Grid.element("Grid_Tag2_Detail").comboItemClick("上海");
		GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 1, "上海");
		Grid.element("Grid_Tag2_Detail").cellDbInput("入库数量", 2, "1,000");
		GridUtil.checkGridComboBoxItemsValue("Grid_Tag2_Detail", "物料仓库", 2, "上海北京天津深圳", "测试用例CASE_DM_M1_029");
		Grid.element("Grid_Tag2_Detail").comboItemClick("北京");
		GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 2, "北京");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100203", true, "测试用例CASE_DM_M1_029");
		ListView.element("ListView1").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "2,000.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "电脑");
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 2, "");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 2, "");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(2);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100203", 1, "测试用例CASE_DM_M1_029");
		ListView.element("ListView1").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(3);
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "数量反填", 1, "2,000.00");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料反填", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 2, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "数量反填", 2, "");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料反填", 2, "");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_029检查目标单2_2——100203，同时进行030用例
		//M1用例编号_CASE_DM_M1_030
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Tag2_M1_002View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormCount("list", "单据编号", "100203", 1, "测试用例CASE_DM_M1_030");
		ListView.element("list").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Tag2_Detail", 1, "null2,000nullnull上海电脑");
		GridUtil.checkGridRowValue("Grid_Tag2_Detail", 2, "null1,000nullnull北京笔记本");
		ToolBar.element("Main_Toolbar").click("Delete");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("目标单2_2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormCount("list", "单据编号", "100203", 0, "测试用例CASE_DM_M1_030");
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(1);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100203", true, "测试用例CASE_DM_M1_030");
		ListView.element("ListView1").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "电脑");
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 2, "");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 2, "");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100203", 1, "测试用例CASE_DM_M1_030");
		ListView.element("ListView1").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "数量反填", 1, "");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料反填", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 2, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "数量反填", 2, "");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料反填", 2, "");
		Grid.element("Grid_Tag_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Tag_Detail"), "选择", true);
		ToolBar.element("Main_Toolbar").click("Datamap_016");
		MainContainer.selectTab(5);
		GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 1, "5,000");
		GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 2, "4,000");
		GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 2, "北京");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("目标单2_2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormCount("list", "单据编号", "100203", 1, "测试用例CASE_DM_M1_030");
		ListView.element("list").dbClick("单据编号", "100203", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Tag2_Detail", 1, "null5,000nullnull上海电脑");
		GridUtil.checkGridRowValue("Grid_Tag2_Detail", 2, "null4,000nullnull北京笔记本");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
