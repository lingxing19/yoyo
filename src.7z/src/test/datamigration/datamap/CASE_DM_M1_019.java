package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_019 extends AbstractTestScript {
    public void run() { 
    	//M1用例编号_CASE_DM_M1_019
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100200", true, "测试用例CASE_DM_M1_019");
    	ListView.element("ListView1").dbClick("单据编号", "100200", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null10,0004.0040,000.00上海电脑nullnullnullnull");
    	Grid.element("Grid_Src_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
    	ToolBar.element("main_toolbar").click("Datamap_034");
    	MainContainer.selectTab(2);
    	ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "初始", "测试用例CASE_DM_M1_019");
    	ToolBar.element("Main_Toolbar").click("Save");
    	SearchBox.element().searchclick("目标单2");
    	MainContainer.selectTab(3);
    	waittime(1000);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100200", 1, "测试用例CASE_DM_M1_019");
    	ListView.element("ListView1").dbClick("单据编号", "100200", "", "");
    	MainContainer.selectTab(4);
    	ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "初始", "测试用例CASE_DM_M1_019");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "数量反填", 1, "");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "物料反填", 1, "");
    	ToolBar.element("Main_Toolbar").click("Edit1");
    	ComboBox.element("T_Status").dropDownClick().itemClick("审批通过(总条件)").getText();
    	ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过(总条件)", "测试用例CASE_DM_M1_019");
    	ToolBar.element("Main_Toolbar").click("Save");
    	MainContainer.closeAllTab();
        SearchBox.element().searchclick("源单2");
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100200", true, "测试用例CASE_DM_M1_019");
    	ListView.element("ListView1").dbClick("单据编号", "100200", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "10,000.00");
    	GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "电脑");
    	MainContainer.closeAllTab();
    			
    	System.out.println("============================================================");				
	}
}
