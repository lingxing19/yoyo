package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_002 extends AbstractTestScript {
    public void run() {
    	//M2用例编号_CASE_DM_M2_002
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "200301", true, "测试用例CASE_DM_M2_002");
		ListView.element("ListView1").dbClick("单据编号", "200301", "", "测试用例CASE_DM_M2_002");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto分组").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto分组", "测试用例CASE_DM_M2_003");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "200301", 2, "测试用例CASE_DM_M2_002");
		ListView.element("ListView1").dbClick(1);
		MainContainer.selectTab(3);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "5,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "10,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 2, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "电脑");
		MainContainer.selectTab(2);
		ListView.element("ListView1").dbClick(2);
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "30");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "笔记本");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
	}
}
