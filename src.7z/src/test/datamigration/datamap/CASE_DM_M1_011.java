package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_011 extends AbstractTestScript {
    public void run() { 
    	
		//M1用例编号_CASE_DM_M1_011
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100113", true, "测试用例CASE_DM_M1_011");
		ListView.element("list").dbClick("单据编号", "100113", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "1000.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 2, "1500.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 3, "2000.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_010");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "1500");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "2000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料仓库", 2, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "笔记本");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100113", 1, "测试用例CASE_DM_M1_011");
		ListView.element("ListView1").dbClick("单据编号", "100113", "", "");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
								
	}
}
