package test.datamap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_4 extends AbstractTestScript {
	
	public void run() {
		
		//M1用例编号_CASE_DM_M1_009
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100111", true, "测试用例CASE_DM_M1_009");
		ListView.element("list").dbClick("单据编号", "100111", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "5000.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_008");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100111", 1, "测试用例CASE_DM_M1_009");
		ListView.element("ListView1").dbClick("单据编号", "100111", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "5000");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单1");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100111", true, "测试用例CASE_DM_M1_009");
		ListView.element("list").dbClick("单据编号", "100111", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "5000.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_008");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "1000");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "800");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100111", 2, "测试用例CASE_DM_M1_009");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "800");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单1");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100111", true, "测试用例CASE_DM_M1_009");
		ListView.element("list").dbClick("单据编号", "100111", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "5000.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_008");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_010
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100112", true, "测试用例CASE_DM_M1_010");
		ListView.element("list").dbClick("单据编号", "100112", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "2500.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_009");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		MainContainer.closeTab(2);
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("审批通过(总条件)").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过(总条件)", "测试用例CASE_DM_M1_010");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单1");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100112", true, "测试用例CASE_DM_M1_010");
		ListView.element("list").dbClick("单据编号", "100112", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "2500.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_009");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100112", 1, "测试用例CASE_DM_M1_010");
		ListView.element("ListView1").dbClick("单据编号", "100112", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "2500");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_011
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100113", true, "测试用例CASE_DM_M1_011");
		ListView.element("list").dbClick("单据编号", "100113", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "1000.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 2, "1500.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 3, "2000.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_010");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "1500");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "2000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料仓库", 2, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "笔记本");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100113", 1, "测试用例CASE_DM_M1_011");
		ListView.element("ListView1").dbClick("单据编号", "100113", "", "");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
				
	}

}
