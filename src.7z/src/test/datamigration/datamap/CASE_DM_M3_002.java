package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M3_002 extends AbstractTestScript {
    public void run() {
		//M3用例编号_CASE_DM_M3_002
		MenuEntry.element("DataMap/DataMap/M3_HeadManual").click();
		MenuEntry.element("DataMap/DataMap/M3_HeadManual/DM_Src_M3_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "300102", true, "测试用例CASE_DM_M3_002");
		ListView.element("list").dbClick("单据编号", "300102", "", "");
		MainContainer.selectTab(1);		
		ToolBar.element("Main_Toolbar").click("optKey2");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "2,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物品单价", 1, "3.00");
		GridUtil.checkCellValue("Grid_Tag_Detail", "总价", 1, "6,000.00");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "单据编号", 1, "300102");
		GridUtil.checkCellValue("Grid_Tag_Detail", "单据日期", 1, "2016-07-12");
		ToolBar.element("Main_Toolbar").click("SYTB");
		DialogUtil.checkQueryBoxDialog();
		Grid.element("detail_grid").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("detail_grid"), "选择", false, 1);
		Grid.element("detail_grid").isRowSelect("选择", 2);
		GridUtil.checkRowSelected(Grid.element("detail_grid"), "选择", true, 2);
		GridUtil.checkCellValue("detail_grid", "入库数量", 2, "1,000.00");
		GridUtil.checkCellValue("detail_grid", "物品单价", 2, "4.00");
		GridUtil.checkCellValue("detail_grid", "总价", 2, "4,000.00");
		GridUtil.checkCellValue("detail_grid", "仓库", 2, "北京");
		GridUtil.checkCellValue("detail_grid", "物料", 2, "笔记本");
		GridUtil.checkCellValue("detail_grid", "单据编号", 2, "300103");
		GridUtil.checkCellValue("detail_grid", "单据日期", 2, "");
		Grid.element("detail_grid").selectRowClick("选择", 3);
		GridUtil.checkRowSelected(Grid.element("detail_grid"), "选择", false, 3);
		Grid.element("detail_grid").selectRowClick("选择", 4);
		GridUtil.checkRowSelected(Grid.element("detail_grid"), "选择", false, 4);
		QueryBoxDialog.element().pushClick();
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "1,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物品单价", 2, "4.00");
		GridUtil.checkCellValue("Grid_Tag_Detail", "总价", 2, "4,000.00");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 2, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "笔记本");
		GridUtil.checkCellValue("Grid_Tag_Detail", "单据编号", 2, "300103");
		GridUtil.checkCellValue("Grid_Tag_Detail", "单据日期", 2, "");
		TextEditor.element("T_BillNO").input("30010203");
		TextEditorUtil.checkInputValue(TextEditor.element("T_BillNO"), "30010203", "测试用例CASE_DM_M3_002");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单3001");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormExsit("list", "单据编号", "30010203", true, "测试用例CASE_DM_M3_002");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");    	
	}
}
