package test.datamap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_17 extends AbstractTestScript {
	
	public void run() {
		
		//M1用例编号_CASE_DM_M1_040
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_004View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100401", true, "测试用例CASE_DM_M1_040");
		ListView.element("list").dbClick("单据编号", "100401", "", "");
		MainContainer.selectTab(1);
		Grid.element("Detail_Grid").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Detail_Grid"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_024");
		MainContainer.selectTab(2);
		ToolBar.element("main_toolbar").click("Edit1");
		Grid.element("Detail_Grid").cellDbInput("总数量", 1, "1000");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单4");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100401", 1, "测试用例CASE_DM_M1_040");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkGridRowValue("Detail_Grid", 1, "nullAnull1,000.00");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 1, "null2,000nullnullnull笔记本");
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 2, "null3,000nullnullnull电脑");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_041
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_004View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100403", true, "测试用例CASE_DM_M1_040");
		ListView.element("list").dbClick("单据编号", "100403", "", "");
		MainContainer.selectTab(1);
		Grid.element("Detail_Grid").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Detail_Grid"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_024");
		MainContainer.selectTab(2);
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单4");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100403", 1, "测试用例CASE_DM_M1_040");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
	
	}

}
