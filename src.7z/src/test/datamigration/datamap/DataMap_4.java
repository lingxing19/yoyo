package test.datamap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_4 extends AbstractTestScript {
	
	public void run() {
		
		//M4用例编号_CASE_DM_M4_001
		MenuEntry.element("DataMap/DataMap/M3_HeadManual").click();
		MenuEntry.element("DataMap/DataMap/M3_HeadManual/DM_Src_M3_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "400101", true, "测试用例CASE_DM_M4_001");
		ListView.element("list").dbClick("单据编号", "400101", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("Main_Toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto", "测试用例CASE_DM_M4_001");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单3001");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("list", "单据编号", "400101", 1, "测试用例CASE_DM_M4_001");
		ListView.element("list").dbClick("单据编号", "400101", "", "");
		MainContainer.selectTab(3);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Warehouse"), "上海", "测试用例CASE_DM_M4_001");
		DatePickerUtil.checkInputValue(DatePicker.element("D_BillDate"), "2016-12-06", "测试用例CASE_DM_M4_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("N_Amount"), "2,000", "测试用例CASE_DM_M4_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("T_Pirce"), "3.10", "测试用例CASE_DM_M4_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("T_Total"), "6,200.00", "测试用例CASE_DM_M4_001");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Material"), "电脑", "测试用例CASE_DM_M4_001");
		SearchBox.element().searchclick("源单3001");
		waittime(1000);
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "400101", true, "测试用例CASE_DM_M4_001");
		ListView.element("list").dbClick("单据编号", "400101", "", "");
		MainContainer.selectTab(4);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N_Amount_FeedBack"), "2,000", "测试用例CASE_DM_M4_001");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
	}

}
