package test.datamap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_2 extends AbstractTestScript {
	
	public void run() {
		
		//M2用例编号_CASE_DM_M2_001
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "200201", true, "测试用例CASE_DM_M2_001");
		ListView.element("list").dbClick("单据编号", "200201", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto分组").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto分组", "测试用例CASE_DM_M2_001");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单2002");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("list", "单据编号", "200201", 3, "测试用例CASE_DM_M2_001");
		ListViewUtil.checkValue("list", "单据编号", 1, "200201");
		ListViewUtil.checkValue("list", "仓库", 1, "上海");
		ListViewUtil.checkValue("list", "数量", 1, "5,000");
		ListViewUtil.checkValue("list", "单价", 1, "2.10");
		ListViewUtil.checkValue("list", "总价", 1, "10,500.00");
		ListViewUtil.checkValue("list", "物料", 1, "电脑");
		
		System.out.println("============================================================");
		
		ListViewUtil.checkValue("list", "单据编号", 2, "200201");
		ListViewUtil.checkValue("list", "仓库", 2, "北京");
		ListViewUtil.checkValue("list", "数量", 2, "30");
		ListViewUtil.checkValue("list", "单价", 2, "3.00");
		ListViewUtil.checkValue("list", "总价", 2, "90.00");
		ListViewUtil.checkValue("list", "物料", 2, "笔记本");
		
		System.out.println("============================================================");
		
		ListViewUtil.checkValue("list", "单据编号", 3, "200201");
		ListViewUtil.checkValue("list", "仓库", 3, "深圳");
		ListViewUtil.checkValue("list", "数量", 3, "1,000");
		ListViewUtil.checkValue("list", "单价", 3, "5.00");
		ListViewUtil.checkValue("list", "总价", 3, "5,000.00");
		ListViewUtil.checkValue("list", "物料", 3, "电脑");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M2用例编号_CASE_DM_M2_002
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "200301", true, "测试用例CASE_DM_M2_002");
		ListView.element("ListView1").dbClick("单据编号", "200301", "", "测试用例CASE_DM_M2_002");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto分组").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto分组", "测试用例CASE_DM_M2_003");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "200301", 2, "测试用例CASE_DM_M2_002");
		ListView.element("ListView1").dbClick(1);
		MainContainer.selectTab(3);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "5,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "10,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 2, "北京");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "电脑");
		MainContainer.selectTab(2);
		ListView.element("ListView1").dbClick(2);
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "30");
		GridUtil.checkCellValue("Grid_Tag_Detail", "仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "笔记本");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M2用例编号_CASE_DM_M2_003
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "200701", true, "测试用例CASE_DM_M2_003");
		ListView.element("list").dbClick("单据编号", "200701", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto无关注字段").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto无关注字段", "测试用例CASE_DM_M2_003");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "200701", 1, "测试用例CASE_DM_M2_003");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M2用例编号_CASE_DM_M2_004
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "200501", true, "测试用例CASE_DM_M2_004");
		ListView.element("list").dbClick("单据编号", "200501", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto", "测试用例CASE_DM_M2_004");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "200501", 0, "测试用例CASE_DM_M2_004");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M2用例编号_CASE_DM_M2_005
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "200601", true, "测试用例CASE_DM_M2_005");
		ListView.element("list").dbClick("单据编号", "200601", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto条件反填").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto条件反填", "测试用例CASE_DM_M2_005");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "200601", 1, "测试用例CASE_DM_M2_005");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M2用例编号_CASE_DM_M2_006
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "201001", true, "测试用例CASE_DM_M2_006");
		ListView.element("ListView1").dbClick("单据编号", "201001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto条件反填").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto条件反填", "测试用例CASE_DM_M2_006");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "201001", 1, "测试用例CASE_DM_M2_006");
		ListView.element("ListView1").dbClick("单据编号", "201001", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("Main_Toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("审批通过(总条件)").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "审批通过(总条件)", "测试用例CASE_DM_M2_006");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "201001", true, "测试用例CASE_DM_M2_006");
		ListView.element("ListView1").dbClick("单据编号", "201001", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "5,000.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "电脑");
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 2, "30.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 2, "笔记本");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M2用例编号_CASE_DM_M2_007
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_004View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "200101", true, "测试用例CASE_DM_M2_007");
		ListView.element("list").dbClick("单据编号", "200101", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto反填").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto反填", "测试用例CASE_DM_M2_007");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单4");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "200101", 1, "测试用例CASE_DM_M2_007");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
