package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_005 extends AbstractTestScript {
    public void run() { 
		
    	//M1用例编号_CASE_DM_M1_005
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
    	MainContainer.selectTab(0);
    	ListViewUtil.checkFormExsit("list", "单据编号", "100104", true, "测试用例CASE_DM_M1_005");
    	ListView.element("list").dbClick("单据编号", "100104", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null30.003.0090.00上海笔记本");
    	Grid.element("Grid_Src_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
    	ToolBar.element("main_toolbar").click("Datamap_003");
    	MainContainer.selectTab(2);
    	Grid.element("Grid_Tag_Detail").cellClear("入库数量", 1);
    	Grid.element("Grid_Tag_Detail").cellInput("入库数量", 1, "1000");
    	Grid.element("Grid_Tag_Detail").cellClear("入库数量", 2);
    	Grid.element("Grid_Tag_Detail").cellInput("入库数量", 2, "10");
    	ToolBar.element("Main_Toolbar").click("Save");
    	SearchBox.element().searchclick("目标单1");
    	MainContainer.selectTab(3);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100104", 1, "测试用例CASE_DM_M1_005");
    	ListView.element("ListView1").dbClick("单据编号", "100104", "", "");
    	MainContainer.selectTab(4);
    	GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "1000");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "10");
    	MainContainer.closeAllTab();
    	SearchBox.element().searchclick("源单1");
    	MainContainer.selectTab(0);
    	ListViewUtil.checkFormExsit("list", "单据编号", "100104", true, "测试用例CASE_DM_M1_005");
    	ListView.element("list").dbClick("单据编号", "100104", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null30.003.0090.00上海笔记本");
    	Grid.element("Grid_Src_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
    	ToolBar.element("main_toolbar").click("Datamap_003");
    	MainContainer.selectTab(2);
    	ToolBar.element("Main_Toolbar").click("Save");
    	SearchBox.element().searchclick("目标单1");
    	MainContainer.selectTab(3);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100104", 2, "测试用例CASE_DM_M1_005");
    	ListView.element("ListView1").dbClick();
    	MainContainer.selectTab(4);
    	GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "4000");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "20");
    	MainContainer.closeAllTab();
    			
    	System.out.println("============================================================");
	}
}
