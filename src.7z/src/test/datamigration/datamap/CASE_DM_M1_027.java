package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_027 extends AbstractTestScript {
    public void run() {
        //M1用例编号_CASE_DM_M1_027
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100202", true, "测试用例CASE_DM_M1_027");
    	ListView.element("ListView1").dbClick("单据编号", "100202", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null10,000nullnull上海电脑nullnullnullnull");
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null8,000nullnull北京笔记本nullnullnullnull");
    	Grid.element("Grid_Src_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
    	ToolBar.element("main_toolbar").click("Datamap_013");
    	MainContainer.selectTab(2);
    	ToolBar.element("Main_Toolbar").click("Edit1");
    	Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "5000");
    	Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 2, "4000");
    	ToolBar.element("Main_Toolbar").click("Save");
    	MainContainer.closeAllTab();
    	SearchBox.element().searchclick("源单2");
    	MainContainer.selectTab(0);
        waittime(1000);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100202", true, "测试用例CASE_DM_M1_027");
    	ListView.element("ListView1").dbClick("单据编号", "100202", "", "");
    	waittime(1000);
    	MainContainer.selectTab(1);
    	GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "");
    	GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "");
    	MainContainer.closeAllTab();
    	SearchBox.element().searchclick("目标单2");
    	MainContainer.selectTab(0);
    	waittime(1000);
        ListViewUtil.checkFormCount("ListView1", "单据编号", "100202", 1, "测试用例CASE_DM_M1_027");
    	ListView.element("ListView1").dbClick("单据编号", "100202", "", "");
    	MainContainer.selectTab(1);
        GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "5,000");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "4,000");
    	Grid.element("Grid_Tag_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Tag_Detail"), "选择", true);
    	ToolBar.element("Main_Toolbar").click("Datamap_014");
    	MainContainer.selectTab(2);
    	ToolBar.element("Main_Toolbar").click("Edit1");
    	Grid.element("Grid_Tag2_Detail").cellDbInput("入库数量", 1, "2,000");
    	//表格第一行【物料仓库】列查询下拉值
    	GridUtil.checkGridComboBoxItemsValue("Grid_Tag2_Detail", "物料仓库", 1, "上海北京天津深圳", "测试用例CASE_DM_M1_027");
    	Grid.element("Grid_Tag2_Detail").celViewClose("物料仓库", 1);
    	
    	//选择“上海”
    	//Grid.element("Grid_Tag2_Detail").comboItemClick("上海");
    	Grid.element("Grid_Tag2_Detail").celComboClick("物料仓库", 1).comboItemClick("上海");
    	//检查表格第一行【物料仓库】单元格值是否为“上海”
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 1, "上海");
    	//表格第一行【物料】列查询下拉值
//    	GridUtil.checkGridComboBoxItemsValue("Grid_Tag2_Detail", "物料", 1, "电脑笔记本", "测试用例CASE_DM_M1_027");
    	//选择“电脑”
    	//Grid.element("Grid_Tag2_Detail").comboItemClick("电脑");
    	Grid.element("Grid_Tag2_Detail").celComboClick("物料", 1).comboItemClick("电脑");
    	//检查表格第一行【物料】单元格值是否为“电脑”
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料", 1, "电脑");
    	Grid.element("Grid_Tag2_Detail").cellDbInput("入库数量", 2, "1,000");
    	//GridUtil.checkGridComboBoxItemsValue("Grid_Tag2_Detail", "物料仓库", 2, "上海北京天津深圳", "测试用例CASE_DM_M1_027");
    	//Grid.element("Grid_Tag2_Detail").comboItemClick("北京");
    	Grid.element("Grid_Tag2_Detail").celComboClick("物料仓库", 2).comboItemClick("北京");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 2, "北京");
    	//GridUtil.checkGridComboBoxItemsValue("Grid_Tag2_Detail", "物料", 2, "电脑笔记本", "测试用例CASE_DM_M1_027");
    	//Grid.element("Grid_Tag2_Detail").comboItemClick("笔记本");
    	Grid.element("Grid_Tag2_Detail").celComboClick("物料", 2).comboItemClick("笔记本");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料", 2, "笔记本");
    	ToolBar.element("Main_Toolbar").click("Save");
    	MainContainer.closeAllTab();
    	SearchBox.element().searchclick("源单2");
    	MainContainer.selectTab(0);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100202", true, "测试用例CASE_DM_M1_027");
    	ListView.element("ListView1").dbClick("单据编号", "100202", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "2,000.00");
    	GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "电脑");
    	GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 2, "");
    	GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 2, "");
    	MainContainer.closeAllTab();
    	
    	System.out.println("============================================================");
    }
}
