package test.datamap;

import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_6 extends AbstractTestScript {
	 
	public void run() {
		
		//M6用例编号_CASE_DM_M6_001
		MenuEntry.element("DataMap/DataMap/M5_SDManual").click();
		MenuEntry.element("DataMap/DataMap/M5_SDManual/DM_Src_M5_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "600201", true, "测试用例CASE_DM_M6_001");
		ListView.element("list").dbClick("单据编号", "600201", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto", "测试用例CASE_DM_M6_001");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("目标单5001");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("list", "单据编号", "A001", 1, "测试用例CASE_DM_M6_001");
		ListView.element("list").dbClick();
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600201", "测试用例CASE_DM_M6_001");
		GridUtil.checkRowCount(Grid.element("Detail_Grid"), 4, "测试用例CASE_DM_M6_001");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_001");
		Grid.element("Detail_Grid").cellClick("公司", 2);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_001");
		Grid.element("Detail_Grid").cellClick("公司", 3);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_001");
		Grid.element("Detail_Grid").cellClick("公司", 4);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_001");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M6用例编号_CASE_DM_M6_002
		MenuEntry.element("DataMap/DataMap/M5_SDManual").click();
		MenuEntry.element("DataMap/DataMap/M5_SDManual/DM_Src_M5_002View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "600101", true, "测试用例CASE_DM_M6_002");
		ListView.element("list").dbClick("单据编号", "600101", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto", "测试用例CASE_DM_M6_002");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("目标单5002");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("list", "单据编号", "B001", 1, "测试用例CASE_DM_M6_002");
		ListView.element("list").dbClick();
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600101", "测试用例CASE_DM_M6_002");
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 4, "测试用例CASE_DM_M6_002");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M6用例编号_CASE_DM_M6_003
		MenuEntry.element("DataMap/DataMap/M5_SDManual").click();
		MenuEntry.element("DataMap/DataMap/M5_SDManual/DM_Src_M5_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "600401", true, "测试用例CASE_DM_M6_003");
		ListView.element("list").dbClick("单据编号", "600401", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto分组").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto分组", "测试用例CASE_DM_M6_003");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("目标单5001");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("list", "单据编号", "A002", 1, "测试用例CASE_DM_M6_003");
		ListViewUtil.checkFormCount("list", "单据编号", "A003", 1, "测试用例CASE_DM_M6_003");
		ListViewUtil.checkFormCount("list", "单据编号", "A004", 1, "测试用例CASE_DM_M6_003");
		ListViewUtil.checkFormCount("list", "单据编号", "A005", 1, "测试用例CASE_DM_M6_003");
		ListView.element("list").dbClick("单据编号", "A002", "", "");
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600401", "测试用例CASE_DM_M6_003");
		GridUtil.checkRowCount(Grid.element("Detail_Grid"), 1, "测试用例CASE_DM_M6_003");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "A003", "", "");
		MainContainer.selectTab(2);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600401", "测试用例CASE_DM_M6_003");
		GridUtil.checkRowCount(Grid.element("Detail_Grid"), 1, "测试用例CASE_DM_M6_003");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "A004", "", "");
		MainContainer.selectTab(3);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600401", "测试用例CASE_DM_M6_003");
		GridUtil.checkRowCount(Grid.element("Detail_Grid"), 1, "测试用例CASE_DM_M6_003");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "A005", "", "");
		MainContainer.selectTab(4);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600401", "测试用例CASE_DM_M6_003");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M6用例编号_CASE_DM_M6_004
		MenuEntry.element("DataMap/DataMap/M5_SDManual").click();
		MenuEntry.element("DataMap/DataMap/M5_SDManual/DM_Src_M5_002View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "600301", true, "测试用例CASE_DM_M6_004");
		ListView.element("list").dbClick("单据编号", "600301", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto分组").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto分组", "测试用例CASE_DM_M6_004");
		ToolBar.element("main_toolbar").click("Save");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("目标单5002");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("list", "单据编号", "B002", 1, "测试用例CASE_DM_M6_003");
		ListViewUtil.checkFormCount("list", "单据编号", "B003", 1, "测试用例CASE_DM_M6_003");
		ListViewUtil.checkFormCount("list", "单据编号", "B004", 1, "测试用例CASE_DM_M6_003");
		ListViewUtil.checkFormCount("list", "单据编号", "B005", 1, "测试用例CASE_DM_M6_003");
		ListView.element("list").dbClick("单据编号", "B002", "", "");
		MainContainer.selectTab(1);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600301", "测试用例CASE_DM_M6_003");
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "B003", "", "");
		MainContainer.selectTab(2);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600301", "测试用例CASE_DM_M6_003");
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "B004", "", "");
		MainContainer.selectTab(3);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600301", "测试用例CASE_DM_M6_003");
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.selectTab(0);
		ListView.element("list").dbClick("单据编号", "B005", "", "");
		MainContainer.selectTab(4);
		TextEditorUtil.checkInputValue(TextEditor.element("TextEditor1"), "600301", "测试用例CASE_DM_M6_003");
		GridUtil.checkRowCount(Grid.element("Grid_Tag_Detail"), 1, "测试用例CASE_DM_M6_003");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
