package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_038 extends AbstractTestScript {
    public void run() {
		//M1用例编号_CASE_DM_M1_038
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100207", true, "测试用例CASE_DM_M1_038");
		ListView.element("ListView1").dbClick("单据编号 ", "100207", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("InverseState");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		ListViewUtil.checkValue("ListView1", "状态", 19, "初始");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
	}
}
