package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M3_001 extends AbstractTestScript {
    public void run() {
		//M3用例编号_CASE_DM_M3_001
		MenuEntry.element("DataMap/DataMap/M3_HeadManual").click();
		MenuEntry.element("DataMap/DataMap/M3_HeadManual/DM_Src_M3_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "300101", true, "测试用例CASE_DM_M3_001");
		ListView.element("list").dbClick("单据编号", "300101", "", "");
		MainContainer.selectTab(1);
		waittime(1000);
		ToolBar.element("Main_Toolbar").click("optKey1");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Edit1");
		NumberEditor.element("N_Amount").clear().input("500");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单3001");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("list", "单据编号", "300101", 1, "测试用例CASE_DM_M3_001");
		ListView.element("list").dbClick("单据编号", "300101", "", "");
		MainContainer.selectTab(4);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N_Amount"), "500", "测试用例CASE_DM_M3_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("T_Pirce"), "3.00", "测试用例CASE_DM_M3_001");
		NumberEditorUtil.checkInputValue(NumberEditor.element("T_Total"), "6,000.00", "测试用例CASE_DM_M3_001");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Material"), "电脑", "测试用例CASE_DM_M3_001");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单3001");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "300101", true, "测试用例CASE_DM_M3_001");
		ListView.element("list").dbClick("单据编号", "300101", "", "");
		MainContainer.selectTab(1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N_Amount_FeedBack"), "500", "测试用例CASE_DM_M3_001");
		ToolBar.element("Main_Toolbar").click("optKey1");
		MainContainer.selectTab(2);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N_Amount"), "1,500", "测试用例CASE_DM_M3_001");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单3001");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("list", "单据编号", "300101", 2, "测试用例CASE_DM_M3_001");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单3001");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "300101", true, "测试用例CASE_DM_M3_001");
		ListView.element("list").dbClick("单据编号", "300101", "", "");
		MainContainer.selectTab(1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("N_Amount_FeedBack"), "2,000", "测试用例CASE_DM_M3_001");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");

	}
}
