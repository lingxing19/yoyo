package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_1 extends AbstractTestScript {
	
	public void run() { 
		
		//M1用例编号_CASE_DM_M1_001
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		//检查源单1中100101单据是否存在
		ListViewUtil.checkFormExsit("list", "单据编号", "100101", true, "测试用例CASE_DM_M1_001");
		//双击打开单据100101
		ListView.element("list").dbClick("单据编号", "100101", "", "");
		MainContainer.selectTab(1);
		//检查源单1-100101单据明细行第1行的值
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		//检查源单1-100101单据明细行第2行的值
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null30.003.0090.00上海笔记本");
		
		System.out.println("============================================================");
		
		//勾选单据明细
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		//校验明细行是否全勾选
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_001");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100101", 1, "测试用例CASE_DM_M1_001");
		ListView.element("ListView1").dbClick("单据编号", "100101", "", "");
		MainContainer.selectTab(1);
		//检查目标单中单据明细第1行值
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 1, "null50002.0010000.00北京电脑nullDataMap_00110,00310,002");
		//检查目标单中单据明细第2行值
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 2, "null303.0090.00上海笔记本nullDataMap_00110,00410,002");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_002
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100102", true, "测试用例CASE_DM_M1_002");
		ListView.element("list").dbClick("单据编号", "100102", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.00nullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null30.003.00nullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_027");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100102", 1, "测试用例CASE_DM_M1_002");
		ListView.element("ListView1").dbClick("单据编号", "100102", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 1, "null50002.0010000.00nullnullTest_027DataMap_02710,00610,005");
		GridUtil.checkGridRowValue("Grid_Tag_Detail", 2, "null303.0090.00nullnullTest_027DataMap_02710,00710,005");
		ToolBar.element("Main_Toolbar").click("Edit1");
		AssertUtil.checkEnabled(DatePicker.element("D_BillDate"), false, "测试用例CASE_DM_M1_002");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_003
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_003");
		MainContainer.selectTab(2);
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "5200");
		ToolBar.element("Main_Toolbar").click("Save");
		DialogUtil.checkShowErrorDialog("映射数量已超量");
		ErrorDialog.element().close();
		Grid.element("Grid_Tag_Detail").cellClear("入库数量", 1);
		Grid.element("Grid_Tag_Detail").cellInput("入库数量", 1, "200");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100103", 1, "测试用例CASE_DM_M1_003");
		ListView.element("ListView1").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "200");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_003");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "4800");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100103", 2, "测试用例CASE_DM_M1_003");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_003");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		
		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_004
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		ToolBar.element("main_toolbar").click("Delete");
		DialogUtil.checkShowErrorDialog("单据数据不能修改（OID为10009的数据行存在已映射数据）");
		ErrorDialog.element().close();
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
