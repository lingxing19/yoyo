package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M2_003 extends AbstractTestScript {
    public void run() {
    	//M2用例编号_CASE_DM_M2_003
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "200701", true, "测试用例CASE_DM_M2_003");
		ListView.element("list").dbClick("单据编号", "200701", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("Edit1");
		ComboBox.element("T_Status").dropDownClick().itemClick("Auto无关注字段").getText();
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Status"), "Auto无关注字段", "测试用例CASE_DM_M2_003");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单1");
		MainContainer.selectTab(2);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "200701", 1, "测试用例CASE_DM_M2_003");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
	}
}
