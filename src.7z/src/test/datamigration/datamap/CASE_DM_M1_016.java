package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_016 extends AbstractTestScript {
    public void run() { 
    	//M1用例编号_CASE_DM_M1_016
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListView.element("list").selectRowClick("选择", 20, 21, 34);
    	ListViewUtil.checkRowSelected(ListView.element("list"), "选择", true, 20, 21, 34);
    	ToolBarButton.element("批量下推").click();
    	SearchBox.element().searchclick("目标单1");
    	MainContainer.selectTab(1);
    	waittime(1000);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100120", 1, "测试用例CASE_DM_M1_016");
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100121", 1, "测试用例CASE_DM_M1_016");
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "200601", 1, "测试用例CASE_DM_M1_016");
    	MainContainer.closeAllTab();
    	
    	
    	System.out.println("=============================================准备删除三张目标单！==================================================");
    	
    	//删除三张目标单
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
    	
		waittime(1000);
		
		MainContainer.selectTab(0);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100120", true, "测试用例CASE_DM_M1_016");
    	ListView.element("ListView1").dbClick("单据编号", "100120", "", "");
    	MainContainer.selectTab(1);
    	ToolBar.element("Main_Toolbar").click("Delete");
    	
    	MainContainer.selectTab(0);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100121", true, "测试用例CASE_DM_M1_016");
    	ListView.element("ListView1").dbClick("单据编号", "100121", "", "");
    	MainContainer.selectTab(1);
    	ToolBar.element("Main_Toolbar").click("Delete");
    	
    	MainContainer.selectTab(0);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "200601", true, "测试用例CASE_DM_M1_016");
    	ListView.element("ListView1").dbClick("单据编号", "200601", "", "");
    	MainContainer.selectTab(1);
    	ToolBar.element("Main_Toolbar").click("Delete");
    	
    	System.out.println("=============================================三张目标单删除成功！==================================================");
        
    	MainContainer.closeAllTab();
    	
    	System.out.println("============================================================");							
	}
}
