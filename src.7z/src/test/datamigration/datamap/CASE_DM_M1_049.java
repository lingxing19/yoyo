package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_049 extends AbstractTestScript {
    public void run() {
		//M1用例编号_CASE_DM_M1_049
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_009View").dblClick();
		MainContainer.selectTab(0);
		ToolBarButton.element("新增").click();
		MainContainer.selectTab(1);
		TextEditor.element("T_BillNO").dbClick().input("M1_100118");
		TextEditorUtil.checkInputValue(TextEditor.element("T_BillNO"), "M1_100118", "测试用例CASE_DM_M1_049");
		ComboBox.element("T_Warehouse").dropDownClick().itemClick("北京");
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Warehouse"), "北京", "测试用例CASE_DM_M1_049");
		Grid.element("Grid_Src_Detail").cellDbInput("入库数量", 1, "4900");
		ToolBar.element("main_toolbar").click("Save");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_077");
		MainContainer.selectTab(2);
		ComboBoxUtil.checkInputValue(ComboBox.element("T_Warehouse"), "上海", "测试用例CASE_DM_M1_049");
		NumberEditorUtil.checkInputValue(NumberEditor.element("T_Amount"), "4,900.00", "测试用例CASE_DM_M1_049");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "4900.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "物品单价", 1, "2.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "总价", 1, "9,800.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料仓库", 1, "上海");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料", 1, "电脑");
		ToolBar.element("main_toolbar").click("Save");
		SearchBox.element().searchclick("目标单9");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormCount("list", "单据编号", "M1_100118", 1, "测试用例CASE_DM_M1_049");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
	}
}
