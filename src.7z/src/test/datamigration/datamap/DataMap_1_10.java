package test.datamap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_1_10 extends AbstractTestScript {
	
	public void run() {
		
		//M1用例编号_CASE_DM_M1_025
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100217", true, "测试用例CASE_DM_M1_025");
		ListView.element("ListView1").dbClick("单据编号", "100217", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "10,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "物品单价", 1, "5.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_025");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "100");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100217", 1, "测试用例CASE_DM_M1_025");
		ListView.element("ListView1").dbClick("单据编号", "100217", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "100");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100217", true, "测试用例CASE_DM_M1_025");
		ListView.element("ListView1").dbClick("单据编号", "100217", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "初始反填", 1, "2.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "完成反填", 1, "500.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "10,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "物品单价", 1, "5.00");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_025");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "300");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100217", 2, "测试用例CASE_DM_M1_025");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "300");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100217", true, "测试用例CASE_DM_M1_025");
		ListView.element("ListView1").dbClick("单据编号", "100217", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Src_Detail", "初始反填", 1, "2.00");
		GridUtil.checkCellValue("Grid_Src_Detail", "完成反填", 1, "1,500.00");
		MainContainer.closeAllTab();

		System.out.println("============================================================");
		
		//M1用例编号_CASE_DM_M1_026
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Src_M1_002_View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100218", true, "测试用例CASE_DM_M1_026");
		ListView.element("ListView1").dbClick("单据编号", "100218", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null4,0001.002.00nullnullnullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null5,0003.004.00nullnullnullnullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_028");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "100");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 2, "200");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100218", 1, "测试用例CASE_DM_M1_026");
		ListView.element("ListView1").dbClick("单据编号", "100218", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "100");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物品单价", 1, "1.0000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "总价", 1, "2.0000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "200");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物品单价", 2, "3.0000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "总价", 2, "4.0000");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100218", true, "测试用例CASE_DM_M1_026");
		ListView.element("ListView1").dbClick("单据编号", "100218", "", "");
		MainContainer.selectTab(1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("D_Total_FeedBack"), "10.00", "测试用例CASE_DM_M1_026");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null4,0001.002.00nullnullnullnullnullnull");
		GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null5,0003.004.00nullnullnullnullnullnull");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_028");
		MainContainer.selectTab(2);
		ToolBar.element("Main_Toolbar").click("Edit1");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "200");
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 2, "300");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单2");
		MainContainer.selectTab(3);
		waittime(1000);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100218", 2, "测试用例CASE_DM_M1_026");
		ListView.element("ListView1").dbClick();
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "200");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物品单价", 1, "1.0000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "总价", 1, "2.0000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "300");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物品单价", 2, "3.0000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "总价", 2, "4.0000");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单2");
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("ListView1", "单据编号", "100218", true, "测试用例CASE_DM_M1_026");
		ListView.element("ListView1").dbClick("单据编号", "100218", "", "");
		MainContainer.selectTab(1);
		NumberEditorUtil.checkInputValue(NumberEditor.element("D_Total_FeedBack"), "20.00", "测试用例CASE_DM_M1_026");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}

}
