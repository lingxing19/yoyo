package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_034 extends AbstractTestScript {
    public void run() {	
    	//M1用例编号_CASE_DM_M1_034
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_005View").dblClick();
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListViewUtil.checkFormExsit("list", "单据编号", "100501", true, "测试用例CASE_DM_M1_034");
    	ListView.element("list").dbClick("单据编号", "100501", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null电脑5.006.003,000天津上海深圳200.00700.00100.00200.00700.00100.00200.00700.00100.00");
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null笔记本7.008.006,000北京深圳北京400.001,400.00200.00400.001,400.00200.00400.001,400.00200.00");
    	Grid.element("Grid_Src_Detail").selectRowClick("2", 1);
    	GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "2", true, 1);
    	ToolBar.element("main_toolbar").click("Datamap_029");
    	MainContainer.selectTab(2);
    	ToolBar.element("Main_Toolbar").click("Edit1");
    	Grid.element("Grid_Tag_Detail").cellDbInput("3", 1, "100");
    	ToolBar.element("Main_Toolbar").click("Save");
    	SearchBox.element().searchclick("目标单5");
    	MainContainer.selectTab(3);
    	waittime(1000);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100501", 1, "测试用例CASE_DM_M1_034");
    	ListView.element("ListView1").dbClick();
    	MainContainer.selectTab(4);
//    	GridUtil.checkGridRowValue("Grid_Tag_Detail", 1, "1005.006.00电脑天津上海深圳200.00700.00100.00200.00700.00100.00200.00700.00100.00");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "3", 1, "100");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "10", 1, "200.00");
    	MainContainer.closeAllTab();
    	SearchBox.element().searchclick("源单5");
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListViewUtil.checkFormExsit("list", "单据编号", "100501", true, "测试用例CASE_DM_M1_034");
    	ListView.element("list").dbClick("单据编号", "100501", "", "");
    	waittime(1000);
    	MainContainer.selectTab(1);
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null电脑5.006.003,000天津上海深圳200.00700.00100.00200.00700.00100.00200.00700.00100.00");
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null笔记本7.008.006,000北京深圳北京400.001,400.00200.00400.001,400.00200.00400.001,400.00200.00");
//    			Grid.element("Grid_Src_Detail").selectAllClick("2");
//    			GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "2", true);
    	Grid.element("Grid_Src_Detail").selectRowClick("2", 1, 2);
    	GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "2", true, 1, 2);
    	ToolBar.element("main_toolbar").click("Datamap_029");
    	MainContainer.selectTab(2);
    	ToolBar.element("Main_Toolbar").click("Save");
    	SearchBox.element().searchclick("目标单5");
    	MainContainer.selectTab(3);
    	waittime(1000);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100501", 2, "测试用例CASE_DM_M1_034");
    	ListView.element("ListView1").dbClick();
    	MainContainer.selectTab(4);
    	GridUtil.checkCellValue("Grid_Tag_Detail", "3", 1, "2,900");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "10", 1, "200.00");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "3", 2, "6,000");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "10", 2, "400.00");
    	MainContainer.closeAllTab();
    			
    	System.out.println("============================================================");
	}
}
