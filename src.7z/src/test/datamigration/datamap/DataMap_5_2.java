package test.datamap;

import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class DataMap_5_2 extends AbstractTestScript {
	
	public void run() {
		
		//M5用例编号_CASE_DM_M5_002
		MenuEntry.element("DataMap/DataMap/M5_SDManual").click();
		MenuEntry.element("DataMap/DataMap/M5_SDManual/DM_Src_M5_002View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "500201", true, "测试用例CASE_DM_M5_002");
		ListView.element("list").dbClick("单据编号", "500201", "", "");
		MainContainer.selectTab(1);
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "2,000");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_5002");
		MainContainer.selectTab(2);
		Grid.element("Grid_Tag_Detail").cellClear("入库数量", 1);
		Grid.element("Grid_Tag_Detail").cellInput("入库数量", 1, "100");
		ToolBar.element("Main_Toolbar").click("Save");
		SearchBox.element().searchclick("目标单5002");
		MainContainer.selectTab(3);
		ListViewUtil.checkFormExsit("list", "单据编号", "500201", true, "测试用例CASE_DM_M5_002");
		ListView.element("list").dbClick("单据编号", "500201", "", "");
		MainContainer.selectTab(4);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "100");
		MainContainer.closeAllTab();
		SearchBox.element().searchclick("源单5002");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "500201", true, "测试用例CASE_DM_M5_002");
		ListView.element("list").dbClick("单据编号", "500201", "", "");
		MainContainer.selectTab(1);
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "2,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 2, "3,000");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		Grid.element("Detail_Grid").cellClick("公司", 2);
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 1, "5,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "入库数量", 2, "6,000");
		Grid.element("Grid_Src_Detail").selectAllClick("选择");
		GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
		ToolBar.element("main_toolbar").click("Datamap_5002");
		MainContainer.selectTab(2);
		waittime(1000);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "1,900");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "笔记本");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 1, "DataMap_5002");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "5,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "笔记本");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 2, "DataMap_5002");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 3, "3,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 3, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 3, "DataMap_5002");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 4, "6,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 4, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 4, "DataMap_5002");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		SearchBox.element().searchclick("目标单5002");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("list", "单据编号", "500201", 2, "测试用例CASE_DM_M5_002");
		ListView.element("list").dbClick();
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "1,900");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 1, "笔记本");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 1, "DataMap_5002");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "5,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 2, "笔记本");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 2, "DataMap_5002");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 3, "3,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 3, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 3, "DataMap_5002");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 4, "6,000");
		GridUtil.checkCellValue("Grid_Tag_Detail", "物料", 4, "电脑");
		GridUtil.checkCellValue("Grid_Tag_Detail", "MapKey", 4, "DataMap_5002");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		SearchBox.element().searchclick("源单5002");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "500201", true, "测试用例CASE_DM_M5_002");
		ListView.element("list").dbClick("单据编号", "500201", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Detail_Grid", "公司", 1, "A");
		Grid.element("Detail_Grid").cellClick("公司", 1);
		GridUtil.checkCellValue("Grid_Src_Detail", "物料", 1, "笔记本");
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "1,900");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料", 2, "电脑");
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 2, "3,000");
		
		System.out.println("============================================================");
		
		GridUtil.checkCellValue("Detail_Grid", "公司", 2, "B");
		Grid.element("Detail_Grid").cellClick("公司", 2);
		GridUtil.checkCellValue("Grid_Src_Detail", "物料", 1, "笔记本");
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "5,000");
		GridUtil.checkCellValue("Grid_Src_Detail", "物料", 2, "电脑");
		GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 2, "6,000");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
	}
}
