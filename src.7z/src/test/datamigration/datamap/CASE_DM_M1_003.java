package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_003 extends AbstractTestScript {
    public void run() { 
		
    	//M1用例编号_CASE_DM_M1_003
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_003");
		MainContainer.selectTab(2);
		Grid.element("Grid_Tag_Detail").cellDbInput("入库数量", 1, "5200");
		ToolBar.element("Main_Toolbar").click("Save");
		DialogUtil.checkShowErrorDialog("映射数量已超量");
		ErrorDialog.element().close();
		Grid.element("Grid_Tag_Detail").cellClear("入库数量", 1);
		Grid.element("Grid_Tag_Detail").cellInput("入库数量", 1, "200");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100103", 1, "测试用例CASE_DM_M1_003");
		ListView.element("ListView1").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "200");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_003");
		MainContainer.selectTab(2);
		GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "4800");
		ToolBar.element("Main_Toolbar").click("Save");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/EI_DM_Tag_M1_001_View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormCount("ListView1", "单据编号", "100103", 2, "测试用例CASE_DM_M1_003");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
		MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
		MainContainer.selectTab(0);
		waittime(1000);
		ListViewUtil.checkFormExsit("list", "单据编号", "100103", true, "测试用例CASE_DM_M1_003");
		ListView.element("list").dbClick("单据编号", "100103", "", "");
		MainContainer.selectTab(1);	
		GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.002.0010,000.00北京电脑");
		Grid.element("Grid_Src_Detail").selectRowClick("选择", 1);
		GridUtil.checkRowSelected(Grid.element("Grid_Src_Detail"), "选择", true, 1);
		ToolBar.element("main_toolbar").click("Datamap_003");
		DialogUtil.checkShowErrorDialog("缺少可映射数据");
		ErrorDialog.element().close();
		
		System.out.println("============================================================");
		
	}
}
