package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.ComboBoxUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.common.util.TextEditorUtil;
import com.bokesoft.yes.autotest.component.factory.ComboBox;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.component.factory.ToolBarButton;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_045 extends AbstractTestScript {
    public void run() {
    	//M1用例编号_CASE_DM_M1_045
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Src_M1_001View").dblClick();
    	MainContainer.selectTab(0);
    	waittime(1000);
    	ListViewUtil.checkFormExsit("list", "单据编号", "100224", true, "测试用例CASE_DM_M1_045");
    	ListView.element("list").dbClick("单据编号", "100224", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 1, "null5000.001.005,000.00上海电脑");
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 2, "null5000.002.1010,500.00上海电脑");
    	GridUtil.checkGridRowValue("Grid_Src_Detail", 3, "null5000.003.1015,500.00上海电脑");
    	Grid.element("Grid_Src_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Src_Detail"), "选择", true);
    	ToolBar.element("main_toolbar").click("AutoMap");
    	SearchBox.element().searchclick("目标单1");
    	MainContainer.selectTab(2);
    	ListViewUtil.checkFormCount("ListView1", "单据编号", "100224", 1, "测试用例CASE_DM_M1_045");
    	MainContainer.closeAllTab();
    	
    	System.out.println("============================================================");
	}
}
