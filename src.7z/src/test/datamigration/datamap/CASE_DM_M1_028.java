package test.datamap;

import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DialogUtil;
import com.bokesoft.yes.autotest.common.util.GridUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.NumberEditorUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.NumberEditor;
import com.bokesoft.yes.autotest.component.factory.SearchBox;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class CASE_DM_M1_028 extends AbstractTestScript {
    public void run() {
    	//M1用例编号_CASE_DM_M1_028
        MenuEntry.element("DataMap/DataMap/M1_DetailManual").click();
    	MenuEntry.element("DataMap/DataMap/M1_DetailManual/DM_Tag2_M1_002View").dblClick();
    	MainContainer.selectTab(0);
    	ListViewUtil.checkFormCount("list", "单据编号", "100202", 1, "测试用例CASE_DM_M1_028");
    	ListView.element("list").dbClick("单据编号", "100202", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 1, "2,000");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 1, "上海");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料", 1, "电脑");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 2, "1,000");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 2, "北京");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料", 2, "笔记本");
    	ToolBar.element("Main_Toolbar").click("Delete");
    	MainContainer.closeAllTab();
    	SearchBox.element().searchclick("目标单2_2");
    	MainContainer.selectTab(0);
    	ListViewUtil.checkFormCount("list", "单据编号", "100202", 0, "测试用例CASE_DM_M1_028");
    	SearchBox.element().searchclick("源单2");
    	MainContainer.selectTab(1);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100202", true, "测试用例CASE_DM_M1_028");
    	ListView.element("ListView1").dbClick("单据编号", "100202", "", "");
    	MainContainer.selectTab(2);
    	GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 1, "");
    	GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 1, "电脑");
    	GridUtil.checkCellValue("Grid_Src_Detail", "数量反填", 2, "");
    	GridUtil.checkCellValue("Grid_Src_Detail", "物料反填", 2, "");
    	SearchBox.element().searchclick("目标单2");
    	MainContainer.selectTab(3);
    	ListViewUtil.checkFormExsit("ListView1", "单据编号", "100202", true, "测试用例CASE_DM_M1_028");
    	ListView.element("ListView1").dbClick("单据编号", "100202", "", "");
    	MainContainer.selectTab(4);
    	GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 1, "5,000");
    	GridUtil.checkCellValue("Grid_Tag_Detail", "入库数量", 2, "4,000");
    	Grid.element("Grid_Tag_Detail").selectAllClick("选择");
    	GridUtil.checkAllSelected(Grid.element("Grid_Tag_Detail"), "选择", true);
    	ToolBar.element("Main_Toolbar").click("Datamap_014");
    	MainContainer.selectTab(5);
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 1, "5,000");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 1, "上海");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 2, "4,000");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 2, "北京");
    	ToolBar.element("Main_Toolbar").click("Save");
    	MainContainer.closeAllTab();
        SearchBox.element().searchclick("目标单2_2");
        MainContainer.selectTab(0);
    	ListViewUtil.checkFormCount("list", "单据编号", "100202", 1, "测试用例CASE_DM_M1_028");
    	ListView.element("list").dbClick("单据编号", "100202", "", "");
    	MainContainer.selectTab(1);
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 1, "5,000");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 1, "上海");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料", 1, "电脑");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "入库数量", 2, "4,000");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料仓库", 2, "北京");
    	GridUtil.checkCellValue("Grid_Tag2_Detail", "物料", 2, "笔记本");
    	MainContainer.closeAllTab();
    			
    	System.out.println("============================================================");
	}
}
