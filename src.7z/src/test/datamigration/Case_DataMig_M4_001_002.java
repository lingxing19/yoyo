package test.datamigration;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M4_001_002 extends AbstractTestScript{
	
	public void run(){
			
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DM_Con_CanView").dblClick();
		MainContainer.selectTab(0);
		//迁移-确认-确认
		ListViewUtil.checkFormExsit("list", "单据编号", "DM_CON_CAN20171018000001", true, "测试用例Case_DataMig_M4_001");	
		ListView.element("list").dbClick("单据编号", "DM_CON_CAN20171018000001", "", "");
		MainContainer.selectTab(1);
		waittime(1000);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		ToolBar.element("ToolBar1").click("ConvertStatus2");
		waittime(1000);
		String[][] expTable = {
									{"-1", "-1.00"},
									{"10771", "100.00"}};
		DataBaseUtil.checkDataMatch("SELECT Material, Amount FROM DM_Con_Can_Object", expTable, "测试用例Case_DataMig_M4_001");
		System.out.println("============================================================");
		//迁移-确认-撤消
		ToolBar.element("ToolBar1").click("Cancel1");
		waittime(1000);
		String[][] expTable2 = {
									{"-1", "-1.00"},
									{"10771", "0.00"}};
		DataBaseUtil.checkDataMatch("SELECT Material, Amount FROM DM_Con_Can_Object", expTable2,"测试用例Case_DataMig_M4_002");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
