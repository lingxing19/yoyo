package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M5_006 extends AbstractTestScript{
	
	public void run(){
		
		//期间结转 RollDataStrategy="CheckPeriod"
		//打开入库单4第一张单据
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form04View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM0420190529000001", true, "测试用例Case_DataMig_M5_006");
		ListView.element("list").dbClick("单据编号", "DMIG_FORM0420190529000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		ToolBar.element("ToolBar1").click("RollData");
		waittime(1000);
		//期间结转后，查看数据库
		String[][] expTable = {
				{ "-1", "-1", "-1.00", "1970-01-01 08:00:00", "-1.00", "-1.00" }, 
				{ "10019", "10771", "2.00", "2019-05-03 00:00:00.000", "0.00", "2.00" }, 
				{ "10019", "10771", "0.00", "2019-05-04 00:00:00.000", "2.00", "2.00" }, 
				{ "10019", "10771", "0.00", "2019-05-05 00:00:00.000", "2.00", "2.00" }, };
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, Amount, BillDate, Amount_begin, Amount_end FROM DMig_Form04_Object",
				expTable, "测试用例Case_DataMig_M5_006");
		System.out.println("============================================================");
		waittime(1000);
		//查看lp表，显示结转日期2019-05-05
		String[][] expTable2 = { 
				{ null, null, null},
				{ "10019", "10771", "2019-05-05 00:00:00.000"}, };
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, BillDate FROM DMig_Form04_Object_lp",
				expTable2, "测试用例Case_DataMig_M5_006");
		MainContainer.closeAllTab();
		
		System.out.println("============================================================");
		
		//打开出库单4第一张单据
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form04AView").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM04A20190529000001", true, "测试用例Case_DataMig_M5_006");
		ListView.element("list").dbClick("单据编号", "DMIG_FORM04A20190529000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		ToolBar.element("ToolBar1").click("RollData");
		waittime(1000);
		//期间结转后，查看数据库
		String[][] expTable3 = {
				{ "-1", "-1", "-1.00", "1970-01-01 08:00:00", "-1.00", "-1.00" }, 
				{ "10019", "10771", "2.00", "2019-05-03 00:00:00.000", "0.00", "2.00" }, 
				{ "10019", "10771", "-2.00", "2019-05-04 00:00:00.000", "2.00", "0.00" }, 
				{ "10019", "10771", "0.00", "2019-05-05 00:00:00.000", "0.00", "0.00" }, };
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, Amount, BillDate, Amount_begin, Amount_end FROM DMig_Form04_Object",
				expTable3, "测试用例Case_DataMig_M5_006");
		System.out.println("============================================================");
		waittime(1000);
		//查看lp表，期末数据值为0，lp表数据不存在
		String[][] expTable4 = { 
				{ null, null, null}, };
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, BillDate FROM DMig_Form04_Object_lp",
				expTable4, "测试用例Case_DataMig_M5_006");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
				
		//打开入库单4第二张单据
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form04View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM0420190529000002", true, "测试用例Case_DataMig_M5_006");
		ListView.element("list").dbClick("单据编号", "DMIG_FORM0420190529000002", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		waittime(1000);
		//期间结转后，查看数据库
		String[][] expTable5 = {
				{ "-1", "-1", "-1.00", "1970-01-01 08:00:00", "-1.00", "-1.00" }, 
				{ "10019", "10771", "2.00", "2019-05-03 00:00:00.000", "0.00", "2.00" }, 
				{ "10019", "10771", "-2.00", "2019-05-04 00:00:00.000", "2.00", "0.00" }, 
				{ "10019", "10771", "0.00", "2019-05-05 00:00:00.000", "0.00", "0.00" }, 
				{ "10019", "10771", "1.00", "2019-05-06 00:00:00.000", "0.00", "1.00" },};
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, Amount, BillDate, Amount_begin, Amount_end FROM DMig_Form04_Object",
				expTable5, "测试用例Case_DataMig_M5_006");
		System.out.println("============================================================");
		waittime(1000);
		//查看lp表，显示结转日期2019-05-06
		String[][] expTable6 = { 
				{ null, null, null}, 
				{ "10019", "10771", "2019-05-06 00:00:00.000"}, };
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, BillDate FROM DMig_Form04_Object_lp",
				expTable6, "测试用例Case_DataMig_M5_006");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
		//打开入库单4第一张单据，点击撤销
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form04View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM0420190529000001", true, "测试用例Case_DataMig_M5_006");
		ListView.element("list").dbClick("单据编号", "DMIG_FORM0420190529000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus2");
		waittime(1000);
		//撤销后，查看数据库，2019-05-03日期数量为0
		String[][] expTable7 = {
				{ "-1", "-1", "-1.00", "1970-01-01 08:00:00", "-1.00", "-1.00" }, 
				{ "10019", "10771", "0.00", "2019-05-03 00:00:00.000", "0.00", "0.00" }, 
				{ "10019", "10771", "-2.00", "2019-05-04 00:00:00.000", "2.00", "0.00" }, 
				{ "10019", "10771", "0.00", "2019-05-05 00:00:00.000", "0.00", "0.00" }, 
				{ "10019", "10771", "1.00", "2019-05-06 00:00:00.000", "0.00", "1.00" },};
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, Amount, BillDate, Amount_begin, Amount_end FROM DMig_Form04_Object",
				expTable7, "测试用例Case_DataMig_M5_006");
		System.out.println("============================================================");
		waittime(1000);
		//查看lp表，显示撤销日期2019-05-03
		String[][] expTable8 = { 
				{ null, null, null}, 
				{ "10019", "10771", "2019-05-03 00:00:00.000"}, };
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, BillDate FROM DMig_Form04_Object_lp",
				expTable8, "测试用例Case_DataMig_M5_006");
		waittime(1000);
		ToolBar.element("ToolBar1").click("RollData");
		//期间结转后，查看数据库
		String[][] expTable9 = {
				{ "-1", "-1", "-1.00", "1970-01-01 08:00:00", "-1.00", "-1.00" }, 
				{ "10019", "10771", "0.00", "2019-05-03 00:00:00.000", "0.00", "0.00" }, 
				{ "10019", "10771", "-2.00", "2019-05-04 00:00:00.000", "0.00", "-2.00" }, 
				{ "10019", "10771", "0.00", "2019-05-05 00:00:00.000", "-2.00", "-2.00" }, 
				{ "10019", "10771", "1.00", "2019-05-06 00:00:00.000", "0.00", "1.00" },};
		DataBaseUtil.checkDataMatch(
				"SELECT Warehouse, Material, Amount, BillDate, Amount_begin, Amount_end FROM DMig_Form04_Object",
				expTable9, "测试用例Case_DataMig_M5_006");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
			
	}

}
