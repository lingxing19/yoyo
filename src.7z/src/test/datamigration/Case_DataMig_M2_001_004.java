package test.datamigration;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M2_001_004 extends AbstractTestScript{
	
	public void run(){
		
		//头表迁头表（负直接量负向迁移）	
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form01View").dblClick();
		MainContainer.selectTab(0);	
		ListViewUtil.checkFormExsit("list", "单据编号", "TSDVoucherPerform20171018000004", true, "测试用例Case_DataMig_M2_001");
		ListView.element("list").dbClick("单据编号", "TSDVoucherPerform20171018000004", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("main_toolbar").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable = {
									{"-1", "#", "-1", "-1.00", "-1.00", "1970-01-01 ", "1970-01-01 08:00:00"},
									{"10771", "aaaa", "11", "-11.00", "11.00", "2017-10-16", "2017-10-16 00:00:00"}
							   };
		DataBaseUtil.checkDataMatch("SELECT HeadDict1, HeadTextEditor2, HeadTextEditor3, HeadNumAssign, HeadNumAddDelta, HeadDatePicker1, HeadDatePicker2 FROM  Object_01" , expTable , "测试用例Case_DataMig_M2_001");
		System.out.println("============================================================");
		//明细迁明细（迁移条件满足)
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "TSDVoucherPerform20171018000005", true, "测试用例Case_DataMig_M2_002");
		ListView.element("list").dbClick("单据编号", "TSDVoucherPerform20171018000005", "", "");
		MainContainer.selectTab(2);	
		ToolBar.element("main_toolbar").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable2 = {
									{"-1", "#", "-1", "-1.00", "-1.00", "1970-01-01", "1970-01-01 08:00:00"},
									{"10772", "bbbb", "22", "22.00", "22.00", "2017-10-16", "2017-10-16 00:00:00"}
								};
		DataBaseUtil.checkDataMatch("SELECT DetailDict1, DetailTextEditor2, DetailTextEditor3, DetailNumAssign, DetailNumAddDelta, DetailDatePicker1, DetailDatePicker2 FROM  Object_02" , expTable2, "测试用例Case_DataMig_M2_002");
		System.out.println("============================================================");
		//明细迁明细（迁移条件不满足）
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "TSDVoucherPerform20171018000006", true, "测试用例Case_DataMig_M2_003");
		ListView.element("list").dbClick("单据编号", "TSDVoucherPerform20171018000006", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("main_toolbar").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable3 = {
									{"-1", "#", "-1", "-1.00", "-1.00", "1970-01-01", "1970-01-01 08:00:00"},
									{"10772", "bbbb", "22", "22.00", "22.00", "2017-10-16", "2017-10-16 00:00:00"}
								};
		DataBaseUtil.checkDataMatch("SELECT DetailDict1, DetailTextEditor2 , DetailTextEditor3, DetailNumAssign, DetailNumAddDelta, DetailDatePicker1, DetailDatePicker2 FROM  Object_02", expTable3, "测试用例Case_DataMig_M2_003");
		System.out.println("============================================================");
		//子明细迁子明细
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "TSDVoucherPerform20171018000007", true, "测试用例Case_DataMig_M2_004");
		ListView.element("list").dbClick("单据编号", "TSDVoucherPerform20171018000007", "", "");
		MainContainer.selectTab(4);
		ToolBar.element("main_toolbar").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable4 = {
									{"-1", "#", "-1", "-1.00", "-1.00", "1970-01-01", "1970-01-01 08:00:00"},
									{"10773", "cccc", "33", "33.00", "33.00", "2017-10-16", "2017-10-16 00:00:00"}
								};
		DataBaseUtil.checkDataMatch("SELECT SubDetailDict1, SubDetailTextEditor2, SubDetailTextEditor3, SubDetailNumAssign, SubDetailNumAddDelta, SubDetailDatePicker1, SubDetailDatePicker2 FROM  Object_03" , expTable4,  "测试用例Case_DataMig_M2_004");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
