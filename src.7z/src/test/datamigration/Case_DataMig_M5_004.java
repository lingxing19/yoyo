package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.DatePickerUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.DatePicker;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M5_004 extends AbstractTestScript {

	public void run() {
		//期间日结转（表达式）
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form03_2View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM03_220180920000001", true, "测试用例Case_DataMig_M5_004");
		ListView.element("list").dbClick("单据编号", "DMIG_FORM03_220180920000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		waittime(1000);
		//查看数据库DMig_Form03_2_Obj1
		String[][] expTable1 = {
				{"-1", "1970-01-01 08:00:00", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10773", "2018-09-17 00:00:00", "100.00", "100.00", "0.00", "100.00", "0.00", "100.00"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, "
				+ "Amount_begin, Amount_end FROM DMig_Form03_2_Obj1", expTable1, "测试用例Case_DataMig_M5_004");
		System.out.println("============================================================");
		ToolBar.element("ToolBar1").click("Edit");
		DatePicker.element("BillDate").clear();
		DatePicker.element("BillDate").viewClick().viewInput(2018, "九月", 15);
		DatePickerUtil.checkInputValue(DatePicker.element("BillDate"), "2018-09-15", "测试用例Case_DataMig_M5_004");
		ToolBar.element("ToolBar1").click("Save");
		//查看数据库
		String[][] expTable2 = {
				{"-1", "1970-01-01 08:00:00", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10773", "2018-09-17 00:00:00", "0.00", "0.00", "0.00", "0.00", "0.00", "0.00"},
				{"10773", "2018-09-15 00:00:00", "100.00", "100.00", "0.00", "100.00", "0.00", "100.00"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end,"
				+ "Amount_begin, Amount_end FROM DMig_Form03_2_Obj1", expTable2, "测试用例Case_DataMig_M5_004");
		ToolBar.element("ToolBar1").click("RollData1");
		//点击【期间日结转（表达式）】，带条件查看数据库DMig_Form03_2_Obj1
		String[][] expTable3 = {
				{"10773", "2018-09-17 00:00:00", "0.00", "0.00", "100.00", "100.00", "100.00", "100.00"},
				{"10773", "2018-09-15 00:00:00", "100.00", "100.00", "0.00", "100.00", "0.00", "100.00"},
				{"10773", "2018-09-16 00:00:00", "0.00", "0.00", "100.00", "100.00", "100.00", "100.00"},
				{"10773", "2018-09-18 00:00:00", "0.00", "0.00", "100.00", "100.00", "100.00", "100.00"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end,"
				+ "Amount_begin, Amount_end FROM DMig_Form03_2_Obj1 where BillDate IN"
				+ "('2018-09-17 00:00:00', '2018-09-15 00:00:00', '2018-09-16 00:00:00', '2018-09-18 00:00:00')", expTable3, "测试用例Case_DataMig_M5_004");		
		MainContainer.closeAllTab();	
		System.out.println("============================================================");
	}
}
