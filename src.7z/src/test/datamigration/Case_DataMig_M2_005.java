package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M2_005 extends AbstractTestScript{
	
	public void run(){
		
		//表达式迁移
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_FormulaView").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORMULA20180929000001", true, "测试用例Case_DataMig_M2_005");	
		ListView.element("list").dbClick("单据编号", "DMIG_FORMULA20180929000001", "", "");	
		MainContainer.selectTab(1); 
		//查看数据库
		waittime(1000);
		String[][] expTable = {
				{ "-1", "-1.00"},
				{"10771", "3.00"},	
		};
		DataBaseUtil.checkDataMatch("SELECT Material, Amount FROM DMig_Formula_Object", expTable, "测试用例Case_DataMig_M2_005");
		System.out.println("============================================================");
		ToolBar.element("ToolBar1").click("Edit");
		Grid.element("detail").cellDbInput("数量", 1, "1").pressEnterKey();
		ToolBar.element("ToolBar1").click("Save");
		String[][] expTable2 = {
				{ "-1", "-1.00"},
				{"10771", "1.00"},	
		};
		DataBaseUtil.checkDataMatch("SELECT Material, Amount FROM DMig_Formula_Object", expTable2, "测试用例Case_DataMig_M2_005");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
