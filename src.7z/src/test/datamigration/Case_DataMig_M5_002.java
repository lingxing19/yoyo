package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M5_002 extends AbstractTestScript{
	
	public void run(){
		
		//期间结转—保存后直接迁移
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form03View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM0320180929000001", true, "测试用例Case_DataMig_M5_001");	
		ListView.element("list").dbClick("单据编号", "DMIG_FORM0320180929000001", "", "");	
		MainContainer.selectTab(1); 
		//查看数据库
		waittime(1000);
		String[][] expTable = {
				{"-1", "-1", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10771", "201805", "100.00", "100.00", "0.00", "100.00"},	
		};
		DataBaseUtil.checkDataMatch("SELECT Material, In_DatePicker, In_Amount, Amount, Amount_begin, Amount_end "
				+ "FROM DMig_Form03_Object ", expTable, "测试用例Case_DataMig_M5_002");
		System.out.println("============================================================");
		//点击【期间迁移】，带条件查看数据库
		ToolBar.element("ToolBar1").click("RollData");
		waittime(1000);
		String[][] expTable2 = {
				{"10771", "201805", "100.00", "100.00", "0.00", "100.00"},	
				{"10771", "201806", "0.00", "0.00", "100.00", "100.00"},
				{"10771", "201807", "0.00", "0.00", "100.00", "100.00"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, In_DatePicker, In_Amount, Amount, Amount_begin, Amount_end "
				+ "FROM DMig_Form03_Object WHERE In_DatePicker IN('201805','201806','201807')", expTable2, "测试用例Case_DataMig_M5_002");
		System.out.println("============================================================");
		//编辑入库数量，保存后，查看数据库
		ToolBar.element("ToolBar1").click("Edit");
		Grid.element("detail").cellDbInput("入库数量", 1, "101").pressEnterKey();
		ToolBar.element("ToolBar1").click("Save");
		waittime(1000);
		String[][] expTable3 = {
				{"10771", "201805", "101.00", "101.00", "0.00", "101.00"},	
				{"10771", "201806", "0.00", "0.00", "100.00", "100.00"},
				{"10771", "201807", "0.00", "0.00", "100.00", "100.00"},	
		};
		DataBaseUtil.checkDataMatch("SELECT Material, In_DatePicker, In_Amount, Amount, Amount_begin, Amount_end "
				+ "FROM DMig_Form03_Object WHERE In_DatePicker IN('201805','201806','201807')", expTable3, "测试用例Case_DataMig_M5_002");
		System.out.println("============================================================");
		//点击【期间结转】后，带条件查看数据库
		ToolBar.element("ToolBar1").click("RollData");
		waittime(1000);
		String[][] expTable4 = {
				{"10771", "201805", "101.00", "101.00", "0.00", "101.00"},	
				{"10771", "201806", "0.00", "0.00", "101.00", "101.00"},
				{"10771", "201807", "0.00", "0.00", "101.00", "101.00"},	
		};
		DataBaseUtil.checkDataMatch("SELECT Material, In_DatePicker, In_Amount, Amount, Amount_begin, Amount_end "
				+ "FROM DMig_Form03_Object WHERE In_DatePicker IN('201805','201806','201807')", expTable4, "测试用例Case_DataMig_M5_002");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
