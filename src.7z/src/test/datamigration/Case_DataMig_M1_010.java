package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M1_010 extends AbstractTestScript{
	
	public void run(){
		
		//重新迁移
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/Stock_03View").dblClick();
		MainContainer.selectTab(0);
		//检查是否存在“单据编号”是“STOCK_0320180927000001”的表单
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCK_0320180927000001", true, "测试用例Case_DataMig_M1_009");		
		ListView.element("list").dbClick("单据编号", "STOCK_0320180927000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		//点击【确认】后，查看数据库
		String[][] expTable = {
				{"-1", "-1", "-1.00"},
				{"10019", "10771", "100.00"},
			};		
		DataBaseUtil.checkDataMatch("select  Warehouse, Material, Qty from stock03", expTable, "测试用例Case_DataMig_M1_010");
		System.out.println("============================================================");
		//编辑表单，录入数据
		ToolBar.element("ToolBar1").click("Edit");
		waittime(1000);
		Grid.element("Grid1").celDictClick("仓库", 2).dictItemClick("shanghai 上海仓库");
		Grid.element("Grid1").celDictClick("物料", 2).dictItemClick("2 手机");
		Grid.element("Grid1").cellDbInput("数量", 2, "100.00").pressEnterKey();
		ToolBar.element("ToolBar1").click("Save");
		waittime(1000);
		//数据保存后，点击【重新迁移】，并查看数据库
		ToolBar.element("ToolBar1").click("ReMigrate");
		String[][] expTable2 = {
				{"-1", "-1", "-1.00"},
				{"10019", "10771", "100.00"},
				{"10023", "10772", "100.00"},
			};		
		DataBaseUtil.checkDataMatch("select  Warehouse, Material, Qty from stock03", expTable2, "测试用例Case_DataMig_M1_010");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
	
	}
}
