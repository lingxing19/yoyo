package test.datamigration;

import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M5_003 extends AbstractTestScript{
	
	public void run(){
		
		//期间年，月，日结转
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_Form03_1View").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM03_120180531000001", true, "测试用例Case_DataMig_M5_003");	
		ListView.element("list").dbClick("单据编号", "DMIG_FORM03_120180531000001", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM03_120180531000002", true, "测试用例Case_DataMig_M5_003");	
		ListView.element("list").dbClick("单据编号", "DMIG_FORM03_120180531000002", "", "");
		MainContainer.selectTab(2);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_FORM03_120180531000003", true, "测试用例Case_DataMig_M5_003");	
		ListView.element("list").dbClick("单据编号", "DMIG_FORM03_120180531000003", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("ConvertStatus");
		waittime(1000);
		//查看数据库DMig_Form03_1_Obj1
		String[][] expTable = {
				{"-1", "-1", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10772", "2018", "500.55", "500.55", "0.00", "500.55"},		
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, Amount_begin, Amount_end FROM DMig_Form03_1_Obj1", expTable, "测试用例Case_DataMig_M5_003");
		System.out.println("============================================================");
		//查看数据库DMig_Form03_1_Obj2
		waittime(1000);
		String[][] expTable2 = {
				{"-1", "-1", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10772", "201805", "300.55", "300.55", "0.00", "300.55"},	
				{"10772", "201806", "200.00", "200.00", "0.00", "200.00"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, Amount_begin, Amount_end FROM DMig_Form03_1_Obj2", expTable2, "测试用例Case_DataMig_M5_003");
		System.out.println("============================================================");
		//查看数据库DMig_Form03_1_Obj3
		waittime(1000);
		String[][] expTable3 = {
				{"-1", "1970-01-01 08:00:00", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00", "-1.00"},
				{"10772", "2018-05-29 00:00:00", "100.55", "100.55", "0.00", "100.55", "0.00", "100.55"},	
				{"10772", "2018-05-30 00:00:00", "200.00", "200.00", "0.00", "200.00", "0.00", "200.00"},	
				{"10772", "2018-06-06 00:00:00", "200.00", "200.00", "0.00", "200.00", "0.00", "200.00"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, Amount_begin, Amount_end "
				+ "FROM DMig_Form03_1_Obj3", expTable3, "测试用例Case_DataMig_M5_003");
		System.out.println("============================================================");
		//点击【期间年结转】，带条件查看数据库DMig_Form03_1_Obj1
		ToolBar.element("ToolBar1").click("RollData1");
		waittime(1000);
		String[][] expTable4 = {
				{"10772", "2018", "500.55", "500.55", "0.00", "500.55"},
				{"10772", "2019", "0.00", "0.00", "500.55", "500.55"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, Amount_begin, Amount_end FROM DMig_Form03_1_Obj1 "
				+ "where BillDate IN ('2018', '2019')", expTable4, "测试用例Case_DataMig_M5_003");
		System.out.println("============================================================");
		//点击【期间月结转】，带条件查看数据库DMig_Form03_1_Obj2
		ToolBar.element("ToolBar1").click("RollData2");
		waittime(1000);
		String[][] expTable5 = {
				{"10772", "201805", "300.55", "300.55", "0.00", "300.55"},	
				{"10772", "201806", "200.00", "200.00", "300.55", "500.55"},
				{"10772", "201807", "0.00", "0.00", "500.55", "500.55"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, Amount_begin, Amount_end FROM DMig_Form03_1_Obj2 "
				+ "where BillDate IN('201805', '201806', '201807')", expTable5, "测试用例Case_DataMig_M5_003");
		System.out.println("============================================================");
		//点击【期间日结转】，带条件查看数据库DMig_Form03_1_Obj3
		ToolBar.element("ToolBar1").click("RollData3");
		waittime(1000);
		String[][] expTable6 = {
				{"10772", "2018-05-29 00:00:00", "100.55", "100.55", "0.00", "100.55", "0.00", "100.55"},
				{"10772", "2018-05-30 00:00:00", "200.00", "200.00", "100.55", "300.55", "100.55", "300.55"},
				{"10772", "2018-06-06 00:00:00", "200.00", "200.00", "300.55", "500.55", "300.55", "500.55"},
				{"10772", "2018-06-07 00:00:00", "0.00", "0.00", "500.55", "500.55", "500.55", "500.55"},
		};
		DataBaseUtil.checkDataMatch("SELECT Material, BillDate, In_Amount, Amount, In_Amount_begin, In_Amount_end, Amount_begin, Amount_end FROM DMig_Form03_1_Obj3 "
				+ "WHERE BillDate IN('2018-05-29 00:00:00','2018-05-30 00:00:00','2018-06-06 00:00:00','2018-06-07 00:00:00')", expTable6, "测试用例Case_DataMig_M5_003");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
