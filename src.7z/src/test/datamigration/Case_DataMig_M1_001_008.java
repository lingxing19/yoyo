package test.datamigration;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M1_001_008 extends AbstractTestScript {
	
	public void run(){
		
		//库存迁移-一出一入		
		//完成入库
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/Stock_01View").dblClick();
		MainContainer.selectTab(0);
		//检查是否存在“单据编号”是“STOCK_0120171018000003”的表单
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCK_0120171018000003", true, "测试用例Case_DataMig_M1_001");		
		ListView.element("list").dbClick("单据编号", "STOCK_0120171018000003", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		// 查数据库得到实际结果,预期结果为二维数组
		// 先以OID 为标识来固定一行数据
		String[][] expTable = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1000.00", "0.00", "0.00"},
									{"10772", "800.00", "0.00", "0.00"},
									{"10773", "500.00", "0.00", "0.00"}
								};		
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock", expTable, "测试用例Case_DataMig_M1_001");
		System.out.println("============================================================");
		//待出库		
		MenuEntry.element("Migration/MigrationTest/StockOutView").dblClick();
		MainContainer.selectTab(2);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCKOUT20171018000003", true, "Case_DataMig_M1_002");
		ListView.element("list").dbClick("单据编号", "STOCKOUT20171018000003", "", "");
		MainContainer.selectTab(3);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable2 = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1000.00", "100.00", "0.00"},
									{"10772", "800.00", "0.00", "0.00"},
									{"10773", "500.00", "0.00", "0.00"}
								};
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock", expTable2, "测试用例Case_DataMig_M1_002");
		System.out.println("============================================================");
		//完成入库
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCK_0120171018000004", true, "测试用例Case_DataMig_M1_003");
		ListView.element("list").dbClick("单据编号", "STOCK_0120171018000004", "", "");// 并未改变formID 
		MainContainer.selectTab(4); // 手动改变formID
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable3 = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1100.00", "100.00", "0.00"},
									{"10772", "900.00", "0.00", "0.00"},
									{"10773", "500.00", "0.00", "0.00"}
								};
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock", expTable3, "测试用例Case_DataMig_M1_003");
		System.out.println("============================================================");
		//待出库
		MainContainer.selectTab(2);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCKOUT20171018000004", true, "测试用例Case_DataMig_M1_004");
		ListView.element("list").dbClick("单据编号", "STOCKOUT20171018000004", "", "");
		MainContainer.selectTab(5);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable4 = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1100.00", "300.00", "0.00"},
									{"10772", "900.00", "0.00", "0.00"},
									{"10773", "500.00", "100.00", "0.00"}
								};
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock", expTable4, "测试用例Case_DataMig_M1_004");
		System.out.println("============================================================");
	    //待入库
		MenuEntry.element("Migration/MigrationTest/StockInView").dblClick();
		MainContainer.selectTab(6);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCKIN20171018000003", true, "测试用例Case_DataMig_M1_005");
		ListView.element("list").dbClick("单据编号", "STOCKIN20171018000003", "", "");
		MainContainer.selectTab(7);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable5 = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1100.00", "300.00", "0.00"},
									{"10772", "900.00", "0.00", "0.00"},
									{"10773", "500.00", "100.00", "50.00"}
								};
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock" , expTable5, "测试用例Case_DataMig_M1_005");
		System.out.println("============================================================");
		//确认出库
		MenuEntry.element("Migration/MigrationTest/StockOut01View").dblClick();
		MainContainer.selectTab(8);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCKOUT0120171018000003", true, "测试用例Case_DataMig_M1_006");
		ListView.element("list").dbClick("单据编号", "STOCKOUT0120171018000003", "", "");
		MainContainer.selectTab(9);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(1000);
		String[][] expTable6 = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1000.00", "300.00", "0.00"},
									{"10772", "850.00", "0.00", "0.00"},
									{"10773", "500.00", "100.00", "50.00"}
								};
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock", expTable6, "测试用例Case_DataMig_M1_006");
		System.out.println("============================================================");
		//待入库，检查规则有效，迁移不成功
		MainContainer.selectTab(6);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCKIN20171018000004", true, "测试用例Case_DataMig_M1_007");
		ListView.element("list").dbClick("单据编号", "STOCKIN20171018000004", "", "");
		MainContainer.selectTab(10);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(500);
		ErrorDialog.element().close();
		waittime(1000);
		String[][] expTable7 = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1000.00", "300.00", "0.00"},
									{"10772", "850.00", "0.00", "0.00"},
									{"10773", "500.00", "100.00", "50.00"}
								};
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock", expTable7, "测试用例Case_DataMig_M1_007");
		System.out.println("============================================================");
		//确认出库，检查规则有效，迁移不成功
		MainContainer.selectTab(8);
		ListViewUtil.checkFormExsit("list", "单据编号", "STOCKOUT0120171018000004", true, "测试用例Case_DataMig_M1_008");
		ListView.element("list").dbClick("单据编号", "STOCKOUT0120171018000004", "", "");
		MainContainer.selectTab(11);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		waittime(500);
		ErrorDialog.element().close();
		waittime(1000);
		String[][] expTable8 = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "1000.00", "300.00", "0.00"},
									{"10772", "850.00", "0.00", "0.00"},
									{"10773", "500.00", "100.00", "50.00"}
								};
		DataBaseUtil.checkDataMatch("select Material, Qty, Qty_O, Qty_I from stock" , expTable8, "测试用例Case_DataMig_M1_008");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

	

}
