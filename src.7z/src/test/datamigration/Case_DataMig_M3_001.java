package test.datamigration;

import com.bokesoft.yes.autotest.common.util.ListViewUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.component.factory.MainContainer;
import com.bokesoft.yes.autotest.component.factory.MenuEntry;
import com.bokesoft.yes.autotest.component.factory.ToolBar;
import com.bokesoft.yes.autotest.script.AbstractTestScript;

public class Case_DataMig_M3_001 extends AbstractTestScript{
	
	public void run(){
		
		//一迁多-数量负向迁移
		MenuEntry.element("Migration/MigrationTest").click();
		MenuEntry.element("Migration/MigrationTest/DMig_moreView").dblClick();
		MainContainer.selectTab(0);
		ListViewUtil.checkFormExsit("list", "单据编号", "DMIG_MORE20171018000004", true, "测试用例Case_DataMig_M3_001");	
		ListView.element("list").dbClick("单据编号", "DMIG_MORE20171018000004", "", "");
		MainContainer.selectTab(1);
		ToolBar.element("ToolBar1").click("ConvertStatus1");
		
		waittime(1000);
		String[][] expTable = {
									{"-1", "-1.00", "-1.00", "-1.00"},
									{"10771", "-1000.00", "1000.00", "1000.00"}
								};
		DataBaseUtil.checkDataMatch("SELECT Material, Amount, Amount1, Amount2 from DMig_more_Object", expTable, "测试用例Case_DataMig_M3_001");
		MainContainer.closeAllTab();
		System.out.println("============================================================");
		
	}

}
