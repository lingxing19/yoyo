package com.bokesoft.yes.autotest.component.datepicker;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IDatePicker;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;
import com.sun.glass.ui.Robot;

public class BaseDatePicker extends AbstractComponent implements IDatePicker {

	protected WebElement datepickerview = null;

	public BaseDatePicker(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
	}

	// 点开日期输入弹出框
	public BaseDatePicker viewClick() {
		el.findElement(By.xpath("//span[@id='dateImg_" + formID + "_" + key + "']")).click();
		waittime(500);
		return this;
	}

	@Override
	public BaseDatePicker viewInput(int year, String month, int day) {

		LogImpl.getInstance().info("在日期选择框中输入：" + year + "年" + month + "月" + day + "日");
		datepickerview = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "_datepickerView']"));
		WebElement sElement = datepickerview.findElement(By.xpath(".//div[@class='datepicker']"));
		WebElement container = sElement.findElement(By.xpath(".//div[@class='datepickerContainer']"));
		// 左右键，选择年
		WebElement year1 = container.findElement(By.xpath(".//th[@class='datepickerMonth']/a/span[1]"));
		WebElement goprev = container.findElement(By.xpath(".//th[@class='datepickerGoPrev']/a/span[1]"));
		WebElement gonext = container.findElement(By.xpath(".//th[@class='datepickerGoNext']/a/span[1]"));
		year1.click();
		int y = Integer.parseInt(year1.getText()); // 获得当前年的数值
		int temp = y - year;
		if (temp > 0) {
			while (temp > 0) {
				goprev.click();
				temp--;
			}
		}
		if (temp < 0) {
			while (temp < 0) {
				gonext.click();
				temp++;
			}
		}

		// 选择月份
		WebElement momths = container.findElement(By.xpath(".//tbody[@class='datepickerMonths']"));
		List<WebElement> monthlist = momths.findElements(By.xpath(".//td//a/span"));

		for (WebElement el : monthlist) {

			System.out.println(el.getText());
			String txt = el.getText();
			if (txt.equalsIgnoreCase("" + month)) {
				el.click();
				break;
			}
		}

		// monthlist.get(month-1).click();
		// monthlist.click();

		// 选择日期
		WebElement datepickerDays = container.findElement(By.xpath(".//tbody[@class='datepickerDays']"));
		List<WebElement> days = datepickerDays
				.findElements(By.xpath(".//td[not(contains(@class,'datepickerNotInMonth'))]//a/span"));

		for (WebElement el : days) {
			String txt = el.getText();
			if (txt.equalsIgnoreCase("" + day)) {
				el.click();
				break;
			}
		}
		return this;
	}

	/**
	 * 选择框左侧按钮点击;并验证月份是否为递减
	 * 
	 * @param num
	 *            点击次数e
	 */
	// public boolean cutDownClick(int num) {
	// datepickerview = driver.findElement(By.xpath("//div[@id='" + formID + "_"
	// + key + "_datepickerView']"));
	// WebElement el
	// =datepickerview.findElement(By.xpath(".//th[@class='datepickerMonth']/a/span"));
	// WebElement left
	// =datepickerview.findElement(By.xpath(".//th[@class='datepickerGoPrev']/a/span"));
	// String s = el.getText();
	// String a[] = s.split(", ");
	// String s1 = a[0];
	// String[] months = { "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月",
	// "十月", "十一月", "十二月" };
	// for(int i=0;i<num;i++){
	// left.click();
	// }
	//
	// String date = el.getText();
	// String a1[] = date.split(", ");
	// String s2 = a1[0];
	//
	// for (int i =0 ;i<months.length; i++) {
	// if(months[i].equals(s1)) {
	// if (s2.equals(months[i - num]))
	// return true;
	// }
	// }
	// return false;
	// }

	/**
	 * 选择框左侧按钮点击;并验证月份是否为递增
	 * 
	 * @param num
	 *            点击次数
	 */
	// public boolean addClick(int num) {
	// datepickerview = driver.findElement(By.xpath("//div[@id='" + formID + "_"
	// + key + "_datepickerView']"));
	// WebElement el
	// =datepickerview.findElement(By.xpath(".//th[@class='datepickerMonth']/a/span"));
	// WebElement right
	// =datepickerview.findElement(By.xpath(".//th[@class='datepickerGoNext']/a/span"));
	// String s = el.getText();
	// String a[] = s.split(", ");
	// String s1 = a[0];
	// String[] months = { "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月",
	// "十月", "十一月", "十二月" };
	// for(int i=0;i<num;i++){
	// right.click();
	// }
	//
	// String date = el.getText();
	// String a1[] = date.split(", ");
	// String s2 = a1[0];
	//
	// for (int i =0 ;i<months.length; i++) {
	// if(months[i].equals(s1)) {
	// if (s2.equals(months[i + num]))
	// return true;
	// }
	// }
	// return false;
	// }

	@Override
	public BaseDatePicker viewInput(int year, String month, int day, int hour, int minute, int second) {
		viewInput(year, month, day);
		LogImpl.getInstance().info("输入时间：" + hour + "：" + minute + "：" + second);
		List<WebElement> timelist = datepickerview.findElements(By.xpath(".//div[@class='time']/input"));
		timelist.get(0).clear();
		timelist.get(0).sendKeys(String.valueOf(hour));
		timelist.get(1).clear();
		timelist.get(1).sendKeys(String.valueOf(minute));
		timelist.get(2).clear();
		timelist.get(2).sendKeys(String.valueOf(second));
		datepickerview.findElement(By.xpath(".//div[@class='time']/button[1]")).click();
		return this;
	}

	/**
	 * 
	 * 编辑框内字符清空
	 * 
	 * @return
	 */
	public IDatePicker clear() {
		LogImpl.getInstance().info("字段：" + key + "清空");
		WebElement element = el.findElement(By.tagName("input"));
		element.click();
		RobotUtil.pressCtrlA();
		RobotUtil.pressBackspaceKey();
		return this;
	}

	@Override
	public BaseDatePicker inputCurrenttime() {
		LogImpl.getInstance().info("输入当前时间");
		viewClick();
		// WebElement
		// sElement=datepickerview.findElement(By.xpath(".//div[@class='datepicker']"));
		// datepickerview.findElement(By.xpath(".//div[@class='time']/button[1]")).click();

		String s = "document.getElementById('" + formID + "_" + key
				+ "_datepickerView').children[1].getElementsByClassName('btn')[0].click()";
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript(s);
		return this;
	}

	/**
	 * 文本框编辑输入测试
	 * 
	 * @param text
	 * @return
	 */
	public IControl input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	/**
	 * 编辑框取值
	 */
	public String getText() {
		String s = el.findElement(By.tagName("input")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	/**
	 * 光标默认全选时有效
	 * 
	 * @return
	 */
	public void pressBackspaceKey() {
		LogImpl.getInstance().info("选中，按Backspace键，清空");
		RobotUtil.pressBackspaceKey();
	}

	/**
	 * 光标移动至end
	 */
	public IDatePicker focusMovetoEnd() {
		WebElement element = el.findElement(By.tagName("input"));
		element.click();
		String s = element.getAttribute("maxlength");
		int len = Integer.parseInt(s);
		for (int i = 0; i < len; i++)
			RobotUtil.pressRight();
		return this;
	}

	/**
	 * 光标局部选中 （因java存在shift键与right键同时按下时无效的bug，故先做numlock关闭，再开启。）
	 * 
	 * @param strat
	 *            起始位置
	 * @param end
	 *            终止位置
	 * 
	 */
	public IDatePicker chooseFocus(int start, int end) {
		WebElement element = el.findElement(By.tagName("input"));
		element.click();
		RobotUtil.press(KeyEvent.VK_HOME);

		Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_NUM_LOCK, false);

		for (int i = 1; i <= end; i++) {
			if (i >= start) {
				RobotUtil.press(KeyEvent.VK_SHIFT, KeyEvent.VK_RIGHT);
			} else {
				RobotUtil.pressRight();
			}
		}

		RobotUtil.press(KeyEvent.VK_NUM_LOCK);
		return this;

	}

	/**
	 * 多次按下Backspace键
	 * 
	 * @param num
	 *            按击次数
	 */
	public void pressBackspaceKey(int num) {
		LogImpl.getInstance().info("按Backspace键");
		// el.findElement(By.tagName("input")).click();

		el.click();
		for (int i = 0; i < num; i++) {
			RobotUtil.pressBackspaceKey();
		}
	}

	public void click() {
		LogImpl.getInstance().info("单击控件");
		el.findElement(By.tagName("input")).click();
	}

	/**
	 * 模拟键盘enter键操作
	 */
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();
        waittime(500);
	}

	/**
	 * 模拟键盘Tab键操作
	 */
	public void pressTabKey() {
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();
	}

	/**
	 * 检测规则红色角标测试
	 */
	public boolean isRedcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("error-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * 必填黄色角标测试
	 */
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("require-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * 可见性测试
	 */
	public boolean isDisplayed() {
		return el.isDisplayed();
	}

	/**
	 * 可用性测试
	 */
	public boolean isEnabled() {
		return el.isEnabled();
	}

	/**
	 * 悬浮提示测试
	 */
	public String getHovertext() {
		return el.getAttribute("title");
	}

	/**
	 * 错误描述测试
	 */
	public String getErrorInfo() {
		return el.findElement(By.className("error-icon")).getAttribute("title");
	}

	/**
	 * 前景色测试
	 */
	public String getForeColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("color");
		String s2 = s.substring(5, s.length() - 4);
		return s2;

	}

	/**
	 * 编辑框内水平左右居中方向测试
	 */
	public String getHalign() {
		return el.findElement(By.tagName("input")).getCssValue("text-align");
	}

	/**
	 * 背景色测试
	 */
	public String getBackColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("background-color");
		String s2 = s.substring(5, s.length() - 4);
		return s2;

	}

	/**
	 * 字体名称测试
	 */
	public String getFontName() {
		String s = el.findElement(By.tagName("input")).getCssValue("font-family");
		String s2 = s.substring(1, s.length() - 1);
		return s2;

	}

	/**
	 * 字体大小测试
	 */
	public String getFontSize() {
		return el.findElement(By.tagName("input")).getCssValue("font-size");
	}

	/**
	 * 字体粗细测试
	 */
	public String getFontWeight() {
		return el.findElement(By.tagName("input")).getCssValue("font-weight");
	}

	/**
	 * 字体样式测试
	 */
	public String getFontStyle() {
		return el.findElement(By.tagName("input")).getCssValue("font-style");
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 日期框输入当前时间后几天
	 */
	@Override
	public IDatePicker inputNextDay(int next) {
		LogImpl.getInstance().info("字段：" + key + "输入成功");
		Date date = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, next);// +1今天的时间加一天

		date = calendar.getTime();

		DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

		System.out.println(dateformat.format(date));

		WebElement input = el.findElement(By.tagName("input"));
		// input.sendKeys(dateformat.format(date));

		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
		javascriptExecutor.executeScript("document.getElementById('dateInput_" + formID + "_" + key + "').value='"
				+ dateformat.format(date) + "'");

		input.click();
		return this;
	}

	/**
	 * 日期框输入当前时间后10分钟
	 */
	public IDatePicker inputNextMinute() {
		Calendar now = Calendar.getInstance();

		now.add(Calendar.MINUTE, 10);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

		String dateStr = sdf.format(now.getTimeInMillis());

		el.findElement(By.tagName("input")).sendKeys((dateStr));

		return this;

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

	/*
	 * 获取当前日期
	 */
	public String getCurrDate() {
		DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");

		Date date = new Date();

		String date1 = dateformat.format(date);
		System.out.println(date1);
		return date1;
	}

	/*
	 * 获取选择框中显示的当前日期 （现有一个样式问题，datepickerSelected之后要修改为Selected）
	 */
	public String getViewCurrDate() {
		datepickerview = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "_datepickerView']"));
		String s = datepickerview.findElement(By.xpath(".//th[@class='datepickerMonth']/a/span")).getText();
		String a[] = s.split(", ");
		String s1 = a[0];
		String s2 = a[1];
		String[] months = { "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月" };
		String[] nums = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" };
		int month = months.length;
		int n = 0;
		for (int i = 0; i < month; i++) {
			String m = months[i];
			if (!s1.equals(m)) {
				n++;
			}
			break;
		}
		String s3 = nums[0];
		for (int i = 0; i < nums.length; i++) {
			if (!s3.equals(nums[n])) {
				s3 = nums[i + 1];
			}
			break;
		}
		String s6 = null;
		String s4 = datepickerview.findElement(By.xpath(".//td[@class,contain('datepickerSelected')]/a/span")).getText();
		if (s4.length() != 0) {
			s6 = "0" + s4;
		} else {
			s6 = s4;
		}
		String s5 = s2 + "-" + s3 + "-" + s6;
		return s5;

	}
	
	public void paste(String text) {
		el.findElement(By.tagName("input")).click();
		RobotUtil.paste(text);	
	}


	public void ctrlC() {
		RobotUtil.pressCtrlC();
	}

	
	public void ctrlV() {
		RobotUtil.pressCtrlV();
	}
}