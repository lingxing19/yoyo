package com.bokesoft.yes.autotest.component;

public interface IUTCDatePicker extends IControl {

	/**
	 * 日期下拉框中输入日期
	 */
	public IUTCDatePicker viewInput(int year, String month, int day);

	/**
	 * 日期下拉框中输入日期时间
	 */
	public IUTCDatePicker viewInput(int year, String month, int day, int hour, int minute, int second);

	/**
	 * 日期下拉框中输入当前日期时间
	 */
	public IUTCDatePicker inputCurrenttime();

	public String getText();

	public IUTCDatePicker clear();

}
