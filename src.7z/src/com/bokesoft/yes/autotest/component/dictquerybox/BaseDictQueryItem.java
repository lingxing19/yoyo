package com.bokesoft.yes.autotest.component.dictquerybox;

public class BaseDictQueryItem {
	
	private String caption;
	private String code;
	private int nodeType;
	
	public BaseDictQueryItem() {
	}

	public BaseDictQueryItem(String caption,String code, int nodeType) {
		this.caption = caption;
//		this.enable = enable;
		this.nodeType = nodeType;
		this.code =code;
	}
//	public int getEnable() {
//		return enable;
//	}

//	public void setEnable(int enable) {
//		this.enable = enable;
//	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public int getNodeType() {
		return nodeType;
	}

	public void setNodeType(int nodeType) {
		this.nodeType = nodeType;
	}
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	@Override
	public String toString() {
		return "capiton:" + caption + ",code:" +code+ ",nodeType:" +nodeType;
	}
}
