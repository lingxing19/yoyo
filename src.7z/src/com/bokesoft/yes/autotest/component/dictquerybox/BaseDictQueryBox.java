package com.bokesoft.yes.autotest.component.dictquerybox;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IDictQueryBox;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseDictQueryBox extends AbstractComponent implements IDictQueryBox {

	
	/**
	 * 
	 * 
	 * @param key 字典标识或表格column+num
	 * @param str 固定字符串 dict_dialog _dropview
	 * @param isGrid 是否在表格中 表格处理一行
	 */
	public BaseDictQueryBox(String col,String key, boolean isGrid) {
		
		FluentWait<WebDriver> wait2 = new FluentWait<WebDriver>(driver);

		wait2.pollingEvery(100,TimeUnit.MILLISECONDS).withTimeout(50,TimeUnit.SECONDS).ignoring(NoSuchElementException.class);

		if (isGrid) {
			this.el = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id(col+ "_" + key + "dict_dialog")));
		} else {
			this.el = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id(formID + "_" + key + "dict_dialog")));
		}
		

	}
	
	/**
	 * 
	 * @param row 行号
	 * @param columnkey 表格column+num
	 */
	public BaseDictQueryBox(String row,String columnkey) {
		this.key = "dict_dialog";
		
		FluentWait<WebDriver> wait2 = new FluentWait<WebDriver>(driver);

		wait2.pollingEvery(100,TimeUnit.MILLISECONDS).withTimeout(50,TimeUnit.SECONDS).ignoring(NoSuchElementException.class);

		this.el = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id(row+ "_" + columnkey + key)));
		

	}
	
	
	@SuppressWarnings("deprecation")
	public BaseDictQueryBox(String dictKey) {
		this.key = "dict_dialog";

//		WebDriverWait wait = new WebDriverWait(driver, 100);
//		wait.until(new Function(){
//			
//		});
		
		FluentWait<WebDriver> wait2 = new FluentWait<WebDriver>(driver);

		wait2.pollingEvery(100,TimeUnit.MILLISECONDS).withTimeout(50,TimeUnit.SECONDS).ignoring(NoSuchElementException.class);

		this.el = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id(formID + "_" + dictKey + key)));
		
		
//		WebElement element = wait..until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='appleId']")));  
//		wait.until(new ExpectedCondition<WebElement>() {
//			@Override
//		public WebElement apply(WebDriver d) {
//				return d.findElement(By.id(key));
//			}
//		});
//
//		this.el = driver.findElement(By.id(key));
	}

	@Override
	public IDictQueryBox itemDbClick(int rowNo) {
		LogImpl.getInstance().info("双击打开当前页第" + rowNo + "行");
		List<WebElement> rows = el
				.findElements(By.xpath(".//table[@class='tbl-body']/tbody/tr[contains(@class,'data')]"));
		Actions action = new Actions(driver);
		action.doubleClick(rows.get(rowNo - 1).findElement(By.tagName("td"))).build().perform();
		return this;
	}

	@Override
	public IDictQueryBox queryTxtInput(String text) {
		LogImpl.getInstance().info("输入查询文本：" + text);
		el.findElement(By.xpath(".//table[@class='layout']//tr[@row='0']/td[@col='0']//input")).sendKeys(text);
		return this;
	}

	@Override
	public IDictQueryBox queryTxtClear() {
		LogImpl.getInstance().info("清空查询文本");
		el.findElement(By.xpath(".//table[@class='layout']//tr[@row='0']/td[@col='0']//input")).clear();
		return this;
	}

	@Override
	public IDictQueryBox queryClick() {
		LogImpl.getInstance().info("点击[查询]按钮");
		el.findElement(By.xpath(".//table[@class='layout']//tr[@row='0']/td[@col='1']//button")).click();
		return this;
	}

	@Override
	public IDictQueryBox pageClick(int pageNo) {
		LogImpl.getInstance().info("跳转到第" + pageNo + "页");
		List<WebElement> pages = el.findElements(By.xpath(".//div[@class='paginationjs-pages']/ul/li/a"));
		pages.get(pageNo).click();
		return this;
	}

	@Override
	public IDictQueryBox nextClick() {
		LogImpl.getInstance().info("跳转到下一页");
		List<WebElement> pages = el.findElements(By.xpath(".//div[@class='paginationjs-pages']/ul/li"));
		if (pages.get(pages.size() - 1).getAttribute("class").contains("disabled")) {
			LogImpl.getInstance().info("已经是最后1页，不能跳转到下一页");
			return this;
		}
		pages.get(pages.size() - 1).click();
		return this;
	}

	@Override
	public IDictQueryBox preClick() {
		LogImpl.getInstance().info("跳转到前一页");
		List<WebElement> pages = el.findElements(By.xpath(".//div[@class='paginationjs-pages']/ul/li"));
		if (pages.get(0).getAttribute("class").contains("disabled")) {
			LogImpl.getInstance().info("已经是第1页，不能跳转到前一页");
			return this;
		}
		pages.get(0).click();
		return this;
	}

	@Override
	public void close() {
		LogImpl.getInstance().info("关闭字典查询弹出框");
//		el.findElement(By.className("dialog-close")).click();
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	/**
	 * 获取子节点对象组
	 * 
	 * 
	 */
	public List<BaseDictQueryItem> getChildren() {
		waittime(1000);
		List<BaseDictQueryItem> items = new ArrayList<BaseDictQueryItem>();
		List<WebElement> list = null;
		BaseDictQueryItem item = null;
		// 取属性,并封装
		list = el.findElements(By.xpath(".//tr[contains(@class, 'data')]"));
		for (WebElement e : list) {
			item = new BaseDictQueryItem();
			item.setCaption(e.findElement(By.xpath(".//td[2]")).getText());
			item.setCode(e.findElement(By.xpath(".//td[1]")).getText());
			int nodeType = 0;
			try {
				nodeType = e.findElement(By.xpath(".//td[1]/span")).getAttribute("class").contains("p_node") ? 1 : 0;
			} catch (Exception e2) {
				// TODO: handle exception
			}
			item.setNodeType(nodeType);
			items.add(item);
			System.out.println(item);
		}

		return items;

	}

	@Override
	public IDictQueryBox queryBoxButtonClick(String buttonName) {
		el.findElement(By.xpath(".//button[text()='" + buttonName + "']")).click();
		return this;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub
		
	}

}
