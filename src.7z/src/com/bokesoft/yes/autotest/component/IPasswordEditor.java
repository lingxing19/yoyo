package com.bokesoft.yes.autotest.component;

public interface IPasswordEditor extends IControl {

	public boolean getPreIcon(String iconName);

	public String getEmbedText();

	public String getPromptText();

	public String getText();
	
	public IPasswordEditor click();
	
	public void clear();

}
