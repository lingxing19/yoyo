package com.bokesoft.yes.autotest.component;

import com.bokesoft.yes.autotest.component.CheckListBox.BaseCheckListBox;

public interface ICheckListBox extends IControl {
	/**
	 * 展开/收起多选下拉框
	 */
	public ICheckListBox dropDownClick();

	/**
	 * 勾选\去掉勾选
	 * 
	 * @param itemName
	 *            下拉项名称
	 */
	public ICheckListBox itemClick(String... itemName);

	public String getText();

	public String getItems();

	public String getPromptText();
	
	public ICheckListBox clickName(String name);
	
	public boolean isChecked(String itemName);
	
	public boolean isButton(String buttonName);
	
	public void backClick();

}
