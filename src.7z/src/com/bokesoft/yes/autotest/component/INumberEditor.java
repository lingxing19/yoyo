package com.bokesoft.yes.autotest.component;

public interface INumberEditor extends IControl {

	public String getText();

	public INumberEditor paste(String text);

	public String getPromptText();

	public INumberEditor clear();
	
	public INumberEditor click();

}
