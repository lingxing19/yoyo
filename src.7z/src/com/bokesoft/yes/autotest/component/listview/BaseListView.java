package com.bokesoft.yes.autotest.component.listview;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.bokesoft.yes.autotest.component.AbstractTableComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IListView;
import com.bokesoft.yes.autotest.component.grid.BaseGrid;
import com.bokesoft.yes.autotest.log.LogImpl;

/**
 * 
 *
 */
public class BaseListView extends AbstractTableComponent implements IListView {

	public BaseListView(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));

		this.rows = el.findElements(By.xpath(".//table[@class='tbl-body']/tbody/tr[contains(@class,'data')]"));
		this.head = el.findElements(By.xpath(".//table[@class='tbl-head']/thead//th[@colindex]"));// 不包含序号

		this.pagesdiv = el.findElement(By.className("paginationjs-pages"));
		if (pagesdiv.isDisplayed() == true) {
			paging = true;
			this.pages = pagesdiv.findElements(By.xpath(".//ul/li"));
			pageCount = pages.size() - 2;
			currentPageNum = Integer.parseInt(
					pagesdiv.findElement(By.xpath(".//li[contains(@class,'active')]")).getAttribute("data-num"));
		}
	}

	@Override
	public void dbClick(int index) {
		LogImpl.getInstance().info("双击打开序号为：" + index + "的单据");
		Actions action = new Actions(driver);
		action.doubleClick(rows.get(index - 1)).build().perform();
		waittime(1000);
	}

	@Override
	public void dbClick() {
		LogImpl.getInstance().info("双击打开当前页中最新生的单据");
		Actions action = new Actions(driver);
		action.doubleClick(rows.get(rows.size() - 1)).build().perform();
		waittime(1000);
	}

	@Override
	public String getValue(String colName, int index) {
		int colIndex = getColIndex(colName);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex + 2) + "]")).getText();
		return s;
	}

	@Override
	public void dbClick(String colName, String text, String workName, String msg) {
		LogImpl.getInstance().info("打开\"" + colName + "\"为\"" + text + "\"且\"" + workName + "\"为\"" + msg + "\"的单据");
		int colindex = getColIndex(colName);
		if (colindex == -1) {
			LogImpl.getInstance().info("不存在\"" + colName + "\"列");
			return;
		}
		if (!paging) {
			// 不分页的情况
			for (WebElement we : rows) {
				WebElement td = we.findElement(By.xpath(".//td[" + (colindex + 2) + "]"));
				String s = td.getText();
				if (s.equalsIgnoreCase(text)) {
					Actions actions = new Actions(driver);
					actions.doubleClick(td).build().perform();
					waittime(2000);
					return;
				}
			}
		} else {
			// 分页的情况
			int p = 1;
			while (p <= pageCount) {
				pageClick(p);
				for (WebElement we : rows) {
					WebElement td = we.findElement(By.xpath(".//td[" + (colindex + 2) + "]"));
					String s = td.getText();
					if (s.equalsIgnoreCase(text)) {
						Actions actions = new Actions(driver);
						actions.doubleClick(td).build().perform();
						waittime(2000);
						return;
					}
				}
				p++;
			}
		}

	}

	@Override
	public boolean isFormExsit(String colName, String text) {
		LogImpl.getInstance().info("查询是否存在\"" + colName + "\"为\"" + text + "\"的单据");
		int colindex = getColIndex(colName);
		if (colindex == -1) {
			LogImpl.getInstance().info("不存在\"" + colName + "\"列");
			return false;
		}
		if (!paging) {
			// 不分页的情况
			for (WebElement we : rows) {
				WebElement td = we.findElement(By.xpath(".//td[" + (colindex + 2) + "]"));
				String s = td.getText();
				if (s.equalsIgnoreCase(text)) {
					return true;
				}
			}
			return false;
		} else {
			// 分页的情况
			int p = 1;
			while (p <= pageCount) {
				pageClick(p);
				for (WebElement we : rows) {
					WebElement td = we.findElement(By.xpath(".//td[" + (colindex + 2) + "]"));
					String s = td.getText();
					if (s.equalsIgnoreCase(text)) {
						pageClick(1);
						return true;
					}
				}
				p++;
			}
			pageClick(1);
			return false;
		}
	}

	@Override
	public int countForm(String colName, String text) {
		LogImpl.getInstance().info("计算\"" + colName + "\"为\"" + text + "\"的单据的总数量");
		int colindex = getColIndex(colName);
		if (colindex == -1) {
			LogImpl.getInstance().info("不存在\"" + colName + "\"列");
			return 0;
		}

		int formscount = 0;
		if (!paging) {
			// 不分页的情况
			for (WebElement we : rows) {
				WebElement td = we.findElement(By.xpath(".//td[" + (colindex + 2) + "]"));
				String s = td.getText();
				if (s.equalsIgnoreCase(text)) {
					formscount++;
				}
			}
		} else {
			// 分页的情况
			// 从第1页开始，计算符合条件的表单
			int p = 1;
			while (p <= pageCount) {
				pageClick(p);
				for (WebElement we : rows) {
					WebElement td = we.findElement(By.xpath(".//td[" + (colindex + 2) + "]"));
					String s = td.getText();
					if (s.equalsIgnoreCase(text)) {
						formscount++;
					}
				}
				p++;
			}
			pageClick(1);
		}
		return formscount;
	}

	@Override
	public int getColIndex(String colName) {
		// LogImpl.getInstance().info("获得列\""+colName+"\"的列号");
		int colindex = -1;
		List<String> colnames = new ArrayList<String>();
		for (WebElement e : head) {
			colnames.add(e.findElement(By.xpath(".//label")).getText().trim());
		}
		for (int i = 0; i < colnames.size(); i++) {
			if (colnames.get(i).equalsIgnoreCase(colName.trim())) {
				colindex = i;
			}
		}
		return colindex;
	}

	@Override
	public BaseListView prevClick() {
		LogImpl.getInstance().info("向前翻页");
		if (currentPageNum == 1) {
			LogImpl.getInstance().info("已经是第一页，无法向前翻页");
			return this;
		}
		pages.get(0).findElement(By.tagName("a")).click();
		waittime(1000);
		rows = el.findElements(By.xpath(".//table[@class='tbl-body']/tbody/tr[contains(@class,'data')]"));
		pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		currentPageNum--;
		return this;
	}

	@Override
	public BaseListView nextClick() {
		LogImpl.getInstance().info("向后翻一页");
		if (currentPageNum == pages.size() - 2) {
			LogImpl.getInstance().info("已经是最后一页，无法向后翻页");
			return this;
		}
		pages.get(pages.size() - 1).findElement(By.tagName("a")).click();
		waittime(1000);
		rows = el.findElements(By.xpath(".//table[@class='tbl-body']/tbody/tr[contains(@class,'data')]"));
		pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		currentPageNum++;
		return this;
	}

	@Override
	public BaseListView pageClick(int pagenum) {
		LogImpl.getInstance().info("跳转到第" + pagenum + "页");
		pages.get(pagenum).findElement(By.tagName("a")).click();
		waittime(1000);
		rows = el.findElements(By.xpath(".//table[@class='tbl-body']/tbody/tr[contains(@class,'data')]"));
		pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		currentPageNum = pagenum;
		return this;
	}

	@Override
	public int getRowCount() {
		// LogImpl.getInstance().info("获得总行数");
		if (!paging) {
			rowCount = rows.size();
		} else {
			// 分页的情况
			int p = 1;
			while (p <= pageCount) {
				pageClick(p);
				rowCount += rows.size();
				p++;
			}
			pageClick(1);
		}
		return rowCount;

	}

	@Override
	public BaseListView setPage2First() {
		LogImpl.getInstance().info("返回第一页");
		pageClick(1);
		return this;
	}

	@Override
	public BaseListView selectRowClick(String colName, int... index) {
		String s = "";
		for (int i = 0; i < index.length - 1; i++) {
			s += Integer.toString(index[i]) + ",";
		}
		s += Integer.toString(index[index.length - 1]);
		LogImpl.getInstance().info("根据行序号，选择行（当前页）:" + s);
		int colIndex = getColIndex(colName);
		for (int i = 0; i < index.length; i++) {
			rows.get(index[i] - 1).findElement(By.xpath(".//td[" + (colIndex + 2) + "]/span")).click();
		}
		return this;
	}

	@Override
	public BaseListView selectAllRow() {
		LogImpl.getInstance().info("勾选所有行（当前页）");
		int colIndex = getColIndex("选择");
		for (int i = 0; i < rows.size(); i++) {
			rows.get(i).findElement(By.xpath(".//td[" + (colIndex + 2) + "]/span")).click();
		}
		return this;
	}

	@Override
	public BaseListView selectAllClick(String colName) {
		// web上listview选择列的bug,修复后完善此函数
		return this;
	}

	public boolean isRowSelect(String colName, int... index) {
		int colIndex = getColIndex(colName);
		for (int i = 0; i < index.length; i++) {
			String s = rows.get(index[i] - 1).findElement(By.xpath(".//td[" + (colIndex + 2) + "]/span"))
					.getAttribute("class");
			if (s != null && s.contains("checked")) {
				continue;
			} else {
				return false;
			}
		}
		return true;
	}

	public boolean isAllSelected(String colName) {
		// TODO Auto-generated method stub
		int colIndex = getColIndex(colName);
		WebElement e = el.findElement(By
				.xpath(".//tr[@class='ui-ygrid-headers']//label[text()='" + colName + "']/preceding-sibling::span[1]"));
		List<WebElement> list = el.findElements(
				By.xpath(".//table[@id='" + formID + "_" + key + "']/tbody/tr/td[" + (colIndex) + "]/span"));
		for (WebElement s : list) {
			if (s.getAttribute("class").contains("checked")) {
				e.getAttribute("class").contains("checked");
				return true;
			} else {
				break;
			}
		}
		return false;
	}

	/**
	 * 点击 视图 按钮
	 */
	public BaseListView ButtonClick(String colName, int index) {
		LogImpl.getInstance().info("点击视图按钮");
		int colIndex = getColIndex(colName);
		rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex + 2) + "]//button")).click();
		return this;
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

	// public int getAllCount(String) {

	// }

}
