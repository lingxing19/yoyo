package com.bokesoft.yes.autotest.component;

public interface IMainContainer {

	/**
	 * 选中某页
	 * 
	 * @param text
	 *            页签上的名称
	 */
	public IMainContainer selectTab(String text);

	/**
	 * 选中某页
	 * 
	 * @param index
	 *            页签的序号，从0开始
	 */
	public IMainContainer selectTab(int index);

	/**
	 * 关闭某页
	 * 
	 * @param text
	 */
	public IMainContainer closeTab(String text);

	/**
	 * 关闭某页
	 * 
	 * @param index
	 *            页签的序号，从0开始
	 */
	public IMainContainer closeTab(int index);

	/**
	 * 关闭所有已经打开的页签
	 */
	public void closeAllTab();
	
	/**
	 * 检查form页名字改变是否正确
	 */
	public void checkFormkey(int index, String formKey, String msg);

}
