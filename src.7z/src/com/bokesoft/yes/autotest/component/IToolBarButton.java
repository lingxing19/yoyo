package com.bokesoft.yes.autotest.component;

public interface IToolBarButton {
	/**
	 * 点击工具栏按钮
	 */
	public IToolBarButton click();
}
