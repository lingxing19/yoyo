package com.bokesoft.yes.autotest.component.passwordeditor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IPasswordEditor;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;
import com.sun.org.apache.xml.internal.security.keys.content.RetrievalMethod;

public class BasePasswordEditor extends AbstractComponent implements IPasswordEditor {

	public BasePasswordEditor(String key) {

		this.key = key;
		this.el = driver.findElement(By.xpath("//span[@id='" + formID + "_" + key + "']"));

	}

	/**
	 * 文本框编辑输入测试
	 * 
	 * @param text
	 * @return
	 */

	public IControl input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	/**
	 * 编辑框取值
	 */
	public String getText() {
		String s = el.findElement(By.tagName("input")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	/**
	 * 光标默认全选时有效
	 * 
	 * @return
	 */
	public void pressBackspaceKey() {
		LogImpl.getInstance().info("选中，按Backspace键，清空");
		el.findElement(By.tagName("input")).click();
		RobotUtil.pressBackspaceKey();
	}

	/**
	 * 模拟键盘enter键操作
	 */
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();
	}

	/**
	 * 模拟键盘Tab键操作
	 */
	public void pressTabKey() {
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();
	}

	/**
	 * 检测规则红色角标测试
	 */
	public boolean isRedcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("error-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * 必填黄色角标测试
	 */
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("require-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * 可见性测试
	 */
	public boolean isDisplayed() {

		return el.isDisplayed();
	}

	/**
	 * 可用性测试
	 */
	public boolean isEnabled() {

		return el.isEnabled();
	}

	/**
	 * 悬浮提示测试
	 */
	public String getHovertext() {

		return el.getAttribute("title");
	}

	/**
	 * 错误描述测试
	 */
	public String getErrorInfo() {
		return el.findElement(By.className("error-icon")).getAttribute("title");
	}

	/**
	 * 空值提示测试
	 * 
	 * @return
	 */
	public String getPromptText() {
		return el.findElement(By.tagName("input")).getAttribute("placeholder");
	}

	/**
	 * 内嵌文本测试
	 * 
	 * @return
	 */
	public String getEmbedText() {
		return el.findElement(By.className("embed")).getAttribute("textContent");
	}

	/**
	 * 左侧图标测试
	 * 
	 * @return
	 */
	public boolean getPreIcon(String iconName) {
		// String s =
		// el.findElement(By.className("pre-icon")).getAttribute("baseURI");
		// String s2 =
		// el.findElement(By.className("pre-icon")).getCssValue("background-image");
		// int beginIndex = s2.indexOf(s) + s.length();
		// String s3 = s2.substring(beginIndex, s2.length() - 2);
		// return s3;
//
//		String s2 = el.findElement(By.className("pre-icon")).getAttribute("Style");
//
//		String re1 = "background-image: url\\(\"(.*?)\"\\)"; // Word 1
//
//		Pattern p = Pattern.compile(re1, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
//		Matcher m = p.matcher(s2);
//		String word1 = "";
//		if (m.find()) {
//			word1 = m.group(1);
//		}
//
//		return word1;
		String s = el.findElement(By.xpath(".//span[@class='pre-icon']")).getAttribute("style");
		if (s.contains(iconName)) {
			return  true ;	
		}
		return false ;
	}

	/**
	 * 前景色测试
	 */
	public String getForeColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	/**
	 * 编辑框内水平左右居中方向测试
	 */
	public String getHalign() {
		return el.findElement(By.tagName("input")).getCssValue("text-align");
	}

	/**
	 * 背景色测试
	 */
	public String getBackColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	/**
	 * 字体名称测试
	 */
	public String getFontName() {
		return el.findElement(By.tagName("input")).getCssValue("font-family");
	}

	/**
	 * 字体大小测试
	 */
	public String getFontSize() {
		return el.findElement(By.tagName("input")).getCssValue("font-size");
	}

	/**
	 * 字体粗细测试
	 */
	public String getFontWeight() {
		return el.findElement(By.tagName("input")).getCssValue("font-weight");
	}

	/**
	 * 字体样式测试
	 */
	public String getFontStyle() {
		return el.findElement(By.tagName("input")).getCssValue("font-style");
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
	/**
	 * 点击操作
	 */
	public IPasswordEditor click() {
		el.findElement(By.tagName("input")).click();
		return this ;
	}
	
	/**
	 * 清空编辑框
	 */
	public void clear() {
		el.findElement(By.xpath(".//span[@class='clear']")).click();
	}
}
