package com.bokesoft.yes.autotest.component.changepassword;

import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IChangePasswordEditor;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class BaseChangePasswordEditor extends AbstractComponent implements IChangePasswordEditor {

	public BaseChangePasswordEditor(String key){
		
		this.key = key;
		this.el = driver.findElement(By.xpath("//span[@id='"+"1"+"_" +key+"']"));

	}
	
	/**
	 * 密码框编辑输入测试
	 * @param text
	 * @return
	 */
	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		LogImpl.getInstance().info("字段："+key+"输入："+text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}
	
	/**
	 * 编辑框取值
	 */
	@Override
	public String getText() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("input")).getAttribute("value");
//		System.out.println(s);
		return s;
	}
	
	/**
	 * 光标默认全选时有效
	 * @return
	 */
	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub
		LogImpl.getInstance().info("选中，按Backspace键，清空");
		el.findElement(By.tagName("input")).click();
		RobotUtil.pressBackspaceKey();
	}
	
	/**
	 * 模拟键盘enter键操作
	 */
	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();
	}


	/**
	 * 模拟键盘Tab键操作
	 */
	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();	
	}
	
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub
		
	}

	
	
	

	

}
