package com.bokesoft.yes.autotest.component.CheckListBox;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.ICheckListBox;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.grid.BaseGrid;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class BaseCheckListBox extends AbstractComponent implements ICheckListBox {

	protected WebElement view = null;

	public BaseCheckListBox(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
		try {
			this.view = driver.findElement(By.id(formID + "_" + key + "_view"));
		} catch (NoSuchElementException e) {
			// TODO: handle exception
		}
	}

	@Override
	public BaseCheckListBox dropDownClick() {
		LogImpl.getInstance().info("点击多选下拉框：" + key);
		el.findElement(By.className("arrow")).click();
		view = driver.findElement(By.id(formID + "_" + key + "_view"));
		waittime(500);
		return this;
	}

	/**
	 * 关闭下拉框
	 */
	public void backClick() {
		el.findElement(By.xpath("./div[@class='arrow']")).click();
		waittime(500);
		
	}
	// @Override
	// public BaseCheckListBox itemClick(String ...itemName) {
	// List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
	// for (String s : itemName) {
	// for (WebElement el : li) {
	// String trim = el.findElement(By.xpath("./span[2]")).getText().trim();
	// if(trim.equals(s.trim())){
	// el.findElement(By.xpath("./span[1]")).click();
	// return this;
	// }
	// }
	// }
	// return this;
	// }

	@Override
	public BaseCheckListBox itemClick(String... itemName) {
		LogImpl.getInstance().info("勾选多选下拉项");
		waittime(1000);
		List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
		for (String s : itemName) {
			for (WebElement el : li) {
				String trim = el.getText().trim();
				// String trim =
				// el.findElement(By.tagName("span")).getText().trim();
				if (trim.equals(s.trim())) {
					el.findElement(By.tagName("span")).click();
					waittime(300);
				}
			}
		}
		return this;
	}
	/**
	 * 多选下拉框确定、取消、消除按钮
	 * @param 确定、取消、消除
	 * @return
	 */
	public BaseCheckListBox clickName(String text){
		WebElement el = view.findElement(By.xpath(".//div/div[@class='chainmean']/span[text()='" + text + "']"));
		el.click();
        waittime(200);
		return this;
	} 

	@Override
	public boolean isDisplayed() {
		return el.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		return el.isEnabled();
	}

	@Override
	public IControl input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	@Override
	public String getHovertext() {
		return el.getAttribute("title");
	}

	@Override
	public String getHalign() {
		return el.findElement(By.tagName("input")).getCssValue("text-align");
	}

	@Override
	public String getForeColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	@Override
	public String getBackColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	@Override
	public String getFontName() {
		return el.findElement(By.tagName("input")).getCssValue("font-family");
	}

	@Override
	public String getFontSize() {
		return el.findElement(By.tagName("input")).getCssValue("font-size");
	}

	@Override
	public String getFontWeight() {
		return el.findElement(By.tagName("input")).getCssValue("font-weight");
	}

	@Override
	public String getFontStyle() {
		return el.findElement(By.tagName("input")).getCssValue("font-style");
	}

	@Override
	public boolean isRedcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("error-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public String getErrorInfo() {
		return el.findElement(By.className("error-icon")).getAttribute("title");
	}

	@Override
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("require-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();

	}

	@Override
	public void pressTabKey() {
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();

	}

	@Override
	public void pressBackspaceKey() {
		LogImpl.getInstance().info("选中，按Backspace键，清空");
		el.findElement(By.tagName("input")).click();
		RobotUtil.pressBackspaceKey();
	}

	public String getText() {
		String s = el.findElement(By.tagName("input")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	/**
	 * 获取下拉项取值
	 */
	public String getItems() {
		List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
		String s = "";
		for (WebElement el : li) {
			System.out.println(el.getText());
			s += el.getText();
		}
		return s;
	}

	/**
	 * 空值提示测试
	 * 
	 * @return
	 */
	public String getPromptText() {
		return el.findElement(By.tagName("input")).getAttribute("placeholder");
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
	/**
	 * 判断选项 是否显示选中 
	 */
	public boolean isChecked(String itemName) {
		WebElement element =view.findElement(By.xpath("./ul/li[@title='"+ itemName+"']/span[1]"));
		if (element.getAttribute("class").contains("checked")) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 判断下列框按钮是否存在
	 * @param buttonName
	 * @return
	 */
	public boolean isButton(String buttonName) {
		WebElement element =view.findElement(By.xpath(".//div[@class='chainmean']/span[text()='"+ buttonName+"']"));
		if (element.getText().equals(buttonName)) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
}