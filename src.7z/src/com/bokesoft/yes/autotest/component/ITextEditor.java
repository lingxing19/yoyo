package com.bokesoft.yes.autotest.component;

public interface ITextEditor extends IControl {

	public ITextEditor click();

	public ITextEditor dbClick();

	public String getPromptText();

	public String getEmbedText();

	public boolean isPreIcon(String iconName);

	public String getText();

	public ITextEditor ctrlA();

	public ITextEditor ctrlC();

	public ITextEditor ctrlV();

	public ITextEditor paste(String text);

	public ITextEditor clearClick();

	public ITextEditor clear();

	public boolean isFocusOn();

	public boolean isClearButton();

}
