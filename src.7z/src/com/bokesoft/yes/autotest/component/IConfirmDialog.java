package com.bokesoft.yes.autotest.component;

public interface IConfirmDialog {

	public IConfirmDialog okClick();

	public IConfirmDialog yesClick();

	public IConfirmDialog noClick();

	public IConfirmDialog cancelClick();

	public IConfirmDialog close();

	public String getText();

}
