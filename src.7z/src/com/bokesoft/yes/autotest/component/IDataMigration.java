package com.bokesoft.yes.autotest.component;

public interface IDataMigration {

}
