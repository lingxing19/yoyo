package com.bokesoft.yes.autotest.component;

import java.util.List;

import com.bokesoft.yes.autotest.component.grid.BaseGrid;
import com.bokesoft.yes.autotest.component.grid.BaseGridDictItem;

public interface IGrid {
	
	/**
	 * @param colName 列名,有隐藏列时输入数字
	 * @return 列号，从0开始（包含序号列）
	 */
	public int getColIndex(String colName);
	
	/**
	 * 向前翻一页
	 * @return
	 */
	public IGrid prevClick();
	
	/**
	 * 向后翻一页
	 * @return
	 */
	public IGrid nextClick();
	
	/**
	 * 直接跳转至某页
	 * @param pagenum  要跳转的页号
	 * @return
	 */
	public IGrid pageClick(int pagenum);
	
	/**
	 * 将分页情况下,设置到第一页
	 * @return
	 */
	public IGrid toFirstClick();
	
	/**
	 * 将分页情况下,设置到最后一页
	 * @return
	 */
	public IGrid toLastClick();
	
	/**
	 * 单元格单击
	 * @param colName 列名
	 * @param index 行序号
	 * @return
	 */
	public IGrid cellClick(String colName,int index);
	
	/**
	 * 单元格双击
	 * @param colName 列名
	 * @param index 行序号
	 * @return
	 */
	public IGrid cellDbClick(String colName,int index);
	
	/**
	 * 单击单元格，输入值 
	 */
    public BaseGrid cellInput(String colName,int index,String text);
	
	/**
	 * 双击单元格，输入值
	 * @return
	 */
    public BaseGrid cellDbInput(String colName,int index,String text);
	
	/**
	 * 点击单元格复选框
	 * @param colName  列名
	 * @param index    行序号
	 * @return
	 */
	public IGrid cellCheckboxClick(String colName,int index);

	
	/**
	 * 单元格日期下拉框输入年月日
	 * @param colName 列名
	 * @param index   行序号
	 * @param year    年份，整数
	 * @param month   月份，整数
	 * @param day     日期，整数
	 * @return
	 */
	public IGrid cellDPViewInput(String colName, int index,int year,int month,int day);
	
	/**
	 * 单元格日期下拉框输入时间
	 * @param colName 列名
	 * @param index   行序号
	 * @param year    年份，整数
	 * @param month   月份，整数
	 * @param day     日期，整数
	 * @param hour    时间，整数
	 * @param minute  分钟，整数
	 * @param second  秒，整数
	 * @return
	 */
	public IGrid cellDPViewInput(String colName, int index,int year,int month,int day,int hour,int minute,int second);
	
	/**
	 * 单元格日期框输入当前时间
	 * @param colName  列名
	 * @param index    行序号
	 * @return
	 */
	public IGrid cellCurrenttimeInput(String colName, int index);
	
	/**
	 * 点击单元格按钮
	 * @param colName 列名  
	 * @param index   行序号
	 * @return
	 */
	public IGrid cellButtonClick(String colName, int index); 
	
	/**
	 * 点击单元格文本按钮
	 * @param colName 列名  
	 * @param index   行序号
	 * @return
	 */
	public IGrid cellTextButtonClick(String colName, int index); 
	
	/**
	 * 点开，字典下拉框
	 */
	public IGrid celDictClick(String colName, int index);
	
	/**
	 * 收起单元格 下拉框 
	 */
	public BaseGrid celViewClose(String colName, int index);
	
	/**
	 * 选中字典项
	 * @param itemName  字典项名称（代码、名称）
	 */
	public IGrid dictItemClick(String itemName);
	
	/**
	 * 展开字典项
	 * @param itemName 字典项名称（代码、名称）
	 *
	 */
	public IGrid dictExpandItemClick(String itemName);
	
	/**
	 * 收起字典项
	 * @param itemName  字典项名称（代码、名称）
	 */
	public IGrid dictCollapseItemClick(String itemName);
	
	/**
	 * 获得根节点
	 */
	public String getDictRootNode();
	
	
	/**
	 * 勾选字典项
	 * @param itemName  字典项名称（代码、名称）
	 */
	public IGrid dictItemCheckClick(String itemName);
	
	
	/**
	 *展开下拉框
	 */
	public IGrid celComboClick(String colName, int index);
	
	/**
	 * 点击选中
	 * @param itemName 下拉项名称
	 */
	public IGrid comboItemClick(String itemName);
	
	/**
	 * 点击选中自动匹配项
	 * @param itemName  下拉项名称
	 */
	public IGrid gridComboAutoItemClick(String itemName);
	
	/**
	 * 获取下拉框自动匹配下拉项
	 */
	public String getGridComboAutoItems();
	
	/**
	 *展开多选下拉框
	 */
	public IGrid celCheckListClick(String colName, int index);
	
	/**
	 * 勾选\去掉勾选
	 * @param itemName 下拉项名称
	 */
	public IGrid checkListItemClick(String ...itemName);
	
	/**
	 * 点击单元格超链接
	 * @param colName  列名
	 * @param index    行序号
	 * @return
	 */
	public IGrid cellHyperLinkClick(String colName, int index);
	
	/**
	 * 树形表格，点击展开/不展开
	 * @param colName  列名
	 * @param index	        行序号
	 * @return
	 */
	public IGrid cellTreeIconClick(String colName, int index);
	
	/**
	 * 清空单元格
	 * @return
	 */
	public IGrid cellClear(String colName, int index);
	
	/**
	 * 获得单元格的值
	 * @param colName 列名
	 * @param index  行序号
	 * @return
	 */
	public String getCellValue(String colName,int index);
	
	/**
	 * 点击“+”号
	 * @return
	 */
	public IGrid addRowClick();
	
	/**
	 * 点击“-”号
	 * @return
	 */
	public IGrid deleteRowClick();
	
	/**
	 * 点击“↑”号
	 * @return
	 */
	public IGrid upRowClick();
	
	/**
	 * 点击“↓”号
	 * @return
	 */
	public IGrid downRowClick();
	
	/**
	 * 点击“自定义操作”
	 * @return
	 */
	public IGrid customOptClick(); 
	
	
/*	*//**
	 * 当前某列是升序\降序\无序
	 * @return "desc"或者“asc”或者“unsortable”
	 *//*
	public String getCurrentSortType(String colName);*/
	
	/**
	 * ctrl+c，复制
	 */
	public IGrid ctrlC();
	
	/**
	 * ctrl+v,粘贴
	 */
	public IGrid ctrlV();
	
	
	/**
	 * @param colName1   源单元格的列名
	 * @param index1        源单元格的行序号
	 * @param colName2   目标单元格的列名
	 * @param index2        目标单元格的行序号
	 * @return
	 */
	public IGrid dragAndDrop(String colName1,int index1,String colName2,int index2);
	
	/**
	 * 单元格是否存在红色角标
	 * @param colName 列名
	 * @param index   行序号
	 * @return
	 */
	public boolean isRedcornerExist(String colName,int index);
	
	/**
	 * 行序号上是否存在红色角标
	 * @param index  行序号
	 * @return
	 */
	public boolean isRedcornerExist(int index);

	/**
	 * 获取子节点各属性
	 */
	public List<BaseGridDictItem> getChildren(boolean root);
   

	/**
	 * 获取字典根节点勾选状态
	 * 
	 */
    public String getDictRootChkstate();
    
    /**
     * 字典节点选中
     */
    public BaseGrid gridDictItemClick(String itemCode);
   
    /**
     * 单元格复选框是否选中
     */
    public boolean isCelCheckBoxChecked(String colName, int index);
    
    /**
     * 获取下拉框下拉项
     */
    public String getGridComboBoxItems();
    
    /**
     * 获取多选下拉框下拉项
     */
    public String getGridCheckListItems();
    
    /**
     * 单元格多选下拉框下拉项是否选中
     */
    public boolean gridCheckListItemChecked(String itemName);
    
    /**
     * 单击录入字符
     */
    public BaseGrid paste(String text);
    

    /**
     * 双击录入字符 
     */
    public BaseGrid dbPaste(String colName,int index ,String text);
    
  
    public String getColBackColor(String colName,int index);
    
	public void pressBackspaceKey(int left,int num) ;


	BaseGrid celldoubleClick(String colName, int index);
	
	

}

