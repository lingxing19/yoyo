package com.bokesoft.yes.autotest.component;

public interface IHyperLink extends IControl {
	public IHyperLink click();

	public String getText();
}
