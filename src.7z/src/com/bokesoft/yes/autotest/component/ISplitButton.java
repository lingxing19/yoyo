package com.bokesoft.yes.autotest.component;

import com.bokesoft.yes.autotest.component.splitbutton.BaseSplitButton;

public interface ISplitButton extends IControl {

	public ISplitButton click();

	/**
	 * 展开/收起下拉项集合
	 */
	public ISplitButton dropDownClick();

	/**
	 * 点击选中
	 * 
	 * @param itemName
	 *            下拉项集合名称
	 */
	public BaseSplitButton itemClick(String itemName);
	
	public boolean isIcon(String iconName);
	
	public boolean isClicked();
	
	public String getItemNames();

}
