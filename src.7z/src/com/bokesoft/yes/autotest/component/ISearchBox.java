package com.bokesoft.yes.autotest.component;

public interface ISearchBox {

	/**
	 * 搜索单据，并打开
	 * 
	 * @param entryName
	 *            entry中的名称
	 */
	public void searchclick(String entryName);

}
