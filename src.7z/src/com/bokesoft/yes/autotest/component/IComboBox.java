package com.bokesoft.yes.autotest.component;

public interface IComboBox extends IControl {

	/**
	 * 展开/收起下拉框
	 */
	public IComboBox dropDownClick();

	/**
	 * 点击选中
	 * 
	 * @param itemName
	 *            下拉项名称
	 */
	public IComboBox itemClick(String itemName);

	/**
	 * 点击选中自动匹配项
	 * 
	 * @param itemName
	 *            下拉项名称
	 */
	public IComboBox autoItemClick(String itemName);

	public IComboBox click();

	public IComboBox clear();

	public String getText();

	public String getItems();
	
	public String getAutoItems();
	
	public String isSelected();
	
	public void backClick();

}
