package com.bokesoft.yes.autotest.component;

public interface IPasswordConfirm {

	public IPasswordConfirm okClick();

	public IPasswordConfirm cancelClick();

}
