package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IDataMigration;
import com.bokesoft.yes.autotest.component.datamigration.BaseDataMigration;

public class DataMigration {

	/**
	 * @param key 配置中控件的Key
	 * @return
	 */
	public static IDataMigration element(String key){
		return new BaseDataMigration(key);
	}
}
