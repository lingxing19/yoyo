package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IMenuEntry;
import com.bokesoft.yes.autotest.component.menuentry.BaseMenuEntry;

public class MenuEntry {
	/**
	 * @param path
	 *            导航
	 *            <li>标签 path的属性值
	 * 
	 */
	public static IMenuEntry element(String path) {
		return new BaseMenuEntry(path);
	}
}
