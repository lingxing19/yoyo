package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ITextArea;
import com.bokesoft.yes.autotest.component.textarea.BaseTextArea;

public class TextArea {
	/**
	 * @param key
	 *            配置中控件的Key
	 * @return
	 */
	public static ITextArea element(String key) {
		return new BaseTextArea(key);
	}
}
