package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IDict;
import com.bokesoft.yes.autotest.component.dict.BaseDict;
import com.bokesoft.yes.autotest.component.texteditor.BaseTextEditor;

public class Dict {
	/**
	 * @param key 配置中控件的Key
	 * @return
	 */
	public static IDict element(String key){
		return new BaseDict(key);
	}
}
