package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IRadioButton;
import com.bokesoft.yes.autotest.component.radiobutton.BaseRadioButton;

public class RadioButton {
	/**
	 * @param key
	 *            按钮名称
	 * @return
	 */
	public static IRadioButton element(String key) {
		return new BaseRadioButton(key);
	}
}
