package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IDropdownButton;
import com.bokesoft.yes.autotest.component.dropdownbutton.BaseDropdownButton;

public class DropdownButton {

	public static IDropdownButton element(String key) {
		
		return new BaseDropdownButton(key);
	}

}
