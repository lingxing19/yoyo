package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IDictView;
import com.bokesoft.yes.autotest.component.dictview.BaseDictView;

public class DictView {
	/**
	 * @param key 配置中控件的Key
	 * @return
	 */
	public static IDictView element(){
		return new BaseDictView();
	}
}
