package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IDictQueryBox;
import com.bokesoft.yes.autotest.component.dictquerybox.BaseDictQueryBox;

public class DictQueryBox {

	public static IDictQueryBox element(String col, String key, boolean isGrid) {
		return new BaseDictQueryBox(col, key, isGrid);
	}

	public static IDictQueryBox element(String row, String columnkey) {
		return new BaseDictQueryBox(row, columnkey);
	}

	public static IDictQueryBox element(String dictkey) {
		return new BaseDictQueryBox(dictkey);
	}
}
