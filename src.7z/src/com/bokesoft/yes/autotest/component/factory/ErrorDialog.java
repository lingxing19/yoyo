package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IErrorDialog;
import com.bokesoft.yes.autotest.component.errordialog.BaseErrorDialog;

public class ErrorDialog {

	public static IErrorDialog element() {

		return new BaseErrorDialog();
	}
}
