package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ITabPanel;
import com.bokesoft.yes.autotest.component.tabpanel.BaseTabPanel;

public class TabPanel {
	/**
	 * @param key
	 *            配置中控件的Key
	 * @return
	 */
	public static ITabPanel element(String key) {
		return new BaseTabPanel(key);
	}

}
