package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ITextButton;
import com.bokesoft.yes.autotest.component.textbutton.BaseTextButton;

public class TextButton {
	/**
	 * @param key
	 *            配置中控件的Key
	 * @return
	 */
	public static ITextButton element(String key) {
		return new BaseTextButton(key);
	}
}
