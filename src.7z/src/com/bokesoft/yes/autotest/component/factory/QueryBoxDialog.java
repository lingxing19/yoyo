package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IQueryBoxDialog;
import com.bokesoft.yes.autotest.component.queryboxdialog.BaseQueryBoxDialog;

public class QueryBoxDialog {

	public static IQueryBoxDialog element() {
		return new BaseQueryBoxDialog();
	}
}
