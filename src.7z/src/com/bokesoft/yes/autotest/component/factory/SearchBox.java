package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ISearchBox;
import com.bokesoft.yes.autotest.component.searchbox.BaseSearchBox;

public class SearchBox {

	public static ISearchBox element() {
		return new BaseSearchBox();
	}
}
