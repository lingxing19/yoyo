package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IFunction;
import com.bokesoft.yes.autotest.component.function.BaseFunction;

public class Function {

public static IFunction element(String key){
		
		return new BaseFunction(key);
	}
}
