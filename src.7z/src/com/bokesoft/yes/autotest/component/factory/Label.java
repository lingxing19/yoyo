package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ILabel;
import com.bokesoft.yes.autotest.component.Label.BaseLabel;

public class Label {
	/**
	 * @param key
	 *            配置中控件的key
	 * @return
	 */
	public static ILabel element(String key) {
		return new BaseLabel(key);
	}
}
