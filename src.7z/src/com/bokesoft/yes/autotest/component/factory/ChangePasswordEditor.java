package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IChangePasswordEditor;
import com.bokesoft.yes.autotest.component.changepassword.BaseChangePasswordEditor;

public class ChangePasswordEditor {

	public static IChangePasswordEditor element(String key) {

		return new BaseChangePasswordEditor(key);

	}

}
