package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IConfirmDialog;
import com.bokesoft.yes.autotest.component.confirmdialog.BaseConfirmDialog;

public class ConfirmDialog {

	public static IConfirmDialog element() {

		return new BaseConfirmDialog();

	}
}