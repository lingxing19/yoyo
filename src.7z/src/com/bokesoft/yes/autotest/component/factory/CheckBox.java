package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ICheckBox;
import com.bokesoft.yes.autotest.component.checkbox.BaseCheckBox;

public class CheckBox {
	/**
	 * @param key
	 *            按钮名称
	 * @return
	 */
	public static ICheckBox element(String key) {
		return new BaseCheckBox(key);
	}
}
