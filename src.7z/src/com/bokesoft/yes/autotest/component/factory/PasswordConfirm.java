package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IPasswordConfirm;
import com.bokesoft.yes.autotest.component.passwordconfirm.BasePasswordConfirm;

public class PasswordConfirm {

	public static IPasswordConfirm element() {

		return new BasePasswordConfirm();

	}
}
