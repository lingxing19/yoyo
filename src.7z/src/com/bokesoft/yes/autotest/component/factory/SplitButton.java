package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ISplitButton;
import com.bokesoft.yes.autotest.component.splitbutton.BaseSplitButton;

public class SplitButton {

	public static ISplitButton element(String key) {

		return new BaseSplitButton(key);
	}

}
