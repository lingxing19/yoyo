package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IComboBox;
import com.bokesoft.yes.autotest.component.combobox.BaseComboBox;

public class ComboBox {
	/**
	 * @param key
	 *            配置中控件的Key
	 * @return
	 */
	public static IComboBox element(String key) {
		return new BaseComboBox(key);
	}
}
