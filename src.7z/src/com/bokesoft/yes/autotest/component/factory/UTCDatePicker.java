package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IUTCDatePicker;
import com.bokesoft.yes.autotest.component.utcdatepicker.BaseUTCDatePicker;

public class UTCDatePicker {

	public static IUTCDatePicker element(String key) {

		return new BaseUTCDatePicker(key);
	}
}
