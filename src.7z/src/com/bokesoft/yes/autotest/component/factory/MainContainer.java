package com.bokesoft.yes.autotest.component.factory;

import org.apache.http.impl.conn.tsccm.WaitingThread;

import com.bokesoft.yes.autotest.component.IMainContainer;
import com.bokesoft.yes.autotest.component.maincontainer.BaseMainContainer;

public class MainContainer {

	private static IMainContainer main = new BaseMainContainer();

	/**
	 * @param text
	 *            tab页上的名称
	 * @return
	 */
	public static IMainContainer selectTab(String text) {
		// TODO save formID
		return main.selectTab(text);
	}

	/**
	 * @param index
	 *            第几个打开的表单，从0开始
	 * @return
	 */
	public static IMainContainer selectTab(int index) {
		return main.selectTab(index);

	}

	public static IMainContainer closeTab(int index) {
		return main.closeTab(index);
	}

	public static IMainContainer closeTab(String text) {
		return main.closeTab(text);
	}

	public static void closeAllTab() {

		main.closeAllTab();
	}
}
