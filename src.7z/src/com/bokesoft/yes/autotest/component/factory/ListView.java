package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.listview.BaseListView;

public class ListView {
	/**
	 * @param key
	 *            配置中控件的key
	 * @return
	 */
	public static BaseListView element(String key) {
		return new BaseListView(key);
	}

}
