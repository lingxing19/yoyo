package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IToolBarButton;
import com.bokesoft.yes.autotest.component.toolbarbutton.BaseToolBarButton;

public class ToolBarButton {
	/**
	 * @param key
	 *            按钮名称
	 * @return
	 */
	public static IToolBarButton element(String key) {
		return new BaseToolBarButton(key);
	}
}
