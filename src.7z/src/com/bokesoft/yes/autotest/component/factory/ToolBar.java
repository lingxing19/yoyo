package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.IToolBar;
import com.bokesoft.yes.autotest.component.toolbar.BaseToolBar;

public class ToolBar {

	public static IToolBar element(String key) {

		return new BaseToolBar(key);
	}

}
