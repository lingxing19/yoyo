package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ICheckListBox;
import com.bokesoft.yes.autotest.component.CheckListBox.BaseCheckListBox;

public class CheckListBox {
	/**
	 * @param key
	 *            配置中控件的Key
	 * @return
	 */
	public static ICheckListBox element(String key) {
		return new BaseCheckListBox(key);
	}
}
