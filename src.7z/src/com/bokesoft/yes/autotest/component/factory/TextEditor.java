package com.bokesoft.yes.autotest.component.factory;

import com.bokesoft.yes.autotest.component.ITextEditor;
import com.bokesoft.yes.autotest.component.texteditor.BaseTextEditor;

public class TextEditor {
	/**
	 * @param key
	 *            配置中控件的Key
	 * @return
	 */
	public static ITextEditor element(String key) {
		return new BaseTextEditor(key);
	}
}
