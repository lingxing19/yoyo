package com.bokesoft.yes.autotest.component.utcdatepicker;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IUTCDatePicker;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class BaseUTCDatePicker extends AbstractComponent implements IUTCDatePicker {

	protected WebElement datepickerview = null;

	public BaseUTCDatePicker(String key) {
		this.key = key;

		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
	}

	// 点开日期输入弹出框
	protected BaseUTCDatePicker viewClick() {
		el.findElement(By.xpath("//span[@id='dateImg_" + formID + "_" + key + "']")).click();

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
		wait.pollingEvery(100, TimeUnit.MILLISECONDS).withTimeout(10, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		datepickerview = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.id(formID + "_" + key + "_datepickerView")));

		// datepickerview=driver.findElement(By.xpath("//div[@id='"+formID+"_"
		// +key+"_datepickerView']"));
		return this;
	}

	@Override
	public BaseUTCDatePicker viewInput(int year, String month, int day) {

		LogImpl.getInstance().info("在日期选择框中输入：" + year + "年" + month + "月" + day + "日");
		viewClick();

		WebElement sElement = datepickerview.findElement(By.xpath(".//div[@class='datepicker']"));
		WebElement container = sElement.findElement(By.xpath(".//div[@class='datepickerContainer']"));

		// 左右键，选择年
		WebElement year1 = container.findElement(By.xpath(".//thead//th[@class='datepickerMonth']//span"));
		WebElement goprev = container.findElement(By.xpath(".//thead//th[@class='datepickerGoPrev']//span"));
		WebElement gonext = container.findElement(By.xpath(".//thead//th[@class='datepickerGoNext']//span"));
		year1.click();

		int y = Integer.parseInt(year1.getText()); // 获得当前年的数值
		int temp = y - year;
		if (temp > 0) {
			while (temp > 0) {
				goprev.click();
				temp--;
			}
		}
		if (temp < 0) {
			while (temp < 0) {
				gonext.click();
				temp++;
			}
		}

		// 选择月份
		WebElement months = container.findElement(By.xpath(".//tbody[@class='datepickerMonths']"));
		List<WebElement> monthlist = months.findElements(By.xpath(".//td//a/span"));

		for (WebElement el : monthlist) {

			// System.out.println( el.getText());
			String txt = el.getText();
			if (txt.equalsIgnoreCase("" + month)) {
				el.click();
				break;
			}
		}

		// monthlist.get(month-1).click();
		// monthlist.click();

		// 选择日期
		WebElement datepickerDays = container.findElement(By.xpath(".//tbody[@class='datepickerDays']"));
		List<WebElement> days = datepickerDays
				.findElements(By.xpath(".//td[not(contains(@class,'datepickerNotInMonth'))]//a/span"));

		for (WebElement el : days) {
			String txt = el.getText();
			if (txt.equalsIgnoreCase("" + day)) {
				el.click();
				break;
			}
		}
		return this;
	}

	// List<WebElement>
	// daylist=container.findElements(By.xpath(".//tbody[@class='utcdatepickerDays']//td"));
	// List<WebElement>
	// notinmonth=container.findElements(By.xpath(".//td//a/span"));
	// daylist.removeAll(notinmonth);
	// daylist.get(day-1).click();
	//
	// return this;
	// }

	@Override
	public BaseUTCDatePicker viewInput(int year, String month, int day, int hour, int minute, int second) {
		viewInput(year, month, day);
		LogImpl.getInstance().info("输入时间：" + hour + "：" + minute + "：" + second);
		List<WebElement> timelist = datepickerview.findElements(By.xpath(".//div[@class='time']/input"));
		timelist.get(0).click();
		RobotUtil.pressBackspaceKey();
		// timelist.get(0).clear();

		timelist.get(0).sendKeys(String.valueOf(hour));

		timelist.get(1).click();
		RobotUtil.pressBackspaceKey();
		// timelist.get(1).clear();
		timelist.get(1).sendKeys(String.valueOf(minute));

		timelist.get(2).click();
		RobotUtil.pressBackspaceKey();
		// timelist.get(2).clear();
		String s = timelist.get(1).getAttribute("value");
		timelist.get(2).sendKeys(String.valueOf(second));
		datepickerview.findElement(By.xpath(".//div[@class='time']/button[1]")).click();
		return this;
	}

	/**
	 * 
	 * 编辑框内字符清空
	 * 
	 * @return
	 */
	public IUTCDatePicker clear() {
		LogImpl.getInstance().info("字段：" + key + "清空");
		el.findElement(By.tagName("input")).clear();
		return this;
	}

	@Override
	public BaseUTCDatePicker inputCurrenttime() {
		LogImpl.getInstance().info("输入当前时间");
		viewClick();

		// WebElement sElement =
		// datepickerview.findElement(By.xpath("//div[@class='datepicker']"));

		WebElement element = datepickerview.findElement(By.xpath("//div[@class='time']/button[1]"));
		waittime(500);
		datepickerview.findElement(By.xpath("//div[@class='time']/button[1]")).click();
		return this;
	}

	/**
	 * 编辑框取值
	 */
	public String getText() {
		String s = el.findElement(By.tagName("input")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	@Override
	public boolean isDisplayed() {

		return el.isDisplayed();
	}

	@Override
	public boolean isEnabled() {

		return el.isEnabled();
	}

	@Override
	public IControl input(String text) {

		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	@Override
	public String getHovertext() {

		return el.getAttribute("title");
	}

	/**
	 * 检测规则红色角标测试
	 */
	public boolean isRedcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("error-icon"));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 必填黄色角标测试
	 */
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看黄色角标");
		try {

			el.findElement(By.className("require-icon"));
			return true;
		} catch (Exception e) {

			return false;
		}
	}

	@Override
	public String getHalign() {

		return null;
	}

	@Override
	public String getForeColor() {

		String s = el.findElement(By.tagName("input")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	@Override
	public String getBackColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	@Override
	public String getFontName() {

		return el.findElement(By.tagName("input")).getCssValue("font-family");
	}

	@Override
	public String getFontSize() {

		return el.findElement(By.tagName("input")).getCssValue("font-size");
	}

	@Override
	public String getFontWeight() {

		return el.findElement(By.tagName("input")).getCssValue("font-weight");
	}

	@Override
	public String getFontStyle() {

		return el.findElement(By.tagName("input")).getCssValue("font-style");
	}

	@Override
	public String getErrorInfo() {

		return el.findElement(By.className("error-icon")).getAttribute("title");
	}

	@Override
	public String getVertical() {

		return null;
	}

	/**
	 * 模拟Enter键
	 */
	@Override
	public void pressEnterKey() {

		LogImpl.getInstance().info("按Enter键");

		RobotUtil.pressEnterKey();

	}

	/**
	 * 模拟Tab键
	 */
	@Override
	public void pressTabKey() {

		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();
	}

	/**
	 * 光标全选时有效
	 */
	@Override
	public void pressBackspaceKey() {

		LogImpl.getInstance().info("选中，按Backspace键，清空");
		el.findElement(By.tagName("input")).click();
		RobotUtil.pressBackspaceKey();
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}
