package com.bokesoft.yes.autotest.component;

public interface ITextArea extends IControl {

	public String getText();

	public ITextArea clear();

	public ITextArea textArea(String text);

	public ITextArea ctrlA();

	public ITextArea ctrlC();

	public ITextArea ctrlV();

	public ITextArea paste(String text);

	public ITextArea moveCursorKey();
	
	public void  click();

}
