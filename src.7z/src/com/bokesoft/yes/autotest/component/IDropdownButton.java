package com.bokesoft.yes.autotest.component;

import com.bokesoft.yes.autotest.component.dropdownbutton.BaseDropdownButton;

public interface IDropdownButton extends IControl {

	
	public boolean isIcon(String iconName);
	
	public IDropdownButton click();
	
	public String getItems() ;
	
	public void itemClick(String itemName);

}
