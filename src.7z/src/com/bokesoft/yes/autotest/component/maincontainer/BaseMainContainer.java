package com.bokesoft.yes.autotest.component.maincontainer;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IMainContainer;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseMainContainer extends AbstractComponent implements IMainContainer {

	public BaseMainContainer() {

	}

	@Override
	public IMainContainer selectTab(String text) {
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabs-header']/ul/li"));

		WebElement element = null;

		for (WebElement el : list) {
			// 获取tab页上的名称
			String s = el.findElement(By.tagName("label")).getText();
			if (s.equalsIgnoreCase(text.trim())) {
				element = el;
				break;
			}
		}

		if (element == null) {
			throw new RuntimeException("未找到表单:" + text);
		}

		element.click();
		setFormID(element);

		LogImpl.getInstance().info("选中表单:" + text);
		return this;
	}

	@Override
	public IMainContainer selectTab(int index) {
		// waitload(By.xpath("//div[@class='ui-tabs-header']/ul/li"));

		List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabs-header']/ul/li"));
		if (index > list.size()) {
			throw new RuntimeException("最大表单数为：" + list.size() + " ,  当前为：" + index);
		}
		waittime(5000);
		WebElement element = list.get(index);
		element.click();
		setFormID(element);

		LogImpl.getInstance().info("选中第:" + index + "个表单。");
		return this;
	}

	private void setFormID(WebElement element) {
		if (element == null) {
			throw new RuntimeException("错误的表单");
		}
		String aria = element.getAttribute("aria-controls");
		int formID = Integer.parseInt(aria.split("_")[0]);
		AbstractComponent.setFormID(formID);
	}

	@Override
	public IMainContainer closeTab(String text) {
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabs-header']/ul/li"));

		WebElement element = null;

		for (WebElement el : list) {
			// 获取tab页上的名称
			String s = el.findElement(By.tagName("label")).getText();
			if (s.equalsIgnoreCase(text.trim())) {
				element = el;
				break;
			}
		}

		if (element == null) {
			throw new RuntimeException("未找到表单:" + text);
		}

		element.findElement(By.tagName("span")).click();
		try {
			ConfirmDialog.element().yesClick();
		} catch (NoSuchElementException e) {
		}
		LogImpl.getInstance().info("关闭表单:" + text);
		return this;
	}

	@Override
	public IMainContainer closeTab(int index) {
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabs-header']/ul/li"));
		if (index > list.size()) {
			throw new RuntimeException("最大表单数为：" + list.size() + " ,  当前为：" + index);
		}

		WebElement element = list.get(index);

		element.findElement(By.tagName("span")).click();
		try {
			ConfirmDialog.element().yesClick();
		} catch (NoSuchElementException e) {
		}

		LogImpl.getInstance().info("关闭第" + index + "个表单。");
		return this;
	}

	@Override
	public void closeAllTab() {
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabs-header']/ul/li"));
		for (WebElement el : list) {
			el.findElement(By.tagName("span")).click();
			try {
				ConfirmDialog.element().yesClick();
			} catch (NoSuchElementException e) {
			}
		}
		LogImpl.getInstance().info("关闭所有已打开的表单");
	}

	@Override
	public void checkFormkey(int index, String formKey, String msg){
		
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabs-header']/ul/li//label"));
		if (index > list.size()) {
			throw new RuntimeException("最大表单数为：" + list.size() + " ,  当前为：" + index);
		}
		waittime(5000);
		WebElement element = list.get(index);
		String ret = element.getText();
		if(ret.equals(formKey)){
			LogImpl.getInstance().info(msg +"======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg +"======检查失败 预期结果为:"+formKey+"	实际结果为:"+ret);
		
	}
	
	
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}
