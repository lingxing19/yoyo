package com.bokesoft.yes.autotest.component.grid;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.spi.RootCategory;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.bokesoft.yes.autotest.component.AbstractTableComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IGrid;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;
import com.sun.xml.internal.ws.api.model.wsdl.WSDLExtensible;

public class BaseGrid extends AbstractTableComponent implements IGrid {
	private String id = null;
	private String cell = null;
	private String rootId = null;
	protected List<WebElement> list = null;
	// 跳转至第一页的元素,每次切换页都需要重新赋值
	protected WebElement toFirst = null;
	// 跳转至最后一页的元素,每次切换页都需要重新赋值
	protected WebElement toLast = null;
	// 跳转至前一页的元素,每次切换页都需要重新赋值
	protected WebElement prev = null;
	// 跳转至后一页的元素,每次切换页都需要重新赋值
	protected WebElement next = null;

	protected WebElement view = null;

	protected List<WebElement> li = null;

	// 是否扩展
	protected boolean isExtend = false;
	// 是否隐藏
	protected boolean isDisplay = false;

	public BaseGrid(String key) {
		this.key = key;
		this.el = driver.findElement(By.id("gbox_" + formID + "_" + key + ""));
		this.rows = driver.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]"));
		this.head = el.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead//th[@id]"));// 包含序号,不包含标题拓展

		List<WebElement> trs = el
				.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead/tr[contains(@class,'ui-ygrid')]"));
		for (WebElement element : head) {
			if (Integer.parseInt(element.getAttribute("rowspan")) != trs.size()) {
				this.isExtend = true;
				break;
			}
		}

		List<WebElement> tds = el
				.findElements(By.xpath(".//table[@id='" + formID + "_" + key + "']/tbody/tr[@class='ygfirstrow']/td"));
		for (WebElement element : tds) {
			if ("none".equals(element.getCssValue("display"))) {
				this.isDisplay = true;
				break;
			}
		}

		try {
			this.pagesdiv = driver.findElement(By.id("pagination_" + formID + "_" + key + "_pager"));
			paging = true;
		} catch (NoSuchElementException e) {
		}
		if (paging) {
			this.pages = pagesdiv.findElements(By.xpath(".//ul/li"));
			pageCount = pages.size();
			try {
				this.toFirst = driver.findElement(By.id("first_" + formID + "_" + key + "_pager"));
			} catch (NoSuchElementException e) {

			}

			try {
				this.prev = driver.findElement(By.id("prev_" + formID + "_" + key + "_pager"));
			} catch (NoSuchElementException e) {

			}

			try {
				this.toLast = driver.findElement(By.id("last_" + formID + "_" + key + "_pager"));
			} catch (NoSuchElementException e) {

			}

			try {
				this.next = driver.findElement(By.id("next_" + formID + "_" + key + "_pager"));
			} catch (NoSuchElementException e) {

			}

			currentPageNum = Integer.parseInt(
					pagesdiv.findElement(By.xpath(".//li[contains(@class,'highlight')]")).getAttribute("data-num"));
		}
		try {
			view = driver.findElement(By.xpath("//div[contains(@style,'display: block')]"));
			List<WebElement> noli = view.findElements(By.xpath(".//ul[@style='display: none;']/li"));
			li = view.findElements(By.tagName("li"));
			li.removeAll(noli);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public int getColIndex(String colName) {
		// LogImpl.getInstance().info("获得列\""+colName+"\"的列号");
		int colindex = -1;

		if (this.isDisplay) {
			colindex = Integer.parseInt(colName);
			List<WebElement> tds = el.findElements(
					By.xpath(".//table[@id='" + formID + "_" + key + "']/tbody/tr[@class='ygfirstrow']/td"));
			for (int i = 0; i < tds.size(); i++) {
				if (i > colindex - 1) {
					return colindex;
				}
				if ("none".equals(tds.get(i).getCssValue("display"))) {
					if (i <= colindex - 1) {
						colindex++;
					}
				}
			}
			return colindex;
		}

		if (this.isExtend) {
			return Integer.parseInt(colName);
		}

		for (int i = 0; i < head.size(); i++) {
			if (head.get(i).getAttribute("title").trim().equalsIgnoreCase(colName.trim())) {
				colindex = i + 1;
				break;
			}
		}
		return colindex;
	}

	@Override
	public BaseGrid prevClick() {
		LogImpl.getInstance().info("向前翻页");
		if (currentPageNum == 1) {
			LogImpl.getInstance().info("已经是第一页，无法向前翻页");
			return this;
		}
		prev.click();
		waittime(1000);
		rows = driver.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]"));
		pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		toFirst = driver.findElement(By.id("first_" + formID + "_" + key + "_pager"));
		toLast = driver.findElement(By.id("last_" + formID + "_" + key + "_pager"));
		prev = driver.findElement(By.id("prev_" + formID + "_" + key + "_pager"));
		next = driver.findElement(By.id("next_" + formID + "_" + key + "_pager"));
		currentPageNum--;
		return this;
	}

	@Override
	public BaseGrid nextClick() {
		LogImpl.getInstance().info("向后翻一页");
		if (currentPageNum == pageCount) {
			LogImpl.getInstance().info("已经是最后一页，无法向后翻页");
			return this;
		}
		next.click();
		waittime(1000);
		rows = driver.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]"));
		pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		toFirst = driver.findElement(By.id("first_" + formID + "_" + key + "_pager"));
		toLast = driver.findElement(By.id("last_" + formID + "_" + key + "_pager"));
		prev = driver.findElement(By.id("prev_" + formID + "_" + key + "_pager"));
		next = driver.findElement(By.id("next_" + formID + "_" + key + "_pager"));
		currentPageNum++;
		return this;
	}

	@Override
	public BaseGrid pageClick(int pagenum) {
		LogImpl.getInstance().info("跳转到第" + pagenum + "页");
		pages.get(pagenum - 1).click();
		waittime(1000);
		rows = driver.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]"));
		// pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		toFirst = driver.findElement(By.id("first_" + formID + "_" + key + "_pager"));
		toLast = driver.findElement(By.id("last_" + formID + "_" + key + "_pager"));
		prev = driver.findElement(By.id("prev_" + formID + "_" + key + "_pager"));
		next = driver.findElement(By.id("next_" + formID + "_" + key + "_pager"));
		currentPageNum = pagenum;
		return this;
	}

	@Override
	public IGrid toFirstClick() {
		LogImpl.getInstance().info("跳转到第1页");
		toFirst.click();
		waittime(1000);
		rows = driver.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]"));
		// pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		toFirst = driver.findElement(By.id("first_" + formID + "_" + key + "_pager"));
		toLast = driver.findElement(By.id("last_" + formID + "_" + key + "_pager"));
		prev = driver.findElement(By.id("prev_" + formID + "_" + key + "_pager"));
		next = driver.findElement(By.id("next_" + formID + "_" + key + "_pager"));
		currentPageNum = 1;
		return this;
	}

	@Override
	public IGrid toLastClick() {
		LogImpl.getInstance().info("跳转到最后一页");
		toLast.click();
		waittime(1000);
		rows = driver.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]"));
		// pages = pagesdiv.findElements(By.xpath(".//ul/li"));
		toFirst = driver.findElement(By.id("first_" + formID + "_" + key + "_pager"));
		toLast = driver.findElement(By.id("last_" + formID + "_" + key + "_pager"));
		prev = driver.findElement(By.id("prev_" + formID + "_" + key + "_pager"));
		next = driver.findElement(By.id("next_" + formID + "_" + key + "_pager"));
		currentPageNum = pageCount;
		return this;
	}

	/**
	 * 获取 当前页 行数
	 */
	@Override
	public int getRowCount() {
		LogImpl.getInstance().info("获得总行数");

		// if (paging) {
		// // 分页的情况
		// int p = 1;
		// while (p <= pageCount) {
		// pageClick(p);
		// rowCount += rows.size();
		// p++;
		// }
		// pageClick(1);
		//
		// } else {
		// rowCount = rows.size();
		// }

		int num = 0;
		for (int i = 0; i < rows.size(); i++) {
			if (rows.get(i).isDisplayed()) {
				num++;
			}
		}

		return num;
	}

	/**
	 * 勾选当前行
	 */
	@Override
	public BaseGrid selectRowClick(String colName, int... index) {
		LogImpl.getInstance().info("根据行序号，选择行（当前页）");
		int colIndex = getColIndex(colName);
		for (int i = 0; i < index.length; i++) {
			WebElement el = rows.get(index[i] - 1).findElement(By.xpath(".//td[" + (colIndex) + "]//span"));
			el.click();
		}
		return this;
	}

	@Override
	public BaseGrid selectAllRow() {
		return this;
	}

	/**
	 * 当前页表格行全选
	 */
	@Override
	public BaseGrid selectAllClick(String colName) {
		LogImpl.getInstance().info("点击全选");
		for (WebElement e : head) {
			if (e.getAttribute("title").equals(colName)) {
				e.findElement(By.xpath(".//div[contains(@class,'ui-ygrid-sortable')]/span")).click();
				break;
			}
		}
		return this;
	}

	/**
	 * 当前页行是否选中
	 */
	@Override
	public boolean isRowSelect(String colName, int... index) {
		int colIndex = getColIndex(colName);
		for (int i = 0; i < index.length; i++) {
			String s = rows.get(index[i] - 1).findElement(By.xpath(".//td[" + (colIndex) + "]/span"))
					.getAttribute("class");
			if (s != null && s.contains("checked")) {
				continue;
			} else {
				return false;
			}
		}
		return true;
	}

	/**
	 * 单元格 单击
	 */
	@Override
	public BaseGrid cellClick(String colName, int index) {
		LogImpl.getInstance().info("第" + index + "行，[" + colName + "]列，单元格单击");
		int colIndex = getColIndex(colName);
		WebElement element = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		element.click();
		return this;
	}

	/**
	 * 单元格 双击
	 */
	@Override
	public BaseGrid celldoubleClick(String colName, int index) {
		LogImpl.getInstance().info("第" + index + "行，[" + colName + "]列，单元格双击");
		int colIndex = getColIndex(colName);
		// WebElement element = rows.get(index -
		// 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		Actions action = new Actions(driver);
		action.doubleClick(rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"))).build().perform();

		return this;
	}

	public BaseGrid cellDbClick(String colName, int index) {
		LogImpl.getInstance().info("第" + index + "行，[" + colName + "]列，单元格双击");
		int colIndex = getColIndex(colName);
		WebElement element = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		element.click();
		element.click();
		return this;
	}

	/**
	 * 单击 输入 单元格
	 */
	@Override
	public BaseGrid cellInput(String colName, int index, String text) {
		LogImpl.getInstance().info("单元格输入值：" + text);
		int colIndex = getColIndex(colName);
		WebElement element = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		element.click();

		// RobotUtil.pressSpace();
		// RobotUtil.pressBackspaceKey();

		for (int i = 0; i < text.length(); i++) {
			char t = text.charAt(i);
			if (64 < t && t < 91) {
				RobotUtil.pressShift();
				RobotUtil.press(text.charAt(i));
				RobotUtil.releaseShift();
			} else {
				RobotUtil.press(text.charAt(i));
			}

			waittime(500);
		}

		// waittime(100);
		// element.findElement(By.xpath(".//span[1]/input")).sendKeys(text.substring(1,
		// text.length()-1));

		RobotUtil.pressEnterKey();
		RobotUtil.pressEnterKey();
		return this;
	}

	/**
	 * 双击输入单元格
	 */
	@Override
	public BaseGrid cellDbInput(String colName, int index, String text) {
		int colIndex = getColIndex(colName);
		LogImpl.getInstance().info("单元格输入值：" + text);
		WebElement element = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		element.click();
		element.click();
		// RobotUtil.pressMouseLeft();
		// RobotUtil.pressMouseLeft();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(".//input")));
		element.findElement(By.xpath(".//input")).sendKeys(text);
		// RobotUtil.pressEnterKey();
		return this;
	}

	/**
	 * 展开树形表格
	 * 
	 * @param colName
	 * @return
	 */
	public BaseGrid rowTreeExpand(String colName, int index) {
		int colIndex = getColIndex(colName);
		LogImpl.getInstance().info("展开树形表格");
		WebElement element = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(By.xpath(".//span[@class='cell-treeIcon cell-collapse']")));
		element.findElement(By.xpath(".//span[@class='cell-treeIcon cell-collapse']")).click();
		return this;
	}

	/**
	 * 折叠树形表格
	 * 
	 * @param colName
	 * @param index
	 * @return
	 */
	public BaseGrid rowTreeCollapse(String colName, int index) {
		int colIndex = getColIndex(colName);
		LogImpl.getInstance().info("折叠树形表格");
		WebElement element = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(By.xpath("//span[@class='cell-treeIcon cell-expand']")));

		element.findElement(By.xpath(".//span[@class='cell-treeIcon cell-expand']")).click();
		return this;
	}

	/**
	 * 点击复选框
	 */
	@Override
	public IGrid cellCheckboxClick(String colName, int index) {
		int colIndex = getColIndex(colName);
		LogImpl.getInstance().info("第" + index + "行，[" + colName + "]列，勾选");
		rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]/span[@class='cellEditor chk']")).click();
		return this;
	}

	/**
	 * 获取单元格取值
	 */
	@Override
	public String getCellValue(String colName, int index) {
		int colIndex = getColIndex(colName);
		waittime(1000);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]")).getText();
		return s;
	}

	public boolean checkColTitleName(String colName) {
		WebElement s = driver.findElement(By.id(formID + "_" + key + "_view"));
		List<WebElement> li = new ArrayList<WebElement>();
		if (isExtend) {
			li = s.findElements(By.xpath(".//tr[@class='ui-ygrid-columnheader']/th"));
		} else {
			li = s.findElements(By.xpath(".//tr[@class='ui-ygrid-headers']/th"));
		}

		for (WebElement e : li) {
			if (colName.equalsIgnoreCase(e.getAttribute("title"))) {
				return true;
			}
		}
		return false;

	}

	/**
	 * 点击+号，新增行
	 */
	@Override
	public BaseGrid addRowClick() {
		LogImpl.getInstance().info("点击+号，新增行");
		driver.findElement(By.id(formID + "_" + key + "_pager_left"))
				.findElement(By.xpath(".//table/tbody/tr/td[1]/div[1]/span[1]")).click();
		return this;
	}

	/**
	 * 点击-号，删除行
	 */
	@Override
	public BaseGrid deleteRowClick() {
		LogImpl.getInstance().info("点击-号，删除行");
		driver.findElement(By.id("del_" + formID + "_" + key)).findElement(By.xpath(".//div/span")).click();
		try {
			ConfirmDialog.element().yesClick();
		} catch (NoSuchElementException e) {
		}
		return this;
	}

	/**
	 * 点击↑号，上移
	 */
	@Override
	public BaseGrid upRowClick() {
		LogImpl.getInstance().info("点击↑号，上移");
		driver.findElement(By.id("upRow_" + formID + "_" + key)).findElement(By.xpath(".//div/span")).click();
		return this;
	}

	/**
	 * 点击↓号，下移
	 */
	@Override
	public BaseGrid downRowClick() {
		LogImpl.getInstance().info("点击↓号，下移");
		driver.findElement(By.id("downRow_" + formID + "_" + key)).findElement(By.xpath(".//div/span")).click();
		return this;
	}

	/**
	 * 点击表格自定义操作
	 */
	@Override
	public IGrid customOptClick() {
		LogImpl.getInstance().info("点击表格自定义操作");
		driver.findElement(By.id("extOpt_" + formID + "_" + key)).findElement(By.xpath(".//div/span")).click();
		return this;
	}

	/**
	 * 是否全选
	 */
	@Override
	public boolean isAllSelected(String colName) {
		int colIndex = getColIndex(colName);
		// 处理隐藏
		if (this.isDisplay) {
			colName = head.get(colIndex - 1).getAttribute("title");
		}
		WebElement e = el.findElement(By.xpath(".//tr[@class='ui-ygrid-headers']//th[@title='" + colName
				+ "']/div[contains(@class,'ui-ygrid-sortable')]/span[1]"));
		List<WebElement> list = el.findElements(
				By.xpath(".//table[@id='" + formID + "_" + key + "']/tbody/tr/td[" + (colIndex) + "]/span"));
		for (WebElement s : list) {
			if (s.getAttribute("class").contains("checked")) {
				e.getAttribute("class").contains("checked");
				return true;
			} else {
				break;
			}
		}
		return false;
	}

	/**
	 * 模拟ctrc
	 */
	@Override
	public BaseGrid ctrlC() {
		LogImpl.getInstance().info("ctrl+c复制");
		RobotUtil.pressCtrlC();
		return this;
	}

	/**
	 * 模拟ctrv
	 */
	@Override
	public BaseGrid ctrlV() {
		LogImpl.getInstance().info("ctrl+v粘贴");
		waittime(500);
		RobotUtil.pressCtrlV();
		return this;
	}

	/**
	 * 单元格上红色角标是否存在
	 */
	@Override
	public boolean isRedcornerExist(String colName, int index) {
		int colIndex = getColIndex(colName);
		WebElement s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		waittime(1000);
		WebElement div = null;
		try {
			div = s.findElement(By.xpath(".//div"));
		} catch (Exception e) {
			return false;
		}

		if (div.getAttribute("class").equals("ui-cell-error")) {
			return true;
		}

		return false;
	}

	/**
	 * 行上红色角标是否存在
	 */
	@Override
	public boolean isRedcornerExist(int index) {
		WebElement s = rows.get(index - 1).findElement(By.xpath(".//td[1]"));
		waittime(1000);
		WebElement div = null;
		try {
			div = s.findElement(By.xpath(".//div"));
		} catch (Exception e) {
			return false;
		}
		if (div.getAttribute("class").equals("ui-cell-error")) {
			return true;
		}
		return false;
	}

	/**
	 * 点击 单元格日期框
	 * 
	 * @param colName
	 * @param index
	 * @return
	 */
	protected WebElement cellDPViewClick(String colName, int index) {
		cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		// 获得单元格
		WebElement e = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		e.findElement(By.tagName("span")).click();
		// 获得日期弹出框
		String s = e.getAttribute("aria-describedby");
		String[] split = s.split("_");
		String temp = split[split.length - 1];
		return driver.findElement(By.id(index + "_" + temp + "_datepickerView"));
	}

	public BaseGrid cellDateViewClick(String colName, int index) {
		cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		WebElement e = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		e.findElement(By.tagName("span")).click();
		return this;
	}

	/**
	 * 输入不带时间日期
	 */
	@Override
	public BaseGrid cellDPViewInput(String colName, int index, int year, int month, int day) {
		// 双击单元格，并获得下拉框
		WebElement datepickerview = cellDPViewClick(colName, index);
		LogImpl.getInstance().info("在单元格日期选择框中输入：" + year + "年" + month + "月" + day + "日");
		WebElement container = datepickerview.findElement(By.xpath(".//div[@class='datepickerContainer']"));

		// 左右键，选择年
		WebElement year1 = container.findElement(By.xpath(".//thead//th[@class='datepickerMonth']//span"));
		WebElement goprev = container.findElement(By.xpath(".//thead//th[@class='datepickerGoPrev']//span"));
		WebElement gonext = container.findElement(By.xpath(".//thead//th[@class='datepickerGoNext']//span"));
		year1.click();
		int y = Integer.parseInt(year1.getText()); // 获得当前年的数值
		int temp = y - year;
		if (temp > 0) {
			while (temp > 0) {
				goprev.click();
				temp--;
			}
		}
		if (temp < 0) {
			while (temp < 0) {
				gonext.click();
				temp++;
			}
		}

		// 选择月份
		List<WebElement> monthlist = container.findElements(By.xpath(".//tbody[@class='datepickerMonths']//td"));
		monthlist.get(month - 1).click();

		// 选择日期
		List<WebElement> daylist = container.findElements(By.xpath(".//tbody[@class='datepickerDays']//td"));
		List<WebElement> notinmonth = container.findElements(
				By.xpath(".//tbody[@class='datepickerDays']//td[contains(@class,'datepickerNotInMonth')]"));
		daylist.removeAll(notinmonth);
		daylist.get(day - 1).click();

		return this;
	}

	/**
	 * 输入带时间日期
	 */
	@Override
	public BaseGrid cellDPViewInput(String colName, int index, int year, int month, int day, int hour, int minute,
			int second) {
		// 输入年月日
		cellDPViewInput(colName, index, year, month, day);
		LogImpl.getInstance().info("输入时间：" + hour + "：" + minute + "：" + second);
		// 获得日期下拉框
		int colIndex = getColIndex(colName);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"))
				.getAttribute("aria-describedby");
		String[] split = s.split("_");
		String temp = split[split.length - 1];
		WebElement datepickerview = driver.findElement(By.id(index + "_" + temp + "_datepickerView"));
		// 输入时、分、秒
		List<WebElement> timelist = datepickerview.findElements(By.xpath(".//div[@class='time']/input"));

		timelist.get(0).click();
		RobotUtil.pressBackspaceKey();
		RobotUtil.pressBackspaceKey();
		timelist.get(0).sendKeys(String.valueOf(hour));

		timelist.get(1).click();
		RobotUtil.pressBackspaceKey();
		RobotUtil.pressBackspaceKey();
		timelist.get(1).sendKeys(String.valueOf(minute));

		timelist.get(2).click();
		RobotUtil.pressBackspaceKey();
		RobotUtil.pressBackspaceKey();
		timelist.get(2).sendKeys(String.valueOf(second));

		datepickerview.findElement(By.xpath(".//div[@class='time']/button[1]")).click();
		return this;
	}

	/**
	 * 入当前时间d
	 */
	@Override
	public BaseGrid cellCurrenttimeInput(String colName, int index) {
		WebElement datepickerview = cellDPViewClick(colName, index);
		LogImpl.getInstance().info("输入当前时间");
		datepickerview.findElement(By.xpath(".//div[@class='time']/button[1]")).click();
		datepickerview.findElement(By.xpath(".//div[@class='time']/button[2]")).click();
		return this;
	}

	/**
	 * 点击 单元格 按钮
	 */
	@Override
	public BaseGrid cellButtonClick(String colName, int index) {
		LogImpl.getInstance().info("点击单元格按钮");
		int colIndex = getColIndex(colName);
		rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]//button")).click();
		return this;
	}

	/**
	 * 点击 表格超链接
	 */
	@Override
	public BaseGrid cellHyperLinkClick(String colName, int index) {
		LogImpl.getInstance().info("点击单元格链接");
		int colIndex = getColIndex(colName);
		rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]/a")).click();
		return this;
	}

	/**
	 * 点击 单元格 文本按钮
	 */
	@Override
	public BaseGrid cellTextButtonClick(String colName, int index) {
		LogImpl.getInstance().info("点击单元格文本按钮");
		int colIndex = getColIndex(colName);
		WebElement element = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		element.click();
		element.click();
		element.findElement(By.xpath(".//span[1]/button")).click();
		return this;
	}

	/**
	 * 点击 表格 单元格 树形 图标
	 */
	@Override
	public BaseGrid cellTreeIconClick(String colName, int index) {
		LogImpl.getInstance().info("点击树形表格展开/不展开");
		int colIndex = getColIndex(colName);
		rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]/span[contains(@class,'cell-treeIcon')]"))
				.click();
		return this;
	}

	/**
	 * 获取 树形单元格是否展开
	 * 
	 * @param colName
	 *            列名
	 * @param index
	 *            序号
	 * @return
	 */
	public boolean isCellTreeIconExpand(String colName, int index) {
		int colIndex = getColIndex(colName);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]/span[1]")).getAttribute("class");
		if (s.contains("cell-collapse")) {
			return false;
		} else if (s.contains("cell-expand")) {
			return true;
		}
		{
			return false;
		}

	}

	@Override
	public BaseGrid dragAndDrop(String colName1, int index1, String colName2, int index2) {
		LogImpl.getInstance().info("拖拽选中表格中的区域");
		int colIndex1 = getColIndex(colName1);
		int colIndex2 = getColIndex(colName2);
		Actions action = new Actions(driver);
		WebElement source = rows.get(index1 - 1).findElement(By.xpath(".//td[" + (colIndex1) + "]"));
		WebElement target = rows.get(index2 - 1).findElement(By.xpath(".//td[" + (colIndex2) + "]"));
		action.dragAndDrop(source, target).perform();
		waittime(500);
		return this;
	}

	@Override
	public BaseGrid cellClear(String colName, int index) {
		LogImpl.getInstance().info("清空单元格的数据");
		cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]//input")).clear();
		return this;
	}

	@Override
	public BaseGrid celDictClick(String colName, int index) {
		LogImpl.getInstance().info("点击单元格字典");
		waittime(2000);
		// 双击进入编辑状态
		cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(".//td[" + (colIndex) + "]")));
		WebElement e = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		// 点击下拉按钮
		waittime(100);
		e.findElement(By.className("arrow")).click();
		waittime(1000);
		// 获得下拉元素
		String s = e.getAttribute("aria-describedby");
		String[] split = s.split("_");
		String temp = split[split.length - 1];
		view = driver.findElement(By.id(index + "_" + temp + "_dropview"));
		li = view.findElements(By.tagName("li"));
		// WebElement element =
		// view.findElement(By.xpath(".//div/li[@class='root']"));
		// WebElement element =
		// view.findElement(By.xpath(".//div/table[@class='body-table root']"));
		// rootId = element.getAttribute("id");
		if (li.size() > 0) {
			WebElement element = view.findElement(By.xpath(".//div/li[contains(@class,'root')]"));
			rootId = element.getAttribute("id");
		} else {
			WebElement element = view.findElement(By.xpath(".//div/table[contains(@class,'body-table root')]"));
			rootId = element.getAttribute("id");
		}

		return this;
	}

	/**
	 * 打开下拉框
	 * 
	 * @param colName
	 * @param index
	 * @return
	 */
	public BaseGrid celViewExpand(String colName, int index) {
		LogImpl.getInstance().info("打开下拉框 ");
		// 双击进入编辑状态
		// cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		WebElement e = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		// 点击下拉按钮
		waittime(100);
		e.findElement(By.className("arrow")).click();
		return this;
	}

	/**
	 * 关闭下拉框
	 */
	public BaseGrid celViewClose(String colName, int index) {
		LogImpl.getInstance().info("关闭下拉框 ");
		// 双击进入编辑状态
		// cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		WebElement e = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		// 点击下拉按钮
		waittime(100);
		e.findElement(By.className("arrow")).click();
		return this;
	}

	/**
	 * 点击字典下拉项
	 */
	@Override
	public BaseGrid dictItemClick(String itemCode) {
		LogImpl.getInstance().info("点击选择字典项：" + itemCode);
		waittime(500);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(By.xpath(".//a[@class='dt-anchor']/span[text()='" + itemCode + "']")));
		view.findElement(By.xpath(".//a[@class='dt-anchor']/span[text()='" + itemCode + "']")).click();
		return this;
	}

	public boolean itemSelect(String itemCode) {
		String s = view.findElement(By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li"))
				.getAttribute("class");
		if (s.contains("disableSelect")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 点击展开字典项
	 */
	@Override
	public BaseGrid dictExpandItemClick(String itemCode) {
		LogImpl.getInstance().info("点击展开字典项：" + itemCode);
		waittime(500);
		view.findElement(
				By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li/span[contains(@class,'icon')]"))
				.click();
		waittime(500);
		String id = view.findElement(By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li"))
				.getAttribute("id");
		this.id = id;
		waittime(500);
		return this;
	}

	/**
	 * 点击关闭字典项 击
	 */
	@Override
	public BaseGrid dictCollapseItemClick(String itemCode) {
		LogImpl.getInstance().info("点击收起字典项：" + itemCode);
		view.findElement(
				By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li/span[contains(@class,'icon')]"))
				.click();
		waittime(500);
		return this;
	}

	/**
	 * 获取 表格字典 根节点
	 */
	@Override
	public String getDictRootNode() {
		waittime(1000);
		return li.get(0).findElement(By.xpath(".//a[1]/span[@class='b-txt']")).getText();
	}

	/**
	 * 选择 字典 下拉项
	 */
	@Override
	public BaseGrid dictItemCheckClick(String itemName) {
		LogImpl.getInstance().info("勾选/取消勾选字典项：" + itemName);
		for (WebElement e : li) {
			String s = e.findElement(By.xpath(".//a[1]/span[@class='b-txt']")).getText().trim();
			if (s.contains(itemName.trim())) {
				e.findElement(By.xpath(".//span[contains(@class,'dt-chk')]")).click();
				return this;
			}
		}
		return this;
	}

	/**
	 * 点击单元格下拉框
	 */
	@Override
	public BaseGrid celComboClick(String colName, int index) {
		LogImpl.getInstance().info("点击单元格下拉框");
		// 双击进入编辑状态
		cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		WebElement e = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		// 点击下拉按钮
		waittime(2000);
		e.findElement(By.className("arrow")).click();
		// 获得下拉元素
		String s = e.getAttribute("aria-describedby");
		String[] split = s.split("_");
		String temp = split[split.length - 1];
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		// wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id(index
		// + "_" + temp + "_view")));
		view = driver.findElement(By.id(index + "_" + temp + "_view"));
		li = view.findElements(By.tagName("li"));
		return this;
	}

	/**
	 * 选中下拉框下拉项
	 */
	@Override
	public BaseGrid comboItemClick(String itemValue) {
		LogImpl.getInstance().info("选中下拉项" + itemValue);
		waittime(500);
		view.findElement(By.xpath(".//ul/li[text()='" + itemValue + "']")).click();
		waittime(500);
		return this;
	}

	/**
	 * 点击单元格下拉框自动匹配下拉项
	 */
	@Override
	public BaseGrid gridComboAutoItemClick(String itemName) {
		LogImpl.getInstance().info("选中自动匹配的下拉项" + itemName);
		waittime(1000);
		List<WebElement> elements = driver.findElements(By.xpath("//div[@class='cmb-autovw cmb-vw']/ul/li"));
		for (WebElement el : elements) {
			if (el.getText().trim().equals(itemName.trim())) {
				System.out.println(el.getText());
				el.click();
				return this;
			}
		}
		return this;
	}

	/**
	 * 获取自动匹配的下拉项取值
	 */
	public String getGridComboAutoItems() {
		waittime(1000);
		driver.findElements(By.xpath("//div[@class='cmb-autovw cmb-vw']"));
		waittime(1000);
		List<WebElement> li = driver.findElements(By.xpath("//div[@class='cmb-autovw cmb-vw']/ul/li"));
		String s = "";
		for (WebElement el : li) {
			System.out.println(el.getText());
			waittime(100);
			s += el.getText();
		}
		return s;
	}

	/**
	 * 点击单元格多选下拉框框
	 */
	@Override
	public BaseGrid celCheckListClick(String colName, int index) {
		LogImpl.getInstance().info("点击单元格多选下拉框");
		// 双击进入编辑状态
		cellDbClick(colName, index);
		int colIndex = getColIndex(colName);
		WebElement e = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));
		// 点击下拉按钮
		e.findElement(By.className("arrow")).click();
		// 获得下拉元素
		String s = e.getAttribute("aria-describedby");
		String[] split = s.split("_");
		String temp = split[split.length - 1];
		view = driver.findElement(By.id(index + "_" + temp + "_view"));
		li = view.findElements(By.tagName("li"));
		return this;
	}

	/**
	 * 表格多选下拉框节点勾选
	 */
	@Override
	public BaseGrid checkListItemClick(String... itemName) {
		LogImpl.getInstance().info("勾选多选下拉项");
		waittime(1000);
		List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
		for (String s : itemName) {
			for (WebElement el : li) {
				String trim = el.getText().trim();
				// String trim =
				// el.findElement(By.tagName("span")).getText().trim();
				if (trim.equals(s.trim())) {
					el.findElement(By.tagName("span")).click();
				}
			}
		}
		return this;
	}

	/**
	 * 多选下拉框确定、取消、消除按钮
	 * 
	 * @param 确定、取消、消除
	 * @return
	 */
	public BaseGrid clickName(String text) {
		WebElement el = view.findElement(By.xpath(".//div/div[@class='chainmean']/span[text()='" + text + "']"));
		el.click();

		return this;
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub

		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * 判断单元格的可用性
	 * 
	 * @param colName
	 *            列名
	 * @param index
	 *            序号
	 * @return
	 */
	public boolean isEnabled(String colName, int index) {
		int colIndex = getColIndex(colName);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]")).getAttribute("class");
		if (s.contains("disabled")) {
			return false;
		}
		return true;
	}

	/**
	 * 判读表格可用性
	 * 
	 * @return
	 */
	public boolean isGridDisplayed() {
		String s = el.getAttribute("class");
		if (s.contains("ui-hidden")) {
			return false;
		}
		return true;
	}

	/**
	 * 判断列的可见性
	 * 
	 * @param colName
	 * @return
	 */
	public boolean iscolDisplayed(String colName) {
		WebElement s = driver.findElement(By.id(formID + "_" + key + "_view"));
		List<WebElement> li = new ArrayList<WebElement>();
		if (isExtend) {
			li = s.findElements(By.xpath(".//tr[@class='ui-ygrid-columnheader']/th"));
		} else {
			li = s.findElements(By.xpath(".//tr[@class='ui-ygrid-headers']/th"));
		}

		for (WebElement e : li) {
			if (colName.equalsIgnoreCase(e.getAttribute("title"))) {
				String style = e.getAttribute("style");
				if (style.contains("display")) {
					return false;
				} else {
					return true;
				}
			}
		}

		return true;
	}

	/**
	 * 判断表格操作按钮的可见性
	 * 
	 * @param optName(添加新纪录、删除所选记录、上移数据行、下移数据行)
	 * @return
	 */
	public boolean isGridOptDisplayed(String optName) {
		WebElement s = driver.findElement(By.id(formID + "_" + key + "_pager"));
		List<WebElement> li = new ArrayList<WebElement>();
		li = s.findElements(By.xpath(".//table[@class='ui-pg-table navtable']//td"));

		for (WebElement e : li) {
			if (optName.equalsIgnoreCase(e.getAttribute("title"))) {
				String style = e.getAttribute("style");
				if (e.getCssValue("display").equals("none")) {
					return false;
				}

			}
		}
		return true;
	}

	// public boolean isFixedRow(int index) {
	// List<WebElement> s = rows.get(index - 1).findElements(By.xpath(".//td"));
	// String strClass = null;
	// for (int i = 0 ;i < s.size(); i++) {
	// strClass = s.get(i).getAttribute("class");
	// // 去除序列，隐藏
	// if (strClass == null || strClass.isEmpty() ||
	// !(strClass.contains("ui-cell-disabled") ||
	// strClass.contains("ygrid-rownum") ||
	// "none".equals(s.get(i).getCssValue("display"))||
	// strClass.contains("edit-cell"))) {
	// return false;
	// }
	// }
	// return true;
	// }
	//

	/**
	 * 判断表格是否可用
	 * 
	 * @return
	 */
	public boolean isGridEnabled() {
		List<WebElement> s = driver.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]"));
		// System.out.println(s.size());
		if (s.size() == 0) {
			return false;
		}
		return true;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 获取单元格前景色
	 * 
	 * @param colName
	 *            列名
	 * @param index
	 *            序号
	 * @return
	 */
	public String getForeColor(String colName, int index) {
		int colIndex = getColIndex(colName);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]")).getCssValue("color");
		String s1 = s.substring(5, s.length() - 4);
		System.out.println(s1);
		return s1;
	}

	/**
	 * 获取列背景色
	 */
	@Override
	public String getColBackColor(String colName, int index) {
		LogImpl.getInstance().info("列背景色");
		int colIndex = getColIndex(colName);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"))
				.getCssValue("background-color");
		String s1 = s.substring(5, s.length() - 4);
		System.out.println(s1);
		return s1;
	}

	/**
	 * 获取行背景色
	 * 
	 * @param colName
	 *            列名
	 * @param index
	 * @return
	 */
	public String getRowBackColor(String colName, int index) {
		LogImpl.getInstance().info("行背景色");
		waittime(500);
		int colIndex = getColIndex(colName);
		String s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]/parent::tr"))
				.getCssValue("background-color");
		String s1 = s.substring(5, s.length() - 4);
		System.out.println(s1);
		return s1;
	}

	public boolean checkRowSelect(int index) {

		List<WebElement> clList = rows.get(index - 1)
				.findElements(By.xpath(".//td[@class='space ui-state-highlight']"));

		for (int i = 0; i < clList.size(); i++) {
			WebElement cld = clList.get(i);

			if (!cld.getAttribute("class").contains("ui-state-highlight")) {
				return false;
			}
		}

		return true;

	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * 单元格是否必填
	 * 
	 * @param colName
	 * @param index
	 * @return
	 */
	public boolean isYellowcornerExist(String colName, int index) {
		int colIndex = getColIndex(colName);
		WebElement s = rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]"));

		WebElement div = null;
		try {
			div = s.findElement(By.xpath(".//div"));
		} catch (Exception e) {
			return false;
		}

		if (div.getAttribute("class").equals("ui-cell-required")) {
			return true;
		}

		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 获取单元格内值显示的水平左右居中方向
	 * 
	 * @param colName
	 * @param index
	 * @return
	 */
	public String getHalign(String colName, int index) {
		int colIndex = getColIndex(colName);
		return rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]")).getCssValue("text-align");

	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 模拟键盘enter按键操作
	 */
	@Override
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		waittime(500);
		RobotUtil.pressEnterKey();
		waittime(500);
	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		LogImpl.getInstance().info("按Delete键");
		waittime(500);
		RobotUtil.pressDeleteKey();
		waittime(500);

	}

	public void pressLeftKey() {
		LogImpl.getInstance().info("按Left键");
		waittime(500);
		RobotUtil.pressLeft();
		waittime(500);
	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey(int left, int num) {
		LogImpl.getInstance().info("选中，按left键，移动");
		el.findElement(By.tagName("input")).click();
		for (int i = 0; i < left; i++) {
			RobotUtil.pressLeft();
		}
		for (int i = 0; i < num; i++) {
			RobotUtil.pressBackspaceKey();
		}
	}

	/**
	 * 获取子节点对象组
	 * 
	 * 
	 */
	public List<BaseGridDictItem> getChildren(boolean root) {
		waittime(2000);
		List<BaseGridDictItem> items = new ArrayList<BaseGridDictItem>();
		List<WebElement> list = null;
		if (root) {
			// list = view.findElements(By.xpath(".//li[@parentid='" + rootId +
			// "']"));
			if (li.size() > 0) {
				list = view.findElements(By.xpath(".//li[@parentid='" + rootId + "']"));
			} else {
				list = view.findElements(By.xpath(".//tr[@parentid='" + rootId + "']"));
			}
		} else {
			list = view.findElements(By.xpath(".//li[@parentid='" + id + "']"));
		}
		BaseGridDictItem item = null;
		for (WebElement e : list) {
			// 取属性,并封装
			item = new BaseGridDictItem();

			int enable = -1;
			String str = e.findElement(By.xpath(".//a[@class='dt-anchor']/span[1]")).getAttribute("class");
			if (str.contains("discard")) {
				enable = 2;
			} else if (str.contains("disable")) {
				enable = 0;
			} else if (str.contains("enable")) {
				enable = 1;
			}
			item.setEnable(enable);
			item.setCaption(e.findElement(By.xpath(".//a[@class='dt-anchor']/span[2]")).getText());
			int nodeType = e.findElement(By.xpath(".//a[@class='dt-anchor']/span[1]")).getAttribute("class")
					.contains("b-") ? 1 : 0;
			item.setNodeType(nodeType);

			// 区分单选和多选
			boolean flag = true;
			try {
				WebElement element = e.findElement(By.xpath(".//span[contains(@class,'dt-chk')]"));
			} catch (org.openqa.selenium.NoSuchElementException ex) {
				flag = false;
			}

			if (flag) {
				// System.out.println("chk-==="+e.findElement(By.xpath(".//span[2]")).getAttribute("chkstate"));
				item.setChkState(Integer.parseInt(e.findElement(By.xpath(".//span[2]")).getAttribute("chkstate")));
			}
			items.add(item);
			System.out.println(item);
		}

		return items;

	}

	/**
	 * 获取字典根节点勾选状态
	 */
	@Override
	public String getDictRootChkstate() {
		return view.findElement(By.xpath(".//li[1]/span[2]")).getAttribute("chkstate");
	}

	@Override
	/**
	 * 选中 表格字典 下拉项
	 */
	public BaseGrid gridDictItemClick(String itemCode) {
		LogImpl.getInstance().info("单击字典项：" + itemCode);
		view.findElement(By.xpath(".//span[text()='" + itemCode + "']")).click();
		WebElement element = view.findElement(By.xpath(".//div/li[@class='root']"));
		rootId = element.getAttribute("id");
		String id = view.findElement(By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li"))
				.getAttribute("id");
		this.id = id;
		return this;
	}

	/**
	 * 判断复选框是否被勾选
	 */
	@Override
	public boolean isCelCheckBoxChecked(String colName, int index) {
		int colIndex = getColIndex(colName);
		LogImpl.getInstance().info("第" + index + "行，[" + colName + "]列，勾选");
		String s = rows.get(index - 1)
				.findElement(By.xpath(".//td[" + (colIndex) + "]/span[contains(@class,'cellEditor chk')]"))
				.getAttribute("class");
		if (s.contains("checked")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 获取下拉框下拉项取值
	 */
	public String getGridComboBoxItems() {
		List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
		String s = "";
		for (WebElement el : li) {
			System.out.println(el.getText());
			waittime(100);
			s += el.getText();
		}

		return s;

	}

	/**
	 * 获取多选下拉框下拉项取值
	 */
	public String getGridCheckListItems() {
		List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
		String s = "";
		for (WebElement el : li) {
			System.out.println(el.getText());
			waittime(100);
			s += el.getText();
		}

		return s;

	}

	/**
	 * 判断表格多选下拉框节点是否被勾选
	 * 
	 */
	public boolean gridCheckListItemChecked(String itemName) {
		// WebElement element =
		// view.findElement(By.xpath(".//ul/li/span[text()='" + itemName +
		// "']/preceding-sibling::input[1]"));

		WebElement element = view
				.findElement(By.xpath(".//ul/li/span[text()='" + itemName + "']/preceding-sibling::span[1]"));

		if (element.getAttribute("class").contains("checked")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 编辑框单击粘贴文本
	 * 
	 * @param text
	 * @return
	 */
	public BaseGrid paste(String text) {
		LogImpl.getInstance().info("字段：" + key + "，粘贴文本：" + text);
		RobotUtil.paste(text);
		return this;
	}

	/**
	 * 编辑框双击粘贴文本
	 * 
	 * @param text
	 * @return
	 */
	public BaseGrid dbPaste(String colName, int index, String text) {
		LogImpl.getInstance().info("字段：" + key + "，粘贴文本：" + text);
		int colIndex = getColIndex(colName);
		cellDbClick(colName, index);
		LogImpl.getInstance().info("单元格输入值：" + text);
		rows.get(index - 1).findElement(By.xpath(".//td[" + (colIndex) + "]//input"));
		RobotUtil.paste(text);
		return this;
	}

	/**
	 * 获取普通表格列名 无扩展列
	 * 
	 * @return
	 */
	public String getGridColName() {
		WebElement s = driver.findElement(By.id(formID + "_" + key + "_view"));
		if (isExtend) {
			List<WebElement> li = s.findElements(By.xpath(".//tr[@class='ui-ygrid-columnheader']/th"));
			String s1 = "";
			for (WebElement e : li) {
				System.out.println(e.getAttribute("title"));
				waittime(100);
				s1 += e.getAttribute("title");

			}

			return s1;
		} else {
			List<WebElement> li1 = s.findElements(By.xpath(".//tr[@class='ui-ygrid-headers']/th"));
			String s2 = "";
			for (WebElement e : li1) {
				System.out.println(e.getAttribute("title"));
				waittime(100);
				s2 += e.getAttribute("title");

			}

			return s2;

		}

	}

	/**
	 * 获取改变列标题 表格列名
	 * 
	 * @return
	 */
	public String getChangeColGridColName() {
		WebElement s = driver.findElement(By.id(formID + "_" + key + "_view"));
		List<WebElement> li = s.findElements(By.xpath(".//tr[@class='ui-ygrid-headers']/th/div"));
		String s1 = "";
		for (WebElement e : li) {
			System.out.println(e.getText());
			waittime(100);
			s1 += e.getText();

		}

		return s1;

	}

	/**
	 * 获取带扩展列且标题显示的表格列名
	 * 
	 * @return
	 */
	public String getGridExpColTitle() {
		List<WebElement> expCol = el.findElements(
				By.xpath(".//table[@class='ui-ygrid-htable']/thead/tr[@class='ui-ygrid-columnheader']/th"));
		String s1 = "";
		for (WebElement e : expCol) {
			System.out.println(e.getAttribute("title"));
			waittime(100);
			s1 += e.getAttribute("title");

		}

		return s1;

	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 点击列实现列值排序
	 * 
	 * @param colName
	 *            列名
	 * @return
	 */
	public BaseGrid GridColClick(String colName) {
		LogImpl.getInstance().info("第" + "[" + colName + "]列，点击排序");
		List<WebElement> li = el.findElements(By.xpath(".//tr[@class='ui-ygrid-headers']/th"));
		for (WebElement e : li) {
			waittime(100);
			if (e.getAttribute("title").equals(colName)) {
				System.out.println(e.findElement(By.className("s-ico")));
				waittime(4000);
				e.findElement(By.className("s-ico")).click();
				break;
			}
		}

		return this;
	}

	/**
	 * 获取表格列升降图标 1=升序 -1=降序 0=列未被点击
	 * 
	 * @param colName
	 *            列名
	 * @return
	 */
	public String getGridColOrder(String colName) {
		String s = el.findElement(By.xpath(".//span[text()='" + colName + "']/following-sibling::span"))
				.getAttribute("class");
		String s1 = "";
		if (s.contains("-asc")) {
			s1 += 1;
		} else if (s.contains("-desc")) {
			s1 += -1;
		} else if (s.contains("-ico")) {
			s1 += 0;
		}
		System.out.println(s1);
		return s1;
	}

	/**
	 * 获取每列上的取值
	 */
	public String getGridColValue(String colName) {
		int colIndex = getColIndex(colName);
		List<WebElement> s = driver.findElements(
				By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]/td[" + (colIndex) + "]"));
		String s1 = "";
		String s2 = "null";
		for (WebElement e : s) {
			waittime(100);
			s1 += e.getAttribute("title");
			if (e.getAttribute("title").equals("")) {
				s1 += s2;
			}
		}
		System.out.println(s1);
		return s1;
	}

	public String getChangeColGridRowValue(int index) {
		List<WebElement> s = rows.get(index - 1).findElements(By.xpath(".//td"));
		String s1 = "";
		String s2 = "null";
		for (WebElement e : s) {
			waittime(200);
			s1 += e.getText();
			if (e.getText().equals("")) {
				s1 += s2;
			}
		}
		System.out.println(s1);
		// String s3 =s1.substring(4,s1.length()-0);
		return s1;
	}

	/**
	 * 获取每行上的取值
	 */
	public String getGridRowValue(int index) {
		List<WebElement> s = rows.get(index - 1).findElements(By.xpath(".//td"));
		String s1 = "";
		String s2 = "null";
		for (WebElement e : s) {
			waittime(200);
			s1 += e.getAttribute("title");
			if (e.getAttribute("title").equals("")) {
				s1 += s2;
			}
		}
		System.out.println(s1);
		String s3 = s1.substring(4, s1.length() - 0);
		return s3;
	}

	/**
	 * 表格专用
	 * 
	 * @param index
	 * @return
	 */
	public String getBaseGridRowValue(int index) {
		List<WebElement> s = rows.get(index - 1).findElements(By.xpath(".//td"));
		String s1 = "";
		String s2 = "null";
		for (WebElement e : s) {
			waittime(200);
			s1 += e.getAttribute("title");
			if (e.getAttribute("title").equals("")) {
				s1 += s2;
			}
		}
		System.out.println(s1);
		return s1;
	}

	/**
	 * 获取表格扩展列个数.只在扩展列标题显示的情况下使用
	 * 
	 * @param colName
	 * @return
	 */
	public int getGridExpColNum(String colName) {
		List<WebElement> expCol = el.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead//th[not(@id)]"));
		String s = "";
		for (WebElement e : expCol) {
			if (e.getAttribute("title").equals(colName)) {
				s += e.getAttribute("colspan");
				break;
			}
		}
		int i = Integer.parseInt(s);
		System.out.println(i);
		return i;
	}

	/**
	 * 获取表格扩展列名称.只在扩展列标题显示的情况下使用
	 * 
	 * @return
	 */
	public String getGridExpColName() {
		List<WebElement> s = el
				.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead/tr[@class='ui-ygrid-headers']/th"));
		String s1 = "";
		for (WebElement e : s) {
			System.out.println(e.getAttribute("title"));
			waittime(200);
			s1 += e.getAttribute("title");
		}
		return s1;
	}

	/**
	 * 获取扩展列上全部值.只在扩展列标题显示的情况下使用
	 * 
	 * @param colName
	 * @return
	 */
	public String getGridExpColValue(String colName) {
		List<WebElement> expCols = el
				.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead/tr[@class='ui-ygrid-headers']//th"));
		String s = "";
		for (WebElement e : expCols) {
			if (e.getAttribute("title").equals(colName)) {
				s += e.getAttribute("id");
				break;
			}
		}
		List<WebElement> s1 = driver
				.findElements(By.xpath("//table[@id='" + formID + "_" + key + "']/tbody/tr[@id]/td"));
		String s2 = "";
		for (WebElement i : s1) {
			if (i.getAttribute("aria-describedby").equals(s)) {
				s2 += i.getAttribute("title");
			}
		}
		System.out.println(s2);
		return s2;
	}

	/**
	 * 全局检查是否触发
	 * 
	 * @return
	 */
	public boolean isAllUiCheck() {
		List<WebElement> s = driver.findElements(By.xpath("//div[@class='errorinfo']"));
		for (WebElement e : s) {
			if (e.getCssValue("display").equals("block")) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 全局检查错误描述测试
	 */
	public String getAllErrorInfo() {
		List<WebElement> s = driver.findElements(By.xpath("//div[@class='errorinfo']"));
		String s1 = "";
		for (WebElement e : s) {
			if (e.getCssValue("display").equals("block")) {
				s1 += e.findElement(By.xpath(".//label")).getText();
			}
		}

		return s1;
	}

	/**
	 * 判断扩展列标题是否显示；只用在测试扩展列标题显示相关用例上
	 * 
	 * @return true 为不显示 false 为显示
	 */
	public boolean expColNoTitle() {
		List<WebElement> list = el.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead/tr"));
		for (WebElement e : list) {
			if (e.getAttribute("class").contains("ui-ygrid-columnheader")) {
				return false;
			} else if (e.getAttribute("class").equals("ui-ygrid-headers")) {
				int s = 1;
				s = list.size();
			}
		}
		return true;
	}

	/**
	 * 获取嵌套扩展列的表格第一行列名
	 * 
	 * @return
	 */
	public String getGridNestExpColTitle1() {
		List<WebElement> li = el
				.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead//tr[@class='ui-ygrid-columnheader']"));
		List<WebElement> s = li.get(0).findElements(By.xpath(".//th"));
		String s1 = "";
		for (WebElement e : s) {
			System.out.println(e.getAttribute("title"));
			waittime(100);
			s1 += e.getAttribute("title");

		}

		return s1;

	}

	/**
	 * 获取嵌套扩展列的表格第二行列名
	 * 
	 * @return
	 */
	public String getGridNestExpColTitle2() {
		List<WebElement> li = el
				.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead//tr[@class='ui-ygrid-columnheader']"));
		List<WebElement> s = li.get(1).findElements(By.xpath(".//th"));
		String s1 = "";
		for (WebElement e : s) {
			System.out.println(e.getAttribute("title"));
			waittime(100);
			s1 += e.getAttribute("title");

		}

		return s1;

	}

	/**
	 * 获取表格下方 页码 显示 页数5
	 * 
	 * @return
	 */
	public String getPagesNum() {
		List<WebElement> s = pagesdiv.findElements(By.xpath(".//li[contains(@class,'pagination_btn')]"));
		String s1 = "";
		for (WebElement e : s) {
			System.out.println(e.getAttribute("data-num"));
			waittime(200);
			s1 += e.getAttribute("data-num");
		}
		return s1;
	}

	/**
	 * 获取表格下方控件显示情况
	 * 
	 * @return
	 */
	public String getPagerControl() {
		WebElement s = driver.findElement(By.id(formID + "_" + key + "_pager" + "_left"));
		List<WebElement> list = s.findElements(By.xpath(".//table[@class='ui-pg-table navtable']/tbody/tr/td"));
		String s1 = "";
		String s2 = "";
		for (WebElement e : list) {
			s1 += e.getAttribute("title");
			System.out.println(e.getAttribute("title"));
			s2 += e.getAttribute("class");
			if (s2.contains("ui-state-disabled")) {
				break;
			}
		}

		return s1;

	}

	public BaseGrid searchButtonClick() {
		view.findElement(By.xpath(".//div[@class='dt-searchwrap']/span[@class='findspan']")).click();
		return this;

	}

	public BaseGrid searchInputClear() {
		view.findElement(By.xpath(".//div[@class='dt-searchwrap']/input[@class='findinput']")).clear();
		return this;

	}

	public BaseGrid searchBoxInput(String text) {
		view.findElement(By.xpath(".//div[@class='dt-searchwrap']/input[@class='findinput']")).sendKeys(text);
		return this;

	}

	/**
	 * 获取表格有隐藏列时标题名称.只有在表格有隐藏列的情况下使用
	 * 
	 * @return
	 */
	public String getGridHidColName() {
		List<WebElement> s = el
				.findElements(By.xpath(".//table[@class='ui-ygrid-htable']/thead/tr[@class='ui-ygrid-headers']/th"));
		String s1 = "";
		for (WebElement e : s) {

			// System.out.println(e.getAttribute("title"));
			waittime(200);
			if (e.getCssValue("display").equals("none")) {
				continue;
			}
			s1 += e.getAttribute("title");
		}
		System.out.println(s1);
		return s1;
	}

	/**
	 * 获取表格文本框空值提示
	 * 
	 * @return
	 */
	public String getPromptText() {
		return el.findElement(By.tagName("input")).getAttribute("placeholder");
	}
}
