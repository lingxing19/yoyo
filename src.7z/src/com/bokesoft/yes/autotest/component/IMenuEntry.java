package com.bokesoft.yes.autotest.component;

public interface IMenuEntry {

	public IMenuEntry click();

	public IMenuEntry dblClick();
}
