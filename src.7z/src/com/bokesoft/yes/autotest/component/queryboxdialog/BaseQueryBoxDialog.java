﻿package com.bokesoft.yes.autotest.component.queryboxdialog;

import org.openqa.selenium.By;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IQueryBoxDialog;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseQueryBoxDialog extends AbstractComponent implements IQueryBoxDialog{
	
	public BaseQueryBoxDialog(){	

		this.el=driver.findElement(By.xpath(".//div[@class='dialog show']"));
		
		
	}

	public int getDialogID() {
		return Integer.parseInt(this.el.getAttribute("id"));
	}
	
	
	@Override
	public IQueryBoxDialog queryClick() {
		LogImpl.getInstance().info("弹出下推源单查询框，点【查询】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='查询']/parent::button")).click();
		return this;
	}
	
	@Override
	public IQueryBoxDialog pushClick() {
		LogImpl.getInstance().info("弹出下推源单查询框，点【下推】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='下推']/parent::button")).click();
		return this;
	}

	public IQueryBoxDialog ThroughClick(){
		LogImpl.getInstance().info("弹出基本信息框，点击【通过】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='通过']/parent::button")).click();
		return this;
		
	}
	
	public IQueryBoxDialog rejectedClick(){
		LogImpl.getInstance().info("弹出基本信息框，点击【驳回】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='驳回']/parent::button")).click();
		return this;
		
	}

	@Override
	public IQueryBoxDialog constantPushClick() {
		LogImpl.getInstance().info("弹出下推源单查询框，点【下推（常量）】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='下推（常量）']/parent::button")).click();
		return this;
	}
	
	@Override
	public IQueryBoxDialog expressionPushClick() {
		LogImpl.getInstance().info("弹出下推源单查询框，点【下推（表达式）】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='下推（表达式）']/parent::button")).click();
		return this;
	}
	
	@Override
	public IQueryBoxDialog fieldPushClick() {
		LogImpl.getInstance().info("弹出下推源单查询框，点【下推（字段）】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='下推（字段）']/parent::button")).click();
		return this;
	}

	public IQueryBoxDialog cancelClick(){
		LogImpl.getInstance().info("弹出基本信息框，点击【取消】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='取消']/parent::button")).click();
		return this;
		
	}
	
	public IQueryBoxDialog determineClick(){
		LogImpl.getInstance().info("弹出基本信息框，点击【确定】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='确定']/parent::button")).click();
		return this;
		
	}

	@Override
	public IQueryBoxDialog okClick() {
		LogImpl.getInstance().info("弹框，点【OK】");
		el.findElement(By.xpath(".//div[@class='ui-btn']/button/span[text()='OK']/parent::button")).click();
		return this;
	}
	
	@Override
	public IQueryBoxDialog close(){
		LogImpl.getInstance().info("关闭对话框");
		el.findElement(By.xpath(".//div[@class='dialog-close']")).click();
		return this;	
	}

	public IQueryBoxDialog closeIcon(){
		
		LogImpl.getInstance().info("关闭表单界面错误提示");
		el.findElement(By.xpath(".//div[@class='errorinfo']/span[@class='closeIcon']")).click();
		return this;
	}
	
	
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub
		
	}



}
