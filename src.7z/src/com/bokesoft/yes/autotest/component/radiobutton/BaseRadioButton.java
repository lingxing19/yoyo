package com.bokesoft.yes.autotest.component.radiobutton;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IRadioButton;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;
import com.sun.org.apache.regexp.internal.recompile;

public class BaseRadioButton extends AbstractComponent implements IRadioButton {

	public BaseRadioButton(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
	}

	@Override
	public IRadioButton click() {
		LogImpl.getInstance().info("勾选    单选框:" + key);
		el.findElement(By.tagName("span")).click();
		return this;
	}

	@Override
	public boolean isChecked() {
		String s = el.findElement(By.tagName("span")).getAttribute("class");
		if (s.contains("checked")) {
			System.out.println(true);
			return true;

		}
		System.out.println(false);
		return false;
	}

	@Override
	public boolean isDisplayed() {
		return el.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		return el.isEnabled();
	}

	@Override
	public IControl input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	@Override
	public String getHovertext() {
		return el.getAttribute("title");
	}

	@Override
	public String getHalign() {
		return el.findElement(By.tagName("label")).getCssValue("text-align");
	}

	@Override
	public String getForeColor() {
		String s = el.findElement(By.tagName("label")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	@Override
	public String getBackColor() {
		String s = el.getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	@Override
	public String getFontName() {
		 return el.findElement(By.tagName("label")).getCssValue("font-family");
		
	}

	@Override
	public String getFontSize() {
		return el.findElement(By.tagName("label")).getCssValue("font-size");
	}

	@Override
	public String getFontWeight() {
		return el.findElement(By.tagName("label")).getCssValue("font-weight");
	}

	@Override
	public String getFontStyle() {
		return el.findElement(By.tagName("label")).getCssValue("font-style");
	}

	@Override
	public boolean isRedcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("error-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public String getErrorInfo() {
		return el.findElement(By.className("error-icon")).getAttribute("title");
	}

	@Override
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("require-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();

	}

	@Override
	public void pressTabKey() {
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();

	}

	@Override
	public void pressBackspaceKey() {
		LogImpl.getInstance().info("选中，按Backspace键，清空");
		el.findElement(By.tagName("input")).click();
		RobotUtil.pressBackspaceKey();
	}

	@Override
	public String getVertical() {
		return el.findElement(By.tagName("label")).getCssValue("vertical-align");
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
}