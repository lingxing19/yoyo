package com.bokesoft.yes.autotest.component;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public abstract class AbstractComponent implements IControl {

	protected static int formID = 0;

	protected static WebDriver driver = null;

	protected WebElement el = null;

	protected String key = null;

	public static void setDriver(WebDriver driver) {
		AbstractComponent.driver = driver;
	}

	public static void setFormID(int formID) {
		AbstractComponent.formID = formID;
	}

	public static int getFormID() {
		return formID;
	}

	protected void waittime(long millis) {
		try {
			Thread.sleep(millis);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 等待需要加载的元素
	 * 
	 */
	// protected void waitload(By by) {
	// WebDriverWait wait = new WebDriverWait(driver, 1000);
	// wait.until(new ExpectedCondition<WebElement>() {
	// @Override
	// public WebElement apply(WebDriver d) {
	// return d.findElement(by);
	// }
	// });
	// }

}
