package com.bokesoft.yes.autotest.component;

public interface IFunction {

	public String getText();

}
