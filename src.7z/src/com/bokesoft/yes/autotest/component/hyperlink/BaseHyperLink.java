package com.bokesoft.yes.autotest.component.hyperlink;

import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IHyperLink;
import com.bokesoft.yes.autotest.component.IRadioButton;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseHyperLink extends AbstractComponent implements IHyperLink {

	public BaseHyperLink(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//a[@id='" + formID + "_" + key + "']"));
	}

	@Override
	public IHyperLink click() {
		LogImpl.getInstance().info("点击超链接:" + key);
		el.click();
		return this;
	}

	@Override
	public boolean isDisplayed() {
		return el.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		return el.isEnabled();
	}

	@Override
	public IControl input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	@Override
	public String getHovertext() {
		return el.getAttribute("title");
	}

	/**
	 * 前景色测试
	 */
	public String getForeColor() {
		String s = el.getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;

	}

	/**
	 * 编辑框内水平左右居中方向测试
	 */
	public String getHalign() {
		return el.getCssValue("text-align");
	}

	/**
	 * 背景色测试
	 */
	public String getBackColor() {
		String s = el.getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;

	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	/**
	 * 字体名称测试
	 */
	public String getFontName() {
		return el.getCssValue("font-family");
	}

	/**
	 * 字体大小测试
	 */
	public String getFontSize() {
		return el.getCssValue("font-size");
	}

	/**
	 * 字体粗细测试
	 */
	public String getFontWeight() {
		return el.getCssValue("font-weight");
	}

	/**
	 * 字体样式测试
	 */
	public String getFontStyle() {
		return el.getCssValue("font-style");
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getVertical() {
		return el.getCssValue("vertical-align");
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public String getText() {
		return el.getAttribute("textContent");
		// System.out.println(s);

	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
}
