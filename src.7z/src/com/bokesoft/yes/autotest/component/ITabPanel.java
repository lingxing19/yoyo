package com.bokesoft.yes.autotest.component;

public interface ITabPanel {

	/**
	 * 选中某页
	 * 
	 * @param text
	 *            页签上的名称
	 */
	public ITabPanel selectTab(String text);

	/**
	 * 选中某页
	 * 
	 * @param index
	 *            页签的序号，从0开始
	 */
	public ITabPanel selectTab(int index);

	public String getTitle();

	public void checkTitleText(int index, String title, String msg);

}
