package com.bokesoft.yes.autotest.component.tabpanel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.ITabPanel;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseTabPanel extends AbstractComponent implements ITabPanel{

	
	public BaseTabPanel(String key){
		this.key = key;		

		this.el=driver.findElement(By.xpath("//div[@id='"+formID+"_" +key+"']"));	
	}

	
	@Override
	public ITabPanel selectTab(String text) {
       //List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabpnl ui-pnl']/ul/li"));
		
		List<WebElement> list = this.el.findElements(By.tagName("li"));
		
		WebElement element = null;
		
		for(WebElement el : list){
			//获取tab页上的名称
			String s = el.findElement(By.tagName("label")).getText();
			if(s.equalsIgnoreCase(text.trim())){
				element = el;
				break;
			}
		}
		
		if(element == null){
			throw new RuntimeException("未找Tab页:"+text);
		}

		element.click();
		
		LogImpl.getInstance().info("选中Tab页:"+text);
		return this;
	}
	

	@Override
	public ITabPanel selectTab(int index){
		//List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabpnl ui-pnl']/ul/li"));	
		
		List<WebElement> list = this.el.findElements(By.tagName("li"));
		
		if(index > list.size()){
			throw new RuntimeException("最大Tab页为："+list.size()+" ,  当前为："+index);
		}

		WebElement element = list.get(index);
		element.click();
		
		LogImpl.getInstance().info("选中第:"+index+"个Tab页。");
		return this;
	}

	@Override
	public String getTitle() {
		
		String s = el.findElement(By.tagName("label")).getAttribute("title");
		return s;
	}


	
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void checkTitleText(int index, String title, String msg) {
		//List<WebElement> list = driver.findElements(By.xpath("//div[@class='ui-tabpnl ui-pnl']/ul/li"));
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='list']/ul/li"));	
		if(index > list.size()){
			throw new RuntimeException("最大Tab页为："+list.size()+" ,  当前为："+index);
		}
		
		WebElement element = list.get(index);
		
		String ret = element.getText();
		if(ret.equals(title)){
			LogImpl.getInstance().info(msg +"======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg +"======检查失败 预期结果为:"+title+"	实际结果为:"+ret);
	}


	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub
		
	}

}
