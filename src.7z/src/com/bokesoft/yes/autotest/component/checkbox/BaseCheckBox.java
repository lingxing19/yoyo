package com.bokesoft.yes.autotest.component.checkbox;

import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.ICheckBox;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseCheckBox extends AbstractComponent implements ICheckBox {

	public BaseCheckBox(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
	}

	/**
	 * 可用性
	 */
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return el.isEnabled();
	}

	/**
	 * 可见性
	 */
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return el.isDisplayed();
	}

	/**
	 * 悬浮提示
	 */
	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return el.getAttribute("title");
	}

	public ICheckBox click() {
		LogImpl.getInstance().info("勾选/去掉勾选  复选框:" + key);
		el.findElement(By.tagName("span")).click();
		return this;
	}

	public boolean isChecked(String text) {
		String s = el.findElement(By.tagName("span")).getAttribute("ischecked");
		return Boolean.parseBoolean(s);
	}

	/**
	 * 检查黄色角标
	 */
	@Override
	// public boolean isYellowcornerExist() {
	// // TODO Auto-generated method stub
	// LogImpl.getInstance().info("查看黄色角标");
	// try {
	// el.findElement(By.className("require-icon"));
	// return true;
	// } catch (NoSuchElementException e) {
	// return false;
	// }
	// }

	/**
	 * 数值框取值
	 */
	public String getText() {
		String s = el.findElement(By.tagName("input")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	/**
	 * 前景色测试
	 */
	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("label")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	/**
	 * 背景色测试
	 */
	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		String s = el.getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	/**
	 * 字体名称测试
	 */
	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		String s1 =el.findElement(By.tagName("label")).getCssValue("font-family");
		String s2 = s1.substring(1,s1.length()-1);	
		return s2 ;
	}

	/**
	 * 字体大小测试
	 */
	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("font-size");
	}

	/**
	 * 粗体测试
	 */
	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("font-weight");
	}

	/**
	 * 斜体测试
	 */
	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("font-style");
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		return el.findElement(By.tagName("label")).getCssValue("vertical-align");
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isChecked() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("span")).getAttribute("class");
		if (s.contains("checked")) {
			System.out.println(true);
			return true;

		}
		System.out.println(false);
		return false;
	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}
