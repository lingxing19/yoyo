package com.bokesoft.yes.autotest.component.button;

import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IButton;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class BaseButton extends AbstractComponent implements IButton {

	public BaseButton(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
	}

	@Override
	public IButton click() {
		LogImpl.getInstance().info("点击Button:" + key);
		el.findElement(By.tagName("button")).click();
		waittime(1000);
		return this;
	}

	/**
	 * 可用性测试
	 */
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return el.isEnabled();
	}

	/**
	 * 可见性测试
	 */
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return el.isDisplayed();
	}

	/**
	 * 悬浮提示信息测试
	 */
	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return el.getAttribute("title");
	}

	/**
	 * 取值
	 */
	@Override
	public String getText() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("button")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	/**
	 * 水平对齐方式测试
	 */
	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("button")).getCssValue("text-align");
	}

	/**
	 * 前景色测试
	 */
	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("span")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	/**
	 * 背景色测试
	 */
	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("button")).getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	/**
	 * 字体名称测试
	 */
	@Override
	public String getFontName() {
		String s1 =el.findElement(By.tagName("span")).getCssValue("font-family");
		String s2 =s1.substring(1,s1.length()-1);	
		
		return s2;
	}

	/**
	 * 字体大小测试
	 */
	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("span")).getCssValue("font-size");
	}

	/**
	 * 加粗测试
	 */
	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("span")).getCssValue("font-weight");
	}

	/**
	 * 斜体测试
	 */
	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("span")).getCssValue("font-style");
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		return el.findElement(By.tagName("span")).getCssValue("vertical-align");
	}

	@Override
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();
	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

	/**
	 * 判断图标是否存在
	 */
	public boolean isIcon(String iconName) {
		String s1 =el.findElement(By.className("icon")).getAttribute("Style");
		if (s1.contains(iconName)) {
			return true ;
			
		}
		return false;
	}
	

}
