﻿package com.bokesoft.yes.autotest.component;

public interface IQueryBoxDialog {

	public IQueryBoxDialog queryClick();

	public IQueryBoxDialog pushClick();

	public IQueryBoxDialog ThroughClick();

	public IQueryBoxDialog rejectedClick();

	public IQueryBoxDialog cancelClick();

	public IQueryBoxDialog determineClick();

	public IQueryBoxDialog constantPushClick();

	public IQueryBoxDialog expressionPushClick();

	public IQueryBoxDialog fieldPushClick();

	public IQueryBoxDialog okClick();

	public IQueryBoxDialog close();
	
	public IQueryBoxDialog closeIcon();

	/**
	 * 获取dialog的id
	 * 
	 */
	public int getDialogID();

}
