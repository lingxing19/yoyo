package com.bokesoft.yes.autotest.component;

public interface ILabel extends IControl {

	public boolean isTextColor(String color);

	public String getText();

	public String getIcon();

	public String getVertical();

	public String checkGetText();

}
