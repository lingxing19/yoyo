package com.bokesoft.yes.autotest.component.combobox;

import java.util.List;

import javax.swing.Spring;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IComboBox;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class BaseComboBox extends AbstractComponent implements IComboBox {

	protected WebElement view = null;

	public BaseComboBox(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
		try {
			this.view = driver.findElement(By.id(formID + "_" + key + "_view"));
		} catch (NoSuchElementException e) {
			// TODO: handle exception
		}
	}

	/**
	 * 点击下拉框下拉按钮
	 */
	@Override
	public BaseComboBox dropDownClick() {
		LogImpl.getInstance().info("点击下拉框：" + key);
		el.findElement(By.xpath("./div[@class='arrow']")).click();
		view = driver.findElement(By.id(formID + "_" + key + "_view"));
		waittime(1000);
		return this;
	}

	/**
	 * 关闭下拉框
	 */
	public void backClick() {
		el.findElement(By.xpath("./div[@class='arrow']")).click();
		waittime(500);
		
	}
	@Override
	public BaseComboBox itemClick(String itemName) {
		LogImpl.getInstance().info("选中下拉项" + itemName);
		List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
		for (WebElement el : li) {
			if (el.getAttribute("title").trim().equals(itemName.trim())) {
				el.click();
				waittime(300);
				return this;
			}
		}
		return this;
		
	}
	
	/**
	 * 获取自动下拉项取值
	 */
	public String getAutoItems() {
		List<WebElement> elements = driver.findElements(By.xpath("//div[contains(@class,'autovw') and contains(@style,'display: block')]/ul/li"));
		String s ="";
		for(WebElement el:elements){
			s+= el.getText();
		}
				
		return s;
	}

	/**
	 * 选中自动匹配下拉项
	 * 项
	 */
	@Override
	public BaseComboBox autoItemClick(String itemName) {
		LogImpl.getInstance().info("选中自动匹配的下拉项" + itemName);
		List<WebElement> elements = driver.findElements(
				By.xpath("//div[@class='loading mask']/following::div[contains(@style,'display: block')]/ul/li"));
		for (WebElement el : elements) {
			if (el.getText().trim().equals(itemName.trim())) {
				el.click();
				return this;
			}
		}
		return this;
	}

	/**
	 * 判断被选中的下拉项
	 */
	public String isSelected() {
		List<WebElement> elements =driver.findElements(By.xpath("//div[contains(@style,'display: block')]/ul/li"));
		String s = "";
		for (WebElement el:elements) {
			if (el.getAttribute("class").equals("sel")) {
				s +=el.getText();
			}
		}
		return s ;
	}
	@Override
	public boolean isDisplayed() {
		return el.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		return el.isEnabled();
	}

	@Override
	public IControl input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	@Override
	public String getHovertext() {
		return el.getAttribute("title");
	}

	@Override
	public String getHalign() {
		return el.findElement(By.tagName("input")).getCssValue("text-align");
	}

	@Override
	public String getForeColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	@Override
	public String getBackColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	@Override
	public String getFontName() {
		return el.findElement(By.tagName("input")).getCssValue("font-family");
	}

	@Override
	public String getFontSize() {
		return el.findElement(By.tagName("input")).getCssValue("font-size");
	}

	@Override
	public String getFontWeight() {
		return el.findElement(By.tagName("input")).getCssValue("font-weight");
	}

	@Override
	public String getFontStyle() {
		return el.findElement(By.tagName("input")).getCssValue("font-style");
	}

	@Override
	public boolean isRedcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("error-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public String getErrorInfo() {
		return el.findElement(By.className("error-icon")).getAttribute("title");
	}

	@Override
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("require-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();

	}

	@Override
	public void pressTabKey() {
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();

	}

	@Override
	public void pressBackspaceKey() {
		LogImpl.getInstance().info("选中，按Backspace键，清空");
		el.findElement(By.tagName("input")).click();
		RobotUtil.pressBackspaceKey();
	}

	/**
	 * 单击测试试
	 * 
	 * @return
	 */
	public IComboBox click() {
		LogImpl.getInstance().info("控件：" + key + ",单击");
		el.findElement(By.tagName("input")).click();
		return this;
	}

	@Override
	public IComboBox clear() {
		LogImpl.getInstance().info("字段：" + key + "清空");
		el.findElement(By.tagName("input")).clear();
		return this;
	}

	@Override
	public String getText() {
		String s = el.findElement(By.tagName("input")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	/**
	 * 获取下拉项取值
	 */
	public String getItems() {
		List<WebElement> li = view.findElements(By.xpath(".//ul/li"));
		String s = "";
		for (WebElement el : li) {
			System.out.println(el.getAttribute("title"));
			s += el.getAttribute("title");
		}
		return s;

	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
}
