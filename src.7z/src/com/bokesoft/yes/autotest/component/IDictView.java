package com.bokesoft.yes.autotest.component;

import java.util.List;

import com.bokesoft.yes.autotest.component.dictview.BaseDictViewItem;

public interface IDictView {
	
	
	public IDictView expandItemClick(String itemCode);
	
	public IDictView itemClick(String itemCode);
	
	public List<BaseDictViewItem> getChildren(boolean root);

	

}
