package com.bokesoft.yes.autotest.component;

public interface IErrorDialog {

	public IErrorDialog close();

	public String getText();
	
	public void close(String clickName);

}
