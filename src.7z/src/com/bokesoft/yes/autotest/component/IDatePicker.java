package com.bokesoft.yes.autotest.component;

import com.bokesoft.yes.autotest.component.datepicker.BaseDatePicker;

public interface IDatePicker extends IControl {

	/**
	 * 日期下拉框中输入日期
	 */
	public IDatePicker viewInput(int year, String month, int day);

	/**
	 * 日期下拉框中输入日期时间
	 */
	public IDatePicker viewInput(int year, String month, int day, int hour, int minute, int second);

	/**
	 * 日期下拉框中输入当前日期时间
	 */
	public IDatePicker inputCurrenttime();

	/**
	 * 日期框输入当前时间后几天
	 */
	public IDatePicker inputNextDay(int next);

	/**
	 * 日期框输入当前时间后10分钟
	 */
	public IDatePicker inputNextMinute();

	public String getText();

	public IDatePicker clear();
	
	public BaseDatePicker viewClick();
	
	public void pressBackspaceKey(int num);
	
	public IDatePicker focusMovetoEnd();
	
	public IDatePicker chooseFocus(int start ,int end);
	
	public void click();
	
	public String getViewCurrDate();
	
	public String getCurrDate();
	
	public void ctrlC();
	
	public void ctrlV();
	
	public void paste(String text);

	
}
