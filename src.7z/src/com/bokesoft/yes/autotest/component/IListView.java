package com.bokesoft.yes.autotest.component;

public interface IListView {
	/**
	 * 给出行号，打开单据（当前页）
	 * 
	 * @param index
	 *            第几行，即序号列的行号
	 */
	public void dbClick(int index);

	/**
	 * 打开最新的生成的那张的单据（当前页）
	 */
	public void dbClick();

	/**
	 * 双击打开符合条件的单据(所有页)。如：打开单据编号为001的单据 dbClick("单据编号","001");
	 * 分页时，打开单据后，如要重新操作listview,需要点击listview的tab页。
	 * 
	 * @param colName
	 *            列名
	 * @param text
	 *            列值
	 * @param workName工作项名称
	 * @param msg
	 *            名称取值想
	 */
	public void dbClick(String colName, String text, String workName, String msg);

	/**
	 * 查询是否存在符合条件的单据的行号(所有页)。如：查询是否存在单据编号为001的单据 isFormExsit("单据编号","001")
	 * 
	 * @param colName
	 *            列名
	 * @param text
	 *            列值
	 * @return 返回单据的数量
	 */
	public boolean isFormExsit(String colName, String text);

	/**
	 * 查询符合条件的单据数量(所有页)。如：查询单据编号为001的单据数量 countForm("单据编号","001")
	 * 
	 * @param colName
	 *            列名
	 * @param text
	 *            列值
	 * @return 返回单据的数量
	 */
	public int countForm(String colName, String text);

	/**
	 * @param colName
	 *            列名
	 * @return 列号，从0开始（不计算序号列）
	 */
	public int getColIndex(String colName);

	/**
	 * 向前翻一页
	 * 
	 * @return
	 */
	public IListView prevClick();

	/**
	 * 向后翻一页
	 * 
	 * @return
	 */
	public IListView nextClick();

	/**
	 * 直接跳转至某页
	 * 
	 * @param pagenum
	 *            要跳转的页号
	 * @return
	 */
	public IListView pageClick(int pagenum);

	/**
	 * 将分页情况下的listview设置到第一页 适用于，重新去new一个listview继续操作（上次操作之后可能停留在任意一页）
	 * 
	 * @return
	 */
	public IListView setPage2First();

	public int getCurrentPageNum();

	/**
	 * 获得ListView中的值
	 * 
	 * @param colName
	 *            列名
	 * @param index
	 *            行序号
	 * @return
	 */
	public String getValue(String colName, int index);

	/**
	 * 点击视图按钮
	 * 
	 * @param colName
	 *            列名
	 * @param index
	 *            行序号
	 * @return
	 */
	public IListView ButtonClick(String colName, int index);

}
