package com.bokesoft.yes.autotest.component;

public interface IChangePasswordEditor extends IControl {

	public String getText();

}
