package com.bokesoft.yes.autotest.component.dict;


public class BaseDictItem {
	// 1 可用 , 0 停用 , 2  禁用
	private int enable;
	private String caption;
	private int nodeType;

	// 1 勾选 , 0 未选  , 2 半选
	private int chkState = -1;

	public BaseDictItem() {
	}
	
	public BaseDictItem(String caption, int enable, int nodeType) {
		this.caption = caption;
		this.enable = enable;
		this.nodeType = nodeType;
	}
	
	public BaseDictItem(String caption, int enable, int nodeType,int chkState) {
		this.caption = caption;
		this.enable = enable;
		this.nodeType = nodeType;
		this.chkState =chkState;
	}
	public int getEnable() {
		return enable;
	}

	public void setEnable(int enable) {
		this.enable = enable;
	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public int getNodeType() {
		return nodeType;
	}

	public void setNodeType(int nodeType) {
		this.nodeType = nodeType;
	}

	public int getChkState() {
		return chkState;
	}

	public void setChkState(int chkState) {
		this.chkState = chkState;
	}

	@Override
	public String toString() {
		return "capiton:" + caption + ",enable:" + enable + ",nodeType:" +nodeType+ ",chkState:" +chkState;
	}
	
}