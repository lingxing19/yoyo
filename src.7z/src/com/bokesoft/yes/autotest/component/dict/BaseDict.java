package com.bokesoft.yes.autotest.component.dict;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IDict;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class BaseDict extends AbstractComponent implements IDict {
	private String id = null;
	private String rootId = null;
	protected WebElement dictView = null;

	protected List<WebElement> li = null;

	public BaseDict(String key) {
		this.key = key;
		this.el = driver.findElement(By.id(formID + "_" + key));
		// this.dictView=el.findElement(By.id(formID+"_"+key+"_dropview"));
		try {
			this.dictView = driver.findElement(By.id(formID + "_" + key + "_dropview"));
		} catch (NoSuchElementException e) {
			// TODO: handle exception
		}

	}

	@Override
	public BaseDict viewClick() {
		LogImpl.getInstance().info("点击展开字典下拉项");
		el.findElement(By.tagName("div")).click();
		waittime(500);
		try {
			dictView = driver.findElement(By.id(formID + "_" + key + "_dropview"));
			li = dictView.findElements(By.tagName("li"));
		} catch (NoSuchElementException e) {
			// TODO: handle exception
		}
		// WebElement element =
		// dictView.findElement(By.xpath(".//div/li[contains(@class,'root')]"));
		if (li.size() > 0) {
			WebElement element = dictView.findElement(By.xpath(".//div/li[contains(@class,'root')]"));
			rootId = element.getAttribute("id");
		} else {
			WebElement element = dictView.findElement(By.xpath(".//div/table[contains(@class,'body-table root')]"));
			rootId = element.getAttribute("id");
		}

		return this;
	}

	@Override
	public BaseDict itemClick(String itemCode) {
		LogImpl.getInstance().info("点击选择字典项：" + itemCode);
		dictView.findElement(By.xpath(".//a[@class='dt-anchor']/span[text()='" + itemCode + "']")).click();
		return this;
	}

	@Override
	public BaseDict chainItemClick(String itemCode, String text) {
		LogImpl.getInstance().info("点击选择字典项：" + itemCode);
		dictView.findElement(
				By.xpath(".//td[@class='Code frist']/div/a[@class='dt-anchor']/span[text()='" + itemCode + "']")).click();
		waittime(500);
		dictView.findElement(By.xpath(".//div/div[@class='chainmean']/span[text()='" + text + "']")).click();
		return this;
	}

	@Override
	public BaseDict expandClick(String itemCode) {
		LogImpl.getInstance().info("点击展开字典项：" + itemCode);
		dictView.findElement(
				By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li/span[contains(@class,'icon')]"))
				.click();
		waittime(500);
		String id = dictView.findElement(By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li"))
				.getAttribute("id");
		this.id = id;
		return this;
	}

	public BaseDict collapseClick(String itemCode) {
		LogImpl.getInstance().info("点击收起字典项：" + itemCode);
		dictView.findElement(
				By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li/span[contains(@class,'icon')]"))
				.click();
		waittime(500);
		return this;
	}

	/**
	 * 获取子节点对象组
	 * 
	 * 
	 */
	public List<BaseDictItem> getChildren(boolean root) {
		List<BaseDictItem> items = new ArrayList<BaseDictItem>();
		List<WebElement> list = null;

		waittime(100);
		if (root) {
			if (li.size() > 0) {
				list = dictView.findElements(By.xpath(".//li[@parentid='" + rootId + "']"));
			} else {
				list = dictView.findElements(By.xpath(".//tr[@parentid='" + rootId + "']"));
			}
			;
		} else {
			list = dictView.findElements(By.xpath(".//li[@parentid='" + id + "']"));
		}
		BaseDictItem item = null;
		for (WebElement e : list) {
			// 取属性,并封装
			item = new BaseDictItem();
			int enable = -1;

			String str = e.findElement(By.xpath(".//a[@class='dt-anchor']/span[1]")).getAttribute("class");

			if (str.contains("discard")) {
				enable = 2;
			} else if (str.contains("disable")) {
				enable = 0;
			} else if (str.contains("enable")) {
				enable = 1;
			}
			item.setEnable(enable);
			item.setCaption(e.findElement(By.xpath(".//a[@class='dt-anchor']/span[2]")).getText());
			int nodeType = e.findElement(By.xpath(".//a[@class='dt-anchor']/span[1]")).getAttribute("class")
					.contains("b-") ? 1 : 0;
			item.setNodeType(nodeType);

			// 区分单选和多选
			boolean flag = true;
			try {
				WebElement element = e.findElement(By.xpath(".//span[contains(@class,'dt-chk')]"));
			} catch (org.openqa.selenium.NoSuchElementException ex) {
				flag = false;
			}

			if (flag) {
				// System.out.println("chk-==="+e.findElement(By.xpath(".//span[2]")).getAttribute("chkstate"));
				item.setChkState(Integer.parseInt(e.findElement(By.xpath(".//span[2]")).getAttribute("chkstate")));
			}
			items.add(item);
			System.out.println(item);
		}

		return items;

	}

	@Override
	public BaseDict clearClick() {
		return this;
	}

	@Override
	public String getRootNode() {

		return dictView.findElement(By.xpath(".//a[1]/span[@class='b-txt']")).getText();
	}

	@Override
	public BaseDict itemCheckClick(String itemCode) {
		LogImpl.getInstance().info("勾选/取消勾选字典项：" + itemCode);
		dictView.findElement(By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li/span[2]")).click();
		return this;
	}

	/**
	 * 
	 * 编辑框内字符清空
	 * 
	 * @return
	 */
	public IDict clear() {
		LogImpl.getInstance().info("字段：" + key + "清空");

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
		ExpectedCondition<WebElement> nameEC = ExpectedConditions
				.visibilityOfElementLocated(By.id(formID + "_" + key + "_textbtn"));
		WebElement input = wait.until(nameEC);
		input.clear();
		// usernameElement.sendKeys(username);

		// el.findElement(By.id(formID+"_" +key+"_textbtn")).clear();

		// el.findElement(By.tagName("input")).clear();
		return this;
	}

	@Override
	public boolean isDisplayed() {
		return el.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		return el.isEnabled();
	}

	@Override
	public IControl input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("input")).sendKeys(text);
		return this;
	}

	@Override
	public IControl inputClick() {
		LogImpl.getInstance().info("点击input" + key);
		el.findElement(By.tagName("input")).click();
		return this;
	}

	@Override
	public String getHovertext() {
		return el.getAttribute("title");
	}

	@Override
	public String getHalign() {
		return el.findElement(By.tagName("input")).getCssValue("text-align");
	}

	@Override
	public String getForeColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("color");
		String s2 = s.substring(5, s.length() - 4);
		return s2;
	}

	@Override
	public String getBackColor() {
		String s = el.findElement(By.tagName("input")).getCssValue("background-color");
		String s2 = s.substring(5, s.length() - 4);
		return s2;

	}

	@Override
	public String getFontName() {
		return el.findElement(By.tagName("input")).getCssValue("font-family");
	}

	@Override
	public String getFontSize() {
		return el.findElement(By.tagName("input")).getCssValue("font-size");
	}

	@Override
	public String getFontWeight() {
		return el.findElement(By.tagName("input")).getCssValue("font-weight");
	}

	@Override
	public String getFontStyle() {
		return el.findElement(By.tagName("input")).getCssValue("font-style");
	}

	@Override
	public boolean isRedcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("error-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}

	}

	@Override
	public String getErrorInfo() {
		return el.findElement(By.className("error-icon")).getAttribute("title");
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看红色角标");
		try {
			el.findElement(By.className("require-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public void pressEnterKey() {
		LogImpl.getInstance().info("按Enter键");
		RobotUtil.pressEnterKey();

	}

	@Override
	public void pressTabKey() {
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();

	}

	@Override
	public void pressBackspaceKey() {
		LogImpl.getInstance().info("选中，按Backspace键，清空");
		el.findElement(By.tagName("input")).click();
		RobotUtil.pressBackspaceKey();

	}

	@Override
	public void pressBackspaceKey(int left, int num) {
		LogImpl.getInstance().info("选中，按left键，移动");
		el.findElement(By.tagName("input")).click();
		for (int i = 0; i < left; i++) {
			RobotUtil.pressLeft();
		}
		for (int i = 0; i < num; i++) {
			RobotUtil.pressBackspaceKey();
		}
	}

	@Override
	public String getText() {
		String s = el.findElement(By.tagName("input")).getAttribute("value");
		System.out.println(s);
		return s;
	};

	@Override
	public boolean itemChecked(String itemCode) {
		String s = dictView.findElement(By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li/div"))
				.getAttribute("class");
		if (s.contains("sel")) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean itemSelect(String itemCode) {
		String s = dictView.findElement(By.xpath(".//span[text()='" + itemCode + "']/parent::a/parent::li"))
				.getAttribute("class");
		if (s.contains("disableSelect")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 多选字典下拉框按钮点击事件
	 */
	@Override
	public IDict dictButtonClick(String buttonName) {
		dictView.findElement(By.xpath(".//div[@class='chainmean']/span[text()='" + buttonName + "']")).click();
		return this;
	}

	/**
	 * 获取根节点勾选状态
	 */
	@Override
	public String getRootChkstate() {
		return dictView.findElement(By.xpath(".//li[1]/span[2]")).getAttribute("chkstate");
	}

	/**
	 * 链式字典下拉框获取页码
	 * 
	 */
	public String getPage() {
		return dictView.findElement(By.xpath(".//div[1]/div[3]/div[1]/span[@class='pageinfo']")).getAttribute("maxnum");
	}

	public IDict paste(String text) {
		LogImpl.getInstance().info("字段：" + key + "，粘贴文本：" + text);
		el.findElement(By.tagName("input")).click();
		RobotUtil.paste(text);
		return this;
	}

	/**
	 * 链式字典下拉框下一页按钮点击事件
	 * 
	 */
	public BaseDict nextPageClick() {
		dictView.findElement(By.xpath(".//div[1]/div[3]/div[1]/span[@class='next']")).click();
		li = dictView.findElements(By.tagName("li"));
		waittime(500);
		if (li.size() > 0) {
			WebElement element = dictView.findElement(By.xpath(".//div/li[contains(@class,'root')]"));
			rootId = element.getAttribute("id");
		} else {
			WebElement element = dictView.findElement(By.xpath(".//div/table[contains(@class,'body-table root')]"));
			rootId = element.getAttribute("id");
		}
		return this;
	}

	public BaseDict numClick(int num) {
		li = dictView.findElements(By.tagName("li"));
		dictView.findElement(By.xpath(".//div[1]/div[3]/div[1]/span[@class='pageinfo']/span[text()='" + num + "']"))
				.click();
		waittime(1000);
		WebElement element = dictView.findElement(By.xpath(".//div/table[contains(@class,'body-table root')]"));
		rootId = element.getAttribute("id");
		return this;
	}

	@Override
	public BaseDict lastPageClick() {
		li = dictView.findElements(By.tagName("li"));
		dictView.findElement(By.xpath(".//div[1]/div[3]/div[1]/span[@class='prev']")).click();
		waittime(500);
		if (li.size() > 0) {
			WebElement element = dictView.findElement(By.xpath(".//div/li[contains(@class,'root')]"));
			rootId = element.getAttribute("id");
		} else {
			WebElement element = dictView.findElement(By.xpath(".//div/table[contains(@class,'body-table root')]"));
			rootId = element.getAttribute("id");
		}
		return this;
	}

	public BaseDict searchBoxInput(String text) {
		dictView.findElement(By.xpath(".//div[@class='dt-searchwrap']/input[@class='findinput']")).sendKeys(text);
		return this;

	}

	public BaseDict searchButtonClick() {
		dictView.findElement(By.xpath(".//div[@class='dt-searchwrap']/span[@class='findspan']")).click();
		return this;

	}

	public BaseDict searchInputClear() {
		dictView.findElement(By.xpath(".//div[@class='dt-searchwrap']/input[@class='findinput']")).clear();
		return this;

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
}
