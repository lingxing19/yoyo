package com.bokesoft.yes.autotest.component.textarea;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import com.bokesoft.yes.autotest.component.AbstractComponent;

import com.bokesoft.yes.autotest.component.ITextArea;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class BaseTextArea extends AbstractComponent implements ITextArea {

	public BaseTextArea(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//span[@id='" + formID + "_" + key + "']"));
	}

	/**
	 * 编辑框取值
	 */
	public String getText() {
		String s = el.findElement(By.tagName("textarea")).getAttribute("value");
		// System.out.println(s);
		return s;
	}

	/**
	 * 可见性测试
	 */
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return el.isDisplayed();
	}

	/**
	 * 可用性测试
	 */
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return el.isEnabled();
	}

	/**
	 * 悬浮提示测试
	 */
	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return el.getAttribute("title");
	}

	public void  click() {
		el.findElement(By.tagName("textarea")).click();
		
	}
	/**
	 * 文本域编辑输入测试
	 * 
	 * @param text
	 * @return
	 */
	public ITextArea input(String text) {
		LogImpl.getInstance().info("字段：" + key + "输入：" + text);
		el.findElement(By.tagName("textarea")).sendKeys(text);
		return this;
	}

	/**
	 * 字符清空
	 */
	public ITextArea clear() {
		LogImpl.getInstance().info("字段：" + key + "清除");
		el.findElement(By.tagName("textarea")).clear();
		return this;
	}

	/**
	 * 必填黄色角标测试
	 */
	public boolean isYellowcornerExist() {
		// LogImpl.getInstance().info("查看黄色角标");
		try {
			el.findElement(By.className("require-icon"));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * 模拟键盘全选操作
	 * 
	 * @return
	 */
	public ITextArea ctrlA() {
		LogImpl.getInstance().info("ctrlA全选");
		RobotUtil.pressCtrlA();
		return this;
	}

	/**
	 * 模拟键盘复制操作
	 * 
	 * @return
	 */
	public ITextArea ctrlC() {
		LogImpl.getInstance().info("ctrlC复制");
		RobotUtil.pressCtrlC();
		return this;
	}

	/**
	 * 模拟键盘粘贴操作
	 * 
	 * @return
	 */
	public ITextArea ctrlV() {
		LogImpl.getInstance().info("ctrlV粘贴");
		RobotUtil.pressCtrlV();
		return this;
	}

	/**
	 * 编辑框粘贴文本
	 * 
	 * @param text
	 * @return
	 */
	public ITextArea paste(String text) {
		LogImpl.getInstance().info("字段：" + key + "，粘贴文本：" + text);
		el.findElement(By.tagName("textarea")).click();
		RobotUtil.paste(text);
		waittime(500);
		return this;
	}

	/**
	 * 模拟移动光标操作
	 */
	public ITextArea pressMoveCursorKey() {
		LogImpl.getInstance().info("移动光标");
		RobotUtil.pressTabKey();
		return this;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("textarea")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("textarea")).getCssValue("font-family");
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("textarea")).getCssValue("font-size");
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("textarea")).getCssValue("font-weight");
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("textarea")).getCssValue("font-style");
	}

	/**
	 * 模拟键盘Tab键操作
	 */
	public void pressTabKey() {
		LogImpl.getInstance().info("按Tab键");
		RobotUtil.pressTabKey();
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ITextArea textArea(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public ITextArea moveCursorKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}
