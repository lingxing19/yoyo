package com.bokesoft.yes.autotest.component;

public interface IMonthPicker extends IControl {

	/**
	 * 日期下拉框中输入年月
	 */
	public IMonthPicker viewInput(int year, String month);

//	/**
//	 * 日期下拉框中输入年月
//	 */
//	public IMonthPicker viewInput1(int year, String month);

	/**
	 * 日期下拉框中输入当前日期时间
	 */
	public IMonthPicker inputCurrenttime();

	public String getText();

	public IUTCDatePicker clear();

}
