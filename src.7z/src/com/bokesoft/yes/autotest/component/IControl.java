package com.bokesoft.yes.autotest.component;

public interface IControl {

	public boolean isDisplayed();

	public boolean isEnabled();

	public IControl input(String text);

	public String getHovertext();

	public String getHalign();

	public String getForeColor();

	public String getBackColor();

	public String getFontName();

	public String getFontSize();

	public String getFontWeight();

	public String getFontStyle();

	public boolean isRedcornerExist();

	public String getErrorInfo();

	public String getVertical();

	public boolean isYellowcornerExist();

	public void pressEnterKey();

	public void pressTabKey();

	public void pressBackspaceKey();

	public void pressDeleteKey();

}
