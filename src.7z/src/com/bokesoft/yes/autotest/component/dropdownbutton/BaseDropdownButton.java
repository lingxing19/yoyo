package com.bokesoft.yes.autotest.component.dropdownbutton;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IDropdownButton;
import com.bokesoft.yes.autotest.component.IControl;

public class BaseDropdownButton extends AbstractComponent implements IDropdownButton {

	protected WebElement view = null;

	public BaseDropdownButton(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//div[@id='" + formID + "_" + key + "']"));
		try {
			this.view = driver.findElement(By.id(formID + "_" + key + "_dropdown"));
		} catch (NoSuchElementException e) {
			// TODO: handle exception
		}
	}


	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return el.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return el.isEnabled();
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return el.getAttribute("title");
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("text-align");

	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("label")).getCssValue("color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	private String convertColor(String color) {
		if (color != null && color.startsWith("rgba")) {
			String s = color.substring(5);
			String[] ss = s.split(",");

			String sss = ss[0] + "," + ss[1] + "," + ss[2];
			return sss;
		}

		return color;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		String s = el.findElement(By.tagName("a")).getCssValue("background-color");
		String s2 = convertColor(s);
		if (s2 != null && s2.startsWith("rgb")) {
			String s3 = s2.substring(4, s2.length() - 1);
			return s3;
		}
		return s2;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("font-family");
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("font-size");
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("font-weight");
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return el.findElement(By.tagName("label")).getCssValue("font-style");
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		return el.findElement(By.tagName("label")).getCssValue("vertical-align");
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
	
	/**
	 * 判断配置的图标是否存在
	 */
	public boolean isIcon(String iconName) {
		String s = el.findElement(By.xpath(".//a/span[@class='icon']")).getAttribute("style");
		if (s.contains(iconName)) {
			return true ;
			
		}
		return false ;
	}

	/**
	 * 点击操作
	 */
	public IDropdownButton click() {
		el.click();
		waittime(100);
		return this;
	}
	
	/**
	 * 获取下拉框内子按钮名称
	 * @return
	 */
	public String getItems() {
		List<WebElement> list = view.findElements(By.xpath(".//ul/li"));
		String s1 = "";
		for (WebElement s : list) {
			try {
				s1 += s.findElement(By.xpath("./a")).getText();
			} catch (Exception e) {
				s1 += "分割线" ;
			}
			
		}
		return s1;
		
	}
	
	/**
	 * 点击子选项 
	 */
	public void itemClick(String itemName) {
		List<WebElement> list = view.findElements(By.xpath(".//ul/li"));
		for (WebElement s : list) {
			try {
				String s1 =s.findElement(By.xpath("./a")).getText();
				if (s1.equals(itemName)) {
					s.click();		
				}
			} catch (Exception e) {
				
			}
			
		}
		
		
	}
}
