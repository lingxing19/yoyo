package com.bokesoft.yes.autotest.component;

public interface IToolBar {
	/**
	 * 点击toolBar上按钮
	 * 
	 * @param key
	 *            操作按钮标识
	 * @return IToolBar的实现类
	 */
	public IToolBar click(String key);

	public String getButtonName();

	/**
	 * 检查toolbar上按钮是否存在
	 * 
	 * @param caption
	 *            按钮标识
	 * @param exist
	 *            预期是否存在
	 */
	public IToolBar checkButtonExist(String key, boolean exist);

	public boolean isIcon(String key ,String iconName);
	public boolean  isDrop(String key);
	public boolean  isEnable(String key);
	public void dropClick(String key);
	public boolean  isShow(String key);
	public String getItemName(String key);
	
}
