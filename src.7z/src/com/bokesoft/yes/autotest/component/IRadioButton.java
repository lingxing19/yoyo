package com.bokesoft.yes.autotest.component;

public interface IRadioButton extends IControl {
	/**
	 * 选中单选框
	 */
	public IRadioButton click();

	/**
	 * 是否勾选
	 */
	public boolean isChecked();
}
