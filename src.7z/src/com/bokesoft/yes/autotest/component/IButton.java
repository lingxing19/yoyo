package com.bokesoft.yes.autotest.component;

public interface IButton extends IControl {

	public IButton click();

	public String getText();
	
	public boolean isIcon(String iconName);

}
