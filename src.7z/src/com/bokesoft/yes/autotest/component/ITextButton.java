package com.bokesoft.yes.autotest.component;

public interface ITextButton extends IControl {
	/**
	 * 点击文本按钮中的按钮
	 */
	public ITextButton click();

	public String getText();

	public String getPromptText();
	
	public ITextButton clear();
}
