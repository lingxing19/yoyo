package com.bokesoft.yes.autotest.component.errordialog;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IErrorDialog;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseErrorDialog extends AbstractComponent implements IErrorDialog {

	public BaseErrorDialog() {

		this.el = driver.findElement(By.id("error_dialog"));

	}

	@Override
	public IErrorDialog close() {

		el.findElement(By.className("dialog-close")).click();
		LogImpl.getInstance().info("错误提示框关闭成功");
		return this;
	}

	@Override
	public String getText() {
		String s = "";
		s = el.findElement(By.xpath(".//div[@class='dialog-content-inner']")).getText();
		return s;
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void close(String clickName) {
		
		el.findElement(By.xpath(".//div[@class='dialog-button-container']/input[@value='"+clickName+"']")).click();

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}
