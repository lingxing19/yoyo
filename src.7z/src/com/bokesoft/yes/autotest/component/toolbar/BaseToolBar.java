package com.bokesoft.yes.autotest.component.toolbar;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IToolBar;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.log.LogImpl;

import sun.net.www.content.audio.wav;

/**
 *
 *
 */
public class BaseToolBar extends AbstractComponent implements IToolBar {

	public BaseToolBar(String key) {
		this.key = key;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id(formID + "_" + key)));
		this.el = driver.findElement(By.id(formID + "_" + key));// 使用toolbar
																// 外层div

	}

	@Override
	public IToolBar click(String key) {
		LogImpl.getInstance().info("点击ToolBar:" + key);
		waittime(1000);
		this.el.findElement(By.xpath(".//li[@key='" + key + "']")).click();
		waittime(1000);
		return this;
	}

	/**
	 * 获取工具栏上所有按钮名称
	 */
	@Override
	public String getButtonName() {
		List<WebElement> list = el.findElements(By.xpath("./ul/li"));
		String s1 = "";
		for (WebElement el : list) {

			s1 += el.findElement(By.xpath("./a[1]/span[1]")).getText();
		}
		return s1;

	}

	/**
	 * 获取在界面上显示的子操作按钮名称
	 * 
	 * @param key
	 *            控件key
	 * @return
	 */
	public String getItemName(String key) {
		List<WebElement> list = el.findElements(By.xpath("./ul/li[@key='" + key + "']/ul[@tabindex='0']/li"));
		String s1 = "";
		for (WebElement el : list) {
			if (el.getAttribute("style").contains("block")) {
				s1 += el.findElement(By.xpath("./a/span")).getText();
			}
		}
		return s1;
	}

	/**
	 * 判断点击下拉按钮后，子操作按钮是否正常显示
	 * 
	 * @param key
	 *            控件KEY
	 * @return
	 */
	public boolean isShow(String key) {
		String s = el.findElement(By.xpath("./ul/li[@key='" + key + "']")).getAttribute("class");
		if (s.contains("show")) {
			return true;

		}
		return false;
	}

	/**
	 * 判断工具栏上按钮左侧图标显示是否与配置一致
	 * 
	 * @param key
	 *            控件key
	 * @param iconName
	 *            配置的图标名称
	 */
	public boolean isIcon(String key, String iconName) {
		WebElement s = el.findElement(By.xpath("./ul/li[@key='" + key + "']"));
		String s1 = s.findElement(By.className("icon")).getAttribute("Style");
		if (s1.contains(iconName)) {
			return true;

		}
		return false;
	}

	/**
	 * 操作按钮是否显示 下拉 按钮
	 */
	public boolean isDrop(String key) {
		WebElement e = el.findElement(By.xpath("./ul/li[@key='" + key + "']"));
		if (e.findElement(By.xpath(".//span[@class='arrow']")).getAttribute("class").equals("arrow")) {
			return true;
		}
		return false;
	}

	/**
	 * 操作按钮点击下拉
	 */
	public void dropClick(String key) {
		List<WebElement> elements = el.findElements(By.xpath(".//ul/li[@key='" + key + "']/a"));
		int i = elements.size();
		if (i == 2) {
			el.findElement(By.xpath(".//ul/li[@key='" + key + "']/a[2]")).click();
			waittime(500);
			return;
		} else if (i == 1) {
			el.findElement(By.xpath(".//ul/li[@key='" + key + "']/a[1]")).click();
			waittime(500);
			return;
		}

	}

	/**
	 * 判断操作按钮是否可用
	 * 
	 * @param key
	 *            控件key
	 * @return
	 */
	public boolean isEnable(String key) {
		WebElement e = el.findElement(By.xpath("./ul/li[@key='" + key + "']"));
		if (e.getAttribute("class").contains("readonly")) {
			return false;

		}
		return true;
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public IToolBar checkButtonExist(String caption, boolean exist) {
		LogImpl.getInstance().info("检查按钮 " + caption + "是否存在");

		try {
			this.el.findElement(By.xpath(".//span[text()='" + caption + "']"));
			if (exist) {
				LogImpl.getInstance().info("按钮 " + caption + "存在,检查成功");
			} else {
				LogImpl.getInstance().info("按钮 " + caption + "存在,检查失败");
			}

		} catch (Exception e) {
			if (exist) {
				LogImpl.getInstance().info("按钮 " + caption + "不存在,检查失败");
			} else {
				LogImpl.getInstance().info("按钮 " + caption + "不存在,检查成功");
			}
		}

		return this;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}