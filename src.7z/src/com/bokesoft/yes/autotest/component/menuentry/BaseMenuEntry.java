package com.bokesoft.yes.autotest.component.menuentry;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IMenuEntry;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseMenuEntry extends AbstractComponent implements IMenuEntry {

	public BaseMenuEntry(String path) {
		this.key = path;

		FluentWait<WebDriver> wait2 = new FluentWait<WebDriver>(driver);
		wait2.pollingEvery(5000, TimeUnit.MILLISECONDS).withTimeout(10, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		// wait2.until(new ExpectedCondition<WebElement>() {
		// @Override
		// public WebElement apply(WebDriver d) {
		// return d.findElement(By.xpath("//li[@path='"+key+"']"));
		// }
		// });

		this.el = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@path='" + key + "']")));

		// this.el = driver.findElement(By.xpath("//li[@path='"+key+"']"));
	}

	@Override
	public IMenuEntry click() {
		LogImpl.getInstance().info("点击菜单节点:" + key);
		waittime(1000);
		this.el.click();
		return this;
	}

	@Override
	public IMenuEntry dblClick() {
		LogImpl.getInstance().info("双击击菜单节点:" + key);

		Actions action = new Actions(driver);
		action.doubleClick(this.el).build().perform();
		waittime(2000);
		return this;
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}
