package com.bokesoft.yes.autotest.component.toolbarbutton;

import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IToolBarButton;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseToolBarButton extends AbstractComponent implements IToolBarButton {

	public BaseToolBarButton(String key) {
		this.key = key;
		this.el = driver.findElement(By.xpath("//ul[@class='tbr-ul']/li/a/span[text()='" + key + "']"));
	}

	@Override
	public IToolBarButton click() {
		LogImpl.getInstance().info("点击ToolBarButton:" + key);
		this.el.click();
		waittime(1000);
		return this;
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}
}
