package com.bokesoft.yes.autotest.component;

import java.util.List;

import com.bokesoft.yes.autotest.component.dictquerybox.BaseDictQueryItem;

public interface IDictQueryBox{
	
	/**
	 * 双击选中当前页某行的字典项
	 * @param rowNo  在当前页中的行号（从0开始）
	 */
	public IDictQueryBox itemDbClick(int rowNo);
	
	/**
	 * 输入查询字段
	 * @param text 查询字段
	 */
	public IDictQueryBox queryTxtInput(String text);
	
	/**
	 * 清空查询框
	 */
	public IDictQueryBox queryTxtClear();
	
	/**
	 * 点击查询按钮
	 */
	public IDictQueryBox queryClick();
	
	/**
	 * 切换到某一页
	 * @param pageNo  页号
	 */
	public IDictQueryBox pageClick(int pageNo);
	
	/**
	 *翻到下一页
	 */
	public IDictQueryBox nextClick();
	
	/**
	 * 翻到前一页
	 */
	public IDictQueryBox preClick();
	
	/**
	 * 关闭查询框
	 */
	public void close();
	
	/**
	 * 获取当前页列表
	 * 
	 */
	public List<BaseDictQueryItem> getChildren();
	
	public IDictQueryBox queryBoxButtonClick(String buttonName);

}
