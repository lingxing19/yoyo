package com.bokesoft.yes.autotest.component.dictview;


public class BaseDictViewItem {
	private int enable;
	private String caption;
	private int nodeType;

	public BaseDictViewItem() {
	}
	
	public BaseDictViewItem(String caption, int enable, int nodeType) {
		this.caption = caption;
		this.enable = enable;
		this.nodeType = nodeType;
	}
	
	public int getEnable() {
		return enable;
	}

	public void setEnable(int enable) {
		this.enable = enable;
	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public int getNodeType() {
		return nodeType;
	}

	public void setNodeType(int nodeType) {
		this.nodeType = nodeType;
	}

	@Override
	public String toString() {
		return "capiton:" + caption + ",enable:" + enable + ",nodeType:" +nodeType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((caption == null) ? 0 : caption.hashCode());
		result = prime * result + enable;
		result = prime * result + nodeType;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BaseDictViewItem other = (BaseDictViewItem) obj;
		if (caption == null) {
			if (other.caption != null)
				return false;
		} else if (!caption.equals(other.caption))
			return false;
		if (enable != other.enable)
			return false;
		if (nodeType != other.nodeType)
			return false;
		return true;
	}	
}