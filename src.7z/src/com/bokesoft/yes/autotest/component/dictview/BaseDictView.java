package com.bokesoft.yes.autotest.component.dictview;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IDictView;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseDictView extends AbstractComponent implements IDictView {
	private String id = null;
	private String rootId = null;

	public BaseDictView() {
		this.key = "DictView";
		this.el = driver.findElement(By.id(formID + "_" + key));
		WebElement element = this.el.findElement(By.xpath(".//tbody//tr[2]"));
		rootId = element.getAttribute("id");
	}

	@Override
	public IDictView expandItemClick(String itemCode) {
		LogImpl.getInstance().info("点击展开字典项：" + itemCode);
		el.findElement(By.xpath(".//td[text()='" + itemCode + "']/span/a[@title='Expand']")).click();
		waittime(500);
		String id = el.findElement(By.xpath(".//td[text()='" + itemCode + "']/parent::tr")).getAttribute("id");
		this.id = id;
		return this;

	}

	@Override
	public IDictView itemClick(String itemCode) {
		LogImpl.getInstance().info("单击字典项：" + itemCode);
		el.findElement(By.xpath(".//td[text()='" + itemCode + "']")).click();

		String id = el.findElement(By.xpath(".//td[text()='" + itemCode + "']/parent::tr")).getAttribute("id");
		this.id = id;
		return this;
	}

	/**
	 * 获取子节点对象组
	 * 
	 * 
	 */
	public List<BaseDictViewItem> getChildren(boolean root) {
		waittime(1000);
		List<BaseDictViewItem> items = new ArrayList<BaseDictViewItem>();
		List<WebElement> list = null;
		if (root) {
			list = el.findElements(By.xpath("//tr[@pid='" + rootId + "']"));
		} else {			
			list = el.findElements(By.xpath("//tr[@pid='" + id + "']"));			
		}
		BaseDictViewItem item = null;
		for (WebElement e : list) {
			// 取属性,并封装
			item = new BaseDictViewItem();

			item.setEnable(Integer.parseInt(e.getAttribute("enable")));
			item.setCaption(e.findElement(By.xpath(".//td[2]")).getText());
			
			waittime(500);
			
			//int nodeType = e.getAttribute("haschild") == null ? 0: 1;
			
			int nodeType = e.findElement(By.xpath(".//td/span")).getAttribute("class").contains("noChild") ? 0 : 1;
			item.setNodeType(nodeType);

			items.add(item);
			System.out.println(item);
		}

		return items;

	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub
		
	}

}
