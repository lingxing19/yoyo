package com.bokesoft.yes.autotest.component;

public interface ICheckBox extends IControl {
	/**
	 * 勾选、取消勾选
	 */
	public ICheckBox click();

	/**
	 * 是否勾选
	 */
	public boolean isChecked();

	public String getText();

	public String getBackColor();

}
