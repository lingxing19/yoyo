package com.bokesoft.yes.autotest.component;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.component.grid.BaseGrid;

/**
 * 
 *
 */
public abstract class AbstractTableComponent extends AbstractComponent {
	// 表头的集合
	protected List<WebElement> head = null;

	// 数据行的集合(当前页),每次切换页都需要重新赋值
	protected List<WebElement> rows = null;

	// 是否分页
	protected boolean paging = false;

	// 分页的div
	protected WebElement pagesdiv = null;

	// 分页按钮元素集合,每次切换页都需要重新赋值
	protected List<WebElement> pages = null;

	// 当前所在的页号,每次切换页都需要重新赋值
	protected int currentPageNum = 1;

	// 总页数
	protected int pageCount = 1;

	// 数据的总行数（所有页）
	protected int rowCount = 0;

	public abstract int getRowCount();

	public int getCurrentPageNum() {
		return currentPageNum;
	}

	/**
	 * @return 总页数
	 */
	public int getPageCount() {
		return pageCount;
	}

	/**
	 * 勾选或者去掉勾选
	 * 
	 * @param index
	 *            要选择行的序号的数组
	 * @return
	 */
	public abstract AbstractTableComponent selectRowClick(String colName, int... index);

	// public abstract AbstractTableComponent selectRowClick(String
	// colName,String Expression);

	/**
	 * 当前页，选择所有行，或者去掉勾选
	 * 
	 * @return
	 */
	public abstract AbstractTableComponent selectAllRow();

	/**
	 * 当前页，选择所有行(勾选表头的全选)
	 * 
	 * @return
	 */
	public abstract AbstractTableComponent selectAllClick(String colName);

	/**
	 * @param index
	 *            确认（当前页）某些行是否勾选
	 * @return
	 */
	public abstract boolean isRowSelect(String colName, int... index);

	/**
	 * 当前页是否全部勾选（检查表头全选）
	 * 
	 * @return
	 */
	public abstract boolean isAllSelected(String colName);

}
