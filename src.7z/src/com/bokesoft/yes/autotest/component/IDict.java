package com.bokesoft.yes.autotest.component;

import java.util.List;

import com.bokesoft.yes.autotest.component.dict.BaseDict;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;

public interface IDict extends IControl{

	/**
	 * 点开/收起，字典下拉框
	 */
	public IDict viewClick();
	
	/**
	 * 选中字典项
	 * @param itemName  字典项名称（代码、名称）
	 */
	public IDict itemClick(String itemCode);
	
	/**
	 * 链式字典选中字典项
	 * @param itemCode
	 * @param text
	 * @return
	 */
	public IDict chainItemClick(String itemCode,String text);
	
	/**
	 * 展开合并字典项
	 * @param itemName 字典项名称（代码、名称）
	 *
	 */
	public IDict expandClick(String itemCode);
	
	
	/**
	 * 获得根节点
	 */
	public String getRootNode();
	

	
	/**
	 * 勾选字典项
	 * @param itemName  字典项名称（代码、名称）
	 */
	public IDict itemCheckClick(String itemCode);
	
	public IDict clearClick();
	
	public IDict clear();
	
	public String getText() ;

	public List<BaseDictItem> getChildren(boolean root);
	
	public boolean itemChecked(String itemCode);
	
	public boolean itemSelect(String itemCode);
		
	public IDict dictButtonClick(String buttonName);
	
	public String getRootChkstate();
	
	public String getPage();
	
	public void pressBackspaceKey(int left,int num);
	
	public IDict paste(String text);

	public BaseDict numClick(int num);
	public BaseDict nextPageClick();
	public BaseDict lastPageClick();
	public BaseDict searchBoxInput(String text);
	public BaseDict searchButtonClick();
	public BaseDict searchInputClear();
	
	public IControl inputClick();
}
