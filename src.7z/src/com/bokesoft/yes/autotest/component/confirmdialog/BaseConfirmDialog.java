package com.bokesoft.yes.autotest.component.confirmdialog;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IConfirmDialog;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.log.LogImpl;

public class BaseConfirmDialog extends AbstractComponent implements IConfirmDialog {

	public BaseConfirmDialog() {

		this.el = driver.findElement(By.xpath(".//div[@class='ui-dlg dialog']"));
		waittime(1000);
	}

	@Override
	public String getText() {
		String s = "";
		s = el.findElement(By.xpath(".//div[@class='dialog-content-inner']//label")).getText();
		System.out.println(s);
		return s;
	}

	@Override
	public IConfirmDialog okClick() {
		LogImpl.getInstance().info("弹出：确定提示框，点【确定】");
		el.findElement(By.xpath(".//div[@class='ui-btn color dlg-btn']/button/span[text()='确定']/parent::button"))
				.click();
		return this;
	}

	@Override
	public IConfirmDialog yesClick() {
		LogImpl.getInstance().info("弹出：提示框，点【是】");
		el.findElement(By.xpath(".//div[@key='YES']/button/span[text()='是']")).click();
		return this;
	}

	@Override
	public IConfirmDialog noClick() {
		LogImpl.getInstance().info("弹出：提示框，点【否】");
		el.findElement(By.xpath(".//div[@key='NO']/button/span[text()='否']/parent::button")).click();
		return this;
	}

	@Override
	public IConfirmDialog cancelClick() {
		LogImpl.getInstance().info("弹出：提示框，点【取消】");
		el.findElement(By.xpath(".//div[@class='ui-btn dlg-btn']/button/span[text()='取消']/parent::button")).click();
		return this;
	}

	@Override
	public IConfirmDialog close() {
		LogImpl.getInstance().info("关闭Confirm提示框");
		el.findElement(By.className("dialog-close")).click();
		return this;
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getForeColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontWeight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFontStyle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHalign() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub

	}

	@Override
	public String getVertical() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub

	}

}
