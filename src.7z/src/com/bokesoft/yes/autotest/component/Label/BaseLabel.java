package com.bokesoft.yes.autotest.component.Label;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.ILabel;


public class BaseLabel extends AbstractComponent implements ILabel{

	public BaseLabel(String key){
		this.key = key;
		this.el=driver.findElement(By.xpath("//div[@id='"+formID+"_" +key+"']"));										
	}


	@Override
	public boolean isTextColor(String color) {
		return el.getAttribute("style").contains("color: "+color+";")?true:false;
	}
	
	/**
	 * 可见性测试
	 */
	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return el.isDisplayed();
	}

	/**
	 * 可用性测试
	 */
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return el.isEnabled();
	}
	
	
	/**
	 * 静态文本默认值公式
	 */
	public String getText(){
		String s = "";
		if (el.isDisplayed()) {
			s =el.findElement(By.tagName("label")).getAttribute("innerText");
		}
		return s ;
	}
	
	/**
	 * 左侧图标测试
	 * @return
	 */
	public String getIcon() {		
//		String s = el.findElement(By.className("icon")).getAttribute("baseURI");
//		String s2 = el.findElement(By.className("icon")).getCssValue("background-image");
//		int beginIndex = s2.indexOf(s) + s.length();
//		String s3 = s2.substring(beginIndex, s2.length() - 2);
//		return s3;
		String s2 = el.findElement(By.className("icon")).getAttribute("Style");
		
	    String re1="background-image: url\\(\"(.*?)\"\\)";	// Word 1

	    Pattern p = Pattern.compile(re1, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
	    Matcher m = p.matcher(s2);
	    String word1 = "";
	    if (m.find())
	    {
	        word1=m.group(1);
	    }
		    
		return word1;
	}
	
	/**
	 * 悬浮提示测试
	 */
	@Override
	public String getHovertext() {
		// TODO Auto-generated method stub
		return el.getAttribute("title");
	}
	
	/**
	 *编辑框内水平方向测试
	 */
	@Override
	public String getHalign() {	
		return el.findElement(By.tagName("label")).getCssValue("text-align");
	}
	
	/**
	 *编辑框内垂直方向测试
	 */
	@Override
	public String getVertical() {	
		return el.findElement(By.tagName("label")).getCssValue("vertical-align");
	}
	
	/**
	 *前景色测试
	 */
	@Override
	public String getForeColor() {	
		String s =  el.findElement(By.tagName("label")).getCssValue("color");
		String s2 = convertColor(s);
		if(s2 != null &&s2.startsWith("rgb")){
			String s3 =s2.substring(4,s2.length()-1);
			return s3;
		}
		return s2;
	}
	
	/**
	 * 背景色测试
	 */
	@Override
	public String getBackColor() {	
		String s = el.getCssValue("background-color");
		String s2 = convertColor(s);
		if(s2 != null &&s2.startsWith("rgb")){
			String s3 =s2.substring(4,s2.length()-1);
			return s3;
		}
		return s2;
	}
	private String convertColor(String color){
		if(color != null && color.startsWith("rgba")){
			String s = color.substring(5);
			String[] ss = s.split(",");
			
			String sss = ss[0]+","+ss[1]+","+ss[2];
			return sss;
		}
		
		return color;
	}
	
	/**
	 * 字体名称测试
	 */
	public String getFontName() {	
		return el.findElement(By.tagName("label")).getCssValue("font-family");
	}
	
	/**
	 * 字体大小测试
	 */
	@Override
	public String getFontSize() {	
		return el.findElement(By.tagName("label")).getCssValue("font-size");
	}
	
	/**
	 * 字体粗细测试
	 */
	@Override
	public String getFontWeight() {	
		return el.findElement(By.tagName("label")).getCssValue("font-weight");
	}
	
	/**
	 * 字体样式测试
	 */
	@Override
	public String getFontStyle() {	
		return el.findElement(By.tagName("label")).getCssValue("font-style");
	}

	@Override
	public IControl input(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public boolean isRedcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getErrorInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isYellowcornerExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void pressEnterKey() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pressTabKey() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public String checkGetText() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void pressBackspaceKey() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void pressDeleteKey() {
		// TODO Auto-generated method stub
		
	}





}
