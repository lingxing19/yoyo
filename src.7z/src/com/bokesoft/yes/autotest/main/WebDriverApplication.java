package com.bokesoft.yes.autotest.main;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.bokesoft.yes.autotest.common.def.BrowserType;
import com.bokesoft.yes.autotest.common.util.AssertUtil;
import com.bokesoft.yes.autotest.common.util.DataBaseUtil;
import com.bokesoft.yes.autotest.common.util.DropdownButtonUtil;
import com.bokesoft.yes.autotest.common.util.FunctionUtil;
import com.bokesoft.yes.autotest.common.util.NavigationUtil;
import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.env.Env;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.autotest.properties.Settings;
import com.bokesoft.yes.autotest.script.AbstractTestScript;
import com.bokesoft.yes.autotest.util.RobotUtil;

public class WebDriverApplication {
	private WebDriver driver = null;

	private List<AbstractTestScript> scripts = null;

	public WebDriverApplication() {
		init();
	}

	private void init() {
		// 设置日志路径
		String logHome = Settings.getInstance().getLogHome();
		System.setProperty(Settings.LOG_HOME, logHome);

		// 获取设置浏览器类型
		String type = Settings.getInstance().getType();
		int t = BrowserType.parse(type);
		Env.getInstance().setType(t);

		// 初始化浏览器
		switch (t) {
		case BrowserType.CHROME:
			initChrome();
			break;
		case BrowserType.FIREFOX:
			initFireFox();
			break;
		case BrowserType.IE:
			initInternetExplorer();
			break;
		default:
			throw new RuntimeException("暂不支持的类型：" + type);
		}

		// 加载所要执行的脚本
		List<String> list = Settings.getInstance().getScriptList();
		scripts = new ArrayList<AbstractTestScript>();

		for (String s : list) {
			try {
				Class<?> scriptClass = Class.forName(s);
				Object o = scriptClass.newInstance();

				((AbstractTestScript) o).setName(s);
				scripts.add((AbstractTestScript) o);

			} catch (Throwable e) {
				e.printStackTrace();
				LogImpl.getInstance().error("测试脚本[" + s + "]加载失败。", e);
			}

		}

		LogImpl.getInstance().info("测试脚本加载完毕。");

		// 设置全局变量
		AbstractComponent.setDriver(driver);
		AssertUtil.setDriver(driver);
		DataBaseUtil.setDriver(driver);
		FunctionUtil.setDriver(driver);
		NavigationUtil.setDriver(driver);
		DropdownButtonUtil.setDriver(driver);
	}

	private void initChrome() {
		// 设置chrome driver

		String filepath = "tools/chromedriver.exe";
		File file = new File(filepath);
		System.setProperty(Settings.WEBDRIVER_CHROME_DRIVER, "" + file);

		// 设置chrome driver 部分参数log
		DesiredCapabilities caps = DesiredCapabilities.chrome();
		LoggingPreferences logPrefs = new LoggingPreferences();
		logPrefs.enable(LogType.BROWSER, Level.ALL);
		caps.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
		driver = new ChromeDriver(caps);

		driver.manage().window().maximize();
	}

	private void initFireFox() {
		// 设置firefox driver
		String firefoxDriver = Settings.getInstance().getProperty(Settings.WEBDRIVER_FIREFOX_DRIVER);
		if (firefoxDriver != null && !firefoxDriver.isEmpty()) {
			String filepath = "tools/geckodriver.exe";
			File file = new File(filepath);
			System.setProperty("webdriver.gecko.driver", "" + file);
			System.setProperty("webdriver.firefox.logfile", "/dev/null");
			System.setProperty(Settings.WEBDRIVER_FIREFOX_DRIVER, firefoxDriver);
		}
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
	}

	private void initInternetExplorer() {
		// 设置IE driver
		String filepath = "tools/IEDriverServer.exe";
		File file = new File(filepath);
		System.setProperty(Settings.WEBDRIVER_IE_DRIVER, "" + file);

		DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
		dc.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		dc.setCapability("ignoreProtectedModeSettings", true);
		driver = new InternetExplorerDriver(dc);
		driver.manage().window().maximize();
	}

	public void runScript() {
		/*
		 * doLogin();
		 * 
		 * try { Thread.sleep(1000); } catch (InterruptedException e1) {
		 * e1.printStackTrace(); }
		 */
		// 运行脚本

		for (AbstractTestScript script : scripts) {
			try {
				LogImpl.getInstance().info("运行脚本：" + script.getName());
				script.setWebDriver(driver);
				script.run();
				LogImpl.getInstance().info("脚本：" + script.getName() + ",执行完毕");
			} catch (org.openqa.selenium.UnhandledAlertException se) {
				se.printStackTrace();
				RobotUtil.pressEnterKey();
				LogImpl.getInstance().error("运行脚本[" + script.getName() + "]时发生错误。", se);

			} catch (Throwable e) {
				e.printStackTrace();
//				driver.navigate().refresh();
				LogImpl.getInstance().error("运行脚本[" + script.getName() + "]时发生错误。", e);
			}
		}

	}

}
