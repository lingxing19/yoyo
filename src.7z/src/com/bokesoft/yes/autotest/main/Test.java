package com.bokesoft.yes.autotest.main;

public class Test {
	public static void main(String[] args) {
		WebDriverApplication app = new WebDriverApplication();
		app.runScript();
	}
}
