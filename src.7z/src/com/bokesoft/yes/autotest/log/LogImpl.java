package com.bokesoft.yes.autotest.log;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.bokesoft.yes.autotest.util.PathUtil;

/**
 * 日志
 * 
 * @author zhufw
 *
 */
public class LogImpl {
	private static LogImpl INSTANCE = null;

	private Logger logger = null;

	private LogImpl() {
		System.out.println(PathUtil.getAppPath(LogImpl.class));
		PropertyConfigurator.configure(PathUtil.getAppPath(LogImpl.class) + "/log4j.properties");
		logger = Logger.getLogger("info");
	}

	public static LogImpl getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new LogImpl();
		}
		return INSTANCE;
	}

	public void info(String info) {
		System.out.println(info);
		logger.info(info);
	}

	public void error(String error) {
//		System.out.println(error);
		System.err.println(error);
		logger.error(error);
	}

	public void error(String error, Throwable e) {
		logger.error(error, e);
	}
}
