package com.bokesoft.yes.autotest.script;

public interface IScript {

	// public void runScript() throws Throwable;

}
