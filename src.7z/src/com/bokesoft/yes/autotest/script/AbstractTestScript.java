package com.bokesoft.yes.autotest.script;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.bokesoft.yes.autotest.properties.Settings;
import com.bokesoft.yes.tools.RemoteServiceProxy;
import com.bokesoft.yigo.struct.datatable.DataTable;

public abstract class AbstractTestScript implements IScript {
	// webdriver 所需driver
	protected WebDriver driver = null;
	// 脚本名称
	private String name = null;

	public void setWebDriver(WebDriver driver) {
		this.driver = driver;
	}

	public void run() {

		doLogin("admin", "");
	}

	public void error(String message, Throwable err) {
		// logger.error(message, err);
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	protected void waittime(long millis) {
		try {
			Thread.sleep(millis);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 登录界面为自定义组建 所以这边直接写死代码
	protected void doLogin(String userName, String password) {
		String url = Settings.getInstance().getURL();
		/*
		 * String userName = Settings.getInstance().getProperty("username");
		 * String password = Settings.getInstance().getProperty("password");
		 */

		driver.get(url);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		WebElement element = null;
		if (userName != null && !userName.isEmpty()) {
			element = driver.findElement(By.className("login-username"));
			element.sendKeys(userName);
		}

		if (password != null && !password.isEmpty()) {
			element = driver.findElement(By.className("login-password"));
			element.sendKeys(password);
		}

		WebElement btn = driver.findElement(By.className("login-button"));
		btn.click();

		// TODO 验证登录成功
	}

	protected void logOut() {
		// WebElement userbox=driver.findElement(By.className("userBox"));
		// userbox.findElement(By.className("userIcon")).click();
		// userbox.findElement(By.xpath(".//a[@class='logout']/span")).click();
		// waittime(500);
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		//// wait.until(ExpectedConditions.elementToBeClickable(By.className("nav-field-btn")));
		//
		// WebElement b=driver.findElement(By.className("nav-field-btn"));
		// waittime(1000);
		// b.click();
		// WebElement s=driver.findElement(By.className("logout"));
		// waittime(1000);
		// s.click();
		// waittime(500);

		FluentWait<WebDriver> wait2 = new FluentWait<WebDriver>(driver);
		wait2.pollingEvery(5000, TimeUnit.MILLISECONDS).withTimeout(10, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);
		WebElement b = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.className("nav-field-btn")));
		b.click();
		b = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.className("logout")));
		b.click();

	}

	protected void modifyPwd() {

		WebElement s1 = driver.findElement(By.className("nav-field-btn"));
		s1.click();
		WebElement s2 = driver.findElement(By.className("modifyPwd"));
		waittime(1000);
		s2.click();
		waittime(1000);
	}

	protected void dbquery(String sql) {
		RemoteServiceProxy proxy = new RemoteServiceProxy(driver);

		DataTable dt = proxy.dbquery(sql, null);
		if (dt.first()) {
			while (!dt.isAfterLast()) {
				System.out.println("oid:" + dt.getLong("oid") + "	code:" + dt.getString("code"));
				dt.next();
			}
		}
	}
}
