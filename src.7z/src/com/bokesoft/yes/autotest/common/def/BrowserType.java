package com.bokesoft.yes.autotest.common.def;

public class BrowserType {
	//谷歌
	public static final int CHROME = 0;
	public static final String S_CHROME = "chrome";
	
	//火狐
	public static final int FIREFOX = 1;
	public static final String S_FIREFOX = "firefox";
	
	//IE
    public static final int IE = 2;
	public static final String S_IE = "IE";
	
	public static int parse(String s) {
		int type = -1;
		if ( S_CHROME.equalsIgnoreCase(s) ) {
			type = CHROME;
		} else if ( S_FIREFOX.equalsIgnoreCase(s) ) {
			type = FIREFOX;
		} else if (S_IE.equalsIgnoreCase(s)) {
		    type = IE;	
		}
		return type;
	}
}
