package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.ICheckBox;
import com.bokesoft.yes.autotest.component.factory.CheckBox;
import com.bokesoft.yes.autotest.log.LogImpl;

public class CheckBoxUtil {

	static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		CheckBoxUtil.driver = driver;
	}

	/**
	 * 校验CheckBox取值是否正确
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(ICheckBox atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * @param checkboxKey
	 *            复选框的Key
	 * @param checked
	 *            true,预期勾选;false,预期未勾选
	 */
	public static void checkChecked(String checkboxKey, boolean checked, String string) {

		if (CheckBox.element(checkboxKey).isChecked() == checked) {

			if (checked) {

				LogImpl.getInstance().info(string + "复选框勾选========检查成功");
				return;
			}
			LogImpl.getInstance().info(string + "复选框未勾选========检查成功");
			return;
		}
		if (checked) {
			LogImpl.getInstance().error(string + "复选框未勾选========检查失败");
			return;
		}
		LogImpl.getInstance().error(string + "复选框勾选========检查失败");
	}

}
