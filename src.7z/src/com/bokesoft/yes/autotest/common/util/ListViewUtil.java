package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;
import com.bokesoft.yes.autotest.component.AbstractTableComponent;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.log.LogImpl;

public class ListViewUtil {

	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {

		ListViewUtil.driver = driver;

	}

	/**
	 * 检查符合条件的单据存在与否
	 * 
	 * @param viewKey
	 *            视图列表的key
	 * @param colName
	 *            列名
	 * @param tex
	 *            列的值
	 * @param b
	 *            true，预期存在；false，预期不存在
	 */
	public static void checkFormExsit(String viewKey, String colName, String text, Boolean b, String msg) {
		if (ListView.element(viewKey).isFormExsit(colName, text) == b) {
			if (b == true) {
				LogImpl.getInstance().info(msg + "======[" + colName + "]列" + ":" + text + "的单据存在=======检查成功");
				return;
			}
			LogImpl.getInstance().info(msg + "======[" + colName + "]列" + ":" + text + "的单据不存在=======检查成功");
			return;
		}
		if (b == true) {
			LogImpl.getInstance().error(msg + "======[" + colName + "]列" + ":" + text + "的单据存在=======检查失败");
			return;
		}
		LogImpl.getInstance().error(msg + "======[" + colName + "]列" + ":" + text + "的单据不存在=======检查失败");
	}

	/**
	 * 检查listview中符合条件的单据数量
	 * 
	 * @param viewKey
	 *            视图列表的key
	 * @param colName
	 *            列名
	 * @param text
	 *            列的值
	 * @param formCount
	 *            预期的数量
	 */
	public static void checkFormCount(String viewKey, String colName, String text, int formCount, String msg) {
		if (ListView.element(viewKey).countForm(colName, text) == formCount) {
			LogImpl.getInstance().info(msg + "======[" + colName + "]是" + text + "的单据数量：" + formCount + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======[" + colName + "]是" + text + "的单据数量：" + formCount
				+ "================================检查失败");
	}

	/**
	 * 检查单元格的值
	 * 
	 * @param viewKey
	 *            表格的key
	 * @param colName
	 *            列名
	 * @param index
	 *            行序号
	 * @param value
	 *            预期的值
	 */
	public static void checkValue(String viewKey, String colName, int index, String value) {
		String Value = ListView.element(viewKey).getValue(colName, index);
		if (Value.equals(value)) {
			LogImpl.getInstance().info(colName + "列，第" + index + "行的值：" + value + "======检查成功。");
		} else {
			LogImpl.getInstance().error(colName + "列，第" + index + "行的值：" + value
					+ "================================检查失败。预期结果为:" + value + "	实际结果为:" + Value);
		}
	}

	/**
	 * listview的行勾选、未勾选验证
	 * 
	 * @param viewKey
	 *            表格对象、视图列表对象
	 * @param b
	 *            true,预期勾选;false,预期不勾选
	 * @param index
	 *            行序号数组，如1,2,4 或者 5,6,7
	 */
	public static void checkRowSelected(AbstractTableComponent viewKey, String colName, Boolean b, int... index) {
		if (viewKey.isRowSelect(colName, index) == b) {
			if (b) {
				LogImpl.getInstance().info("当前页勾选======检查成功");
			} else {
				LogImpl.getInstance().info("当前页未勾选======检查成功");
			}
		} else {
			if (b) {
				LogImpl.getInstance().error("当前页勾选======检查失败");
			} else {
				LogImpl.getInstance().error("当前页未勾选=======检查失败");
			}
		}

	}

	/**
	 * listview的全选、全不选验证
	 * 
	 * @param viewKey
	 *            表格对象、视图列表对象
	 * @param b
	 *            true,预期全选;false,预期全不选
	 */
	public static void checkAllSelected(AbstractTableComponent viewKey, String colName, Boolean b) {
		if (viewKey.isAllSelected(colName) == b) {
			if (b == true) {
				LogImpl.getInstance().info("当前页全选======检查成功");
				return;
			}
			LogImpl.getInstance().info("当前页全不选======检查成功");
			return;
		}
		if (b == true) {
			LogImpl.getInstance().error("当前页全选======检查失败。");
			return;
		}
		LogImpl.getInstance().error("当前页全不选=======检查失败");
	}

	/**
	 * 验证ListView总行数
	 * 
	 * @param viewKey
	 *            视图对象
	 * @param rows
	 *            预期总行数
	 */
	public static void CheckAllRows(String viewKey, int rows, String msg) {
		if (ListView.element(viewKey).getRowCount() == rows) {
			LogImpl.getInstance().info(msg + "总行数一致======检查成功");
			return;
		} else {
			LogImpl.getInstance().error(msg + "总行数不一致======检查失败");
			return;
		}

	}

}
