package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;
import com.bokesoft.yes.autotest.component.ILabel;
import com.bokesoft.yes.autotest.log.LogImpl;

public class LabelUtil {

	static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		LabelUtil.driver = driver;
	}

	/**
	 * 校验Label取值是否正确
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(ILabel atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件-Label编辑框中的图标
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param url
	 *            预期的值
	 */
	public static void checkIcon(ILabel atc, String url, String msg) {
		String ret = atc.getIcon();
		if (ret.equals(url)) {
			LogImpl.getInstance().info(msg + "======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + url + "	实际结果为:" + ret);
	}
}
