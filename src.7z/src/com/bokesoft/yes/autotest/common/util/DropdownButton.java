package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

public class DropdownButton {

	static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		DropdownButton.driver = driver;
	}

}
