package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.ISplitButton;
import com.bokesoft.yes.autotest.log.LogImpl;

public class SplitButtonUtil {

	static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		SplitButtonUtil.driver = driver;
	}

	/**
	 * 检验图标显示是否正确
	 * 
	 * @param atc
	 *            控件key
	 * @param iconName
	 *            图片名称
	 * @param s
	 *            true or false
	 * @param msg
	 *            测试用例编号
	 */
	public static void checkIconName(ISplitButton atc, String iconName, boolean s, String msg) {
		boolean ret = atc.isIcon(iconName);
		if (ret == s) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + s + "	实际结果为:" + ret);

	}

	/**
	 * 检验控件是否为选中状态
	 * @param atc      控件key
	 * @param s        true or false
	 * @param msg      测试用例编号
	 */
	public static void checkIsClicked(ISplitButton atc, boolean s, String msg) {
		boolean ret = atc.isClicked();
		if (ret == s) {

			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + s + "	实际结果为:" + ret);

	}
	
	/**
	 * 检验下拉项名称
	 * @param atc     控件key
	 * @param s       下拉项名称
	 * @param msg     测试用例编号
	 */
	public static void checkItemNames(ISplitButton atc, String s, String msg) {
		String ret= atc.getItemNames();
		
		if (ret.equals(s)) {

			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + s + "	实际结果为:" + ret);

	}

}
