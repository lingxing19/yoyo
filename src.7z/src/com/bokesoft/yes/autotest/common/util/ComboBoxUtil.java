package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.IComboBox;
import com.bokesoft.yes.autotest.component.ITextEditor;
import com.bokesoft.yes.autotest.log.LogImpl;

public class ComboBoxUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		ComboBoxUtil.driver = driver;
	}

	/**
	 * 检查头控件编辑框中的值
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(IComboBox atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 校验下拉项值
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            下拉取值
	 * @param msg
	 *            测试用例编号
	 */
	public static void checkgetItemsValue(IComboBox atc, String text, String msg) {
		String ret = atc.getItems();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检验自动匹配下拉值
	 * @param atc
	 * @param text
	 * @param msg
	 */
	public static void checkgetAutoItems(IComboBox atc, String text, String msg) {
		String ret = atc.getAutoItems();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检验被选中的下拉项
	 * @param atc       控件key
	 * @param value     被选中下拉项
	 * @param msg       测试用例编号
	 */
	public static void checkIsSelected(IComboBox atc,String value,String msg) {
		String ret = atc.isSelected();
		if (ret.equals(value)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}
	
	
	
	
	public static void checkEmbedText(IComboBox atc, String text, String msg) {
		// TODO Auto-generated method stub
		String ret = atc.getItems();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

}
