package com.bokesoft.yes.autotest.common.util;

import org.apache.bcel.verifier.exc.VerifierConstraintViolatedException;
import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.ICheckListBox;
import com.bokesoft.yes.autotest.log.LogImpl;

public class CheckListBoxUtil {

	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		CheckListBoxUtil.driver = driver;
	}

	/**
	 * 校验下拉项值
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            下拉取值
	 * @param msg
	 *            测试用例编号
	 */
	public static void checkgetItemsValue(ICheckListBox atc, String text, String msg) {
		String ret = atc.getItems();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框中的值
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(ICheckListBox atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件的空值提示
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkPromptText(ICheckListBox atc, String text, String msg) {
		String ret = atc.getPromptText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}
	
	/**
	 * 校验下拉框内各个选项的勾选状态
	 * @param atc       控件key
	 * @param text      各选项是否选中
	 * @param msg       测试用例编号
	 */
	public static void checkChecked (ICheckListBox atc,String itemName, Boolean text, String msg) {
		boolean ret = atc.isChecked(itemName);
		if (ret==text) {
			LogImpl.getInstance().info(msg + "================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}
	
	public static void checkButtons (ICheckListBox atc,String buttonName, Boolean text, String msg) {
		boolean ret = atc.isButton(buttonName);
		if (ret==text) {
			LogImpl.getInstance().info(msg + "=============检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "=================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}
	
}
