package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.ICheckBox;
import com.bokesoft.yes.autotest.component.IPasswordEditor;
import com.bokesoft.yes.autotest.log.LogImpl;

public class PassWordUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		PassWordUtil.driver = driver;
	}

	/**
	 * 检查头控件编辑框右侧图标
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param s
	 *            true or false
	 * @param iconName 
	 *            图标名称
	 */
	public static void checkPreIcon(IPasswordEditor atc,Boolean s, String iconName, String msg) {
		boolean ret = atc.getPreIcon(iconName);
		if (ret==s) {
			LogImpl.getInstance().info(msg + "图标存在且显示正确=================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "图标不存在或显示不正确================检查失败 预期结果为:" + s + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件的空值提示
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkPromptText(IPasswordEditor atc, String text, String msg) {
		String ret = atc.getPromptText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框的内嵌文本
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkEmbedText(IPasswordEditor atc, String text, String msg) {
		String ret = atc.getEmbedText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 校验头控件取值是否正确
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(IPasswordEditor atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

}
