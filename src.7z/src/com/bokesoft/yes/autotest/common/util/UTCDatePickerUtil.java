package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.IUTCDatePicker;
import com.bokesoft.yes.autotest.log.LogImpl;

public class UTCDatePickerUtil {

	static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		UTCDatePickerUtil.driver = driver;
	}

	/**
	 * 校验UTC日期框取值是否正确
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(IUTCDatePicker atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

}
