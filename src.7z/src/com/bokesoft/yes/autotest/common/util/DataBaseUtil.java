package com.bokesoft.yes.autotest.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.WebDriver;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.bokesoft.yes.tools.RemoteServiceProxy;
import com.bokesoft.yigo.common.def.DataType;
import com.bokesoft.yigo.struct.datatable.DataTable;

public class DataBaseUtil {

	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		DataBaseUtil.driver = driver;
	}

	
	/**
	 * 匹配数据库数据,比较时为完全的数据库查询值比较
	 * @param String 查询语句 查询字段为需要比较的字段,防止行乱序使用order by 进行排序
	 * 预期结果 ret 无值时使用size = 0 的数组
	 * 
	 * @param String[] 预期数据
	 * 
	 */
	public static void checkDataMatch(String sql, String[][] ret, String msg) {
		if (ret == null) {
			return;
		}
		
		RemoteServiceProxy proxy = new RemoteServiceProxy(driver);
		DataTable dt = proxy.dbquery(sql, null);

		if (dt == null) {
			return;
		}
		
		if (dt.size() == 0 && ret.length == 0) {
			LogImpl.getInstance().info("表中无数据====检查成功--" + msg);
			return;
		}

		int i = 0;
		if (dt.first()) {
			while (!dt.isAfterLast()) {
				if (i >= ret.length) {
					LogImpl.getInstance().error("表中数据多于预期数据=======检查失败--" + msg);
					break;
				}
				String[] row = ret[i];
				for (int j = 0; j < row.length; j++) {
					int dataType = dt.getMetaData().getColumnInfo(j).getDataType();
					Object value = dt.getObject(j);
					
					// 数据类型处理,为空判断和日期处理
					if (value == null) {
						if (row[j] == null) {
							LogImpl.getInstance().info("表中第" + (j+1) +"列值" + row[j] + "存在====检查成功--" + msg);
						} else {
							LogImpl.getInstance().error("表中第" + (j+1) +"列值" + row[j] + "不存在====检查失败--" + msg);
						}
					} else {
						switch (dataType) {
						case DataType.DATE:
						case DataType.DATETIME:
							Date date = (Date) value;
							SimpleDateFormat sdf = null;
							if (row[j].trim().length() > 11) {
								sdf= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							} else {
								sdf= new SimpleDateFormat("yyyy-MM-dd");
							}
							long time = 0;
							try {
								time = sdf.parse(row[j]).getTime();
							} catch (ParseException e) {
								e.printStackTrace();
							}
							if (date.getTime() == time) {
								LogImpl.getInstance().info("表中第" + (j+1) +"列值" + row[j] + "存在====检查成功--" + msg);
							} else {
								LogImpl.getInstance().error("表中第" + (j+1) +"列值" + row[j] + "不存在====检查失败--" + msg);
							}							
							break;
						default:
							if (row[j].equals(value.toString())) {
								LogImpl.getInstance().info("表中第" + (j+1) +"列值" + row[j] + "存在====检查成功--" + msg);
							} else {
								LogImpl.getInstance().error("表中第" + (j+1) +"列值" + row[j] + "不存在====检查失败--" + msg);
							}							
						}
					}				
					
				}
				LogImpl.getInstance().info("表中第" + i +"行====检查成功--" + msg);
				dt.next();
				i ++;
			}
		}
		
		if (ret.length > dt.size()) {
			LogImpl.getInstance().error("表中数据少于预期数据=======检查失败--" + msg);
		}
	}
}
