package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.AbstractComponent;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.QueryBoxDialog;
import com.bokesoft.yes.autotest.log.LogImpl;

public class DialogUtil {

	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		DialogUtil.driver = driver;
	}

	/**
	 * 检查是否弹出确认框
	 */
	public static void checkShowConfirmDialog() {
		try {
			ConfirmDialog.element();
			LogImpl.getInstance().info("True       弹出确认框。");
			// Confirm.element().close();
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().error("False     弹出确认框。");
		}
	}

	/**
	 * 检查是否弹出确认框
	 * 
	 * @param text
	 *            弹框标题
	 */
	public static void checkShowConfirmDialog(String text) {
		try {
			// Confirm.element();
			if (ConfirmDialog.element().getText().equals(text)) {
				LogImpl.getInstance().info("确认框提示信息：" + text + "======检查成功。");
			} else {
				LogImpl.getInstance().info("确认框提示信息：" + text + "======检查失败。");
			}
			// Confirm.element().close();
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().error("确认框提示信息：" + text + "======检查失败。");
		}
	}

	/**
	 * 检查是否弹出错误提示框
	 */
	public static void checkShowErrorDialog() {
		try {
			// ErrorDialog.element();
			LogImpl.getInstance().info("弹出错误提示框======检查成功。");
			// ErrorDialog.element().close();
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().info("弹出错误提示框======检查失败。");
		}
	}

	/**
	 * 检查是否弹出错误提示框
	 * 
	 * @param text
	 *            弹框标题
	 */
	public static void checkShowErrorDialog(String text) {
			
			String s =ErrorDialog.element().getText();
			System.out.println(s);
			if (s.equals(text)) {
				LogImpl.getInstance().info("提示正确：" + text + "=====================检查成功。");
				return;
			}
			LogImpl.getInstance().error("提示错误：" + text + "=======================检查错误。");
	}

	/**
	 * 检查是否弹出下推源单查询框
	 */
	public static void checkQueryBoxDialog() {
		try {
			int id = QueryBoxDialog.element().getDialogID();
			AbstractComponent.setFormID(id);
			LogImpl.getInstance().info("弹出查询框======检查成功。");
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().error("弹出查询框======检查失败。");
		}
	}

	/**
	 * 检查弹出框内文本是否正确
	 * 
	 * @param text
	 *            预期结果
	 */
	public static void checkConfirmDialogText(String text) {
		String ret = ConfirmDialog.element().getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info("弹出框文本正确======检查成功。");
			return;
		}
		LogImpl.getInstance()
				.error("预期结果：" + text + "	  实际结果为:" + ret + "弹出框文本错误====================================检查失败。");
	}

	/**
	 * 检查错误提示框内文本是否正确
	 * 
	 * @param text
	 *            预期结果
	 */
	public static void checkErrorDialogText(String text) {
		String ret = ErrorDialog.element().getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info("错误提示框文本正确======检查成功。");
			return;
		}
		LogImpl.getInstance()
				.error("预期结果：" + text + "	  实际结果为:" + ret + "错误提示框文本错误====================================检查失败。");
	}
}
