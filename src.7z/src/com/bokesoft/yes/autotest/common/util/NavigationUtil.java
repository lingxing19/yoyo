package com.bokesoft.yes.autotest.common.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.log.LogImpl;


public class NavigationUtil {

	static WebDriver driver = null;
	
	public static void setDriver(WebDriver driver) {
		NavigationUtil.driver = driver;
	}
	
	/**
	 * 校验StatusInfoItem的caption
	 * @param 
	 * @param 
	 */
	public static void checkStatuItemCaption(String key,String caption){

		WebElement org = driver.findElement(By.xpath("//label[@class='org_lbl']"));

		try {
			List<WebElement> status = org.findElements(By.tagName("p"));
			for (int i = 0; i < status.size(); i++) {
				WebElement p = status.get(i);
				if (key.equals(p.getAttribute("key"))) {
					if (p.getText().equals(caption)) {
						LogImpl.getInstance().error(key +"======检查成功 预期结果："+ caption);
						return;
					}
				}
			}
			LogImpl.getInstance().error(key +"======================检查失败 预期结果："+ caption);
		} catch (Exception e) {
			LogImpl.getInstance().error(key +"======================检查失败 预期结果："+ caption);
		}
		
		
	}
}
