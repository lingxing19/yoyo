package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.factory.RadioButton;
import com.bokesoft.yes.autotest.log.LogImpl;

public class RadioButtonUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		RadioButtonUtil.driver = driver;
	}

	/**
	 * 检查单选框勾选状态 radiobuttonKey 控件key checked 状态取值
	 */
	public static void checkRadioBtChecked(String radiobuttonKey, boolean checked, String string) {
		if (RadioButton.element(radiobuttonKey).isChecked() == checked) {
			if (checked) {
				LogImpl.getInstance().info(string + "单选框勾选========检查成功");
				return;
			}
			LogImpl.getInstance().info(string + "单选框未勾选========检查成功");
			return;
		}
		if (checked) {
			LogImpl.getInstance().error(string + "单选框未勾选========检查失败");
			return;
		}
		LogImpl.getInstance().error(string + "单选框勾选========检查失败");
	}

}
