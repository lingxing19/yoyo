package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import com.bokesoft.yes.autotest.log.LogImpl;

public class FunctionUtil {
	
	static WebDriver driver = null;
	
	public static void setDriver(WebDriver driver) {
		FunctionUtil.driver = driver;
	}
	
	public static void checkConsoleLog(String...strs) {
		LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
		
		Boolean[] booleans = new Boolean[strs.length];
		
        for (LogEntry entry : logEntries) {
        	LogImpl.getInstance().info("后台输出"+entry.getMessage());
        	for (int i = 0; i < strs.length; i++) {
        		if (entry.getMessage().contains(strs[i])) {
        			booleans[i] = true;
            		
            	}
        	}
        }
        
        for (int i = 0 ;i < booleans.length; i ++ ) {
        	if (booleans[i] == null) {
        		LogImpl.getInstance().error("后台输出："+strs[i]+"======检查失败。");
        	} else {       		
        		LogImpl.getInstance().info("后台输出："+strs[i]+"======检查成功。");
        	}
        }
		
	}
	
	/**
	 * 检查2个值是否相等
	 * @param s1  比较的值（各种数据类型都可以）
	 * @param s2  比较的值（各种数据类型都可以）
	 * @param msg  检查描述
	 */
	public static void check(Object s1, Object s2, String msg) {
		if(s1.equals(s2)){
			LogImpl.getInstance().info(msg+"======检查成功。");
			return;
		}		
		LogImpl.getInstance().error(msg + "======检查失败。");
	}
	

}
