package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.ITextEditor;
import com.bokesoft.yes.autotest.component.factory.TextEditor;
import com.bokesoft.yes.autotest.log.LogImpl;

public class TextEditorUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		TextEditorUtil.driver = driver;
	}

	/**
	 * 检查头控件编辑框中的值
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(ITextEditor atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

//	/**
//	 * 检查头控件编辑框右侧图标
//	 * 
//	 * @param atc
//	 *            头控件（带编辑框）对象
//	 * @param url
//	 *            预期的值
//	 */
//	public static void checkPreIcon(ITextEditor atc, String url, String msg) {
//		String ret = atc.getPreIcon();
//		if (ret.equals(url)) {
//			LogImpl.getInstance().info(msg + "======检查成功");
//
//			return;
//		}
//		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + url + "	实际结果为:" + ret);
//	}

	/**
	 * 检查头控件编辑框的左侧图标
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param s
	 *            true or false
	 */
	public static void checkPreIcon(ITextEditor atc, Boolean s, String iconName, String msg) {
		boolean ret = atc.isPreIcon(iconName);
		if (ret==s) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + s + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件的空值提示
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkPromptText(ITextEditor atc, String text, String msg) {
		String ret = atc.getPromptText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框的内嵌文本
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkEmbedText(ITextEditor atc, String text, String msg) {
		String ret = atc.getEmbedText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 判断控件是否存在焦点
	 * 
	 * @param atc
	 *            控件KEY
	 * @param s
	 *            预期值
	 */
	public static void checkFocusOn(String atc, boolean s, String msg) {
		boolean ret = TextEditor.element(atc).isFocusOn();
		if (ret == s) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + s + "	实际结果为:" + ret);
	}

	public static void checkClearButton(String atc, boolean s, String msg) {
		boolean ret = TextEditor.element(atc).isClearButton();
		if (ret == s) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + s + "	实际结果为:" + ret);
	}
}
