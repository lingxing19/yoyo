package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.IDropdownButton;
import com.bokesoft.yes.autotest.log.LogImpl;

public class DropdownButtonUtil {

	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {

		DropdownButtonUtil.driver = driver;
	}
	/**
	 * 检验配置的图标是否存在于界面上
	 * @param atc          控件Key
	 * @param s            true or false
	 * @param iconName     图标名称
	 * @param msg          测试用例编号
	 */
	public static void  checkIcon(IDropdownButton atc, boolean s , String iconName, String msg) {
		boolean ret = atc.isIcon(iconName);
		if (ret==s) {
			LogImpl.getInstance().info(msg + "图标存在且一致==================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "图标不存在或不一致=====================检查失败 预期结果为:" + s + "	实际结果为:" + ret);
	}
	
	public static void checkItemsName(IDropdownButton atc, String s, String msg) {
		String ret = atc.getItems();
		if (ret.equals(s)) {
			LogImpl.getInstance().info(msg + "与预期结果一致==================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "与预期结果不一致=====================检查失败 预期结果为:" + s + "	实际结果为:" + ret);
	}

}
