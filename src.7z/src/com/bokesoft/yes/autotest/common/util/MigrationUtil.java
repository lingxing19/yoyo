package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

public class MigrationUtil {

	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		MigrationUtil.driver = driver;
	}

	
	
}
