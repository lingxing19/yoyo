package com.bokesoft.yes.autotest.common.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.component.AbstractTableComponent;
import com.bokesoft.yes.autotest.component.IControl;
import com.bokesoft.yes.autotest.component.IToolBar;
import com.bokesoft.yes.autotest.component.factory.ConfirmDialog;
import com.bokesoft.yes.autotest.component.factory.ErrorDialog;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.factory.ListView;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.sun.xml.internal.bind.v2.model.core.Element;

public class AssertUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		AssertUtil.driver = driver;
	}

	// 万能检查公式
	/**
	 * 检查2个值是否相等
	 * 
	 * @param s1
	 *            比较的值（各种数据类型都可以）
	 * @param s2
	 *            比较的值（各种数据类型都可以）
	 * @param msg
	 *            检查描述
	 */
	public static void check(Object s1, Object s2, String msg) {
		if (s1.equals(s2)) {
			LogImpl.getInstance().info(msg + "======检查成功。");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败。");
	}

	/**
	 * 检查s1是否包含s2
	 * 
	 * @param s1
	 * @param s2
	 * @param msg
	 *            检查描述
	 */
	public static void checkFuzzyMatching(String s1, String s2, String msg) {
		if (s1.contains(s2)) {
			LogImpl.getInstance().info(msg + "======检查成功。");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败。");
	}

	public static void showConfirm() {
		try {
			ConfirmDialog.element();
			LogImpl.getInstance().info("弹出确认框======检查成功。");
			ConfirmDialog.element().close();
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().error("弹出确认框======检查失败。");
		}
	}

	public static void showConfirm(String text) {
		try {
			ConfirmDialog.element();
			if (ConfirmDialog.element().getText().equals(text)) {
				LogImpl.getInstance().info("确认框：" + text + "======检查成功。");
			} else {
				LogImpl.getInstance().info("确认框：" + text + "======检查失败。");
			}
			ConfirmDialog.element().close();
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().error("确认框：" + text + "======检查失败。");
		}
	}

	public static void showErrorDialog() {
		try {
			ErrorDialog.element();
			LogImpl.getInstance().info("弹出错误提示框======检查成功。");
			ErrorDialog.element().close();
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().info("弹出错误提示框======检查失败。");
		}
	}

	public static void showErrorDialog(String text) {
		try {
			ErrorDialog.element();
			if (ErrorDialog.element().getText().contains(text)) {
				LogImpl.getInstance().info("提示错误：" + text + "======检查成功。");
			} else {
				LogImpl.getInstance().info("提示错误：" + text + "======检查失败。");
			}
			ErrorDialog.element().close();
		} catch (NoSuchElementException e) {
			LogImpl.getInstance().info("错误提示：" + text + "======检查失败。");
		}
	}

	/**
	 * 检查头控件编辑框左右水平居中平
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkHalign(IControl atc, String text, String msg) {
		String ret = atc.getHalign();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框前景色
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkForeColor(IControl atc, String text, String msg) {
		String ret = atc.getForeColor();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框背景色
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkBackColor(IControl atc, String text, String msg) {
		String ret = atc.getBackColor();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框字体格式
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkFontName(IControl atc, String text, String msg) {
		String ret = atc.getFontName();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框字体大小
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkFontSize(IControl atc, String text, String msg) {
		String ret = atc.getFontSize();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框字体宽度
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkFontWeight(IControl atc, String text, String msg) {
		String ret = atc.getFontWeight();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查头控件编辑框字体样式
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkFontStyle(IControl atc, String text, String msg) {
		String ret = atc.getFontStyle();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 头控件检查规则校验
	 * 
	 * @param atc
	 *            头控件对象
	 * @param b
	 *            true, 检查规则通过 ; false，检查规则不通过
	 */
	public static void uiCheck(IControl atc, Boolean b, String string) {
		if (b == atc.isRedcornerExist()) {
			if (b) {
				LogImpl.getInstance().info(string + "红色角标存在=====检查成功。");
			} else {
				LogImpl.getInstance().info(string + "红色角标不存在=====检查成功。");
			}
		} else {
			if (b) {
				LogImpl.getInstance().error(string + "红色角标不存在====检查失败。");
			} else {
				LogImpl.getInstance().error(string + "红色角标存在====检查失败。");
			}
		}
	}

	// public static void uiCheck(IControl atc,Boolean b,String string){
	// if(atc.isRedcornerExist()==b){
	// if(b==true){
	// LogImpl.getInstance().info(string +"红色角标存在======检查成功。");
	// return;
	// }else {
	// LogImpl.getInstance().info(string +"红色角标不显示======检查成功。");
	// return;
	// }
	// }
	// if(atc.isRedcornerExist()!=b){
	// LogImpl.getInstance().error(string +"红色角标存在======检查失败。");
	// return;
	// }
	// LogImpl.getInstance().error(string +"红色角标不显示======检查失败。");
	//
	// }

	/**
	 * 头控件错误描述校验
	 * 
	 * @param atc
	 *            头控件对象
	 * @param text
	 *            预期的值
	 */
	public static void checkErrorInfo(IControl atc, String text, String msg) {
		if (atc.getErrorInfo().equals(text)) {
			LogImpl.getInstance().info(msg + text + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + text + "======检查失败");
	}
	/**
	 * 全局检查错误描述测试
	 * 
	 * @param text
	 * 				顶部报错提示
	 * 
	 */
	public static void getAllErrorInfo(String text,String msg) {
		List<WebElement> s = driver.findElements(By.xpath("//div[@class='errorinfo']"));
		for (WebElement e : s)
			if (e.getCssValue("display").equals("block")) {
				text = e.findElement(By.xpath(".//label")).getText();
				LogImpl.getInstance().info(text + msg + "======检查成功");
				return;
			}
			LogImpl.getInstance().error(text + msg + "======检查失败");				
		}
		
		
	
	
	/**
	 * 头控件必填校验
	 * 
	 * @param atc
	 *            头控件对象
	 * @param b
	 *            true, 必填 ; false，检查通过
	 */
	public static void checkRequired(IControl atc, Boolean b, String string) {
		if (!atc.isYellowcornerExist() == b) {
			if (b == true) {
				LogImpl.getInstance().info(string + "需必填====检查成功");
				return;
			}
			LogImpl.getInstance().info(string + "黄色角标消失====检查失败");
			return;
		}
		if (b == true) {
			LogImpl.getInstance().error(string + "需必填====检查失败");
			return;
		}
		LogImpl.getInstance().error(string + "黄色角标消失==检查成功");
	}

	/**
	 * 检查头控件显示状况
	 * 
	 * @param atc
	 *            头控件对象（源文件中要存在）
	 * @param b
	 *            true,显示；false，不显示
	 */
	public static void checkDisplayed(IControl atc, Boolean b, String string) {
		if (atc.isDisplayed() == b) {
			if (b) {
				LogImpl.getInstance().info(string + "头控件显示======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info(string + "头控件不显示======检查成功。");
				return;
			}
		}
		if (atc.isDisplayed() != b) {
			LogImpl.getInstance().error(string + "头控件不显示======检查失败。");
			return;
		}
		LogImpl.getInstance().error(string + "头控件显示======检查失败。");

	}

	/**
	 * 检查头控件可编辑
	 * 
	 * @param atc
	 *            头控件对象（源文件中要存在）
	 * @param b
	 *            true,可编辑；false，不可编辑
	 */
	public static void checkEnabled(IControl atc, Boolean b, String string) {
		if (atc.isEnabled() == b) {
			if (b == true) {
				LogImpl.getInstance().info(string + "头控件可用======检查成功。");
				return;
			}
			LogImpl.getInstance().error(string + "头控件不可用======检查失败。");
			return;
		}
		if (b == false) {
			LogImpl.getInstance().info(string + "头控件不可用======检查成功。");
			return;
		}
		LogImpl.getInstance().error(string + "头控件可用======检查失败。");
		return;
	}

	/**
	 * 检查头控件悬浮提示框
	 * 
	 * @param atc
	 *            头控件对象（源文件中要存在）
	 * @param text
	 *            预期的值
	 */
	public static void checkHovertext(IControl atc, String text, String string) {
		if (atc.getHovertext().equals(text)) {
			LogImpl.getInstance().info(string + text + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(string + text + "======检查失败");
	}

	/**
	 * 检查头控件编辑框垂直对齐方式
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkVertical(IControl atc, String text, String msg) {
		String ret = atc.getVertical();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	// listview相关的检查

	/**
	 * 检查listview中符合条件的单据数量
	 * 
	 * @param viewKey
	 *            视图列表的key
	 * @param colName
	 *            列名
	 * @param text
	 *            列的值
	 * @param formCount
	 *            预期的数量
	 */
	public static void checkFormCount(String viewKey, String colName, String text, int formCount) {
		if (ListView.element(viewKey).countForm(colName, text) == formCount) {
			LogImpl.getInstance().info("[" + colName + "]是" + text + "的单据数量：" + formCount + "======检查成功");
			return;
		}
		LogImpl.getInstance().error("[" + colName + "]是" + text + "的单据数量：" + formCount + "======检查失败");
	}

	/**
	 * 检查符合条件的单据存在与否
	 * 
	 * @param viewKey
	 *            视图列表的key
	 * @param colName
	 *            列名
	 * @param text
	 *            列的值
	 * @param b
	 *            true，预期存在；false，预期不存在
	 */
	public static void checkFormExsit(String viewKey, String colName, String text, Boolean b) {
		if (ListView.element(viewKey).isFormExsit(colName, text) == b) {
			if (b == true) {
				LogImpl.getInstance().info("[" + colName + "]是" + text + "的单据存在=======检查成功");
				return;
			}
			LogImpl.getInstance().info("[" + colName + "]是" + text + "的单据不存在=======检查成功");
			return;
		}
		if (b == true) {
			LogImpl.getInstance().error("[" + colName + "]是" + text + "的单据存在=======检查失败");
			return;
		}
		LogImpl.getInstance().error("[" + colName + "]是" + text + "的单据不存在=======检查失败");
	}

}
