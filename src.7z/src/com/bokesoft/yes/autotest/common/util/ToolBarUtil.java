package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.component.IButton;
import com.bokesoft.yes.autotest.component.IToolBar;
import com.bokesoft.yes.autotest.log.LogImpl;

public class ToolBarUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		ToolBarUtil.driver = driver;
	}
	/**
	 * 校验工具栏上按钮名称 是否显示正确击
	 * @param atc          控件key
	 * @param caption      应显示的按钮名称
	 * @param msg          测试用例编号
	 */
	public static void checkButtonNames(IToolBar atc , String caption , String msg) {
		String ret = atc.getButtonName();
		if (ret.equals(caption)) {
			LogImpl.getInstance().info(msg + "===========检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "==================检查失败 预期结果为:" + caption + "	实际结果为:" + ret);
	}
	
	/**
	 * 检验操作按钮左侧图标是否显示正确
	 * @param atc        工具栏key
	 * @param key        操作按钮key
	 * @param iconName   图标名称
	 * @param s          true or false
	 * @param msg        测试用例编号
	 */
	public static void checkIsIcon(IToolBar atc , String key ,String iconName, Boolean s ,String msg) {
		boolean ret = atc.isIcon(key,iconName);
		if (ret==s) {
			LogImpl.getInstance().info(msg + "==================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "=====================检查失败 预期结果为:" + s + "	实际结果为:" + ret);
		
		
	}
	/**
	 * 检验操作按钮后侧下拉按钮是否显示
	 * @param atc      工具栏key
	 * @param key      操作按钮key
	 * @param s        true or false
	 * @param msg      测试用例编号
	 */
	
	public static void checkIsDrop(IToolBar atc ,String key ,boolean s, String msg ) {
		boolean ret =atc.isDrop(key);
		if (ret==s) {
			LogImpl.getInstance().info(msg + "==================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "=====================检查失败 预期结果为:" + s + "	实际结果为:" + ret);		
	}

	/**
	 * 检验工具栏上操作按钮是否显示可用
	 * @param atc      工具栏key
	 * @param key      操作按钮key
	 * @param s        true or false
	 * @param msg      测试用例编号
	 */
	public static void checkIsEnable(IToolBar atc,String key ,boolean s, String msg) {
		boolean ret = atc.isEnable(key);
		if (ret==s) {
			LogImpl.getInstance().info(msg + "==================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "=====================检查失败 预期结果为:" + s + "	实际结果为:" + ret);
		
	}
	
	/**
	 * 检验操作按钮点击下拉按钮后，子操作按钮是否展开显示
	 * @param atc      工具栏key
	 * @param key      操作按钮key
	 * @param s        true or false
	 * @param msg      测试用例编号
	 */
	public static  void checkIsShow(IToolBar atc,String key,boolean s,String msg) {
		boolean ret = atc.isShow(key);
		if (ret==s) {
			LogImpl.getInstance().info(msg + "==================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "=====================检查失败 预期结果为:" + s + "	实际结果为:" + ret);
		
	}
	
	/**
	 * 检验应在界面显示的子操作按钮名称
	 * @param atc         工具栏key
	 * @param key         操作按钮key
	 * @param caption     子操作按钮caption
	 * @param msg         测试用例编号
	 */
	public static  void checkItemName(IToolBar atc,String key,String caption ,String  msg) {
		String ret =atc.getItemName(key);
		if (ret.equals(caption)) {
			LogImpl.getInstance().info(msg + "==================检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "=====================检查失败 预期结果为:" + caption + "	实际结果为:" + ret);
		
		
	}

}
