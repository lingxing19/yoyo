package com.bokesoft.yes.autotest.common.util;

import java.util.List;
import org.openqa.selenium.WebDriver;
import com.bokesoft.yes.autotest.component.dict.BaseDictItem;
import com.bokesoft.yes.autotest.component.dictquerybox.BaseDictQueryItem;
import com.bokesoft.yes.autotest.component.dictview.BaseDictViewItem;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.log.LogImpl;

public class DictUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		DictUtil.driver = driver;
	}

	/**
	 * 获取子节点属性并比较是否相同
	 * 
	 * @param result
	 *            预期结果
	 * @param expResult
	 *            实际结果
	 * @param msg
	 *            用例编号
	 */
	public static void checkDictViewItemFiled(List<BaseDictViewItem> result, List<BaseDictViewItem> expResult,
			String msg) {
		
		if(result.size() != expResult.size()){
			LogImpl.getInstance().error(msg + "======缺少数据");
			return;
		}
		
		for (int i = 0; i < expResult.size(); i++) {
			BaseDictViewItem expItem = expResult.get(i);
			BaseDictViewItem item = result.get(i);
			if (item != null) {
				if (item.getCaption().equals(expItem.getCaption())) {
					LogImpl.getInstance().info(msg + "节点名称正确======检查成功");
				} else {
					LogImpl.getInstance().error(
							msg + "节点名称错误======检查失败 预期结果为:" + expItem.getCaption() + "	  实际结果为:" + item.getCaption());
				}
				if (item.getEnable() == expItem.getEnable()) {
					LogImpl.getInstance().info(msg + "节点状态正确======检查成功");
				} else {
					LogImpl.getInstance().error(
							msg + "节点状态错误======检查失败 预期结果为:" + expItem.getEnable() + "	  实际结果为:" + item.getEnable());
				}
				if (item.getNodeType() == expItem.getNodeType()) {
					LogImpl.getInstance().info(msg + "节点类型正确======检查成功");
				} else {
					LogImpl.getInstance().error(
							msg + "节点类型错误======检查失败 预期结果为:" + expItem.getNodeType() + "	  实际结果为:" + item.getNodeType());
				}
			} else {
				LogImpl.getInstance().error(msg + "======缺少数据" + item.toString());
			}
		}
	}

	/**
	 * 获取子节点属性并比较是否相同
	 * 
	 * @param result
	 *            预期结果
	 * @param expResult
	 *            实际结果
	 * @param msg
	 *            用例编号
	 */
	public static void checkDictItemFiled(List<BaseDictItem> result, List<BaseDictItem> expResult, String msg) {

		if (result == null) {
			return;
		}

		if (expResult.size() != result.size()) {
			LogImpl.getInstance().error(msg + "检查该节点下子节点是否一致=====================================数据个数错误");

		}

		if (expResult.size() == 0) {
			LogImpl.getInstance().info(msg + "检查该节点下无子节点======检查成功");
		}

		for (int i = 0; i < expResult.size(); i++) {
			BaseDictItem expItem = expResult.get(i);
			BaseDictItem item = result.get(i);
			if (item != null) {
				if (item.getCaption().equals(expItem.getCaption())) {
					LogImpl.getInstance().info(msg + "节点名称正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点名称错误============================检查失败 预期结果为:"	+ expItem.getCaption() + "	  实际结果为:" + item.getCaption());
				}
				if (item.getEnable() == expItem.getEnable()) {
					LogImpl.getInstance().info(msg + "节点状态正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点状态错误============================检查失败 预期结果为:"	+ expItem.getEnable() + "	  实际结果为:" + item.getEnable());
				}
				if (item.getNodeType() == expItem.getNodeType()) {
					LogImpl.getInstance().info(msg + "节点类型正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点类型错误============================检查失败 预期结果为:"	+ expItem.getNodeType() + "	  实际结果为:" + item.getNodeType());
				}
				// 不检测单选
				if (expItem.getChkState() >= 0) {
					if (item.getChkState() == expItem.getChkState()) {
						LogImpl.getInstance().info(msg + "节点勾选状态正确======检查成功");
					} else {
						LogImpl.getInstance().error(msg + "节点勾选状态错误=====================检查失败 预期结果为:"	+ expItem.getChkState() + "	  实际结果为:" + item.getChkState());
					}
				}
			} else {
				LogImpl.getInstance().error(msg + "========================================缺少数据" + item.toString());
			}
		}
	}

	/**
	 * 检查字典根节点
	 * 
	 * @param dictKey
	 *            字典的key
	 * @param value
	 *            预期的根节点名称
	 * @param msg
	 *            用例编号
	 */
	public static void checkRootNode(String dictKey, String itemName, String msg) {
		String ret = Dict.element(dictKey).viewClick().getRootNode();
		if (ret.trim().equals(itemName.trim())) {
			LogImpl.getInstance().info(msg + "根节点：" + itemName + "根节点正确======检查成功。");
			return;
		}
		LogImpl.getInstance()
				.error(msg + "预期结果：" + itemName + "	  实际结果为:" + ret + "根节点错误====================================检查失败。");
	}

	/**
	 * 检查多选字典根节点勾选状态
	 * 
	 * @param dictKey
	 *            字典的key
	 * @param s
	 *            预期的根节点勾选状态
	 * @param msg
	 *            用例编号
	 */
	public static void checkRootState(String dictKey, String text, String msg) {
		String ret = Dict.element(dictKey).viewClick().getRootChkstate();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "根节点：" + text + "根节点勾选状态======检查成功。");
			return;
		}
		LogImpl.getInstance()
				.error(msg + "===========================================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}
	/**
	 * 
	 * @param dictKey
	 *            字典的key
	 * @param itemCode
	 *            节点的值
	 * @param b
	 *            预期的节点可选
	 * @param msg
	 *            用例编号
	 */
	public static void checkItemDisableSelect(String dictKey, String itemCode, boolean b, String msg) {
		boolean ret = Dict.element(dictKey).viewClick().itemSelect(itemCode);
		if (ret == b) {
			LogImpl.getInstance().info(msg + "节点可选择========检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "节点可选择============================检查失败 预期结果为:" + b + "	实际结果为:" + ret);
		return;
	}

	/**
	 * 校验字典编辑框内取值是否正确
	 * 
	 * @param dictKey
	 *            字典的key
	 * @param text
	 *            取值
	 * @param msg
	 *            用例编号
	 */
	public static void checkInputValue(String dictKey, String text, String msg) {
		String ret = Dict.element(dictKey).getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error(msg + "===========================================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 校验字典下拉框中选中节点状态
	 * 
	 * @param dictKey
	 *            字典的key
	 * @param text
	 *            取值
	 * @param msg
	 *            用例编号
	 */
	public static void checkItemChecked(String dictKey, String itemCode, boolean b, String msg) {
		boolean ret = Dict.element(dictKey).viewClick().itemChecked(itemCode);
		if (ret == b) {
			LogImpl.getInstance().info(msg + "节点显示选中========检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "节点显示未选中============================检查失败 预期结果为:" + b + "	实际结果为:" + ret);
		return;
	}

	/**
	 * 检查链式字典页数是否正确
	 * 
	 */
	public static void checkDictPage(String dictKey, String text, String msg) {
		String ret = Dict.element(dictKey).viewClick().getPage();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "根节点：" + text + "链式字典页数正确======检查成功。");
			return;
		}
		LogImpl.getInstance()
				.error(msg + "链式字典页数不一致=======================================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 获取查询框子节点属性并比较是否相同
	 * 
	 * @param result
	 *            预期结果
	 * @param expResult
	 *            实际结果
	 * @param msg
	 *            用例编号
	 */
	public static void checkQueryBoxItemFiled(List<BaseDictQueryItem> result, List<BaseDictQueryItem> expResult,
			String msg) {
		if (result == null) {
			return;
		}
		if (expResult.size() != result.size()) {
			LogImpl.getInstance().error(msg + "检查该节点下子节点是否一致=====================================数据个数错误");
		}

		if (expResult.size() == 0) {
			LogImpl.getInstance().info(msg + "检查该节点下无子节点======检查成功");
		}

		for (int i = 0; i < expResult.size(); i++) {
			BaseDictQueryItem expSet = expResult.get(i);
			BaseDictQueryItem set = result.get(i);
			if (set != null) {
				if (set.getCaption().equals(expSet.getCaption())) {
					LogImpl.getInstance().info(msg + "节点名称正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点名称错误============================检查失败 预期结果为:"
							+ expSet.getCaption() + "	  实际结果为:" + set.getCaption());
				}
				if (set.getCode().equals(expSet.getCode())) {
					LogImpl.getInstance().info(msg + "节点Code正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点Code错误============================检查失败 预期结果为:"
							+ expSet.getCode() + "	  实际结果为:" + set.getCode());
				}
				if (set.getNodeType() == expSet.getNodeType()) {
					LogImpl.getInstance().info(msg + "节点类型正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点类型错误============================检查失败 预期结果为:"
							+ expSet.getNodeType() + "	  实际结果为:" + set.getNodeType());
				}
			} else {
				LogImpl.getInstance().error(msg + "======缺少数据" + set.toString());
			}
		}

	}
}
