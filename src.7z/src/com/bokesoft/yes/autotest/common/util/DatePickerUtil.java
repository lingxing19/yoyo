package com.bokesoft.yes.autotest.common.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;

import com.bokesoft.yes.autotest.component.IDatePicker;
import com.bokesoft.yes.autotest.log.LogImpl;
import com.sun.scenario.effect.Bloom;

public class DatePickerUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		DatePickerUtil.driver = driver;
	}

	/**
	 * 检查头控件编辑框中的值
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkInputValue(IDatePicker atc, String text, String msg) {
		String ret = atc.getText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功 结果为:" + ret);
			return;
		}
		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检测选择框默认时间是否与当前时间一致 
	 * @param atc      Key
	 * @param msg      
	 */
	public static void checkCurrDate(IDatePicker atc,  String msg) {
		String s1=atc.getCurrDate();
		String s2=atc.getViewCurrDate();
		if(s1.equals(s2)){
			System.out.println(true);
			LogImpl.getInstance().info(msg + "======检查成功 与当前时间一致   结果为:" + s1+"  :  "+s2);
			return;
		}
		System.out.println(false);
		LogImpl.getInstance().info(msg + "======检查失败   与当前时间不一致   结果为:" + s1+"  :  "+s2);
		
	}
	
	/**
	 * 检验点击选择框左侧按钮时，月份是否呈递减趋势
	 * @param atc       key
	 * @param num       点击次数
	 * @param b         True Or False
	 * @param msg
	 */
//	public static void checkMCutDown(IDatePicker atc , int num , Boolean b ,String msg) {
//		boolean s1=atc.cutDownClick(num);
//		if (s1==b) {
//			LogImpl.getInstance().info(msg + "======检查成功  呈递减         结果为:" + s1);
//			return;
//		}
//		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + b + "	实际结果为:" + s1);
//	}
//	
	/**
	 * 检验点击选择框左侧按钮时，月份是否呈递减趋势
	 * @param atc       key
	 * @param num       点击次数
	 * @param b         True Or False
	 * @param msg
	 */
//	public static void checkAddClick(IDatePicker atc , int num , Boolean b ,String msg) {
//		boolean s1=atc.addClick(num);
//		if (s1==b) {
//			LogImpl.getInstance().info(msg + "======检查成功  呈递增          结果为:" + s1);
//			return;
//		}
//		LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + b + "	实际结果为:" + s1);
//	}
}
