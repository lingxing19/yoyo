package com.bokesoft.yes.autotest.common.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.bokesoft.yes.autotest.component.AbstractTableComponent;
import com.bokesoft.yes.autotest.component.factory.Dict;
import com.bokesoft.yes.autotest.component.factory.Grid;
import com.bokesoft.yes.autotest.component.grid.BaseGrid;
import com.bokesoft.yes.autotest.component.grid.BaseGridDictItem;
import com.bokesoft.yes.autotest.log.LogImpl;

public class GridUtil {
	private static final String String = null;
	private static WebDriver driver = null;

	public static void setDriver(WebDriver driver) {
		GridUtil.driver = driver;
	}

	/**
	 * 检查单元格的值
	 * 
	 * @param gridKey
	 *            表格的key
	 * @param colName
	 *            列名
	 * @param index
	 *            行序号
	 * @param value
	 *            预期的值
	 */
	public static void checkCellValue(String gridKey, String colName, int index, String value) {
		String cellValue = Grid.element(gridKey).getCellValue(colName, index);
		if (cellValue.equals(value)) {
			LogImpl.getInstance().info(colName + "列，第" + index + "行的值：" + value + "======检查成功。");
		} else {
			LogImpl.getInstance().error(colName + "列，第" + index + "行的值：" + value
					+ "================================检查失败。预期结果为:" + value + "	实际结果为:" + cellValue);
		}
	}


	/**
	 * 校验单元格必填是否存在
	 * 
	 * @param gridKey
	 *            表格Key
	 * @param colName
	 *            列名
	 * @param index
	 *            行数
	 * @param b
	 *            true为存在 or false为不存在
	 */
	public static void cellRequiredCheck(String gridKey, String colName, int index, Boolean b) {
		if (Grid.element(gridKey).isYellowcornerExist(colName, index) == b) {
			if (b == true) {
				LogImpl.getInstance().info("必填黄色角标存在===========================检查成功。");
				return;
			}
			LogImpl.getInstance().info("必填黄色角标不存在===============================检查成功。");
			return;
		}
		if (Grid.element(gridKey).isYellowcornerExist(colName, index) != b) {
			if (b == true) {
				LogImpl.getInstance().error("必填黄色角标存在==============================检查失败。");
				return;
			}
			LogImpl.getInstance().error("必填黄色角标不存在==================================检查失败。");
		}
	}

	/**
	 * 单元格检查规则校验
	 * 
	 * @param gridKey
	 *            表格的key
	 * @param colName
	 *            列名
	 * @param index
	 *            行序号
	 * @param b
	 *            true,预期检查规则通过；false,预期检查规则不通过
	 */
	public static void cellUICheck(String gridKey, String colName, int index, Boolean b) {
		if (Grid.element(gridKey).isRedcornerExist(colName, index) == b) {
			if (b == true) {
				LogImpl.getInstance().info("检查规则不通过红色角标存在===========================检查成功。");
				return;
			}
			LogImpl.getInstance().info("检查规则通过红色角标不存在===============================检查成功。");
			return;
		}
		if (Grid.element(gridKey).isRedcornerExist(colName, index) != b) {
			if (b) {
				LogImpl.getInstance().error("检查规则不通过红色角标存在==============================检查失败。");
				return;
			}
			LogImpl.getInstance().error("检查规则通过红色角标不存在==================================检查失败。");
		}
	}

	/**
	 * 行检查规则校验
	 * 
	 * @param gridKey
	 *            表格的key
	 * @param index
	 *            行序号
	 * @param b
	 *            true,预期检查规则通过；false,预期检查规则不通过
	 */
	public static void rowUICheck(String gridKey, int index, Boolean b) {
		if (Grid.element(gridKey).isRedcornerExist(index) == b) {
			if (b == true) {
				LogImpl.getInstance().info("行检查规则不通过红色角标存在===========================检查成功。");
				return;
			}
			LogImpl.getInstance().info("行检查规则通过红色角标不存在===============================检查成功。");
			return;
		}
		if (Grid.element(gridKey).isRedcornerExist(index) != b) {
			if (b) {
				LogImpl.getInstance().error("行检查规则不通过红色角标存在==============================检查失败。");
				return;
			}
			LogImpl.getInstance().error("行检查规则通过红色角标不存在==================================检查失败。");
		}
	}

	/**
	 * 表格或者listview的行勾选、未勾选验证
	 * 
	 * @param table
	 *            表格对象、视图列表对象
	 * @param b
	 *            true,预期勾选;false,预期不勾选
	 * @param index
	 *            行序号数组，如1,2,4 或者 5,6,7
	 */
	public static void checkRowSelected(AbstractTableComponent table, String colName, Boolean b, int... index) {
		if (table.isRowSelect(colName, index) == b) {
			if (b) {
				LogImpl.getInstance().info("当前页勾选======检查成功");
			} else {
				LogImpl.getInstance().info("当前页未勾选======检查成功");
			}
		} else {
			if (b) {
				LogImpl.getInstance().error("当前页勾选======检查失败");
			} else {
				LogImpl.getInstance().error("当前页未勾选=======检查失败");
			}
		}

	}

	/**
	 * 表格或者listview的全选、全不选验证
	 * 
	 * @param table
	 *            表格对象、视图列表对象
	 * @param b
	 *            true,预期全选;false,预期全不选
	 */
	public static void checkAllSelected(AbstractTableComponent table, String colName, Boolean b) {
		if (table.isAllSelected(colName) == b) {
			if (b == true) {
				LogImpl.getInstance().info("当前页全选======检查成功");
				return;
			}
			LogImpl.getInstance().info("当前页全不选======检查成功");
			return;
		}
		if (b == true) {
			LogImpl.getInstance().error("当前页全选======检查失败。");
			return;
		}
		LogImpl.getInstance().error("当前页全不选=======检查失败");
	}

	/**
	 * 表格或者listview的当前页号 验证
	 * 
	 * @param table
	 *            表格对象、视图列表对象
	 * @param pageNum
	 *            预期的当前页号
	 */
	public static void checkCurrentPageNum(AbstractTableComponent table, int pageNum) {
		if (table.getCurrentPageNum() == pageNum) {
			LogImpl.getInstance().info("当前页：" + pageNum + "======检查成功");
			return;
		}
		LogImpl.getInstance().error("当前页：" + pageNum + "======检查失败");
	}

	/**
	 * 表格或者listview的总页数 验证
	 * 
	 * @param table
	 *            表格对象、视图列表对象
	 * @param pageCount
	 *            预期的总页数
	 */
	public static void checkPageCount(AbstractTableComponent table, int pageCount) {
		if (table.getPageCount() == pageCount) {
			LogImpl.getInstance().info("总页数：" + pageCount + "=======检查成功");
			return;
		}
		LogImpl.getInstance().error("总页数：" + pageCount + "=======检查失败");
	}

	/**
	 * 表格或者listview的总行数 验证
	 * 
	 * @param table
	 *            表格对象、视图列表对象
	 * @param rowCount
	 *            预期的总行数
	 */
	public static void checkRowCount(AbstractTableComponent table, int rowCount, String msg) {
		if (table.getRowCount() == rowCount) {
			LogImpl.getInstance().info(msg + "======总行数：" + rowCount + "=======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "======总行数：" + rowCount + "=======检查失败");
	}

	/**
	 * 校验表格字典各节点是否正确
	 * 
	 * @param result
	 *            实际结果
	 * @param expResult
	 *            预期结果
	 * @param msg
	 *            用例编号
	 */
	public static void checkGridDictItemFiled(List<BaseGridDictItem> result, List<BaseGridDictItem> expResult,
			String msg) {

		if (result == null) {
			return;
		}

		if (expResult.size() != result.size()) {
			LogImpl.getInstance().error(msg + "检查该节点下子节点是否一致=====================================数据个数错误");

		}

		if (expResult.size() == 0) {
			LogImpl.getInstance().info(msg + "检查该节点下无子节点======检查成功");
		}

		for (int i = 0; i < expResult.size(); i++) {
			BaseGridDictItem expItem = expResult.get(i);
			BaseGridDictItem item = result.get(i);
			if (item != null) {
				if (item.getCaption().equals(expItem.getCaption())) {
					LogImpl.getInstance().info(msg + "节点名称正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点名称错误============================检查失败 预期结果为:"
							+ expItem.getCaption() + "	  实际结果为:" + item.getCaption());
				}
				if (item.getEnable() == expItem.getEnable()) {
					LogImpl.getInstance().info(msg + "节点状态正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点状态错误============================检查失败 预期结果为:"
							+ expItem.getEnable() + "	  实际结果为:" + item.getEnable());
				}
				if (item.getNodeType() == expItem.getNodeType()) {
					LogImpl.getInstance().info(msg + "节点类型正确======检查成功");
				} else {
					LogImpl.getInstance().error(msg + "节点类型错误============================检查失败 预期结果为:"
							+ expItem.getNodeType() + "	  实际结果为:" + item.getNodeType());
				}
				// 不检测单选
				if (expItem.getChkState() >= 0) {
					if (item.getChkState() == expItem.getChkState()) {
						LogImpl.getInstance().info(msg + "节点勾选状态正确======检查成功");
					} else {
						LogImpl.getInstance().error(msg + "节点勾选状态错误=====================检查失败 预期结果为:"
								+ expItem.getChkState() + "	  实际结果为:" + item.getChkState());
					}
				}
			} else {
				LogImpl.getInstance().error(msg + "========================================缺少数据" + item.toString());
			}
		}
	}

	public static void checkGridDictItemDisableSelect(String gridKey, String colName, Integer index, String itemCode,
			boolean b, String msg) {
		boolean ret = Grid.element(gridKey).celDictClick(colName, index).itemSelect(itemCode);
		if (ret == b) {
			LogImpl.getInstance().info(msg + "节点可不选择========检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "节点可选择============================检查失败 预期结果为:" + b + "	实际结果为:" + ret);
		return;
	}

	/**
	 * 检查单元格字典根节点
	 * 
	 * @param dictKey
	 *            字典的key
	 * @param value
	 *            预期的根节点名称
	 * @param msg
	 *            用例编号
	 */
	public static void checkGridDictRootNode(String gridKey, String itemName, String msg) {
		String ret = Grid.element(gridKey).getDictRootNode();
		if (ret.trim().equals(itemName.trim())) {
			LogImpl.getInstance().info(msg + "根节点：" + itemName + "根节点正确======检查成功。");
			return;
		}
		LogImpl.getInstance()
				.error(msg + "预期结果：" + itemName + "	  实际结果为:" + ret + "根节点错误====================================检查失败。");
	}

	/**
	 * 检查多选字典根节点勾选状态
	 * 
	 * @param dictKey
	 *            字典的key
	 * @param s
	 *            预期的根节点勾选状态
	 * @param msg
	 *            用例编号
	 */
	public static void checkGridDictRootState(String gridKey, String text, String msg) {
		String ret = Grid.element(gridKey).getDictRootChkstate();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "根节点：" + text + "根节点勾选状态======检查成功。");
			return;
		}
		LogImpl.getInstance()
				.error(msg + "===========================================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 检查checkBox是否勾选
	 * 
	 * @param gridKey
	 *            表格key
	 * @param b
	 *            勾选状态
	 * @param msg
	 *            用例编号
	 */
	public static void checkGridCheckBoxChecked(String gridKey, String colName, int index, Boolean b, String msg) {
		if (Grid.element(gridKey).isCelCheckBoxChecked(colName, index) == (b)) {
			LogImpl.getInstance().info(msg + "根节点：" + b + "根节点勾选状态======检查成功。");
			return;
		}
		LogImpl.getInstance().error(msg + "===========================================检查失败 预期结果为:" + b + "	实际结果为:"
				+ Grid.element(gridKey).isCelCheckBoxChecked(colName, index));
	}

	/**
	 * 校验下拉项值
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            下拉取值
	 * @param msg
	 *            测试用例编号
	 */
	public static void checkGridComboBoxItemsValue(String gridKey, String colName, int index, String text, String msg) {
		String ret = Grid.element(gridKey).celComboClick(colName, index).getGridComboBoxItems();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "下拉项正确======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "===========================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 校验自动匹配下拉项值
	 * 
	 * @param atc
	 *            对象
	 * @param text
	 *            下拉取值
	 * @param msg
	 *            测试用例编号
	 */
	public static void checkGridComboBoxAutoItemsValue(String gridKey, String text, String msg) {
		String ret = Grid.element(gridKey).getGridComboAutoItems();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "下拉项正确======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "===========================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 校验表格多选下拉框中勾选节点状态
	 * 
	 * @param gridKey
	 *            表格key
	 * @param b
	 *            取值
	 * @param msg
	 *            用例编号
	 */
	public static void checkGridCheckListItemChecked(String gridKey, String[] items, boolean b, String msg) {
		for (int i = 0; i < items.length; i++) {
			boolean ret = Grid.element(gridKey).gridCheckListItemChecked(items[i]);
			if (ret == b) {
				LogImpl.getInstance().info(msg + "节点显示选中========检查成功");
			} else {
				LogImpl.getInstance()
						.error(msg + "节点显示未选中============================检查失败 预期结果为:" + b + "	实际结果为:" + ret);
			}
		}
	}

	/**
	 * 校验多选下拉项值
	 * 
	 * @param gridKey
	 *            表格对象
	 * @param text
	 *            下拉取值
	 * @param msg
	 *            用例编号
	 */
	public static void checkGridCheckListItemsValue(String gridKey, String colName, int index, String text,
			String msg) {
		String ret = Grid.element(gridKey).celCheckListClick(colName, index).getGridCheckListItems();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "下拉项正确======检查成功");
			return;
		}
		LogImpl.getInstance().error(msg + "===========================检查失败 预期结果为:" + text + "	实际结果为:" + ret);
	}

	/**
	 * 校验表格列名是否正确
	 * 
	 * @param gridKey
	 * @param value
	 */
	public static void checkGridColNames(String gridKey, String value) {
		String ret = Grid.element(gridKey).getGridColName();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("各列名正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("各列名不正确===========================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkGridTitleName(String gridKey, String colName) {
		boolean flag = Grid.element(gridKey).checkColTitleName(colName);
		if (flag) {
			LogImpl.getInstance().info("列标题正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("列标题不正确===========================检查失败 预期结果为:");
	}

	/**
	 * 检查表格列单元格背景色
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkCelBackColor(String gridKey, String colName, int index, String value) {
		String ret = Grid.element(gridKey).getColBackColor(colName, index);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("单元格列背景色正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("单元格列背景色不正确==========================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查表格行单元格背景色
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkRowBackColor(String gridKey, String colName, int index, String value) {
		String ret = Grid.element(gridKey).getRowBackColor(colName, index);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("单元格行背景色正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("单元格行背景色不正确==========================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查表格单元格前景色
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkCelForeColor(String gridKey, String colName, int index, String value) {
		String ret = Grid.element(gridKey).getForeColor(colName, index);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("单元格前景色正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("单元格前景色不正确==========================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查单元格左右水平居中平
	 * 
	 * @param atc
	 *            头控件（带编辑框）对象
	 * @param text
	 *            预期的值
	 */
	public static void checkGridHalign(String gridKey, String colName, int index, String value) {
		String ret = Grid.element(gridKey).getHalign(colName, index);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("单元格左右水平居中对齐正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("单元格左右水平居中对齐不正确=============================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkGridColOrder(String gridKey, String colName, String value) {
		String ret = Grid.element(gridKey).getGridColOrder(colName);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该列数据升降序图标正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该列数据升降序图标不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkGridColValue(String gridKey, String colName, String value) {
		String ret = Grid.element(gridKey).getGridColValue(colName);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该列数据顺序正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("该列数据顺序不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkGridRowValue(String gridKey, int index, String value) {
		String ret = Grid.element(gridKey).getGridRowValue(index);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该行数据顺序正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("该行数据顺序不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 表格专用
	 * 
	 * @param gridKey
	 * @param index
	 * @param value
	 */
	public static void checkBaseGridRowValue(String gridKey, int index, String value) {
		String ret = Grid.element(gridKey).getBaseGridRowValue(index);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该行数据顺序正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("该行数据顺序不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkChangeColGridRowValue(String gridKey, int index, String value) {
		String ret = Grid.element(gridKey).getChangeColGridRowValue(index);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该行数据顺序正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("该行数据顺序不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkGridExpColNum(String gridKey, String colName, int index) {
		int ret = Grid.element(gridKey).getGridExpColNum(colName);
		if (ret == index) {
			LogImpl.getInstance().info("该列扩展个数正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("该列扩展个数不正确=================================检查失败 预期结果为:" + index + "	实际结果为:" + ret);
	}

	/**
	 * 检查带扩展列表格扩展列名是否正确
	 * 
	 * @param gridKey
	 * @param value
	 */
	public static void checkGridExpColName(String gridKey, String value) {
		String ret = Grid.element(gridKey).getGridExpColName();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该列扩展列名称正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该列扩展列名称不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查带有嵌套扩展列表格第一层扩展列名是否正确
	 * 
	 * @param gridKey
	 * @param value
	 */
	public static void checkGridNestExpColTitle1(String gridKey, String value) {
		String ret = Grid.element(gridKey).getGridNestExpColTitle1();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该表格各列名称正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该表格各列名称不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查带有嵌套扩展列表格第二层嵌套扩展列名是否正确
	 * 
	 * @param gridKey
	 * @param value
	 */
	public static void checkGridNestExpColTitle2(String gridKey, String value) {
		String ret = Grid.element(gridKey).getGridNestExpColTitle2();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该表格各列名称正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该表格各列名称不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 校验带扩展列表格标题列列名是否正确
	 * 
	 * @param gridKey
	 * @param value
	 */
	public static void checkGridExpColTitle(String gridKey, String value) {
		String ret = Grid.element(gridKey).getGridExpColTitle();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该表格各列名称正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该表格各列名称不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 校验改变列名表格标题列列名是否正确
	 * 
	 * @param gridKey
	 * @param value
	 */
	public static void checkChangeColGridColTitle(String gridKey, String value) {
		String ret = Grid.element(gridKey).getChangeColGridColName();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该表格各列名称正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该表格各列名称不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkGridExpColValue(String gridKey, String colName, String value) {
		String ret = Grid.element(gridKey).getGridExpColValue(colName);
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该列数据顺序正确======检查成功");
			return;
		}
		LogImpl.getInstance().error("该列数据顺序不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void allUiCheck(String gridKey, Boolean b) {
		if (Grid.element(gridKey).isAllUiCheck() == b) {
			if (b == true) {
				LogImpl.getInstance().info("全局检查显示======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info("全局检查不显示======检查成功。");
				return;
			}
		}
		if (Grid.element(gridKey).isAllUiCheck() != b) {
			if (b == true) {
				LogImpl.getInstance().error("全局检查显示==========================检查失败。");
				return;
			} else {
				LogImpl.getInstance().error("全局检查不显示=========================检查失败。");
			}
		}
	}

	public static void checkAllErrorInfo(String gridKey, String value) {
		String ret = Grid.element(gridKey).getAllErrorInfo();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("全局检查错误描述正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("全局检查错误描述不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查带有扩展列表格的扩展标题列名是否显示
	 * 
	 * @param gridKey
	 * @param b
	 */
	public static void checkExpColNoTitle(String gridKey, Boolean b) {
		if (Grid.element(gridKey).expColNoTitle() == b) {
			if (b == true) {
				LogImpl.getInstance().info("扩展列标题无显示======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info("扩展列标题显示======检查成功。");
				return;
			}
		}
		if (Grid.element(gridKey).expColNoTitle() != b) {
			if (b == true) {
				LogImpl.getInstance().error("扩展列标题无显示==========================检查失败。");
				return;
			} else {
				LogImpl.getInstance().error("扩展列标题显示=========================检查失败。");
				return;
			}
		}
	}

	/**
	 * 检查表格单元格是否可编辑
	 * 
	 * @param gridKey
	 *            表格Key
	 * @param colName
	 *            列名
	 * @param index
	 *            行数
	 * @param b
	 *            true,可编辑；false，不可编辑
	 */
	public static void checkCellEnabled(String gridKey, String colName, int index, Boolean b) {
		if (Grid.element(gridKey).isEnabled(colName, index) == b) {
			if (b == true) {
				LogImpl.getInstance().info("单元格可用======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info("单元格不可用=======检查成功。");
				return;
			}

		}
		if (Grid.element(gridKey).isEnabled(colName, index) != b) {
			if (b == true) {
				LogImpl.getInstance().error("单元格不可用=========================检查失败。");
				return;
			} else {
				LogImpl.getInstance().error("单元格可用=============================检查失败。");
				return;
			}
		}
	}

	/**
	 * 检查表格的可见性
	 * 
	 * @param gridKey
	 * @param b
	 */
	public static void checkGridDisplayed(String gridKey, Boolean b) {
		BaseGrid grid = null;
		try {
			grid = Grid.element(gridKey);
		} catch (NoSuchElementException e) {

		}

		if (grid == null) {
			if (b) {
				LogImpl.getInstance().info("表格显示");

			} else {
				LogImpl.getInstance().info("表格不显示======检查成功");
				return;
			}
		}

		if (grid.isGridDisplayed() == b) {
			if (b) {
				LogImpl.getInstance().info("表格显示======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info("表格不显示======检查成功。");
				return;
			}
		}

		if (grid.isGridDisplayed() != b) {
			LogImpl.getInstance().error("表格不显示======检查失败。");
			return;
		}
		LogImpl.getInstance().error("表格显示======检查失败。");

	}

	public static void checkColDisplayed(String gridKey, String colName, Boolean b) {
		if (Grid.element(gridKey).iscolDisplayed(colName) == b) {
			if (b == false) {
				LogImpl.getInstance().info("单元格不可见======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info("单元格可见======检查成功。");
				return;
			}

		}
		if (Grid.element(gridKey).iscolDisplayed(colName) != b) {
			if (b == true) {
				LogImpl.getInstance().error("单元格可见=========================检查失败。");
				return;
			} else {
				LogImpl.getInstance().error("单元格不可见=========================检查失败。");
				return;
			}
		}
	}
	/**
	 * 检查表格操作按钮可见性
	 * @param gridKey
	 * @param optName(添加新记录、删除所选记录、上移数据行、下移数据行)
	 * @param b
	 */
	public static void checkGirdOptDisplayed(String gridKey, String optName, Boolean b) {
		if (Grid.element(gridKey).isGridOptDisplayed(optName) == b) {
			if (b == false) {
				LogImpl.getInstance().info("表格操作按钮不可见======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info("表格操作按钮可见======检查成功。");
				return;
			}

		}
		if (Grid.element(gridKey).isGridOptDisplayed(optName) != b) {
			if (b == true) {
				LogImpl.getInstance().error("表格操作按钮可见=========================检查失败。");
				return;
			} else {
				LogImpl.getInstance().error("表格操作按钮不可见=========================检查失败。");
				return;
			}
		}
	}

	/**
	 * 检查表格单元格是否可编辑
	 * 
	 * @param gridKey
	 *            表格Key
	 * @param b
	 *            true,可编辑；false，不可编辑
	 */
	public static void checkGridEnabled(String gridKey, Boolean b) {
		if (Grid.element(gridKey).isGridEnabled() == b) {
			if (b == true) {
				LogImpl.getInstance().info("表格可编辑======检查成功。");
				return;
			} else {
				LogImpl.getInstance().info("表格不可编辑=======检查成功。");
				return;
			}

		}
		if (Grid.element(gridKey).isGridEnabled() != b) {
			if (b == true) {
				LogImpl.getInstance().error("表格不可编辑=========================检查失败。");
				return;
			} else {
				LogImpl.getInstance().error("表格可编辑=============================检查失败。");
				return;
			}
		}
	}

	public static void checkGridPagesNum(String gridKey, String value) {
		String ret = Grid.element(gridKey).getPagesNum();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该表格当前页码显示正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该表格当前页码显示不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	public static void checkCellTreeIconExpand(String gridKey, String colName, int index, Boolean b) {
		if (Grid.element(gridKey).isCellTreeIconExpand(colName, index) == b) {
			if (b == true) {
				LogImpl.getInstance().info("树形单元格已展开===========================检查成功。");
				return;
			}
			LogImpl.getInstance().info("树形单元格未展开===============================检查成功。");
			return;
		}
		if (Grid.element(gridKey).isCellTreeIconExpand(colName, index) != b) {
			if (b) {
				LogImpl.getInstance().error("树形单元格已展开==============================检查失败。");
				return;
			}
			LogImpl.getInstance().error("树形单元格未展开==================================检查失败。");
		}
	}

	public static void checkPagerControl(String gridKey, String value) {
		String ret = Grid.element(gridKey).getPagerControl();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该表格下方控件显示正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该表格下方控件显示不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查带隐藏列表格扩展列名是否正确
	 * 
	 * @param gridKey
	 * @param value
	 */
	public static void checkGridHidColName(String gridKey, String value) {
		String ret = Grid.element(gridKey).getGridHidColName();
		if (ret.equals(value)) {
			LogImpl.getInstance().info("该列隐藏列名称正确======检查成功");
			return;
		}
		LogImpl.getInstance()
				.error("该列隐藏列名称不正确=================================检查失败 预期结果为:" + value + "	实际结果为:" + ret);
	}

	/**
	 * 检查空值提示
	 * 
	 * @param gridkey
	 * @param colName
	 * @param text
	 * @param msg
	 */
	public static void checkPromptText(String gridkey, String colName, String text, String msg) {
		String ret = Grid.element(gridkey).cellDbClick(colName, 1).getPromptText();
		if (ret.equals(text)) {
			LogImpl.getInstance().info(msg + "======检查成功");
		} else {
			LogImpl.getInstance().error(msg + "======检查失败 预期结果为:" + text + "	实际结果为:" + ret);
		}

	}

}
