package com.bokesoft.yes.autotest.util;

public class PathUtil {
	public static String getAppPath(Class<?> cls) {
		ClassLoader loader = cls.getClassLoader();

		String clsName = cls.getName() + ".class";
		Package pack = cls.getPackage();
		String path = "";

		if (pack != null) {
			String packName = pack.getName();
			clsName = clsName.substring(packName.length() + 1);

			if (packName.indexOf(".") < 0)
				path = packName + "/";
			else {
				int start = 0, end = 0;
				end = packName.indexOf(".");
				while (end != -1) {
					path = path + packName.substring(start, end) + "/";
					start = end + 1;
					end = packName.indexOf(".", start);
				}
				path = path + packName.substring(start) + "/";
			}
		}

		java.net.URL url = loader.getResource(path + clsName);
		String realPath = url.getPath();
		int pos = realPath.indexOf("file:");
		if (pos > -1)
			realPath = realPath.substring(pos + 5);
		pos = realPath.indexOf(path + clsName);
		realPath = realPath.substring(0, pos - 1);
		if (realPath.endsWith("!"))
			realPath = realPath.substring(0, realPath.lastIndexOf("/"));
		try {
			realPath = java.net.URLDecoder.decode(realPath, "utf-8");
		} catch (Exception e) {
			realPath = "";
		}
		String os = System.getProperty("os.name");
		// Windows
		if (os.length() > 6 && os.substring(0, 7).equalsIgnoreCase("WINDOWS")) {
			if (!realPath.isEmpty() && realPath.charAt(0) == '/') {
				realPath = realPath.substring(1, realPath.length());
				realPath += "/";
			}
		} else {
			if (realPath.isEmpty() || realPath.charAt(0) == '/') {
				realPath += "/";
			}
		}

		return realPath;
	}
}
