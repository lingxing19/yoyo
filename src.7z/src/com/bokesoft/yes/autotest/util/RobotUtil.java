package com.bokesoft.yes.autotest.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.Keys;

public class RobotUtil {
	private static Robot robot = null;
	static {
		try {
			robot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 模拟键盘crtl+v的操作
	 * 
	 * @param string
	 *            需要粘贴的内容
	 */
	public static void paste(String string) {
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	/**
	 * 模拟Tab键
	 */
	public static void pressTabKey() {

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
	}

	public static void pressSpace() {
		robot.keyPress(KeyEvent.VK_SPACE);
		robot.keyRelease(KeyEvent.VK_SPACE);
	}

	/**
	 * 模拟Enter键
	 */
	public static void pressEnterKey() {
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
	}

	/**
	 * 模拟Backspace键
	 */
	public static void pressBackspaceKey() {

		robot.keyPress(KeyEvent.VK_BACK_SPACE);
		robot.keyRelease(KeyEvent.VK_BACK_SPACE);
		robot.delay(500);
	}

	/**
	 * 模拟Delete键
	 */
	public static void pressDeleteKey() {

		robot.keyPress(KeyEvent.VK_DELETE);
		robot.keyRelease(KeyEvent.VK_DELETE);
		robot.delay(500);
	}

	/**
	 * 模拟ctrl+c
	 */
	public static void pressCtrlC() {

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_C);
		robot.keyRelease(KeyEvent.VK_C);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	/**
	 * 模拟ctrl+v
	 */
	public static void pressCtrlV() {

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	/**
	 * 模拟ctrl+A
	 */
	public static void pressCtrlA() {

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	/**
	 * 模拟keyPress
	 */
	public static void press(char c) {
		System.out.println(c);

		int key = KeyEvent.getExtendedKeyCodeForChar(c);
		robot.keyPress(key);
		robot.keyRelease(key);
	}

	public static void press(int key) {
		robot.keyPress(key);
		robot.keyRelease(key);
	}
	
	public static void press2(int key) {
		robot.keyPress(key);
//		robot.keyRelease(key);
	}
	
	public static void release2(int key) {
//		robot.keyPress(key);
		robot.keyRelease(key);
	}
	/**
	 * 模拟左方向键
	 */
	public static void pressLeft() {
		robot.keyPress(KeyEvent.VK_LEFT);
		robot.keyRelease(KeyEvent.VK_LEFT);
		robot.delay(100);
	}

	/**
	 * 模拟右方向键
	 */
	public static void pressRight() {
		robot.keyPress(KeyEvent.VK_RIGHT);
		robot.keyRelease(KeyEvent.VK_RIGHT);
		robot.delay(100);
	}
	
	public static void press(int... key) {
		for(int i = 0 ; i < key.length; i ++){
			robot.keyPress(key[i]);
		}
		
		for(int i = key.length - 1 ; i >= 0; i-- ){
			robot.keyRelease(key[i]);
		}
		robot.delay(100);
	}
	
	public static void pressShift() {
		robot.keyPress(KeyEvent.VK_SHIFT);		
	}
	
	public static void releaseShift(){
		robot.keyRelease(KeyEvent.VK_SHIFT);
		robot.delay(100);
	}
}
