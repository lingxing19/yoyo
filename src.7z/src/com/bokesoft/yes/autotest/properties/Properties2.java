package com.bokesoft.yes.autotest.properties;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public class Properties2 extends Properties {
	// 保存读取的一行脚本
	private List<Object> keys = new ArrayList<>();

	public Object put(Object key, Object value) {
		keys.add(key);
		return super.put(key, value);
	}

	public List<Object> getKeys() {
		return this.keys;
	}

	// private LinkedHashSet<Object> keys = new LinkedHashSet<Object>();
	//
	// public Enumeration<Object> keys(){
	// return Collections.<Object> enumeration(keys);
	// }
	//
	// public Object put(Object key, Object value){
	// keys.add(key);
	// return super.put(key, value);
	// }
	//
	// public Set<Object> keySet(){
	// return keys;
	// }
	//
	// public Set<String> stringPropertyNames(){
	// Set<String> set = new LinkedHashSet<String>();
	//
	// for(Object key : keys){
	// set.add((String)key);
	// }
	// return set;
	// }
}
