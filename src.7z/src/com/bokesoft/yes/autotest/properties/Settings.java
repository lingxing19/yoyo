package com.bokesoft.yes.autotest.properties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

/**
 * 定义测试的浏览器，及相关组建， 定义测试的起始页面和登录的相关信息
 * 
 * @author zhufw
 *
 */
public class Settings {
	final public static String TYPE = "type";

	final public static String URL = "url";

	final public static String LOG_HOME = "log_home";

	final public static String WEBDRIVER_CHROME_DRIVER = "webdriver.chrome.driver";

	final public static String WEBDRIVER_FIREFOX_DRIVER = "webdriver.firefox.bin";

	final public static String WEBDRIVER_IE_DRIVER = "webdriver.ie.driver";

	final private static String fileName = "settings";

	private PropertyResourceBundle bundle = null;

	private static Settings INSTANCE = null;

	private Settings() {
		try {
			bundle = (PropertyResourceBundle) ResourceBundle.getBundle(fileName);
		} catch (Throwable e) {
			throw new RuntimeException("settings.properties文件读取失败。");
		}
	}

	public String getProperty(String key) {
		String sRet = "";
		try {
			sRet = bundle.getString(key);
			if (sRet != null && !sRet.isEmpty()) {
				sRet = sRet.trim();
			}
		} catch (Throwable e) {
			throw new RuntimeException("settings.properties文件读取[" + key + "]失败。");
		}

		return sRet;
	}

	public static Settings getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new Settings();
		}
		return INSTANCE;
	}

	public String getType() {
		return getProperty(TYPE);
	}

	public String getURL() {
		return getProperty(URL);
	}

	/**
	 * 获取脚本集合
	 * 
	 */
	public List<String> getScriptList() {
		String path = getProperty("script.path");
		List<String> list = new ArrayList<String>();

		InputStreamReader read = null;
		BufferedReader br = null;
		try {
			File f = new File(path);
			if (f.isFile() && f.exists()) {
				read = new InputStreamReader(new FileInputStream(f));
				Properties2 p = new Properties2();
				p.load(read);
				for (Object s : p.getKeys()) {
					list.add((String) s);
				}
			}

		} catch (Throwable e) {
			throw new RuntimeException(path + "文件读取失败。");
		} finally {
			if (read != null) {
				try {
					read.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public String getLogHome() {
		return getProperty(LOG_HOME);
	}

	public static void main(String[] args) throws Throwable {
		File f = new File("D:\\eclipse-java-neon-2-win32-x86_64\\workspace\\AutoTest\\src\\scriptlist.properties");
		InputStreamReader read = new InputStreamReader(new FileInputStream(f));
		Properties2 p = new Properties2();
		p.load(read);

		for (Object s : p.keySet()) {
			System.out.println(s);
		}

	}
}
