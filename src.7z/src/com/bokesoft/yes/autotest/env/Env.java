package com.bokesoft.yes.autotest.env;

public class Env {
	private static Env INSTANCE = null;

	// 浏览器类型
	private int type = 0;

	private Env() {

	}

	public static Env getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new Env();
		}
		return INSTANCE;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getType() {
		return this.type;
	}
}
