package com.bokesoft.yes.tools;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.bokesoft.yes.autotest.properties.Settings;
import com.bokesoft.yes.common.util.StringUtil;
import com.bokesoft.yes.tools.json.JSONUtil;
import com.bokesoft.yes.tools.json.YesJSONUtil;
import com.bokesoft.yes.tools.zip.GZIPTools;
import com.bokesoft.yes.view.proxy.Request;
import com.bokesoft.yigo.common.exception.GeneralException;
import com.bokesoft.yigo.struct.datatable.DataTable;
import com.bokesoft.yigo.struct.env.Env;

public class RemoteServiceProxy {

	protected WebDriver driver = null;

	private Env env = null;

	public RemoteServiceProxy(WebDriver d) {
		driver = d;

		Set<org.openqa.selenium.Cookie> set = driver.manage().getCookies();
		env = new Env();
		env.setMode(1);
		for (org.openqa.selenium.Cookie cookie : set) {
			if (cookie.getName().equalsIgnoreCase("ClientID")) {
				//env.setClientID(cookie.getValue());
				ArrayList<String> list = new ArrayList<String>();
				list.add("clientID=" + cookie.getValue() + "; HttpOnly");
				env.setCookies(list);
			}
			//
			// System.out.println("Name :"+cookie.getName());
			// System.out.println("Value :"+cookie.getValue());
		}

	}

	/**
	 * 鏌ヨ鏁版嵁搴�
	 * 
	 * @param sql
	 * @param o
	 * @return
	 */
	public DataTable dbquery(String sql, Object... objects) {
		String url = Settings.getInstance().getURL() + "/servlet";

		Request request = new Request(url, env);
		List<Object> args = new ArrayList<Object>();

		if (objects != null) {
			for (Object o : objects) {
				args.add(o);
			}
		}

		JSONArray array;
		try {
			array = YesJSONUtil.toJSONArray(args);

			return ((DataTable) request.doRequest(new Object[][] { { "service", "DBQuery" },
					new Object[] { "cmd", "DBQuery" }, new Object[] { "sql", sql }, new Object[] { "paras", array } }));
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	public Object doRequest(String urlString, Object[][] paras) throws Throwable {
		HttpURLConnection connection = null;
		Object result = null;
		OutputStream out = null;
		try {
			String tmpResult;
			URL url = new URL(urlString);
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("X-Requested-With", "YesRequest");
			connection.setRequestProperty("X-YES-Version", "YES1");
			connection.setRequestMethod("POST");
			connection.setRequestProperty("User-Agent", "Profile/MIDP-1.0 Configuration/CLDC-1.0");

			connection.setRequestProperty("Content-type", "application/x-www-form-urlencoded;charset=UTF-8");

			connection.setRequestProperty("accept-encoding", "gzip");
			// connection.setRequestProperty("ticketid",
			// TypeConvertor.toString(Integer.valueOf(this.env.getTicketID())));

			connection.setDoOutput(true);
			connection.setDoInput(true);

			StringBuilder send = new StringBuilder();

			int length = paras.length;
			packageDefault(send, this.env);
			if (length > 0)
				send.append('&');

			String s = compressParas(paras);
			if ((s != null) && (!(s.isEmpty()))) {
				send.append(s);
			}

			String sendString = send.toString();
			byte[] bytes = sendString.getBytes();

			connection.setRequestProperty("Content-length", Integer.toString(bytes.length));

			out = connection.getOutputStream();
			out.write(bytes);

			out.flush();

			int code = connection.getResponseCode();

			if (code == 200) {
				tmpResult = null;

				Map headerFields = connection.getHeaderFields();
				if (headerFields != null) {
					Iterator it = headerFields.entrySet().iterator();
					Map.Entry entry = null;
					while (it.hasNext()) {
						entry = (Map.Entry) it.next();
						String key = (String) entry.getKey();
						if ("Set-Cookie".equals(key)) {
							List list = (List) entry.getValue();
							this.env.setCookies(list);
						}
					}
				}

				InputStream in = connection.getInputStream();

				String contentEconding = connection.getContentEncoding();

				if ((contentEconding != null) && (contentEconding.indexOf("gzip") != -1)) {
					tmpResult = GZIPTools.decompress(in, "UTF-8");
				} else {
					ByteArrayOutputStream tmpByteArrayOut = new ByteArrayOutputStream();
					byte[] buffer = new byte[1024];
					int size = in.read(buffer);
					while (size > 0) {
						tmpByteArrayOut.write(buffer, 0, size);
						size = in.read(buffer);
					}
					tmpResult = tmpByteArrayOut.toString();
					tmpByteArrayOut.close();
					try {
						if (in != null)
							in.close();
					} catch (Throwable localThrowable1) {
					}
				}
				if ((tmpResult != null) && (!(tmpResult.isEmpty()))) {
					JSONObject json = new JSONObject(tmpResult);

					// if ((json.has("data")) && (!(json.isNull("data")))) {
					// result = json.get("data");
					// if ((result instanceof JSONObject) &&
					// (!(json.isNull("type")))) {
					// int type = JavaDataType.parse(json.optString("type"));
					// decodeResult = DataDecoder.decode(type, (JSONObject)
					// result);
					// if (decodeResult != null)
					// result = decodeResult;
					// }
					// }
				}

			} else {
				tmpResult = null;
				InputStream errorStream = connection.getErrorStream();

				String contentEconding = connection.getContentEncoding();
				if ((contentEconding != null) && (contentEconding.indexOf("gzip") != -1)) {
					tmpResult = GZIPTools.decompress(errorStream, "UTF-8");
				} else {
					ByteArrayOutputStream tmpByteArrayOut = new ByteArrayOutputStream();
					byte[] buffer = new byte[1024];
					int size = errorStream.read(buffer);
					while (size > 0) {
						tmpByteArrayOut.write(buffer, 0, size);
						size = errorStream.read(buffer);
					}
					tmpResult = tmpByteArrayOut.toString();
					tmpByteArrayOut.close();
					try {
						if (errorStream != null)
							errorStream.close();
					} catch (Throwable decodeResult) {
					}
				}

				if ((tmpResult != null) && (!(tmpResult.isEmpty()))) {
					if (JSONUtil.isJSONObject(tmpResult)) {
						JSONObject json = new JSONObject(tmpResult);
						if (json.has("error")) {
							JSONObject errorResult = (JSONObject) json.get("error");
							if (errorResult != null) {
								int error = errorResult.getInt("error_code");
								String message = "";
								if (errorResult.has("error_info"))
									message = errorResult.getString("error_info");

								throw new GeneralException(error, message);
							}
						}
					}
					throw new GeneralException(code, tmpResult);
				}

				String message = connection.getResponseMessage();
				throw new GeneralException(code, message);
			}
		} catch (ConnectException e) {
		} finally {
			try {
				if (out != null)
					out.close();
			} catch (Throwable localThrowable2) {
			}
			if (connection != null) {
				if (connection.getHeaderFields().containsKey("ticketid"))
					this.env.setTicketID(connection.getHeaderFieldInt("ticketid", 0));

				if ((!(StringUtil.isBlankOrNull(this.env.getClientID())))
						&& (connection.getHeaderFields().containsKey("newClientID")))
					this.env.setClientID(connection.getHeaderField("newClientID"));

				connection.disconnect();
			}
		}
		return result;
	}

	private String compressParas(Object[][] paras) throws Throwable {
		String s = null;
		JSONObject json = new JSONObject();
		StringBuffer send = new StringBuffer();
		int length = paras.length;
		for (int i = 0; i < length; ++i) {
			Object[] line = paras[i];
			String key = line[0].toString();

			String value = line[1].toString();

			json.put(key, value);

			send.append(key);
			send.append("=");
			s = URLEncoder.encode(value, "utf-8");
			send.append(s);
			if ((length > 0) && (i != length - 1)) {
				send.append('&');
			}

		}

		return send.toString();
	}

	private int packageDefault(StringBuilder send, Env env) throws Throwable {
		int count = 0;
		String s = null;
		if (env.getClientID() != null) {
			send.append("clientID");
			send.append("=");
			s = URLEncoder.encode(env.getClientID(), "utf-8");
			send.append(s);
			++count;
		}
		Locale locale = Locale.getDefault();
		if (count > 0)
			send.append('&');

		send.append("locale=");
		s = new StringBuilder().append(locale.getLanguage()).append("-").append(locale.getCountry()).toString();
		send.append(URLEncoder.encode(s, "utf-8"));
		++count;

		TimeZone tz = TimeZone.getDefault();
		send.append('&');
		send.append("timezone=");
		s = tz.getID();
		send.append(URLEncoder.encode(s, "utf-8"));
		++count;

		if (env.getTempClientID() != null) {
			send.append('&');
			send.append("tmpclientid=");
			s = env.getTempClientID();
			send.append(URLEncoder.encode(s, "utf-8"));
			++count;
		}

		if (env.getMode() != -1) {
			send.append('&');
			send.append("mode");
			send.append("=");
			s = URLEncoder.encode(String.valueOf(env.getMode()), "utf-8");
			send.append(s);
			++count;
		}

		return count;
	}
}
